			FIND_ROUTE PROJECT

NAME: VAMSEEDHAR REDDY THANDRA
UTAID: 1001968085
PROGRAMMING LANGUAGE:- PYTHON

->The project is about to find the route and distance between any two cities using search algorithm here we have used state space search algorithm.

->The programs performs both informed and uninformed searches depends on the inputs that we give in the compilation.

->Here in this project we have been give by the input file called input.txt file which have the cities and there distance between them this is for uninformed search.

->And h_kassel.txt file will be provided that is the straight line distance from other cities to kassel and this is for informed search. where an most admissible heuristics for the search.

->In this project i have used  A* search for where to find the optimal shortest path between the start node and destination node.

->IN MY PROJECT THE LANGUAGE I USED IS PYTHON FOR COMPILATION PLEASE USE THE PYHTON COMANDS FOR 
EX:-python find_route.py input.txt [city1] [city2]
 
-> save the new test file in .py file in the same folder