				MAXCONNECT4 GAME

NAME: VAMSEEDHAR REDDY THANDRA
UTAID: 1001968085
PROGRAMMING LANGUAGE:- PYHTON

-> This is a game playing algorithm using minmax search strategy between two
players where player 1 will be red and player 2 will be green the board will 
give the count that how many 4 rows does my player will have

-> Here as given i have shown two play modes one will be interactive mode where 
the players will play until the board is full and one will be shown as winner
 as player A is winner. Here in first if the computer plays at some depth level
then it pops'up to your chance this continues till the board fills with balls.

->And the one-move mode is to make the program easy to compete and communicate 
the moves using text file the text file i used here are " red_next.txt" and 
"green_next.txt".

->In this project i have used depth-limited alpha-beta pruning algorithm.


THE COMMANDS THAT ARE TO BE USED WHILE COMPILATION:-

  FOR INTERACTIVE MODE
-> python maxconnect4.py interactive [input file] [computer/human file] depth
  FOR ONE-MOVE MODE 
-> python maxconnect4.py one-move red_next.txt green_next.txt depth

  
THANKYOU!!