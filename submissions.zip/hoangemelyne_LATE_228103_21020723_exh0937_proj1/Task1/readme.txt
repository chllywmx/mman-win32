Emelyne Hoang
1001900937
Python 3.7.13 (Compatible with Omega)

All code was written and run using Google Colab.


Code structure
The code is blocked into 2 main parts: UCS(graph, origin, destination, heuristics) and main(argv), from top to bottom.

The function UCS() contains the main code used to run uniform cost search on the data processed in main(). The code starts by initilizing all values to be used, then loops until the fringe is empty or if its current city is the destination. If closed is empty or if the source/destination combination is not in closed, the current city is expanded and its children are added to the fringe. If the destination city is found, the route is constructed by looking for the current city's origin city in closed, from the start to the end. Since the distances in closed are the total distance and heuristics from the origin to the current city, each distance is reconstructed to only include the distance from city to city, then added together to get the total distance. The number of nodes popped, expanded, and generated, as well as the route and total distance are returned to main().

The main() function checks command-line input for proper formatting before assigning them to their respective variables. The graph/table to be used in UCS() is made using the provided input file, and includes the cities with their source/destination citites switched so that all routes are considered. If a heuristics file is provided, then a dictionary is created using it; otherwise a dictionary is made with all city's heuristic set to 0. The graph, origin and destination city, and heuristics are passed to UCS() to perform the search. The returned values mentioned in the precious paragraph are then stored to variables in main and printed using the appropriate labels.

The program outputs different values for the number of nodes popped, expanded, and generated compared to the provided output; however, when a heuristic file is provided, it does pop, expand, and generate less nodes than uninformed search, and it produces the correct distance and route in both search types.


Code execution
The code can simply be executed using the format:

	python find_route.py [input_filename] [origin_city] [destination_city] [heuristic_filename (optional)]

In Google Colab, this exact line was run in a code cell:

	!python3 "/content/drive/My Drive/Colab Notebooks/find_route.py" input1.txt Bremen Kassel

and

	!python3 "/content/drive/My Drive/Colab Notebooks/find_route.py" input1.txt Bremen Kassel h_kassel.txt

Additionally, the code can be run via the Windows Command Prompt that has been enabled with Python (this can be checked by opening the Command Prompt and entering "python"). Then, the following commands can also be entered:

	python find_route.py input1-1.txt Bremen Kassel

and

	python find_route.py input1-1.txt Bremen Kassel h_kassel.txt
