'''
Emelyne Hoang
1001900937
Programming Mini-Project 1
Task 1
'''

import sys

def UCS(graph, origin, destination, heuristics):
    fringe = [[origin, origin, 0]] # creates fringe with start state
    closed = []
    popped = 0
    expanded = 0
    generated = 1
    route = []
    distance = 0

    while True:
        if len(fringe) == 0: # exit if fringe is empty
            return (popped, expanded, generated, "inf", None)

        fringe.sort(key=lambda x: x[2]) # sort fringe
        city = fringe.pop(0) # pop front of fringe
        popped += 1

        if city[1] == destination: # if destination city is the goal
            route = [city] # add destination city to route
            while route[0][0] != origin: # find route from closed
                for c in closed:
                    if c[1] == route[0][0]:
                        route = [c] + route # add to beginning of route
                        break
            
            for i in range(len(route)): # change from total distance to node-to-node distance
                for g in graph:
                    if route[i][0] == g[0] and route[i][1] == g[1]:
                        route[i] = g
                        distance += g[2] # get distance from found route

            return (popped, expanded, generated, route, distance)

        # expand if closed is empty or if source/destination
        # combination is not in closed (don't want to go backwards)
        if len(closed) == 0 or (city[0:2] not in [cols[0:2] for cols in closed]
           and list(reversed(city[0:2])) not in [cols[0:2] for cols in closed]):
            closed.append(city)
            expanded += 1
            for c in graph: # generate children
                if c[0] == city[1] and c[1] != city[0]:
                    fringe.append([c[0], c[1], c[2] + city[2] + heuristics[c[1]]])
                    generated += 1


def main(argv):
    if len(argv) < 4 or len(argv) > 5: # check arguments
        print('Three command-line arguments are required and one is optional:')
        print('Usage: %s [input_filename] [origin_city] [destination_city]' % argv[0])
        print('or: %s [input_filename] [origin_city] [destination_city] [heuristic_filename]' % argv[0])
        sys.exit(2)
    elif len(argv) == 4:
        (input_filename, origin, destination) = argv[1:4]
    else:
        (input_filename, origin, destination, heuristic_filename) = argv[1:5]
    
    graph = [] # create graph
    with open(input_filename, 'r') as f:
        for line in f:
            if 'END OF INPUT' not in line:
                (loc1, loc2, dist) = line.split()
                graph.append([loc1, loc2, int(dist)])
                graph.append([loc2, loc1, int(dist)]) # add cities in reverse
            else:
                break
    
    if len(argv) == 5: # create heuristics
        heuristics = {}
        with open(heuristic_filename, 'r') as f:
            for line in f:
                if 'END OF INPUT' not in line:
                    (city, heur) = line.split()
                    heuristics[city] = int(heur)
                else:
                    break
    else: # all heuristics equal 0
        heuristics = dict.fromkeys([x for l in [cols[0:2] for cols in graph] for x in l],0)

    # perform UCS
    (popped, expanded, generated, route, distance) = UCS(graph, origin, destination, heuristics)

    # print results
    print("Nodes Popped:", popped)
    print("Nodes Expanded:", expanded)
    print("Nodes Generated:", generated)
    if route is None:
        print("Distance: infinity")
        print("Route:")
        print("None")
    else:
        print("Distance: %.1f km" % float(distance))
        print("Route:")
        for r in route:
            print(r[0] + " to " + r[1] + ", %.1f km" % float(r[2]))


if __name__ == '__main__':
    main(sys.argv)
