'''
Emelyne Hoang
1001900937
Programming Mini-Project 1
Task 2
'''

import math as m
import random

from copy import deepcopy

def miniMax(possibleBoard, maxPlayer, maxPlayerPiece, alpha, beta, depth):
    # random choice if one can't be made
    random.seed()
    choice = random.randrange(0,7)

    # checks board if terminal state or at maximum depth
    possibleBoard.checkPieceCount
    if possibleBoard.pieceCount == 42 or depth == 0:
        return (choice, calculate(possibleBoard.gameBoard, maxPlayerPiece))
    
    # minimax with alpha-beta pruning
    if maxPlayer:
        maxAlpha = -m.inf
        for column in range(7):
            # saving state here instead of another object
            originalBoard = deepcopy(possibleBoard.gameBoard)
            originalTurn = possibleBoard.currentTurn

            if possibleBoard.playPiece(column):
                if possibleBoard.currentTurn == 1:
                    possibleBoard.currentTurn = 2
                else: # possibleBoard.currentTurn == 2
                    possibleBoard.currentTurn == 1

                newAlpha = miniMax(possibleBoard, False, maxPlayerPiece, alpha, beta, depth - 1)[1]
                # reset state
                possibleBoard.gameBoard = originalBoard
                possibleBoard.currentTurn = originalTurn
                possibleBoard.checkPieceCount()

                # alpha part of alpha-beta pruning
                if newAlpha > maxAlpha:
                    maxAlpha = newAlpha
                    choice = column
                alpha = max(alpha, maxAlpha)
                if alpha >= beta:
                    break
        return choice, maxAlpha
    else: # minPlayer
        minBeta = m.inf
        for column in range(7):
            # saving state here instead of another object
            originalBoard = deepcopy(possibleBoard.gameBoard)
            originalTurn = possibleBoard.currentTurn

            if possibleBoard.playPiece(column):
                if possibleBoard.currentTurn == 1:
                      possibleBoard.currentTurn = 2
                else: # possibleBoard.currentTurn == 2
                    possibleBoard.currentTurn == 1
                
                newBeta = miniMax(possibleBoard, True, maxPlayerPiece, alpha, beta, depth - 1)[1]
                # reset state
                possibleBoard.gameBoard = originalBoard
                possibleBoard.currentTurn = originalTurn
                possibleBoard.checkPieceCount()

                # beta part of alpha-beta pruning
                if newBeta < minBeta:
                    minBeta = newBeta
                    choice = column
                beta = min(beta, minBeta)
                if alpha >= beta:
                    break
        return choice, minBeta


def calculate(gameBoard, maxPlayerPiece):
    maxScore = 0.0;

    if maxPlayerPiece == 1:
        minPlayerPiece = 2
    else: # maxPlayerPiece == 2
        minPlayerPiece = 1

    # Calculate horizontals
    for row in gameBoard:
        maxScore += (row[0:4].count(maxPlayerPiece) + (row[0:4].count(0) * 0.5) - row[0:4].count(minPlayerPiece)) / 4
        maxScore += (row[1:5].count(maxPlayerPiece) + (row[1:5].count(0) * 0.5) - row[1:5].count(minPlayerPiece)) / 4
        maxScore += (row[2:6].count(maxPlayerPiece) + (row[2:6].count(0) * 0.5) - row[2:6].count(minPlayerPiece)) / 4
        maxScore += (row[3:7].count(maxPlayerPiece) + (row[3:7].count(0) * 0.5) - row[3:7].count(minPlayerPiece)) / 4

    # Calculate verticals
    for column in list(zip(*gameBoard)):
        maxScore += (column[0:4].count(maxPlayerPiece) + (column[0:4].count(0) * 0.5) - column[0:4].count(minPlayerPiece)) / 4
        maxScore += (column[1:5].count(maxPlayerPiece) + (column[1:5].count(0) * 0.5) - column[1:5].count(minPlayerPiece)) / 4
        maxScore += (column[2:6].count(maxPlayerPiece) + (column[2:6].count(0) * 0.5) - column[2:6].count(minPlayerPiece)) / 4
    
    # Calculate diagonals
    for r in range(len(gameBoard) - 3):
        for c in range(len(gameBoard[0]) - 3):
            temp = [] # takes 4x4 section of board
            for s in range(r, r + 4):
                temp += [gameBoard[s][c:c + 4]]
            
            diag1 = [j[i] for i, j in enumerate(temp)] # takes top left/bottom right diagonal
            maxScore += (diag1.count(maxPlayerPiece) + (diag1.count(0) * 0.5) - diag1.count(minPlayerPiece)) / 4

            diag2 = [j[-i-1] for i, j in enumerate(temp)] # takes top right/bottom left diagonal
            maxScore += (diag2.count(maxPlayerPiece) + (diag2.count(0) * 0.5) - diag2.count(minPlayerPiece)) / 4

    return maxScore
