Emelyne Hoang
1001900937
Python 3.7.13 (Compatible with Omega)

All code was written, run, and timed using Google Colab.
Execution times are included in CPU_runtime.xlsx


Code structure
The code is separated into three files, two of which were provided: maxconnect4.py, MaxConnect4Game.py, and MiniMax.py.

maxconnect4.py was modified to include user input in 'interactive' mode, as well as a loop so that the computer and user can take turns. Interactive mode also outputs a computer.txt and human.txt file that stores the current state of the game. A block was also added to both game mode to indicate the winner of the game, if any.

MaxConnect4Game.py was modified to print the board a bit more readably, as well as adding a playerPlay() function to proccess what happens when the player chooses a move. This is virtually identical to the previous aiPlay() function. The aiPlay() function was modified to run a new command from MiniMax.py to choose a turn for the AI player.

MiniMax.py is a new file that contains the minimax search with alpha-beta pruning that helps the AI choose a move to make. It starts by randomly choosing a choice, then checking if the board is full or the depth is at 0. If it is, then a score is calculated using the calculate() function that looks at all possible 4-in-a-row states and adding 1 if there is a max player piece, 0.5 if there is an empty space, or -1 if there is a min player piece, dividing this sum by 4, then adding it to the total score to be returned. After this block is the minmax search with alpha-beta pruning. This follows the standard minmax search with alpha-beta pruning algorithm, with some modifications so the previous state is saved before recursion, then resintating that state after.


Code execution
The code can simply be executed using the format:

	python maxconnect4.py interactive [input_file] [computer-next/human-next] [depth]
or

	python maxconnect4.py one-move [input_file] [output_file] [depth]

In Google Colab, this exact line was run in a code cell:

	!python3 "/content/drive/My Drive/Colab Notebooks/maxconnect4.py" interactive input1.txt computer-next 7
and

	!!python3 "/content/drive/My Drive/Colab Notebooks/maxconnect4.py" one-move red_next.txt green_next.txt 5

Additionally, the code can be run via the Windows Command Prompt that has been enabled with Python (this can be checked by opening the Command Prompt and entering "python"). Then, the following commands can also be entered:

	python maxconnect4.py interactive input1.txt computer-next 7

and

	python maxconnect4.py one-move green_next.txt red_next.txt 5


