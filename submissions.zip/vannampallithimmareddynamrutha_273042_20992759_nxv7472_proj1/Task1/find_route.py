def file1_input1(filename):
    distbtwnodes = {}
    #opening and reading the file 
    readInfile = open(filename, 'r') 
    for line in readInfile: 
        n = line.split()
        #checks if the line equals to "END OF INPUT" and returns the distance
        if (line.strip() == "END OF INPUT"): 
                return distbtwnodes
    #if n[0] is not avilable it stores empty values in dict
        if n[0] not in distbtwnodes:
            distbtwnodes[n[0]] = {}
    #if n[1] is not avilable it stores empty values in dict
        if n[1] not in distbtwnodes:
            distbtwnodes[n[1]] = {} 
        #else it will store the distance freom one city to another city in dict
        distbtwnodes[n[0]][n[1]] = float(n[2]) 
        distbtwnodes[n[1]][n[0]] = float(n[2]) 
    return distbtwnodes

import heapq as hq 
#this function performs uninformed cost search
def Uninformed_search( startState, goalState, nodesdist):
    #stores the generated nodes
    fringe = [(0,startState,[])]
    #count popped nodes
    popped=0 
    #count expanded nodes
    expanded = 0 
    #initialy there will be one generated node in fringe
    generated = 1 
    #stores the expanded nodes
    closedSet = set() 
    #iterates when length of fringe is greater than or equals to 1
    while len(fringe)>=1:
        #hq.heappop removes the smallest item stays in index 0 and replace its position with next smallest once 
        (enc,currentnode,Path) = hq.heappop(fringe)
        #increas the pop count each time a node is popped
        popped=popped+1
        Path = list(Path)
        #if the current node is not in closedSet it will be appended in to in and node will be expanded 
        if currentnode not in closedSet:
            expanded =expanded+1
            closedSet.add(currentnode)
            #appending the node to path to find the route
            Path.append(currentnode)
            #if current node equals to goal node it will display popped,expanded and generated nodes count
            if currentnode == goalState:
                # print(closedSet)
                print("Nodes Popped:",popped)
                print("Nodes Expanded:",expanded-1)
                print("Nodes Generated:",generated)
                return Path
            #for each key value pair of the node  it calculates cost and add the count to generated nodes  
            for n, c in nodesdist[currentnode].items():
                generated = generated+1
                cost = enc + c
                hq.heappush(fringe, (cost, n, Path))
    #displays popped, expaned and generated count if the goal is not met 
    print("Nodes Popped:",popped)      
    print("Nodes Expanded:",expanded)
    print("Nodes Generated:",generated)
    # print(closedSet)

    return []

def file2_h_kassel(filename2):
    distbtwnodes2 = {} 
    #opening and reading the file 
    readInfile = open(filename2, 'r') 
    #for each line in text file check if the line =="END OF INPUT" else it will store the Heuristic of each city in dict
    for line in readInfile:
        if (line.strip() == "END OF INPUT" ): 
                return distbtwnodes2
        else:
            n = line.split() 
            distbtwnodes2[n[0]] = float(n[1]) 
    return distbtwnodes2
#this function performs A* search
def informedAstar( startState, goalState, nodesdist, hu):
    #stores the generated nodes
    fringe = [(0,startState,[])]
    #count popped nodes
    popped=0
    #count expanded nodes
    expanded = 0 
    #initialy there will be one generated node in fringe
    generated = 1 
    #stores the expanded nodes
    closedSet = set() 
    #iterates when length of fringe is greater than or equals to 1
    while len(fringe)>=1:
        #hq.heappop removes the smallest item stays in index 0 and replace its position with next smallest once 
        (enc,currentnode,Path) = hq.heappop(fringe)
        #increas the pop count each time a node is popped
        popped=popped+1
        Path = list(Path)
        #if the current node is not in closedSet it will be appended in to in and node will be expanded 
        if currentnode not in closedSet:
            expanded =expanded+1
            closedSet.add(currentnode)
            #appending the node to path to find the route
            Path.append(currentnode)
            #if current node equals to goal node it will display popped,expanded and generated nodes count
            if currentnode == goalState:
                # print(closedSet)
                print("Nodes Popped:",popped)
                print("Nodes Expanded:",expanded-1)
                print("Nodes Generated:",generated)
                return Path
            #for each key value pair of the node  it calculates cost and add the count to generated nodes  
            for n, c in nodesdist[currentnode].items():
                generated = generated+1
                distance = 0.0
                #calculates the distance from one city to another city
                for i in range(len(Path)-1):
                    distance += nodesdist[Path[i]][Path[i+1]]
                cost = distance + c + hu[n]
                hq.heappush(fringe, (cost, n, Path))
    #displays popped, expaned and generated nodes count if the goal is not met 
    # print(closedSet)
    print("Nodes Popped:",popped)               
    print("Nodes expanded:",expanded)
    print("Nodes generated:",generated)
    return []

import sys
def main():
    lst = sys.argv
    #uninformed search
    #lst[1] saves file name
    filename = lst[1] 
    #lst[2] store initial node
    startState = lst[2] 
    #lst[3] store final node
    goalState = lst[3]
    if(len(lst) == 4): 
        usearch = True
        print("\nPerforming Uninformed Search:")
    #informed A* search
    elif(len(lst) == 5): 
        usearch = False
        print("\nPerforming Informed A* Search:")
    #if the given argument is invalid
    else: 
        print('Provide valid arguments\n')
        sys.exit()
    #reading input1.txt file
    nodesdist = file1_input1(filename)
    if usearch:
        node = Uninformed_search(startState, goalState, nodesdist)
    else:
        #stores input hfiles
        huIpF = lst[4] 
        hu = file2_h_kassel(huIpF)
        node = informedAstar( startState, goalState, nodesdist, hu)
#if the goalstate is not found it display distance infinity
    if len(node) == 0:
        print("Distance: Infinity")
        print("Route:")
        print("None")
    #if the goalstate is found it calculates the distance from one node to another and cummulative ditance from start state to goal state
    else:
        distance =0.0
        path=[]
        for i in range(len(node)-1):
            distance += nodesdist[node[i]][node[i+1]]
            path.append(node[i]+" to "+node[i+1]+", "+str(nodesdist[node[i]][node[i+1]])+" KM")
        print("Distance: {}  KM ".format(distance))
        print("Route:\n {} ".format(path))
#calling main function
if __name__ == "__main__":
    main()