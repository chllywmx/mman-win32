import sys

def find_city_cost(city_left, city_right):
    if (city_left + ' ' + city_right) in city_cost:
        cost = city_cost[city_left + ' ' + city_right]
    elif (city_right + ' ' + city_left) in city_cost:
        cost = city_cost[city_right + ' ' + city_left]
    else:
        cost = float('inf')
    return cost


def find_successor_nodes(node,nodes_generated,nodes_expanded):
    global fringe
    if node['node'] in closed_set:
        return nodes_generated,nodes_expanded    
    closed_set.add(node['node'])
    nodes_expanded += 1

    successors = []
    for i in city_cost:
        if node['node'] in i:
            temp = i.split(' ')
            if node['node'] == temp[0]:
                successors.append({'node': temp[1], 'parent':node, 'cost': node['cost'] + find_city_cost(temp[1],node['node']), 'heuristic_cost': heuristic_cost.get(temp[1],0)})
            else:
                successors.append({'node': temp[0], 'parent':node,'cost': node['cost'] + find_city_cost(temp[0],node['node']), 'heuristic_cost': heuristic_cost.get(temp[0],0)})

    nodes_generated += len(successors)

    for node in successors:
        node['total'] = node['cost'] + node['heuristic_cost']
    fringe.extend(successors)
    fringe = sorted(fringe, key=lambda n: n['total']) 
    return nodes_generated,nodes_expanded

fringe = []
closed_set = set()
nodes_popped = 0
nodes_generated = 1
nodes_expanded = 0
reached_goal = 0

origin_city = sys.argv[2]
destination_city = sys.argv[3]
heuristic_cost = {}

if len(sys.argv) == 5:
    file_contents = open(sys.argv[4],'r').read().split('\n')
    l = 0
    while(file_contents[l] != 'END OF INPUT'):
        temp = file_contents[l].split(' ')
        heuristic_cost[temp[0]] = float(temp[1])
        l+=1    

city_cost = {}
file_contents = open(sys.argv[1],'r').read().split('\n')

l = 0
while(file_contents[l] != 'END OF INPUT'):
    temp = file_contents[l].split(' ')
    city_cost[temp[0] + ' ' + temp[1]] = float(temp[2])
    l+=1


intial_state = {'node': origin_city, 'parent': None, 'cost': 0, 'heuristic_cost': heuristic_cost.get(origin_city,0), 'total':  heuristic_cost.get(origin_city,0)}
fringe.append(intial_state)

while fringe:
    next_node = fringe.pop(0)
    nodes_popped +=1 

    if next_node['node'] == destination_city:
        reached_goal = 1
        break

    nodes_generated,nodes_expanded = find_successor_nodes(next_node,nodes_generated,nodes_expanded)


print('Nodes Popped:',nodes_popped)
print('Nodes Expanded:',nodes_expanded)
print('Nodes Generated:',nodes_generated)


if reached_goal:  
    path = []
    print('Distance: ' + str(next_node['cost']) + ' km')
    print('Route:')
    while next_node['parent']:
        path.append(next_node['parent']['node'] + ' to ' + next_node['node'] + ', ' + str(next_node['cost'] - next_node['parent']['cost']) + " km")
        next_node = next_node['parent']
    print('\n'.join(path[::-1]))
else:
    print('Distance: infinity\nRoute:\nNone')
