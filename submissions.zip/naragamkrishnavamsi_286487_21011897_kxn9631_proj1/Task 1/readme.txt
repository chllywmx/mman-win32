Name - Krishna Vamsi Naragam
UTA ID - 1001979630

Python 2.4.3 programming language is used for this task and this code is compatible with omega.

I have added the origin city to the fringe initially and then I get the successor nodes using find_successor_nodes funtion, while the fringe is not empty,
I pop the nodes in the fringe (which is in sorted order of heuristic cost + distance between the nodes) until the destination city is reached.


To run the code with uninformed search
python findroute.py [input_filename] [origin_city] [destination_city] 

To run the code with informed search
python findroute.py [input_filename] [origin_city] [destination_city] [heuristic_filename]