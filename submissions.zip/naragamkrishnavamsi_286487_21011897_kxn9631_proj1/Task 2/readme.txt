Name - Krishna Vamsi Naragam
UTA ID - 1001979630

Python 3.9.13 programming language is used for this task. So this is not compatible with omega.

I have implemented depth limited alpha beta pruning minmax, the function name for minmax is aiPlay_minmax_ab 
and the alpha beta pruning I have implemented min_play and max_play and eval_func functions.

To run the code in Interactive Mode we need to run 
python3 maxconnect4.py interactive [input_file] [computer-next/human-next] [depth]

To run the code in One-Move Mode we need to run
python3 maxconnect4.py one-move [input_file] [output_file] [depth]

CPU runtime

depth 1 - 0.17 secs
depth 2 - 0.19 secs
depth 3 - 0.20 secs
depth 4 - 0.26 secs
depth 5 - 0.27 secs
depth 6 - 0.60 secs
depth 7 - 0.60 secs
depth 8 - 3.01 secs
depth 9 - 3.05 secs
depth 10 - 21 secs
depth 11 - 30 secs
depth 12 - 2 mins 23 secs