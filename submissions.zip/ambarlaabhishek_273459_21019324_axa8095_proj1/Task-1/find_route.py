from queue import PriorityQueue
import sys

def city_data(cities):
    results = []
    with open(cities) as file:
        for city in file:
            strip = city.rstrip()
            if strip == "END OF INPUT":
                break
            else:
                results.append(strip)
                continue
    return results

def seperator(results):
    l1, l2, l3 = [], [], []
    count = 0
    while count < len(results):
        lop = results[count].split(" ")
        first = lop[0]
        l1.append(first)
        second = lop[1]
        l2.append(second)
        third = lop[2]
        l3.append(third)
        count += 1
    return l1, l2, l3

def start_graph(s, e, d):
    j = dict()
    count = 0
    while count < (len(s)):
        if s[count] not in j:
            j[s[count]] = []
            j[s[count]].append([e[count], d[count]])
        else:
            j[s[count]].append([e[count], d[count]])
        count += 1
    count = 0
    while count < (len(e)):
        if e[count] not in j:
            j[e[count]] = []
            j[e[count]].append([s[count], d[count]])
        else:
            j[e[count]].append([s[count], d[count]])
        count += 1
    return j

def uniformcostsearch(cities, start_city, final_city):
    result1, result2, result3 = 0, 0, 0
    s_r, d_r, di_r, final_routes = [], [], [], []
    routes = city_data(cities)
    s_l, d_l, distance = seperator(routes)
    graph = start_graph(s_l, d_l, distance)
    sj, ej = start_city, final_city
    visited, lop = [], PriorityQueue()
    lop.put((0, sj))
    result1 += 1
    final_dist = 0
    while not lop.empty():
        result2 += 1
        t1 = lop.get()
        now, f1 = t1[1], t1[0]
        visited.append(now)
        if now != ej:
            result3 += 1
            for i in graph[now]:
                dist_new, new = int(i[1]), i[0]
                if new not in visited:
                    lop.put([f1 + dist_new, new])
                    s_r.append(now)
                    d_r.append(new)
                    di_r.append(dist_new)
                    result1 += 1
        else:
            final_dist += f1
            break
    if final_city in d_r:
        endi = final_city
        while endi != start_city:
            t1 = endi
            ind = d_r.index(endi)
            endi = s_r[ind]
            final_routes.append([endi, t1, di_r[ind]])
        final_routes.reverse()
        print("Nodes Popped = ", result2)
        print("Nodes Expanded = ", result3)
        print("Nodes Generated = ", result1)
        print("Distance = ", final_dist)
        print("Route = ", final_routes)
    else:
        print("Nodes Popped = ", result2)
        print("Nodes Expanded = ", result3)
        print("Nodes Generated = ", result1)
        print("Distance = ", "infinity")
        print("Route = ", "None")


def astarsearch(cities, start_city, final_city, heuris):
    result1, result2, result3 = 0, 0, 0
    s_r, d_r, di_r, final_routes = [], [], [], []
    routes = city_data(cities)
    s_l, d_l, distance = seperator(routes)
    graph = start_graph(s_l, d_l, distance)
    lpo = dict()
    jop = []
    with open(heuris) as file:
        for i in file:
            if i.rstrip() != "END OF INPUT":
                jop.append(i.rstrip())
            else:
                break
    place = []
    dfg = []
    for i in jop:
        s = i.split(" ")
        place.append(s[0])
        dfg.append(s[1])
    for i in range(len(place)):
        if place[i] in lpo:
            lpo[place[i]].append([dfg[i]])
        else:
            lpo[place[i]] = []
            lpo[place[i]].append([dfg[i]])
    sj, ej = start_city, final_city
    visited, lop = [], PriorityQueue()
    lop.put((int(lpo[sj][0][0]), sj))
    result1 += 1
    final_dist = 0
    while not lop.empty():
        result2 += 1
        t1 = lop.get()
        now, f1 = t1[1], t1[0]
        visited.append(now)
        if now != ej:
            result3 += 1
            for i in graph[now]:
                dist_new, new = int(i[1]), i[0]
                if new not in visited:
                    lop.put((f1 + dist_new + int(lpo[new][0][0]) - int(lpo[now][0][0]), new))
                    s_r.append(now)
                    d_r.append(new)
                    di_r.append(dist_new)
                    result1 += 1
        else:
            print(lpo[now][0][0])
            final_dist += f1 - int(lpo[now][0][0])
            break
    if final_city in d_r:
        endi = final_city
        while endi != start_city:
            t1 = endi
            ind = d_r.index(endi)
            endi = s_r[ind]
            final_routes.append([endi, t1, di_r[ind]])
        final_routes.reverse()
        print("Nodes Popped = ", result2)
        print("Nodes Expanded = ", result3)
        print("Nodes Generated = ", result1)
        print("Distance = ", final_dist)
        print("Route = ", final_routes)
    else:
        print("Nodes Popped = ", result2)
        print("Nodes Expanded = ", result3)
        print("Nodes Generated = ", result1)
        print("Distance = ", "infinity")
        print("Route = ", "None")

if len(sys.argv) == 4:
    uniformcostsearch(sys.argv[1], sys.argv[2], sys.argv[3])
elif len(sys.argv) == 5:
    astarsearch(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])