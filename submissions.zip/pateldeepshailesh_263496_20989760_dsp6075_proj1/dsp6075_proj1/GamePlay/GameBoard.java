// DEEP SHAILESH PATEL
// 1001946075

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GameBoard {
	// class fields
	private int[][] playBoardDesign;
	private int counter;
	private int recentMove;

	public GameBoard(int[][] playBoardDesign, int counter, int recentMove) {
		super();
		this.playBoardDesign = playBoardDesign;
		this.counter = counter;
		this.recentMove = recentMove;
	}

	public GameBoard(String inputFile) {

		this.playBoardDesign = new int[6][7];
		this.counter = 0;
		int counter = 0;
		Scanner input = null;
		String data = null;

		// open the input file
		try {
			input = new Scanner(new File(inputFile));
		} catch (IOException e) {
			System.out.println("\nInvalid!!\nPlease Try again" + "\n");
			e.printStackTrace();
		}

		// Reading input data
		for (int i = 0; i < 6; i++) {
			try {

				data = input.next();

				for (int j = 0; j < 7; j++) {

					this.playBoardDesign[i][j] = data.charAt(counter++) - 48;

					if (!((this.playBoardDesign[i][j] == 0) || (this.playBoardDesign[i][j] == 1)
							|| (this.playBoardDesign[i][j] == 2))) {
						System.out.println(
								"\nError!\nReading the piece " + "from the input file was not a 1, a 2 or a 0");
						this.exitGame(0);
					}

					if (this.playBoardDesign[i][j] > 0) {
						this.counter++;
					}
				}

			} catch (Exception e) {
				System.out.println("\nInvalid!\n" + "Please check file path!!\n");
				e.printStackTrace();
				this.exitGame(0);
			}

			// reset the counter
			counter = 0;

		} // end for loop

		// read one more line to get the next players turn
		try {
			data = input.next();
		} catch (Exception e) {
			System.out.println("\nInvalidating Next Turn!!\n");
			e.printStackTrace();
		}

		this.recentMove = data.charAt(0) - 48;

		if (!((this.recentMove == 1) || (this.recentMove == 2))) {
			System.out.println("Error!\n the current turn read is not a " + "1 or a 2!");
			this.exitGame(0);
		} else if (this.getrecentMove() != this.recentMove) {
			System.out.println(
					"Error!\n Invalidating current move " + "according to the number of pieces played!");
			this.exitGame(0);
		}
	}

	public GameBoard(int play[][]) {

		this.playBoardDesign = new int[6][7];
		this.counter = 0;

		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				this.playBoardDesign[i][j] = play[i][j];

				if (this.playBoardDesign[i][j] > 0) {
					this.counter++;
				}
			}
		}
	}

	public int getGameScore(int move) {
		// reset the scores
		int moveScore = 0;

		// check horizontally
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 4; j++) {
				if ((this.playBoardDesign[i][j] == move) && (this.playBoardDesign[i][j + 1] == move)
						&& (this.playBoardDesign[i][j + 2] == move) && (this.playBoardDesign[i][j + 3] == move)) {
					moveScore++;
				}
			}
		}

		// check vertically
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 7; j++) {
				if ((this.playBoardDesign[i][j] == move) && (this.playBoardDesign[i + 1][j] == move)
						&& (this.playBoardDesign[i + 2][j] == move) && (this.playBoardDesign[i + 3][j] == move)) {
					moveScore++;
				}
			}
		}

		// check diagonally - backs lash -> \
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 4; j++) {
				if ((this.playBoardDesign[i][j] == move) && (this.playBoardDesign[i + 1][j + 1] == move)
						&& (this.playBoardDesign[i + 2][j + 2] == move)
						&& (this.playBoardDesign[i + 3][j + 3] == move)) {
					moveScore++;
				}
			}
		}

		// check diagonally - forward slash -> /
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 4; j++) {
				if ((this.playBoardDesign[i + 3][j] == move) && (this.playBoardDesign[i + 2][j + 1] == move)
						&& (this.playBoardDesign[i + 1][j + 2] == move) && (this.playBoardDesign[i][j + 3] == move)) {
					moveScore++;
				}
			}
		}

		return moveScore;
	}

	// Return the current player based on moves played
	public int getrecentMove() {
		return (this.counter % 2) + 1;
	}

	public int getcounterNumber() {
		return this.counter;
	}

	public int[][] getGameBoardDesign() {
		return this.playBoardDesign;
	}

	public boolean validPlay(int col) {

		if (!(col >= 0 && col <= 7)) {
			// check the col bounds
			return false;
		} else if (this.playBoardDesign[0][col] > 0) {
			// check if col is full
			return false;
		} else {
			// col is NOT full and the column is within bounds
			return true;
		}
	}

	// check if current state is terminal state
	public boolean goalState() {

		for (int i = 0; i < 7; i++) {
			if (this.playBoardDesign[0][i] == 0)
				return false;
		}
		return true;
	}

//	Returns a new game board object after playing a move with given column number
	public GameBoard getOutput(int col) {

		int[][] outputBoard = makeCopy(this.playBoardDesign);

		GameBoard newBoard = new GameBoard(outputBoard, this.getcounterNumber(), this.getrecentMove());

		newBoard.makeMove(col);

		return newBoard;
	}

	private int[][] makeCopy(int[][] boardDesign) {

		int[][] output = new int[6][7];
		for (int i = 5; i >= 0; i--) {
			for (int j = 0; j < 7; j++) {
				output[i][j] = boardDesign[i][j];
			}
		}
		return output;
	}

	public boolean makeMove(int col) {

		// check if the column choice is a valid play
		if (!this.validPlay(col)) {
			return false;
		} else {

			// starting at the bottom of the board,
			// place the piece into the first empty spot
			for (int i = 5; i >= 0; i--) {
				if (this.playBoardDesign[i][col] == 0) {
					if (this.counter % 2 == 0) {
						this.playBoardDesign[i][col] = 1;
						this.counter++;

					} else {
						this.playBoardDesign[i][col] = 2;
						this.counter++;
					}

					

					return true;
				}
			}
			// the pgm shouldn't get here
			System.out.println("Something went wrong with playPiece()");

			return false;
		}
	} // end makeMove

	public void deleteMove(int col) {

		// starting looking at the top of the game board,
		// and remove the top piece
		for (int i = 0; i < 6; i++) {
			if (this.playBoardDesign[i][col] > 0) {
				this.playBoardDesign[i][col] = 0;
				this.counter--;

				break;
			}
		}

		

	} // end remove piece

	// Writing output to terminal
	public void printGameBoard() {
		System.out.println(" -----------------");

		for (int i = 0; i < 6; i++) {
			System.out.print(" | ");
			for (int j = 0; j < 7; j++) {
				System.out.print(this.playBoardDesign[i][j] + " ");
			}

			System.out.println("| ");
		}

		System.out.println(" -----------------");
	}

	// Writing outupt to file
	public void printGameBoardToFile(String outputFile) {
		try {
			BufferedWriter output = new BufferedWriter(new FileWriter(outputFile));

			for (int i = 0; i < 6; i++) {
				for (int j = 0; j < 7; j++) {
					output.write(this.playBoardDesign[i][j] + 48);
				}
				output.write("\r\n");
			}

			// write the current turn
			output.write(this.getrecentMove() + "\r\n");
			output.close();

		} catch (IOException e) {
			System.out.println("\nInvalid!!\n" + " Please try again.");
			e.printStackTrace();
		}
	} // end printGameBoardToFile()

	public int calScore(int move) {

		int moveScore = 0;

		// check horizontally
		for (int i = 0; i < 6; i++) {
			int r_Score = 0;
			for (int j = 0; j < 4; j++) {

				int[] designArray = { this.playBoardDesign[i][j], this.playBoardDesign[i][j + 1],
						this.playBoardDesign[i][j + 2], this.playBoardDesign[i][j + 3] };

				r_Score += getCalScore(move, designArray);
			}

			moveScore += r_Score;
		}

		// check vertically
		for (int i = 0; i < 3; i++) {
			int r_Score = 0;
			for (int j = 0; j < 7; j++) {
				int[] designArray = { this.playBoardDesign[i][j], this.playBoardDesign[i + 1][j],
						this.playBoardDesign[i + 2][j], this.playBoardDesign[i + 3][j] };

				r_Score += getCalScore(move, designArray);
			}

			moveScore += r_Score;
		}

		// check diagonally - backs lash -> \
		for (int i = 0; i < 3; i++) {
			int r_Score = 0;
			for (int j = 0; j < 4; j++) {
				int[] designArray = { this.playBoardDesign[i][j], this.playBoardDesign[i + 1][j + 1],
						this.playBoardDesign[i + 2][j + 2], this.playBoardDesign[i + 3][j + 3] };
				r_Score += getCalScore(move, designArray);
			}

			moveScore += r_Score;
		}

		// check diagonally - forward slash -> /
		for (int i = 0; i < 3; i++) {
			int r_Score = 0;
			for (int j = 0; j < 4; j++) {
				int[] designArray = { this.playBoardDesign[i + 3][j], this.playBoardDesign[i + 2][j + 1],
						this.playBoardDesign[i + 1][j + 2], this.playBoardDesign[i][j + 3] };

				r_Score += getCalScore(move, designArray);
			}
			moveScore += r_Score;
		}

		return moveScore;
	}

	public int getCalScore(int move, int[] rowArr) {

		int moveScore = 0;
		int voidScore = 0;
		int othermoveScore = 0;
		int finalScore = 0;

		int othermove = move == 1 ? 2 : 1;

		for (int i = 0; i < rowArr.length; i++) {

			if (rowArr[i] == move)
				moveScore += 1;
			else if (rowArr[i] == othermove)
				othermoveScore += 1;
			else
				voidScore += 1;

			if (moveScore == 4)
				finalScore += 20;
			else if (moveScore == 3 && voidScore == 1)
				finalScore += 3;
			else if (moveScore == 2 && voidScore == 2)
				finalScore += 2;
			else if (othermoveScore == 4)
				finalScore -= 4;

		}

		return finalScore;
	}

	private void exitGame(int score) {
		System.out.println("Exit\n\n");
		System.exit(score);
	}

}
