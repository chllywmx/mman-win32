Name: Deep Shailesh Patel
ID: 1001946075
Submission: CSE5360 - Project 1 (Task 2)


-------------------- STEPS TO RUN THE PROGRAM --------------------

1. Compile all the java files:

Command: javac Play.java GamePlayAgent.java GameBoard.java (Ref: Screenshot Compile_Code.png)

2. Run the Home file:

Command: java Play <mode> input.txt output.txt <depth> (Ref: Screenshot Run_Code.png)

------------- PROGRAMMING LANGUAGE USED AND INFORMATION---------------

Programming Language used: Java
Java version used: jdk18.0.1.1

Note: Place the input and heuristic files under the same directory (sample files already in the directory named input1.txt and h_kassel.txt).
         Make sure, If you add any file in the directory that has the same name while you run the code.

