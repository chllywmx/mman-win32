// DEEP SHAILESH PATEL
// 1001946075

public class GamePlayAgent {

	private GameBoard copyGameBoard = null;

	public GamePlayAgent(GameBoard gameBoard) {

		copyGameBoard = new GameBoard(gameBoard.getGameBoardDesign(), gameBoard.getcounterNumber(), gameBoard.getrecentMove());
	}

	public int findBestMove(int depth) {

		int[] playArr = this.getMaxValue(this.copyGameBoard, this.copyGameBoard.getrecentMove(), -1,
				Integer.MIN_VALUE, Integer.MAX_VALUE, depth);

		return playArr[1];
	}

//	The method forms part of the minimax algorithm
	public int[] getMaxValue(GameBoard state, int maxPlayer, int action, int alpha, int beta, int depth) {

		if (state.goalState()) {
			System.out.println("here 1");
			return new int[] { state.calScore(maxPlayer), action };
		}
		if (depth > 0) {
			int maxVal = Integer.MIN_VALUE;
			for (int i = 0; i < 7; i++) {

				if (state.validPlay(i)) {

					int minVal = getMinValue(state.getOutput(i), maxPlayer, action, alpha, beta, depth - 1);
					if (minVal > maxVal) {
						maxVal = minVal;
						action = i;
					}
					if (maxVal >= beta)
						return new int[] { maxVal, action };
					alpha = Math.max(alpha, maxVal);
				}
			}
			return new int[] { maxVal, action };
		} else {
			return new int[] { state.calScore(maxPlayer), action };
		}
	}

//	The method forms part of the minimax algorithm
	private int getMinValue(GameBoard state, int maxPlayer, int action, int alpha, int beta, int depth) {

		if (state.goalState())
			return state.calScore(maxPlayer);

		int minVal = Integer.MAX_VALUE;
		if (depth > 0) {
			for (int i = 0; i < 7; i++) {
				if (state.validPlay(i)) {
					minVal = Math.min(minVal,
							getMaxValue(state.getOutput(i), maxPlayer, action, alpha, beta, depth - 1)[0]);
					if (minVal <= alpha)
						return minVal;
					beta = Math.min(beta, minVal);
				}
			}
			return minVal;
		} else {
			return state.calScore(maxPlayer);
		}
	}

}
