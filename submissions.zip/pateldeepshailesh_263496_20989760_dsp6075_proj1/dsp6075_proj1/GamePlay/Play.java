// DEEP SHAILESH PATEL
// 1001946075

public class Play {

	public static final String INTERACTIVE_GAME_MODE = "INTERACTIVE";
	public static final String ONE_MOVE_GAME_MODE = "ONE-MOVE";

	public static void main(String[] args) {

		if (args.length != 4) {
			System.out.println("Four command-line arguments are needed:\n"
					+ "Usage: java [program name] interactive [input_file] [computer-next / human-next] [depth]\n"
					+ " or:  java [program name] one-move [input_file] [output_file] [depth]\n");

			exit_function(0);
		}

		// Reading input arguments
		String gameVersion = args[0].toString(); // the game mode "interactive" / "one-move"
		String input = args[1].toString(); // the input game file
		String output = args[2].toString(); // the output file
		int depth = Integer.parseInt(args[3]); // the depth level of the ai search

		// Setting up the initial game board configuration
		GameBoard gameBoard = new GameBoard(input);

		GamePlayAgent gamePlayAgent = new GamePlayAgent(gameBoard);

		System.out.print("game state before move:\n");
		gameBoard.printGameBoard();

		System.out.println("Score: Player_1 = " + gameBoard.getGameScore(1) + ", Player_2 = " + gameBoard.getGameScore(2) + "\n");

		if (gameVersion.equalsIgnoreCase(INTERACTIVE_GAME_MODE)) {

			// Implementation for interactive mode
			System.out.println("Implementation for interactive mode");
			exit_function(0);

		} else if (!gameVersion.equalsIgnoreCase(ONE_MOVE_GAME_MODE)) {

			System.out.println("Invalid game mode!\n Hint: try again with mode: interactive / one-move");
			exit_function(0);

		} else if (gameBoard.getcounterNumber() < 42) {

			// Use GamePlayAgent to determine next move
			int columnToPlay = gamePlayAgent.findBestMove(depth);

			gameBoard.makeMove(columnToPlay);

			System.out.println("move " + gameBoard.getcounterNumber() + ": Player " + gameBoard.getrecentMove()
					+ ", column " + columnToPlay);

			System.out.print("game state after move:\n");
			gameBoard.printGameBoard();
			
			System.out.println("Score: Player_1 = " + gameBoard.getGameScore(1) + ", Player_2 = " + gameBoard.getGameScore(2) + "\n");
			
			gameBoard.printGameBoardToFile(output);
		
		} else {
			
			System.out.println("No moves to play!");
			exit_function(0);
		}

	}

	private static void exit_function(int value) {
		System.out.println("Exit Called!\n\n");
		System.exit(value);
	}

}
