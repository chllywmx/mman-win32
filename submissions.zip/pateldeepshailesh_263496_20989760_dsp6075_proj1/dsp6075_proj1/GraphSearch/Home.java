// DEEP SHAILESH PATEL
// 1001946075

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class Home {

	// input.txt London Kassel h_kassel.txt

	public static void main(String[] args) {

		List<Node> fring = new ArrayList<>();
		List<String> closed_Set = new ArrayList<>();
		int node_Expanded = 0;
		int node_Generated = 1;
		Integer deep = 0;
		List<Edge> routing = null;

		try {

			if (args.length < 3 || args.length > 4) {

				System.out.println("Invalid Input!!");
				exit(0);
			}

			String inputFile = args[0];
			String source = args[1];
			String destination = args[2];
			String inputHeuristicsFile = null;

			if (args.length == 4)
				inputHeuristicsFile = args[3];

			Graph currentGraph = new Graph(inputFile);

			// If source is same as destination
			if (source.equalsIgnoreCase(destination)) {
				printOutput(0, 0, 0, null);
				exit(0);
			}

			// Begin Graph search using UCS / A* Search
			if (inputHeuristicsFile != null) {
				currentGraph.prepHeuMap(inputHeuristicsFile, destination);
			}

			// Add source to frige
			Node node = new Node(source, null, deep, 0, getHeuristicsDistance(0, currentGraph, source));
			fring.add(node);

			while (true) {

				Node popNode = new Node(fring.remove(0));
				//Uncomment to debug
				//System.out.println("Node Expanded: " + popNode.toString());
				node_Expanded += 1;
				deep += 1;

				// Goal test
				if (popNode.getnodeVal().equalsIgnoreCase(destination)) {

					routing = new ArrayList<>();
					getRoute(popNode, currentGraph, routing);
					Collections.reverse(routing);
					printOutput(node_Expanded, node_Generated, popNode.getDistance(), routing);
					break;
				}

				// Check if state is present in closed set
				if (!closed_Set.contains(popNode.getnodeVal())) {

					// Add the state to closed state
					closed_Set.add(popNode.getnodeVal());
					List<Edge> valNode = currentGraph.findValedge(popNode.getnodeVal());

					if (valNode.isEmpty()) {

						System.out.println("Terminated Node!");
						break;

					} else {

						// Add all the generated children nodes to fring
						for (Edge children : valNode) {

							Integer cumilativeDistance = children.getDistance() + getCumilativeDistance(popNode);

							Node generatedNode = new Node(children.getTarget(), popNode, deep, cumilativeDistance,
									getHeuristicsDistance(cumilativeDistance, currentGraph, children.getTarget()));

							fring.add(generatedNode);

							// Uncomment to debug
							//System.out.println("Node Generated: " + generatedNode.toString());

							node_Generated += 1;
						}

						// Sort the fring
						Collections.sort(fring, new Comparator<Node>() {

							@Override
							public int compare(Node o1, Node o2) {

								if (o1.getHeuristicsDistance() == 0 && o2.getHeuristicsDistance() == 0) {
									return o1.getDistance() - o2.getDistance();
								}
								return o1.getHeuristicsDistance() - o2.getHeuristicsDistance();
							}
						});

					}

				} else if (fring.isEmpty()) {

					System.out.println("No Route exists between " + source + " and " + destination);
					printOutput(node_Expanded, node_Generated, Integer.MAX_VALUE, null);
					break;
				}

			}

			exit(0);

		} catch (Exception e) {

			e.printStackTrace();
			exit(0);
		}
	}

	private static void printOutput(int node_Expanded, int node_Generated, int distance, List<Edge> routing) {

		System.out.println("Nodes popped: " + node_Expanded);
		System.out.println("nodes generated: " + node_Generated);
		System.out.println("distance: " + (distance == Integer.MAX_VALUE ? "Infinity" : (distance + "Kms")));

		if (!Objects.isNull(routing)) {
			System.out.println("route: ");
			routing.forEach(edge -> System.out
					.println(edge.getSource() + " to " + edge.getTarget() + ", " + edge.getDistance() + " Kms"));
		} else {
			System.out.println("route: none");
		}

	}

	private static void getRoute(Node goalNode, Graph currentGraph, List<Edge> routeList) {

		if (goalNode.getparNode() != null) {

			Edge routeEdge = currentGraph.findprepEdge(goalNode.getparNode().getnodeVal(), goalNode.getnodeVal());
			routeList.add(routeEdge);
			getRoute(goalNode.getparNode(), currentGraph, routeList);
		}

	}

	private static Integer getHeuristicsDistance(Integer cumilativeDistance, Graph currentGraph, String key) {

		Integer heuristicsDistance = 0;
		Map<String, Integer> heuMap = currentGraph.getHeuMap();

		if (!Objects.isNull(heuMap) && !heuMap.isEmpty()) {

			heuristicsDistance += (cumilativeDistance + heuMap.get(key));
		}

		return heuristicsDistance;
	}

	private static Integer getCumilativeDistance(Node parent) {

		if (!Objects.isNull(parent))
			return parent.getDistance();
					//+ getCumilativeDistance(parent.getparNode());
		else
			return 0;
	}

	private static void exit(int exitCode) {
		System.exit(exitCode);
	}

}
