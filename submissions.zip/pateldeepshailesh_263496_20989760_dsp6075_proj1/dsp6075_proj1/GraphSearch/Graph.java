// DEEP SHAILESH PATEL
// 1001946075

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Graph {

	private static final String END_OF_INPUT = "END OF INPUT";
	private List<Edge> edge = new ArrayList<>();
	private Map<String, Integer> heuMap;

	public Graph(String input_File) {

		try {

			Scanner input = new Scanner(new File(input_File));

			while (input.hasNextLine()) {

				String line = input.nextLine();

				if (line.equals(END_OF_INPUT)) {
					break;
				}

				String[] inputLine = line.split(" ");

				edge.add(new Edge(inputLine[0], inputLine[1], Integer.valueOf(inputLine[2])));
				edge.add(new Edge(inputLine[1], inputLine[0], Integer.valueOf(inputLine[2])));

			}

		} catch (FileNotFoundException e) {

			System.out.println("Invalid!!");
			e.printStackTrace();
			exit(0);
		}
	}
	
	public void prepHeuMap(String heuFile, String goal) {

		try {
			
			Scanner input = new Scanner(new File(heuFile));
			
			heuMap = new HashMap<>();
			
			while(input.hasNextLine()) {
				
				String line = input.nextLine();
				
				if(line.equals(END_OF_INPUT)) {
					break;
				}
				
				String[] inputLine = line.split(" ");
				
				if(inputLine[0].equalsIgnoreCase(goal)) {
					
					// Validates if heuristics file aligns with goal
					if(!heuFile.substring(2, heuFile.indexOf(".txt")).equalsIgnoreCase(goal) || Integer.parseInt(inputLine[1]) != 0) {
						
						System.out.println("Is not Goal!");
						heuMap = new HashMap<String, Integer>();
						exit(0);
					}
				}
				
				heuMap.put(inputLine[0], Integer.valueOf(inputLine[1]));
			}

		} catch (FileNotFoundException e) {

			System.out.println("Invalid!!");
			e.printStackTrace();
			exit(0);
		}

	}

	public List<Edge> findValedge(String source) {
		
		List<Edge> childrenNodeList = new ArrayList<>();
		
		for(Edge edge: this.edge) {
			
			if(edge.getSource().equalsIgnoreCase(source)) {
				childrenNodeList.add(edge);
			}
		}
		
		return childrenNodeList;
	}
	
	public Edge findprepEdge(String source, String goal) {
		
		Edge result = null;
		
		for(Edge edge: this.edge) {
			
			if(edge.getSource().equalsIgnoreCase(source) && edge.getTarget().equalsIgnoreCase(goal)) {
				
				result = new Edge(edge.getSource(), edge.getTarget(), edge.getDistance());
			}
		}
		
		return result;
	}
	
	public Map getHeuMap() {
		
		return heuMap;
	}
	
	private static void exit(int terminate) {

		System.out.println("Program has been Terminated!\n");
		System.exit(terminate);
	}

}
