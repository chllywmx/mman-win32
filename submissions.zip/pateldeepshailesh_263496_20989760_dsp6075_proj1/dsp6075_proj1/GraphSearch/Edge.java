// DEEP SHAILESH PATEL
// 1001946075

public class Edge {

	private String source;
	private String target;
	private Integer distance;
	
	public Edge(String source, String target, Integer distance) {
		super();
		this.source = source;
		this.target = target;
		this.distance = distance;
	}
	public String getSource() {
		return source;
	}
	public String getTarget() {
		return target;
	}
	public Integer getDistance() {
		return distance;
	}
	
	@Override
	public String toString() {
		return "Edge [source=" + source + ", target=" + target + ", distance=" + distance + "]";
	}
	
	

}
