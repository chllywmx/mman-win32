// DEEP SHAILESH PATEL
// 1001946075

public class Node {
	
	private String nodeVal;
	private Node parNode;
	private Integer deep;
	private Integer distance;
	private Integer heuristicsDistance;
	
	public Node(String nodeVal, Node parNode, Integer deep, Integer distance, Integer heuristicsDistance) {
		super();
		this.nodeVal = nodeVal;
		this.parNode = parNode;
		this.deep = deep;
		this.distance = distance;
		this.heuristicsDistance = heuristicsDistance;
	}
	
	public Node(Node node) {
		
		super();
		this.nodeVal = node.getnodeVal();
		this.parNode = node.getparNode();
		this.deep = node.getdeep();
		this.distance = node.getDistance();
		this.heuristicsDistance = node.getHeuristicsDistance();
	}
	
	public String getnodeVal() {
		return nodeVal;
	}
	public Node getparNode() {
		return parNode;
	}
	public Integer getdeep() {
		return deep;
	}
	public Integer getDistance() {
		return distance;
	}
	public Integer getHeuristicsDistance() {
		return heuristicsDistance;
	}
	
	@Override
	public String toString() {
		return "Node [nodeVal=" + nodeVal + ", parNode=" + parNode + ", deep=" + deep + ", distance="
				+ distance + ", heuristics= " + heuristicsDistance + "]";
	}
	
	

}
