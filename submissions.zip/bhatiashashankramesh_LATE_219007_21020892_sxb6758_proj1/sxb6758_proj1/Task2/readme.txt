Name: Shashank Ramesh Bhatia
UTA ID: 1001876757
NET ID: sxb6758

Programming Language Used: Python 3.9

Code Structure:
It contains 5 files:
1) "maxconnect4.py" - it is the main file. Modified one-move function. Filled in interactive
2) "MaxConnect4Game.py" - contains game structure. Added "depth", made changes in aiPlay()
3) "DepthAlphaBetaMinMax.py" - implementation of alpha-beta algorithm
4) "Evaluate_score.py" - Calculates score
5) "EvaluationTimes.xlsx" - It contains the table of depth limit vs runtime


How to run the code?
The supporting files "MaxConnect4Game.py", "DepthAlphaBetaMinMax.py", "Evaluate_score.py" input file and output file should be in same folder in which "maxconnect4.py" is in.

Run program using in the following format:
python maxconnect4.py [one-move] [input.txt] [output.txt] [depth]
In above line [one-move] is the mode, it can be "one-move"  or "interactive". "input1.txt" is the input file. It can have any name. "output1.txt" is the output file. [depth] is the depth limit in integer.

