from MaxConnect4Game import *
from copy import deepcopy
from Evaluate_score import *

INFINITE = 9999999999

class depthAlphaBeta:
    def __init__(self, connect4game):
        self.connect4game = connect4game

        self.utility_value = {}

    def minimax(self):
        current_state = copy.deepcopy(self.connect4game.gameBoard)
        for i in range(7):
            if self.connect4game.playPiece(i) is not None:
                if self.connect4game.piece_count == 42 or self.connect4game.depth == 0:
                    self.connect4game.gameBoard = copy.deepcopy(current_state)
                    return i
                else:
                    val = self.beta_alpha(self.connect4game.gameBoard, -INFINITE, INFINITE, self.connect4game.depth - 1)

                    self.utility_value[i] = val
                    self.connect4game.gameBoard = copy.deepcopy(current_state)

        max_utility_value = max([i for i in self.utility_value.values()])
        for i in range(7):
            if i in self.utility_value:
                if self.utility_value[i] == max_utility_value:
                    self.utility_value.clear()
                    return i

    def max_val(self, current_node):
        main_node = copy.deepcopy(current_node)
        child_nodes = []
        for i in range(7):
            current_state = self.connect4game.playPiece(i)
            if current_state is not None:
                child_nodes.append(self.connect4game.gameBoard)
                self.connect4game.gameBoard = copy.deepcopy(main_node)
        return child_nodes

    def alpha_beta(self, current_node, alpha, beta, depth):
        value = -INFINITE
        child_nodes = self.max_val(current_node)
        if child_nodes == [] or depth == 0:
            self.connect4game.countScore()
            return eval_score(self.connect4game.gameboard)
        else:
            for node in child_nodes:
                self.connect4game.gameBoard = copy.deepcopy(node)
                value = max(value, self.beta_alpha(node, alpha, beta, depth - 1))
                if value >= beta:
                    return value
                alpha = max(alpha, value)
            return value

    def min_val(self, current_node):
        main_node = copy.deepcopy(current_node)
        if self.current_move == 1:
            opponent = 2
        elif self.current_move == 2:
            opponent = 1
        child_nodes = []
        for i in range(7):
            current_state = self.check_piece(i, opponent)
            if current_state is not None:
                child_nodes.append(self.gameboard)
                self.connect4game.gameBoard = copy.deepcopy(main_node)
        return child_nodes

    def beta_alpha(self, current_node, alpha, beta, depth):
        value = INFINITE
        child_nodes = self.min_val(current_node)
        if child_nodes == [] or depth == 0:
            self.connect4game.countScore()
            return eval_score(self.connect4game.gameBoard)
        else:
            for node in child_nodes:
                self.connect4game.gameBoard = copy.deepcopy(node)
                value = min(value, self.alpha_beta(node, alpha, beta, depth - 1))
                if value <= alpha:
                    return value
                beta = min(beta, value)
        return value


