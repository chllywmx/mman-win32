# Calculates score based on eval function
def eval_score(connect4game):
    if connect4game.player1Score == connect4game.player2Score:
        return 0

    if connect4game.player1Score > connect4game.player2Score:
        return connect4game.player1Score

    if connect4game.player1Score < connect4game.player2Score:
        return -1 * connect4game.player2Score

