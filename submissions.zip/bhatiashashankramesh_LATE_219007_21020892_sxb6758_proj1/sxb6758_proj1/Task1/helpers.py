END_OF_FILE = "END OF INPUT"


class Node:
    def __init__(self, city, parent, cost, heuristic):
        self.parent = parent # parent is of type Node
        self.city = city
        self.cost = cost
        self.heuristic = heuristic


