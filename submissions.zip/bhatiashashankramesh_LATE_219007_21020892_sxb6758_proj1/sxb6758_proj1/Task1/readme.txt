Mini Programming Project 1 - Task 1

Name:	Shashank Ramesh Bhatia
UTA ID:	1001876757
Net ID:	sxb6758
Language:Python (3.9)

Code Structure:
	File: find_route.py : The main file. Opens the "input" file and "heuristics" file (if provided), and displays results after performing informed or uninformed search

	File: helpers.py : Contains the "Node" class required.

How to run : 
Download and install Python 3. This has been tested and developed using python 3.9
Run the following command
python find_route.py [input_file.txt] [source] [destination] (for uninformed search)

or

python find_route.py [input_file.txt] [source] [destination] [heuristics.txt] (for informed search)
