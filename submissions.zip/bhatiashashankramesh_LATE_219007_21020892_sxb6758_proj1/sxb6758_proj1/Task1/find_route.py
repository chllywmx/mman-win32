import sys
from helpers import *
import heapq

# User inputs cmds args
cmds = []

# User input Files initialization
input_file = None
h_file = None

# 0 = unInformed, 1 = Informed
flag = 0

# for expanded nodes
nodes_e = 0
# for popped nodes
nodes_p = 0
# for generated nodes
nodes_g = 0

# for storing the route
route = dict()

cmds = sys.argv

# Command Line Validation

if len(cmds) < 4:
    print("Incorrect number of inputs.\nPlease Enter all the inputs")
    sys.exit()

input_file = open(cmds[1], "r")
source_node = str(cmds[2]).lower()
dest_node = str(cmds[3]).lower()

i = None

infoCity = dict()

# read the input file
currentfline = input_file.readline().replace("\n", "").replace("\r", "")

while currentfline != END_OF_FILE:
    citycostpair = currentfline.replace("\n", "").replace("\r", "").split(" ")

    start = citycostpair[0].lower()
    end = citycostpair[1].lower()
    dist = citycostpair[2]

    entry = [end, dist]
    if start in infoCity.keys():
        infoCity[start].append(entry)
        nodes_g += 1
    else:
        temp = []
        temp.append(entry)
        infoCity[start] = temp

    entry = [start, dist]
    if end in infoCity.keys():
        infoCity[end].append(entry)
        nodes_g += 1
    else:
        temp = []
        temp.append(entry)
        infoCity[end] = temp

    currentfline = input_file.readline().replace("\n", "").replace("\r", "")

# if heuristic file is available, read that too
hueristics = dict()
if (len(cmds) == 5):

    flag = 1

    h_file = open(cmds[4], "r")

    hueristics

    current_hf_line = h_file.readline().replace("\n", "").replace("\r", "")

    while current_hf_line != END_OF_FILE:
        hs = current_hf_line.replace("\n", "").replace("\r", "").split(" ")

        hueristics[hs[0].lower()] = int(hs[1])

        current_hf_line = h_file.readline().replace("\n", "").replace("\r", "")


def print_output(dest):
    global nodes_p
    cuma_dist = "infinity"

    final_route = []
    if dest in route:
        cuma_dist = str(route[dest][1]) + " km"
        parent = route[dest][0]
        while parent is not None:
            dist = int(route[dest][1]) - int(route[parent][1])
            final_route.append(parent + " to " + dest + ", " + str(dist) + " km")
            dest = parent
            parent = route[dest][0]
            nodes_p += 1

    str_output = "Nodes Popped: " + str(nodes_p) + "\n"
    str_output += "Nodes Expanded: " + str(nodes_e) + "\n"
    str_output += "Nodes Generated: " + str(nodes_g) + "\n"
    str_output += "Distance: " + cuma_dist + "\n"
    str_output += "Route:\n"
    if len(final_route) == 0:
        str_output += "None"
    else:
        while not (len(final_route) == 0):
            str_output += final_route.pop() + "\n"
    print(str_output)


if flag == 0:  # Uninformed search

    visited_Node = []

    # initialising fringe with source as src, dest as null
    fringe = []
    heapq.heappush(fringe, (0, Node(source_node, None, 0)))

    while fringe:
        # storing the node from fringe at index 0 to currentNode
        currentNode = heapq.heappop(fringe)[1]
        # expanded nodes value increase
        nodes_e += 1

        # check if node is visited or not. If not, it enters it the route
        if (currentNode.city not in route) or (int(route[currentNode.city][1]) > currentNode.cost):
            valueRoute = [currentNode.parent.city if currentNode.parent is not None else None, currentNode.cost]
            route[currentNode.city] = valueRoute

        # If the destination is reached then stop
        if currentNode.city == dest_node:
            break
        # if the current city is in visited then skip it
        if currentNode.city in visited_Node:
            continue

        childrenCityInfo = infoCity[currentNode.city]

        for childrenCity in infoCity[currentNode.city]:
            child_cost = currentNode.cost + int(childrenCity[1])
            n = Node(childrenCity[0], currentNode, child_cost)
            heapq.heappush(fringe, (child_cost, n))

        # Adding the city to visited the node
        visited_Node.append(currentNode.city)

    # prints the output in the required format
    print_output(dest_node)

else:  # Informed search

    visited_Node = []

    # initialising fringe with source as src, dest as null and path as 0
    fringe = []
    heapq.heappush(fringe, (0, Node(source_node, None, 0, 0)))

    while fringe:
        # storing the node from fringe at index 0 to currentNode
        currentNode = heapq.heappop(fringe)[1]
        # expanded nodes value increase
        nodes_e += 1

        # check if node is visited or not. If not, it enters it the route
        if (currentNode.city not in route) or (int(route[currentNode.city][1]) > currentNode.cost):
            valueRoute = [currentNode.parent.city if currentNode.parent is not None else None, currentNode.cost]
            route[currentNode.city] = valueRoute

        # If the destination is reached then stop
        if currentNode.city == dest_node:
            break
        # if the current city is in visited then skip it
        if currentNode.city in visited_Node:
            continue

        childrenCityInfo = infoCity[currentNode.city]

        for childrenCity in infoCity[currentNode.city]:
            child_cost = currentNode.cost + int(childrenCity[1])

            h_cost = child_cost + hueristics[childrenCity[0]]

            n = Node(childrenCity[0], currentNode, child_cost, h_cost)
            heapq.heappush(fringe, (h_cost, n))

        # Adding the city to visited the node
        visited_Node.append(currentNode.city)

    # prints the output in the required format
    print_output(dest_node)
