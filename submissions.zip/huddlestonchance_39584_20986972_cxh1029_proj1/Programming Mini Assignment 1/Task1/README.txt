Chance Huddleston
1001241029
CSE 4308 Artificial Intelligence Programming Mini Assignment Task 1 Summer 2022

OS: Windows 10
Language: Python 3.9.9 64-bit
Omega Compatible: Unknown

The source code is found in find_route.py
Include all necessary file parameter arguments in the same directory as the program

Running Program:
1. Open command line interface / terminal
2. Navigate to the folder that the .zip file was extracted to and go to Task1 folder
    YOU MUST BE INSIDE FOLDER FOR PROJECT TO RUN
3. Type:
    3.1. For Informed Search:
        "python .\find_route.py [input_filename] [origin_city] [destination_city] [heuristic_filename]"
    3.2 For Uninformed Search: 
        "python .\find_route.py [input_filename] [origin_city] [destination_city]"
4. (If required) To install necessary missing packages:
    "pip install [package]"