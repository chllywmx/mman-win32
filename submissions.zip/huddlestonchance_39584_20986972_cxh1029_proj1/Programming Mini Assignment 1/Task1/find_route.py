#Chance Huddleston
#1001241029
# CSE4308 Artificial Intelligence Summer 2022
# Programming Mini-Assignment 1

from asyncio.windows_events import NULL
from cmath import inf
from queue import Queue
import sys

   
#A* Search that becomes uninformed search when heuristic not provided
def informed_search(source, destination, adjList, heuristic):
    #heuristic not provided, then becomes uninformed
    if heuristic == NULL or heuristic == None or heuristic == {}:
        return uninformed_search(source, destination, adjList)
    #Open list for keeping track of checkable nodes
    open_list = set([source])
    #Closed list for keeping track of trashed nodes
    closed_list = set([])
    #Path list for keeping track of path
    path = []
    #Used to trace path back to start node
    parent_map = {}
    parent_map[source] = source
    #Guess value for optimizing to destination
    guess = {}
    guess[source] = 0
    #Values for return
    expanded = 0
    popped = 0
    total_dist = 0
    route_set = []

    while len(open_list) > 0:
        current_node = None
        for i in open_list:
            if current_node == None or guess[i] + heuristic[i] < guess[current_node] + heuristic[current_node]:
                current_node = i
        #Path does not exist
        if current_node == None:
            print("Route does not exist")
            return None
        #Found destination, reconstruct path
        if current_node == destination:
            while parent_map[current_node]!=current_node:
                path.append(current_node)
                current_node = parent_map[current_node]
            path.append(source)
            path.reverse()

            #Calculate Distance and format path
            x = len(path)
            i=0
            while i +1 <x:
                for connects,value in adjList[path[i]]:
                    if connects == path[i+1]:
                        total_dist += value
                        temp = "{0} to {1}, {2} km".format(path[i],connects,value)
                        route_set.append(temp)
                i+=1

            
            #Output formatting
            print("Nodes Popped: ", popped)
            print("Nodes Expanded: ", expanded)
            print("Nodes Generated: ", len(open_list)+len(closed_list))
            print("Distance: ", total_dist ,"km")
            print("Route:")
            for x in route_set:
                print(x)

            return 
        try:
            #Get values of adjacent nodes (Expand)
            for(node, val) in adjList[current_node]:
                #Node current not in either list, add the parent node
                if node not in open_list and node not in closed_list:
                    open_list.add(node)
                    parent_map[node] = current_node
                    guess[node] = guess[current_node] + val
                    expanded +=1
                #Find if faster path
                else:
                    if guess[node] > guess[current_node] + val:
                        guess[node] = guess[current_node] + val
                        parent_map[node] = current_node
                        #Faster path found from a closed node
                        if node in closed_list:
                            closed_list.remove(node)
                            open_list.add(node)
                            popped -=1
                            expanded +=1
        except: 
            #Dead end node found, do nothing
            print("")
        #Node fully expanded, add to closed list
        open_list.remove(current_node)
        closed_list.add(current_node)
        popped +=1

    print("Path does not exist")
    return None


#Uninformed BFS search algorithm
def uninformed_search(source, destination, adjList):
    #Visited Nodes
    visited = set()
    #Queue
    queue = Queue()
    queue.put(source)
    #Keeping track of parent nodes
    parent_map = {}
    parent_map[source] = None
    #Output
    popped = 0
    expanded = 0
    total_dist = 0
    path = []
    route_set = []


    while not queue.empty():
        #Expand next node
        current_node = queue.get()

        #Path found, backtrack to source
        if current_node == destination:
            path.append(destination)
            while parent_map[destination] is not None:
                path.append(parent_map[destination])
                destination = parent_map[destination]
            path.reverse()
            #Complete, exit loop
            break
        try:
            #Expand adjacent edges of current node
            for (node, val) in adjList[current_node]:
                if node:
                    if node not in visited:
                        queue.put(node)
                        parent_map[node] = current_node
                        visited.add(node)
                        expanded+=1
        except:
            #dead end Node found, do nothing
            print("")


    #Calculate Distance and format path
    x = len(path)
    i=0
    while i +1 <x:
        for connects,value in adjList[path[i]]:
            if connects == path[i+1]:
                total_dist += value
                temp = "{0} to {1}, {2} km".format(path[i],connects,value)
                route_set.append(temp)
        i+=1

            
    #Output formatting
    print("Nodes Popped: ", popped)
    print("Nodes Expanded: ", expanded)
    print("Nodes Generated: ", len(visited))
    print("Distance: ", total_dist ,"km")
    print("Route:")
    for x in route_set:
        print(x)
    return





#Parsing Input
n = len(sys.argv)
if n > 5:
    print("Too many arguments\n")
    exit()

try:
    file_input = sys.argv[1]
    origin_city = sys.argv[2]
    destination_city = sys.argv[3]
    if n==5:
        histic_file= sys.argv[4]

except Exception:
    print("Incorrect argument formatting\n")
    print("find_route.py [input_filename] [origin_city] [destination_city] [heuristic_filename]\n")
    exit()

############ Task 1
# Implement a search algorithm that can find a route between any two cities. Your program will be called find_route, and will take exactly commandline arguments as follows:
# find_route input_filename origin_city destination_city heuristic_filename

    #Blank list of cities to add
adjList = {}
cityList = []


def add_node(node):
    if node not in cityList:
        cityList.append(node)

def add_connect(source, dest, val):
    temp=[]
    if source in cityList and dest in cityList:
        #Add source to list if not exists
        if source not in adjList:
            temp.append([dest, val])
            adjList[source] = temp
        #If source is already in list, add to list
        elif source in adjList:
            temp.extend(adjList[source])
            temp.append([dest,val])
            adjList[source]=temp
   
    
    #Build Nodes from input file
f=open(file_input, "r")
#Read Line
line = f.readline()
while line:
    if line is NULL or line == "END OF INPUT":
        break
    #Read cities 
        #read[0] = source City
        #read[1] = destination city
        #read[2] = cost value
    read = line.split()
    source = str(read[0])
    des = str(read[1])
    val = int(read[2])

    add_node(source)
    add_node(des)
    #Add the connections to the cities
    add_connect(source,des,val)
    #Add both connections if it's not a directed graph
    #add_connect(des,source,val)
    #Continue reading while there are lines
    line = f.readline()



######## Build Heuristic list ##########
hList = {}
hf = NULL

#Attach heuristic value to city
#Returns a dict
def add_histic(city, value):
    hList[city].append(value)


#If the file exists begin parsing
if(n==5):
    hf = open(histic_file, "r")
    line = hf.readline()
    while line:
        if line is NULL or line == "END OF INPUT":
            break
        #Read city and heuristic values
            #read[0] = city
            #read[1] = h(n)
        read = line.split()
        city = str(read[0])
        hn = int(read[1])
        hList[city] = hn

        line = hf.readline()

###############  DEBUG  ###################
#for node in adjList:
#    for name, val in adjList[node]:
#        print(name, val)
#print(hList)
#print(cityList)

############ Run Program ############
informed_search(origin_city, destination_city,adjList, hList)



