Chance Huddleston
1001241029 
CSE 4308 Artificial Intelligence Summer 2022

OS: Windows 10
Language: Python 3.9.9 64-bit
Omega Compatible: Unknown

maxconnect.py is the main source code, which will be used to run the code. Include all files in the same directory.
For measuring execution time, the time.bat file has been provided for a Windows machine to determine the execution time.
There are no out of the ordinary packages installed but just in case the computer is not up to date on currently included packages in Python 3,
the instructions have been provided.

Running Program:
1. Open command line interface
2. Navigate to the folder that the .zip file was extracted to and go to Task2 folder
    YOU MUST BE INSIDE FOLDER FOR PROJECT TO RUN
3. Type:
    3.1. For interactive mode: 
            ".\time python .\maxconnect4.py interactive [input_file] [computer-next/human-next] [depth]"
    3.2. For one move mode: 
            ".\time python .\maxconnect4.py one-move [input_file] [output_file] [depth]"
4. (If required) To install necessary missing packages:
    "pip install [package]"