#!/usr/bin/env python

# Written by Chris Conly based on C++
# code provided by Dr. Vassilis Athitsos
# Written to be Python 2.4 compatible for omega

from ast import arg
import sys
import math
from MaxConnect4Game import *
import copy



#minimax algortithm with Alpha Beta Pruning
def minimax(currentGame, depth, alpha, beta, maximizingPlayer):
    valid_move = currentGame.valid_locations()
    print(valid_move)
    if depth == 0:
        return(None, currentGame.countScore())
    #Maximizing Player (Player)
    if maximizingPlayer:
        value = -math.inf
        #Default if no best column found
        column = random.choice(valid_move)
        #Check each column for the best move
        for col in valid_move:
            #Use the player2Score to figure out which column is the best play
            col_check, val = minimax(currentGame,int(depth)-1,alpha,beta,False)
            #If the score is better than another column, return better column
            if val > value:
                value = val
                column = col
            alpha = max(alpha, value)
            #Pruning
            if alpha >= beta:
                break
        return column, currentGame.player2Score
    #Minimizing Player (Opponent)
    else:
        value = math.inf
        #Default if no best column found
        column = random.choice(valid_move)
        #Check each column for the best move
        for col in valid_move:
            #Assume Player 1 wants to win and selects best decision
            col_check, val = minimax(currentGame,int(depth)-1,alpha,beta,True)
            #if the score is better than another column, return better column
            if val:
                if val < value:
                    value = val
                    column = col
            beta = min(beta,value)
            #Pruning
            if alpha >= beta:
                break
        return column, currentGame.player1Score
        

def oneMoveGame(currentGame, depth):
    if currentGame.pieceCount == 42:    # Is the board full already?
        print('BOARD FULL\n\nGame Over!\n')
        sys.exit(0)
    
    #currentGame.aiPlay() # Make a move (only random is implemented)
    check = copy.copy(currentGame)
    play_col, val = minimax(check,depth,10,-10,True)
    currentGame.playPiece(play_col)
    print('Game state after move:')
    currentGame.printGameBoard()

    currentGame.countScore()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))

    currentGame.printGameBoardToFile()
    currentGame.gameFile.close()


def interactiveGame(currentGame,playerTurn, depth):
    if currentGame.pieceCount == 42:    # Is the board full already?
        print('BOARD FULL\n\nGame Over!\n')
        sys.exit(0)

    #It is now the players turn
    if(playerTurn):
        currentGame.currentTurn=1
        col = input("Enter column # [1-7]: ")
        #Make sure the column is valid
        while not int(col) or int(col) > 7 or int(col) < 1:
            col = input("Enter valid column # [1-7]: ")
        currentGame.playPiece(int(col)-1)
        print('Game state after move:')
        currentGame.printGameBoard()
        playerTurn = False
    #It is the AI turn
    else:
        currentGame.currentTurn=2
        check = copy.copy(currentGame)
        play_col, val = minimax(check,depth,10,-10,True)
        currentGame.playPiece(play_col)
        print('Game state after move:')
        currentGame.printGameBoard()
        playerTurn = True

    currentGame.countScore()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))
    interactiveGame(currentGame, playerTurn, depth)



def main(argv):
    # Make sure we have enough command-line arguments
    if len(argv) != 5:
        print('Four command-line arguments are needed:')
        print('Usage: %s interactive [input_file] [computer-next/human-next] [depth]' % argv[0])
        print('or: %s one-move [input_file] [output_file] [depth]' % argv[0])
        sys.exit(2)

    game_mode, inFile = argv[1:3]

    if not game_mode == 'interactive' and not game_mode == 'one-move':
        print('%s is an unrecognized game mode' % game_mode)
        sys.exit(2)

    currentGame = maxConnect4Game() # Create a game

    # Try to open the input file
    try:
        currentGame.gameFile = open(inFile, 'r')
    except IOError:
        sys.exit("\nError opening input file.\nCheck file name.\n")

    # Read the initial game state from the file and save in a 2D list
    file_lines = currentGame.gameFile.readlines()
    currentGame.gameBoard = [[int(char) for char in line[0:7]] for line in file_lines[0:-1]]
    currentGame.currentTurn = int(file_lines[-1][0])
    currentGame.gameFile.close()

    print('\nMaxConnect-4 game\n')
    print('Game state before move:')
    currentGame.printGameBoard()

    # Update a few game variables based on initial state and print the score
    currentGame.checkPieceCount()
    currentGame.countScore()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))

    if game_mode == 'interactive':
        if argv[3] == "human-next":
            playerTurn = True
        else:
            playerTurn = False
        interactiveGame(currentGame, playerTurn, argv[4]) # Be sure to pass whatever else you need from the command line
    else: # game_mode == 'one-move'
        # Set up the output file
        outFile = argv[3]
        try:
            currentGame.gameFile = open(outFile, 'w')
        except:
            sys.exit('Error opening output file.')
        oneMoveGame(currentGame, argv[4]) # Be sure to pass any other arguments from the command line you might need.

if __name__ == '__main__':
    main(sys.argv)


