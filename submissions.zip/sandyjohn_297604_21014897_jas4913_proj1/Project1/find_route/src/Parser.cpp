#include "Parser.hpp"
#include <sstream>
#include <iostream>
#include <stdexcept>

Parser::Parser(std::string const fileName)
{
    inputFile.open(fileName);
    if(!inputFile.is_open())
    {
        throw std::invalid_argument("Could not open file");
    }
}

searchTree Parser::extractSearchTree()
{
    std::string line;
    while(std::getline(inputFile, line))
    {
        if(line.compare(END_TOKEN) == 0)
        {   
            //We reached the end of the file.
            break;
        }

        //Find the start of this edge
        size_t spacePosOne = line.find_first_of(SPACE);
        std::string start = line.substr(0, spacePosOne);

        //Find the end of this edge
        size_t spacePosTwo = line.find(SPACE, spacePosOne+1);
        std::string end = line.substr(spacePosOne+1, (spacePosTwo - spacePosOne- 1));

        //Find the cost of this edge
        std::string costStr = line.substr(spacePosTwo+1, line.length());
        double cost(0.0);
        try
        {
            cost = std::stod(costStr);        
        }
        catch(const std::invalid_argument& e)
        {
            std::cerr << "ERROR: Unable to parse the cumCost provided for edge on the following line:" << std::endl;
            std::cerr << line << std::endl;
            std::cerr << "Exiting.";
        }

        auto currentNeighbors = myTree.find(start);
        if(currentNeighbors == myTree.end()){
            neighMap newNeigh;
            myTree[start] = newNeigh;
        }

        (myTree[start])[end] = cost;

        currentNeighbors = myTree.find(end);
        if(currentNeighbors == myTree.end()){
            neighMap newNeigh;
            myTree[end] = newNeigh;
        }

        (myTree[end])[start] = cost;

    }

    //TODO: Delete this debug code.
    //std::cout << "I've parsed the search tree. It looks like this:" << std::endl;
    //for (auto& x: myTree)
    //{
    //    std::cout << "City: " << x.first << " Has neighors (cumCost): " << std::endl;
    //    for (auto& y: x.second)
    //    {
    //        std::cout << "    " << y.first << "(" << y. second << ")" << std::endl;
    //    } 
    //}
    return myTree;

}

heurMap Parser::extractHeuristics()
{
    std::string line;
    while(std::getline(inputFile, line))
    {
        if(line.compare(END_TOKEN) == 0)
        {   
            //We reached the end of the file.
            break;
        }

        //Find the node with this heuristic
        size_t spacePosOne = line.find_first_of(SPACE);
        std::string node = line.substr(0, spacePosOne);

        //Find the cost of this edge
        std::string costStr = line.substr(spacePosOne+1, line.length());
        double cost(0.0);
        try
        {
            cost = std::stod(costStr);        
        }
        catch(const std::invalid_argument& e)
        {
            std::cerr << "ERROR: Unable to parse the cumCost provided for edge on the following line:" << std::endl;
            std::cerr << line << std::endl;
            std::cerr << "Exiting.";
        }

        myHeuristicMap[node] = cost;

    }

    //TODO: Delete this debug code.
    //std::cout << "I've parsed the heuristics. It looks like this:" << std::endl;
    //for (auto& x: myHeuristicMap)
    //{
    //    std::cout << x.first << " Has heuristic : " << x.second << std::endl;
    //}

    return myHeuristicMap;
}

Parser::~Parser()
{
    if(inputFile.is_open())
    {
        inputFile.close();
    }
}