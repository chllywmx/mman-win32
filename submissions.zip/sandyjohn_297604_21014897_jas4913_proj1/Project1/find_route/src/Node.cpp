#include "Node.hpp"

Node::Node(std::string name, int depth, double cumCost, double moveCost):
name(name),
cumCost(cumCost),
moveCost(moveCost),
depth(depth),
parentLink(nullptr)
{
    //nothing to do
}



bool Node::operator <(const Node &rhs) const
{
    return (this->cumCost < rhs.cumCost);
}

bool Node::operator >(const Node &rhs) const
{
    return (this->cumCost > rhs.cumCost);
}

bool Node::operator ==(const Node &rhs) const
{
    return (this->cumCost == rhs.cumCost);
}

void Node::addChild(std::shared_ptr<Node> child)
{
    child->setParent(shared_from_this());
}

void Node::setParent(std::shared_ptr<Node> parentPtr)
{
    this->parentLink = parentPtr;
}