// The main executive for searching
#include <iostream>
#include <queue>
#include <unordered_set>
#include <stack>

#include <Search.hpp>

bool Search::uniformCostSearch(searchTree stateSpace, std::string origin, std::string destination)
{
    //First, make the root node of the search:
    std::shared_ptr<Node> rootNode = std::make_shared<Node>(origin, 0, 0, 0);
    rootNode->setParent(nullptr);
    nodesPopped = 0;
    nodesGenerated = 1;
    nodesExpanded = 0;

    auto compare = [](std::shared_ptr<Node> lhs, std::shared_ptr<Node> rhs){ return (rhs->cumCost < lhs->cumCost);};

    using ucsFringe = std::priority_queue<std::shared_ptr<Node>, std::vector<std::shared_ptr<Node>>, decltype(compare)>;
    using closedSet = std::unordered_set<std::string>;

    ucsFringe theFringe(compare);
    theFringe.push(rootNode);

    closedSet clSet;

    int depth = 1;

    while(!theFringe.empty())
    {
        std::shared_ptr<Node> thisNode = theFringe.top();
        theFringe.pop();
        nodesPopped++;
 
        if(thisNode->name.compare(destination) == 0)
        {
            endGoal = thisNode;
            return true;
        }

        //Only expand the node if it is not already in the closed set.
        if(clSet.find(thisNode->name) == clSet.end())
        {
            neighMap cands = stateSpace[thisNode->name];
            nodesExpanded++;
            expandedNodes.push_back(thisNode);
            for(auto& map: cands)
            {
                std::shared_ptr<Node> newNode = std::make_shared<Node>(map.first, depth, thisNode->cumCost + map.second, map.second);
                thisNode->addChild(newNode);
                nodesGenerated++;
                theFringe.push(newNode);
            }
        }

        clSet.insert(thisNode->name);

    }

    return false;
}

bool Search::aStarSearch(searchTree stateSpace, heurMap heuristics, std::string origin, std::string destination)
{
    //First, make the root node of the search:
    std::shared_ptr<Node> rootNode = std::make_shared<Node>(origin, 0, 0, 0);
    rootNode->setParent(nullptr);
    nodesPopped = 0;
    nodesGenerated = 1;
    nodesExpanded = 0;

    auto compare = [heuristics](std::shared_ptr<Node> lhs, std::shared_ptr<Node> rhs){
         return ((rhs->cumCost + heuristics.at(rhs->name)) < lhs->cumCost + heuristics.at(lhs->name));};

    using aStarFringe = std::priority_queue<std::shared_ptr<Node>, std::vector<std::shared_ptr<Node>>, decltype(compare)>;
    using closedSet = std::unordered_set<std::string>;

    aStarFringe theFringe(compare);
    theFringe.push(rootNode);

    closedSet clSet;

    int depth = 1;

    while(!theFringe.empty())
    {
        std::shared_ptr<Node> thisNode = theFringe.top();
        theFringe.pop();
        nodesPopped++;
 
        if(thisNode->name.compare(destination) == 0)
        {
            endGoal = thisNode;
            return true;
        }

        //Only expand the node if it is not already in the closed set.
        if(clSet.find(thisNode->name) == clSet.end())
        {
            neighMap cands = stateSpace[thisNode->name];
            nodesExpanded++;
            expandedNodes.push_back(thisNode);
            for(auto& map: cands)
            {
                std::shared_ptr<Node> newNode = std::make_shared<Node>(map.first, depth, thisNode->cumCost + map.second, map.second);
                thisNode->addChild(newNode);
                nodesGenerated++;
                theFringe.push(newNode);
            }
        }

        clSet.insert(thisNode->name);

    }

    return false;
}


void Search::unwindAndPrintSearch()
{
    std::cout << "Nodes Popped: " << nodesPopped << std::endl;
    std::cout << "Nodes Expanded: " << nodesExpanded << std::endl;
    std::cout << "Nodes Generated: " << nodesGenerated << std::endl;
    std::cout << "Distance: " << endGoal->cumCost << " km"  << std::endl;
    std::cout << "Route: " << std::endl;

    std::shared_ptr<Node> chain = endGoal;
    std::stack<std::shared_ptr<Node>> stackedNodes;

    while(chain)
    {
        stackedNodes.push(chain);
        chain = chain->parentLink;
    }

    std::shared_ptr<Node> lastPtr = stackedNodes.top();
    stackedNodes.pop();

    while(!stackedNodes.empty())
    {
        std::shared_ptr<Node> thisPtr = stackedNodes.top();
        stackedNodes.pop();

        std::cout << lastPtr->name << " to " << thisPtr->name << ", " << thisPtr->moveCost << " km" << std::endl;

        lastPtr = thisPtr;
    }
     
}

void Search::printFailedSearch()
{
    std::cout << "Nodes Popped: " << nodesPopped << std::endl;
    std::cout << "Nodes Expanded: " << nodesExpanded << std::endl;
    std::cout << "Nodes Generated: " << nodesGenerated << std::endl;
    std::cout << "Distance: infinity" << std::endl;
    std::cout << "Route: " << std::endl;
    std::cout << "None" << std::endl;
}
