#include <iostream>

#include "Search.hpp"
#include "Parser.hpp"

int main(int argc, char** argv)
{

    if(argc != 4 && argc != 5)
    {
        std::cout << "Usage: find_route input_filename origin_city destination_city [heuristic_filename]" << std::endl;
        std::cout << "If a heuristic_filename is provided, informed search will be performed. Otherwise, uninformed search" << std::endl;
        std::cerr << "Invalid arguments. Exiting.";
        return 1;
    }

    //Injest inputs from the command line
    const char* statesFile = argv[1];
    const char* origin = argv[2];
    const char* destination = argv[3];

    const char* heurFile = nullptr;
    if (argc == 5)
    {
        heurFile = argv[4];
    }

    std::unique_ptr<Parser> inpParser;
    //Try to construct the parser objects. If it fails to find the file,
    // it will throw an exception. 
    try
    {
        inpParser = std::make_unique<Parser>(statesFile);
    }
    catch(const std::invalid_argument& e)
    {
        std::cerr << "ERROR: " << e.what() << statesFile << '\n';
        std::cerr << "Exiting.";
        return 1;
    }

    std::unique_ptr<Parser> heurParser;
    heurMap heuristics;
    if(heurFile)
    {
        try
        {
            heurParser = std::make_unique<Parser>(heurFile);
        }
        catch(const std::invalid_argument& e)
        {
            std::cerr << "ERROR: " << e.what() << heurFile << '\n';
            std::cerr << "Exiting.";
            return 1;
        }
        heuristics = heurParser->extractHeuristics();
    }

    searchTree theSearchSpace = inpParser->extractSearchTree();

    if(theSearchSpace.find(origin) == theSearchSpace.end() || theSearchSpace.find(destination) == theSearchSpace.end())
    {
        std::cerr << "Unable to locate origin and/or destination in search space." << std::endl;
        std::cerr << "Exiting.";
        return 1;        
    }

    std::cout << "Searching for path from " << origin << " to " << destination << std::endl;

    std::unique_ptr<Search> search = std::make_unique<Search>();

    bool success = false;
    
    if(heurParser)
    {
        success = search->aStarSearch(theSearchSpace, heuristics, origin, destination);
    }
    else 
    {
        success = search->uniformCostSearch(theSearchSpace, origin, destination);
    }

    if (success)
    {
        search->unwindAndPrintSearch();
    } else
    {
        search->printFailedSearch();
    }
    
}