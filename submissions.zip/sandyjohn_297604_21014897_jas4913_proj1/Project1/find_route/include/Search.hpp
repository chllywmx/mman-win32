#ifndef SEARCH_H
#define SEARCH_H

#include "Parser.hpp" //TODO: Search shouldn't need parser
#include <Node.hpp>
#include <vector>

class Search
{

    public:     
        bool uniformCostSearch(searchTree stateSpace, std::string origin, std::string destination);
        bool aStarSearch(searchTree stateSpace, heurMap heuristics, std::string origin, std::string destination);
        void unwindAndPrintSearch(void);
        void printFailedSearch(void);


    private:
        int nodesPopped;
        int nodesGenerated;
        int nodesExpanded;

        std::vector<std::shared_ptr<Node>> expandedNodes;

        std::shared_ptr<Node> endGoal; 

};

#endif //SEARCH_H