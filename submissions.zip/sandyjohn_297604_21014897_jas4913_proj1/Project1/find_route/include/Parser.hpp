
#ifndef PARSER_H
#define PARSER_H

#include <string>
#include <fstream>

#include <unordered_map>

using neighMap = std::unordered_map<std::string, double>;
using searchTree = std::unordered_map<std::string, neighMap>;
using heurMap = std::unordered_map<std::string, double>;

class Parser
{
    public:
    //RAII this class
    Parser(std::string fileName);

    ~Parser();

    searchTree extractSearchTree(void);
    heurMap extractHeuristics(void);


    private:
       std::ifstream inputFile;
       searchTree myTree;
       heurMap    myHeuristicMap;
       inline static constexpr char* END_TOKEN = "END OF INPUT";
       inline static constexpr char* SPACE = " ";

};

#endif //PARSER_H