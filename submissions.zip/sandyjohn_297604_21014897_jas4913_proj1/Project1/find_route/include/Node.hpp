// This file describes the data structure representing a node in a search algorithm
#ifndef NODE_H
#define NODE_H

#include <string>
#include <memory>

class Node : public std::enable_shared_from_this<Node>
{
public:

    Node::Node(void):
        name(""),
        cumCost(-1),
        moveCost(-1),
        depth(-1),
        parentLink(nullptr)
        {
          //Nothing else to do
        }

    Node(std::string name, int depth, double cumCost, double moveCost);

    bool operator <(const Node &rhs) const;

    bool operator >(const Node &rhs) const;

    bool operator ==(const Node &rhs) const;

    std::string name;
    double cumCost;
    double moveCost;
    int depth;
    std::shared_ptr<Node> parentLink;

    void addChild(std::shared_ptr<Node> child);
    void setParent(std::shared_ptr<Node> parent);
   
};

#endif //NODE_H