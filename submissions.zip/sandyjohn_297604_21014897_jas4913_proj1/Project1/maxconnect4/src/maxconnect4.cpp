// MaxConnect-4 code

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <memory>
#include <array>

#include <vector>
#include <iostream>

#include <string>

class gameStatus     
{ 
private:
  std::array<long, 42> gameData;

public: 
  long * gameBoard[6];
  long currentTurn;
  int player1Score;
  int player2Score;
  int pieceCount;
  FILE *gameFile;

  gameStatus()
  {
    gameBoard[0] = &((gameData)[0]);
    gameBoard[1] = &((gameData)[7]);
    gameBoard[2] = &((gameData)[14]);
    gameBoard[3] = &((gameData)[21]);
    gameBoard[4] = &((gameData)[28]);
    gameBoard[5] = &((gameData)[35]);

    int i;
    for (i = 0; i < 42; i++)
    {
      gameData[i] = 0;
    }

    currentTurn = 1;
    player1Score = 0;
    player2Score = 0;
    pieceCount = 0;
    gameFile = 0;
  }

  //Copy Constructor
  gameStatus (const gameStatus &orig)
  {

	gameBoard[0] = &((gameData)[0]);
    gameBoard[1] = &((gameData)[7]);
    gameBoard[2] = &((gameData)[14]);
    gameBoard[3] = &((gameData)[21]);
    gameBoard[4] = &((gameData)[28]);
    gameBoard[5] = &((gameData)[35]);

	
    int i;
    for (i = 0; i < 42; i++)
    {
      gameData[i] = orig.gameData[i];
    }
    
	currentTurn  = orig.currentTurn ;
    player1Score = orig.player1Score;
    player2Score = orig.player2Score;
    pieceCount   = orig.pieceCount  ;
    gameFile     = orig.gameFile    ;

  }

};

// Output current game status to console
void printGameBoard(gameStatus &currentGame)
{
  int i = 0;
  int j = 0;
  printf(" -----------------\n");
  for(i = 0; i < 6; i++)
  {    
    printf(" | ");
    for(j = 0; j < 7; j++)
    {
      printf("%li ", currentGame.gameBoard[i][j]);
    }
    printf("| \n");
  }
  printf(" -----------------\n");
}

// Output current game status to file
void printGameBoardToFile(gameStatus &currentGame)
{
    int i = 0;
    int j = 0;
    for(i = 0; i < 6; i++)
    {    
        for(j = 0; j < 7; j++)
        {
            fprintf(currentGame.gameFile, "%li", currentGame.gameBoard[i][j]);
        }
        fprintf(currentGame.gameFile, "\r\n");
    }
    fprintf(currentGame.gameFile, "%d\r\n", currentGame.currentTurn);
}

// Given a column and which player it is, 
// place that player's piece in the requested column
int playPiece(int column, gameStatus &currentGame)
{
    // if column full, return 0 
    if(currentGame.gameBoard[0][column] != 0)
  {
        return 0;
  }
    
  int i;
    // starting at the bottom of the board, place the piece into the
    // first empty spot
    for(i = 5; i >= 0; i--)
    {
        if(currentGame.gameBoard[i][column] == 0)
        {
            currentGame.gameBoard[i][column] = currentGame.currentTurn;
            currentGame.pieceCount++;
            return 1;
        }
    }
  return 0;
}

using score = int;

int miniMaxDecision(const gameStatus currentStatus, int depthLimit);
score maxValue(gameStatus currentStatus, int& alpha, int& beta, int depthLimit);
score minValue(gameStatus currentStatus, int& alpha, int& beta, int depthLimit);
bool isTerminalState(gameStatus currentStatus);
std::vector<int> possibleMoves(gameStatus currentStatus);
void countScore(gameStatus &currentGame);
score evaluationFunction(gameStatus currentGame);

// The AI section. Now plays minimax
void aiPlay(gameStatus &currentGame, int depthLimit)
{    

   //This is where minimax goes....
   gameStatus cpy(currentGame);
    int column = miniMaxDecision(cpy, depthLimit);

    int result = 0;

    result = playPiece(column, currentGame);
    if(result == 0)
  {
        std::cerr << "Picked a non-possible move!" << std::endl;
        return;
  }
  else
  {
    printf("\n\nmove %li: Player %li, column %li\n", 
           currentGame.pieceCount, currentGame.currentTurn, column+1);
        if(currentGame.currentTurn == 1)
            currentGame.currentTurn = 2;
        else if (currentGame.currentTurn == 2)
            currentGame.currentTurn = 1;
  }
}

bool isTerminalState(gameStatus currentStatus)
{
    for(int i = 0; i < 6; i++)
    {
        for(int j = 0; j < 7; j++)
        {
            if (currentStatus.gameBoard[i][j] == 0) 
            {
            return false;
            }
        }
    }
    return true;
}

std::vector<int> possibleMoves(gameStatus currentStatus)
{
    std::vector<int> possMoves;
    for(int j = 0; j < 7; j++)
    {
		int spaceVal = currentStatus.gameBoard[0][j];
        if (spaceVal == 0) 
        {
            possMoves.push_back(j);
        }
    }
    return possMoves;
}

int miniMaxDecision(gameStatus currentStatus, int depthLimit)
{
    int alpha = INT32_MIN;
    int beta = INT32_MAX;
    int maxScore = INT32_MIN;
    int bestMove = -1;

    int termLimit = currentStatus.pieceCount + depthLimit;
	std::vector<int> moves = possibleMoves(currentStatus);
    for(int col :moves)
    {
        gameStatus theoryJ = currentStatus;
        playPiece(col, theoryJ);
        int jScore = minValue(theoryJ, alpha, beta, termLimit);
        if (jScore > maxScore)
        {
             maxScore = jScore;
             bestMove = col;
        }
    }
    return bestMove;
}

score maxValue(gameStatus currentStatus, int& alpha, int& beta, int depthLimit)
{
    score result = 0;
    if(isTerminalState(currentStatus))
    {
       countScore(currentStatus);
       if (currentStatus.currentTurn == 1)
       {
           result = currentStatus.player1Score - currentStatus.player2Score;
       }
       else if (currentStatus.currentTurn == 2)
       {
           result = currentStatus.player2Score - currentStatus.player1Score;
       }
    }
    else if(currentStatus.pieceCount >= depthLimit)
    {
        result = evaluationFunction(currentStatus);
    }
    else 
    {
        int maxScore = INT32_MIN;
        for(int col : possibleMoves(currentStatus))
        {
            gameStatus theoryJ = currentStatus;
            playPiece(col, theoryJ);
            int jScore = minValue(theoryJ, alpha, beta, depthLimit);
            if (jScore > maxScore)
            {
                 maxScore = jScore;
            }
            if (maxScore >= beta)
            {
                break;
            }
            if (maxScore > alpha)
            {
                alpha = maxScore;
            }
        }
        return maxScore;
    }
}

score minValue(gameStatus currentStatus, int& alpha, int& beta, int depthLimit)
{
    score result = 0;
    if(isTerminalState(currentStatus))
    {
       countScore(currentStatus);
       if (currentStatus.currentTurn == 1)
       {
           result = currentStatus.player1Score - currentStatus.player2Score;
       }
       else if (currentStatus.currentTurn == 2)
       {
           result = currentStatus.player2Score - currentStatus.player1Score;
       }
    }
    else if(currentStatus.pieceCount >= depthLimit)
    {
        result = evaluationFunction(currentStatus);
    }
    else 
    {
        int minScore = INT32_MAX;
        for(int col : possibleMoves(currentStatus))
        {
            gameStatus theoryJ = currentStatus;
            playPiece(col, theoryJ);
            int jScore = maxValue(theoryJ, alpha, beta, depthLimit);
            if (jScore <  minScore)
            {
                 minScore = jScore;
            }
            if(minScore <= alpha)
            {
                break;
            }
            if(minScore < beta)
            {
                beta = minScore;
            }
        }
        return minScore;
    }
}

score evaluationFunction(gameStatus currentGame)
{
    currentGame.player1Score = 0;
    currentGame.player2Score = 0;

    //scan for horizontal scores:
    for (int i = 0; i < 6; ++i)
    {
        int currentStreak(0);
        int lastVal(0);
        for (int j = 0; j < 7; ++j)
        {
            int thisVal = currentGame.gameBoard[i][j];
            bool onStreak = false;
            if(thisVal == lastVal && thisVal != 0)
            {
                //Add to the current streak!
                currentStreak++;
                onStreak = true;
            }
            bool streakEnded = currentStreak != 0 && !onStreak;
            bool endOfRow = currentStreak != 0 && onStreak && j == 6;
            if(streakEnded || endOfRow)
            {
                if(currentStreak >= 3)
                {
                    //Give a huge reward for getting 4 or more in a row.
                    currentStreak *= 2;
                }
                //A Streak just ended, score and reset
                if(lastVal == 1)
                {
                    currentGame.player1Score += currentStreak;
                }
                else if(lastVal == 2)
                {
                    currentGame.player2Score += currentStreak;
                }
                currentStreak = 0;
            }

            lastVal = thisVal;
        }
    }

    //scan for vertical scores:
    for (int j = 0; j < 7; ++j)
    {
        int currentStreak(0);
        int lastVal(0);
        for (int i = 0; i < 6; ++i)
        {
            int thisVal = currentGame.gameBoard[i][j];
            if(thisVal == lastVal && thisVal != 0)
            {
                //Add to the current streak!
                currentStreak++;
            }
            else if(currentStreak != 0)
            {
                //A Streak just ended, score and reset
                if(lastVal == 1)
                {
                    currentGame.player1Score += currentStreak;
                }
                else if(lastVal == 2)
                {
                    currentGame.player2Score += currentStreak;
                }
                currentStreak = 0;
            }

            lastVal = thisVal;
        }
    }

    score maxedScore(0);
    if (currentGame.currentTurn == 1)
    {
        maxedScore = currentGame.player1Score - currentGame.player2Score;
    }
    else if (currentGame.currentTurn == 2)
    {
        maxedScore = currentGame.player2Score - currentGame.player1Score;
    }
    else 
    {
        std::cerr << "Whose turn is it?!" << std::endl;
    }
    return maxedScore;
}

void countScore(gameStatus &currentGame)
{
  currentGame.player1Score = 0; 
  currentGame.player2Score = 0; 

  //check horizontally
  int i;
  for(i = 0; i < 6; i++)
  {
        //check player 1
        if(currentGame.gameBoard[i][0] == 1 && currentGame.gameBoard[i][1] == 1 
            && currentGame.gameBoard[i][2] == 1 && currentGame.gameBoard[i][3] == 1)
            {currentGame.player1Score++;}
        if(currentGame.gameBoard[i][1] == 1 && currentGame.gameBoard[i][2] == 1 
            && currentGame.gameBoard[i][3] == 1 && currentGame.gameBoard[i][4] == 1)
            {currentGame.player1Score++;}
        if(currentGame.gameBoard[i][2] == 1 && currentGame.gameBoard[i][3] == 1 
            && currentGame.gameBoard[i][4] == 1 && currentGame.gameBoard[i][5] == 1)
            {currentGame.player1Score++;}
        if(currentGame.gameBoard[i][3] == 1 && currentGame.gameBoard[i][4] == 1 
            && currentGame.gameBoard[i][5] == 1 && currentGame.gameBoard[i][6] == 1)
            {currentGame.player1Score++;}
        //check player 2
        if(currentGame.gameBoard[i][0] == 2 && currentGame.gameBoard[i][1] == 2 
            && currentGame.gameBoard[i][2] == 2 && currentGame.gameBoard[i][3] == 2)
            {currentGame.player2Score++;}
        if(currentGame.gameBoard[i][1] == 2 && currentGame.gameBoard[i][2] == 2 
            && currentGame.gameBoard[i][3] == 2 && currentGame.gameBoard[i][4] == 2)
            {currentGame.player2Score++;}
        if(currentGame.gameBoard[i][2] == 2 && currentGame.gameBoard[i][3] == 2 
            && currentGame.gameBoard[i][4] == 2 && currentGame.gameBoard[i][5] == 2)
            {currentGame.player2Score++;}
        if(currentGame.gameBoard[i][3] == 2 && currentGame.gameBoard[i][4] == 2 
            && currentGame.gameBoard[i][5] == 2 && currentGame.gameBoard[i][6] == 2)
            {currentGame.player2Score++;}
    }

    //check vertically
    int j;
    for(j = 0; j < 7; j++)
    {
        //check player 1
        if(currentGame.gameBoard[0][j] == 1 && currentGame.gameBoard[1][j] == 1 
            && currentGame.gameBoard[2][j] == 1 && currentGame.gameBoard[3][j] == 1)
            {currentGame.player1Score++;}
        if(currentGame.gameBoard[1][j] == 1 && currentGame.gameBoard[2][j] == 1 
            && currentGame.gameBoard[3][j] == 1 && currentGame.gameBoard[4][j] == 1)
            {currentGame.player1Score++;}
        if(currentGame.gameBoard[2][j] == 1 && currentGame.gameBoard[3][j] == 1 
            && currentGame.gameBoard[4][j] == 1 && currentGame.gameBoard[5][j] == 1)
            {currentGame.player1Score++;}
        //check player 2
        if(currentGame.gameBoard[0][j] == 2 && currentGame.gameBoard[1][j] == 2 
            && currentGame.gameBoard[2][j] == 2 && currentGame.gameBoard[3][j] == 2)
            {currentGame.player2Score++;}
        if(currentGame.gameBoard[1][j] == 2 && currentGame.gameBoard[2][j] == 2 
            && currentGame.gameBoard[3][j] == 2 && currentGame.gameBoard[4][j] == 2)
            {currentGame.player2Score++;}
        if(currentGame.gameBoard[2][j] == 2 && currentGame.gameBoard[3][j] == 2 
            && currentGame.gameBoard[4][j] == 2 && currentGame.gameBoard[5][j] == 2)
            {currentGame.player2Score++;}
    }

    //check diagonally
    
    //check player 1
    if(currentGame.gameBoard[2][0] == 1 && currentGame.gameBoard[3][1] == 1 
        && currentGame.gameBoard[4][2] == 1 && currentGame.gameBoard[5][3] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[1][0] == 1 && currentGame.gameBoard[2][1] == 1 
        && currentGame.gameBoard[3][2] == 1 && currentGame.gameBoard[4][3] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[2][1] == 1 && currentGame.gameBoard[3][2] == 1 
        && currentGame.gameBoard[4][3] == 1 && currentGame.gameBoard[5][4] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[0][0] == 1 && currentGame.gameBoard[1][1] == 1 
        && currentGame.gameBoard[2][2] == 1 && currentGame.gameBoard[3][3] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[1][1] == 1 && currentGame.gameBoard[2][2] == 1 
        && currentGame.gameBoard[3][3] == 1 && currentGame.gameBoard[4][4] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[2][2] == 1 && currentGame.gameBoard[3][3] == 1 
        && currentGame.gameBoard[4][4] == 1 && currentGame.gameBoard[5][5] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[0][1] == 1 && currentGame.gameBoard[1][2] == 1 
        && currentGame.gameBoard[2][3] == 1 && currentGame.gameBoard[3][4] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[1][2] == 1 && currentGame.gameBoard[2][3] == 1 
        && currentGame.gameBoard[3][4] == 1 && currentGame.gameBoard[4][5] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[2][3] == 1 && currentGame.gameBoard[3][4] == 1 
        && currentGame.gameBoard[4][5] == 1 && currentGame.gameBoard[5][6] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[0][2] == 1 && currentGame.gameBoard[1][3] == 1 
        && currentGame.gameBoard[2][4] == 1 && currentGame.gameBoard[3][5] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[1][3] == 1 && currentGame.gameBoard[2][4] == 1 
        && currentGame.gameBoard[3][5] == 1 && currentGame.gameBoard[4][6] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[0][3] == 1 && currentGame.gameBoard[1][4] == 1 
        && currentGame.gameBoard[2][5] == 1 && currentGame.gameBoard[3][6] == 1)
            {currentGame.player1Score++;}

    if(currentGame.gameBoard[0][3] == 1 && currentGame.gameBoard[1][2] == 1 
        && currentGame.gameBoard[2][1] == 1 && currentGame.gameBoard[3][0] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[0][4] == 1 && currentGame.gameBoard[1][3] == 1 
        && currentGame.gameBoard[2][2] == 1 && currentGame.gameBoard[3][1] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[1][3] == 1 && currentGame.gameBoard[2][2] == 1 
        && currentGame.gameBoard[3][1] == 1 && currentGame.gameBoard[4][0] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[0][5] == 1 && currentGame.gameBoard[1][4] == 1 
        && currentGame.gameBoard[2][3] == 1 && currentGame.gameBoard[3][2] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[1][4] == 1 && currentGame.gameBoard[2][3] == 1 
        && currentGame.gameBoard[3][2] == 1 && currentGame.gameBoard[4][1] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[2][3] == 1 && currentGame.gameBoard[3][2] == 1 
        && currentGame.gameBoard[4][1] == 1 && currentGame.gameBoard[5][0] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[0][6] == 1 && currentGame.gameBoard[1][5] == 1 
        && currentGame.gameBoard[2][4] == 1 && currentGame.gameBoard[3][3] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[1][5] == 1 && currentGame.gameBoard[2][4] == 1 
        && currentGame.gameBoard[3][3] == 1 && currentGame.gameBoard[4][2] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[2][4] == 1 && currentGame.gameBoard[3][3] == 1 
        && currentGame.gameBoard[4][2] == 1 && currentGame.gameBoard[5][1] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[1][6] == 1 && currentGame.gameBoard[2][5] == 1 
        && currentGame.gameBoard[3][4] == 1 && currentGame.gameBoard[4][3] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[2][5] == 1 && currentGame.gameBoard[3][4] == 1 
        && currentGame.gameBoard[4][3] == 1 && currentGame.gameBoard[5][2] == 1)
            {currentGame.player1Score++;}
    if(currentGame.gameBoard[2][6] == 1 && currentGame.gameBoard[3][5] == 1 
        && currentGame.gameBoard[4][4] == 1 && currentGame.gameBoard[5][3] == 1)
            {currentGame.player1Score++;}
        
    //check player 2
    if(currentGame.gameBoard[2][0] == 2 && currentGame.gameBoard[3][1] == 2 
        && currentGame.gameBoard[4][2] == 2 && currentGame.gameBoard[5][3] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[1][0] == 2 && currentGame.gameBoard[2][1] == 2 
        && currentGame.gameBoard[3][2] == 2 && currentGame.gameBoard[4][3] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[2][1] == 2 && currentGame.gameBoard[3][2] == 2 
        && currentGame.gameBoard[4][3] == 2 && currentGame.gameBoard[5][4] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[0][0] == 2 && currentGame.gameBoard[1][1] == 2 
        && currentGame.gameBoard[2][2] == 2 && currentGame.gameBoard[3][3] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[1][1] == 2 && currentGame.gameBoard[2][2] == 2 
        && currentGame.gameBoard[3][3] == 2 && currentGame.gameBoard[4][4] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[2][2] == 2 && currentGame.gameBoard[3][3] == 2 
        && currentGame.gameBoard[4][4] == 2 && currentGame.gameBoard[5][5] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[0][1] == 2 && currentGame.gameBoard[1][2] == 2 
        && currentGame.gameBoard[2][3] == 2 && currentGame.gameBoard[3][4] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[1][2] == 2 && currentGame.gameBoard[2][3] == 2 
        && currentGame.gameBoard[3][4] == 2 && currentGame.gameBoard[4][5] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[2][3] == 2 && currentGame.gameBoard[3][4] == 2 
        && currentGame.gameBoard[4][5] == 2 && currentGame.gameBoard[5][6] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[0][2] == 2 && currentGame.gameBoard[1][3] == 2 
        && currentGame.gameBoard[2][4] == 2 && currentGame.gameBoard[3][5] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[1][3] == 2 && currentGame.gameBoard[2][4] == 2 
        && currentGame.gameBoard[3][5] == 2 && currentGame.gameBoard[4][6] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[0][3] == 2 && currentGame.gameBoard[1][4] == 2 
        && currentGame.gameBoard[2][5] == 2 && currentGame.gameBoard[3][6] == 2)
            {currentGame.player2Score++;}

    if(currentGame.gameBoard[0][3] == 2 && currentGame.gameBoard[1][2] == 2 
        && currentGame.gameBoard[2][1] == 2 && currentGame.gameBoard[3][0] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[0][4] == 2 && currentGame.gameBoard[1][3] == 2 
        && currentGame.gameBoard[2][2] == 2 && currentGame.gameBoard[3][1] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[1][3] == 2 && currentGame.gameBoard[2][2] == 2
        && currentGame.gameBoard[3][1] == 2 && currentGame.gameBoard[4][0] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[0][5] == 2 && currentGame.gameBoard[1][4] == 2 
        && currentGame.gameBoard[2][3] == 2 && currentGame.gameBoard[3][2] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[1][4] == 2 && currentGame.gameBoard[2][3] == 2 
        && currentGame.gameBoard[3][2] == 2 && currentGame.gameBoard[4][1] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[2][3] == 2 && currentGame.gameBoard[3][2] == 2 
        && currentGame.gameBoard[4][1] == 2 && currentGame.gameBoard[5][0] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[0][6] == 2 && currentGame.gameBoard[1][5] == 2 
        && currentGame.gameBoard[2][4] == 2 && currentGame.gameBoard[3][3] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[1][5] == 2 && currentGame.gameBoard[2][4] == 2 
        && currentGame.gameBoard[3][3] == 2 && currentGame.gameBoard[4][2] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[2][4] == 2 && currentGame.gameBoard[3][3] == 2 
        && currentGame.gameBoard[4][2] == 2 && currentGame.gameBoard[5][1] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[1][6] == 2 && currentGame.gameBoard[2][5] == 2 
        && currentGame.gameBoard[3][4] == 2 && currentGame.gameBoard[4][3] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[2][5] == 2 && currentGame.gameBoard[3][4] == 2 
        && currentGame.gameBoard[4][3] == 2 && currentGame.gameBoard[5][2] == 2)
            {currentGame.player2Score++;}
    if(currentGame.gameBoard[2][6] == 2 && currentGame.gameBoard[3][5] == 2 
        && currentGame.gameBoard[4][4] == 2 && currentGame.gameBoard[5][3] == 2)
            {currentGame.player2Score++;}
}


int main(int argc, char ** argv)
{
  char ** command_line = argv;

  if (argc != 5)
  {
    printf("Four command-line arguments are needed:\n");
    printf("Usage: %s interactive [input_file] [computer-next/human-next] [depth]\n", command_line [0]);
    printf("or:  %s one-move [input_file] [output_file] [depth]\n", command_line [0]);

    return 0;
  }

  char * output = nullptr;

  char * game_mode = command_line [1];
  bool interactiveMode = false;
  bool computerTurn = false;
  if (strcmp(game_mode, "interactive") == 0)
  {
      interactiveMode = true;
      output = "human.txt";
      if(strcmp(command_line [3], "human-next") == 0)
      {
        computerTurn = false;
      }
      else if(strcmp(command_line [3], "computer-next") == 0)
      {
        computerTurn = true;
      }
      else
      {
            printf("%s is an unrecognized next turn\n", game_mode);
            return 0;
      }
  }
  else if (strcmp (game_mode, "one-move") == 0)
  {
      output = command_line [3];
      computerTurn = true;
  }
  else 
  {
    printf("%s is an unrecognized game mode\n", game_mode);
    return 0;
  }


  char * input = command_line[2];

  int depthLimit = std::stoi(command_line [4]);
  ///////////////////////////////////////////////////
  // Game loop below here:
  ///////////////////////////////////////////////////
  bool gameOn = true;
  while(gameOn)
  {
    gameOn = interactiveMode;
    gameStatus currentGame;     // Declare current game
    printf("\nMaxConnect-4 game\n");
  
    currentGame.gameFile = fopen(input, "r");
    printf("game state before move:\n");
    
    //set currentTurn
    char current = 0;
    int i, j;
    if (currentGame.gameFile != 0)
    {
      for(i = 0; i < 6; i++)
      {
        for(j = 0; j < 7; j++)
        {
          do 
          {
            current = getc(currentGame.gameFile);
          }
          while ((current == ' ') || (current == '\n') || (current == '\r'));
  
          currentGame.gameBoard[i][j] = current - 48;
      if(currentGame.gameBoard[i][j] > 0)
          {
        currentGame.pieceCount++;
      }
        }
      }
   
      do 
      {
        current = getc(currentGame.gameFile);
      }
      while ((current == ' ') || (current == '\n') || (current == '\r'));
      
      currentGame.currentTurn = current - 48;
      fclose(currentGame.gameFile);
    }
  
    printGameBoard(currentGame);
    countScore(currentGame);
    printf("Score: Player 1 = %d, Player 2 = %d\n\n", currentGame.player1Score, currentGame.player2Score);
  
    if(currentGame.pieceCount == 42)
    {
      printf("\nBOARD FULL\n");
      printf("Game over!\n\n");
  
      return 1;
    }
    
    if(computerTurn)
    {
        aiPlay(currentGame, depthLimit);
        computerTurn = false;
    } else
    {
        bool success = false;
        int colChoice = -1;
        while(!success)
        {
            std::cout << "Human: Please enter your move as a one-based column: ";    
            std::cin >> colChoice;
            colChoice--;
            success = (playPiece(colChoice, currentGame) == 1);
        }
        printf("\n\nmove %li: Player %li, column %li\n", 
           currentGame.pieceCount, currentGame.currentTurn, colChoice+1);
        if(currentGame.currentTurn == 1)
            currentGame.currentTurn = 2;
        else if (currentGame.currentTurn == 2)
            currentGame.currentTurn = 1;

        computerTurn = true;
    }
    printf("game state after move:\n");
    printGameBoard(currentGame);
    countScore(currentGame);
    printf("Score: Player 1 = %d, Player 2 = %d\n\n", currentGame.player1Score, currentGame.player2Score);
    
    currentGame.gameFile = fopen(output, "w");
    if (currentGame.gameFile != 0)
    {
      printGameBoardToFile(currentGame);
      fclose(currentGame.gameFile);
    }
    else
    {
      printf("error: could not open output file %s\n", output);
      gameOn = false;
    }

    input = output;
}
  return 1;
}
