# UtaCse5360
Artificial Intelligence I

## Project 1

In order to build the source code within project 1, you will need CMake 3.14 or higher, and a C++ compiler that supports C++17. You execute the following commands:

```
cmake -S . -B ./build [-A x64]
cmake --build ./build [--config Release]
```

Where the options in square brackets are optional for windows. I tested and verified everything in this project works with MSVC 19.32, via Visual Studio 17 2022 Personal Edition.

### Running find_route

The executable for the find_route part of the assignment will be built at:

```
build\Project1\find_route\[Release]\find_route[.exe]
```

You can execute it normally from that location, or copy it to wherever you'd rather run from. The square brackets again represent windows only parts.

### Running maxconnect4

The executable for the find_route part of the assignment will be 
built at:

```
build\Project1\maxconnect4\[Release]\maxconnect4[.exe]
```

You can execute it normally from that location, or copy it to 
wherever you'd rather run from.The square brackets again represent windows only parts.

#### Timing Table

I created a timing table of executing times versus depth limit, that file is located at:

```
Project1\maxconnect4\TimingTable.csv
```

It was captured using Windows PowerShell's Measure-Command function:

```
 Measure-Command {.\build\Project1\maxconnect4\Release\maxconnect4.exe one-move .\input1.txt output1.txt 19}
```
