#Ankita Meshram
#1001980282
#Task1

import sys

#Variables declaring for storing
iSource = []
iDestination = []
iCost = []
heuristic = {}

def costFun(src,dest):
    for i in range(0, len(iSource)):
        if ((iSource[i] == src or iDestination[i]== src) and (iSource[i] == dest or iDestination[i]== dest)):
            return iCost[i]

def heuristicForNode(Node):
    return heuristic[Node]

def getHeuristics(fileName):
    file=open(fileName, "r")
    for line in file:
        if(str(line).lower().find("end of input")==-1):
            cols=line.strip().split(" ")
            heuristic[cols[0]]=cols[1]

def pathGenerate(routeChoosen):
    route=[]
    if(routeChoosen is None):
        route.append("None")
    else:
        for i in range(len(routeChoosen)-1):
            cost=costFun(routeChoosen[i],routeChoosen[i+1])
            route.append(str(routeChoosen[i])+" to "+str(routeChoosen[i+1])+", "+str(cost)+" km")
    return route

def inputsFromFile(isInformedSearch,costFile,heuristicFile):
    file=open(costFile, "r")
    for line in file:
        if(str(line).lower().find("end of input")==-1):
            cols=line.strip().split(" ")
            iSource.append(cols[0])
            iDestination.append(cols[1])
            iCost.append(cols[2])
            if(isInformedSearch):
                getHeuristics(heuristicFile)

def ucsFunc(start,end,expandedNode,generatedNode,isInformed):
    cost=0
    fringe = []
    route = []
    heuristic = 0
    route.append(start)
    if(isInformed):
        heuristic=heuristicForNode(start)
    fringe.append((start,route,cost,heuristic))
    generatedNode+=1
    visitedNode = []
    while len(fringe)!=0:
        node,route,costofpath,heuristic= fringe.pop(0)
        expandedNode += 1
        if node==end:
            return node,route,costofpath,expandedNode,generatedNode,visitedNode
        else:
            if(node not in visitedNode):
                successors,successorsCount= successorNode(node,isInformed)
                generatedNode += successorsCount
                visitedNode.append(node)
                for childNode in successors:
                    curPath = route[:]
                    curPath.append(childNode[0])
                    cumCost = costofpath + childNode[1]
                    fringe.append((childNode[0], curPath, cumCost,childNode[2]))
                fringe.sort(key=lambda x: x[2]+x[3])
    return None,None,None,expandedNode,generatedNode,visitedNode

def successorNode(node,isInformedSearch):
    successors=[]
    heuCost=0
    for i in range(0,len(iSource)):
        if(iSource[i]==node):
            if(isInformedSearch):
                heuCost=heuristicForNode(iDestination[i])
            successors.append((iDestination[i], float(iCost[i]),float(heuCost)))
        elif(iDestination[i]==node):
            if(isInformedSearch):
                heuCost = heuristicForNode(iSource[i])
            successors.append((iSource[i], float(iCost[i]),float(heuCost)))
    return  sorted(successors,key=lambda x:x[1]+x[2]),len(successors)



def main():
    isInformed=False
    heuristicFile=""
    routeProb=""
    if(len(sys.argv) ==5):
        isInformed=True
        heuristicFile=sys.argv[4]
    inputsFromFile(isInformed,sys.argv[1],heuristicFile)
    node, route, costofpath, expandedNode, generatedNode, visitedNode = ucsFunc(sys.argv[2], sys.argv[3], 0, 0,isInformed)
    visitedNodeCount = len(visitedNode)
    finalRoute = pathGenerate(route)
    print("Nodes Popped: " + str(expandedNode))
    print("Nodes Expanded: "+ str(visitedNodeCount))
    print("Nodes Generated: " + str(generatedNode))
    if(costofpath is None):
        print("Distance: infinity")
    else:
        print("Distance: "+str(costofpath)+" km")
    print("Route: ")
    if len(finalRoute)==1:
        routeProb=finalRoute[0]
    else:
        routeProb='\n'.join(finalRoute)
    print(routeProb)


if __name__ == '__main__':
    main()