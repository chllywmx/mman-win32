Name    : Ankita Meshram
UTA ID  : 1001980282
Language: Python
Version : Python 3.10.1

Code Structure:
The main function will call Informed or Uninformed Search based
on the parameters passed.
When heuristic is not provided then program is doing uninformed search.
When heuristic is provided then program is doing informed search.


Commands:
1. python find_route.py input1.txt Bremen Kassel
Output--
Nodes Popped: 12
Nodes Expanded: 6
Nodes Generated: 20
Distance: 297.0 km
Route:
Bremen to Hannover: 132 km
Hannover to Kassel: 165 km

2. python find_route.py input1.txt London Kassel
Nodes Popped: 7
Nodes Expanded: 4
Nodes Generated: 7
Distance: infinity
Route:
None

3. python find_route.py input1.txt Bremen Kassel h_kassel.txt
Nodes Popped: 3
Nodes Expanded: 2
Nodes Generated: 8
Distance: 297.0 km
Route:
Bremen to Hannover, 132 km
Hannover to Kassel, 165 km
