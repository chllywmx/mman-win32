Name    : Ankita Meshram
UTA ID  : 1001980282
Language: Python
Version : Python 3.10.1

Code Structure:
maxconnect4.py : Consist of program for the game for different modes.
MaxConnect4Game.py : Consist the class for entire game.
It contains min-max, alpha-beta pruning and evaluation function.

Commands:
Interactive Mode:
    python maxconnect4.py interactive input1.txt computer-next 7

One-Move Mode:
    python maxconnect4.py one-move input1.txt output.txt 3

