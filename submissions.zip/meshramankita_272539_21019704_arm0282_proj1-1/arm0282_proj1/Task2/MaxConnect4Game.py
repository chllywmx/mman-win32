#Ankita Meshram
#1001980282


#!/usr/bin/env python
# Written by Chris Conly based on C++
# code provided by Vassilis Athitsos
# Written to be Python 2.4 compatible for omega

from copy import copy
import copy
import random
import sys

class maxConnect4Game:
    def __init__(self):
        self.gameBoard = [[0 for i in range(7)] for j in range(6)]
        self.currentTurn = 1
        self.player1Score = 0
        self.player2Score = 0
        self.pieceCount = 0
        self.gameFile = None
        self.utility = None
        random.seed()

    # Count the number of pieces already played
    def checkPieceCount(self):
        self.pieceCount = sum(1 for row in self.gameBoard for piece in row if piece)

    # Output current game status to console
    def printGameBoard(self):
        print (' -----------------')
        for i in range(6):
            print(self.gameBoard[i])
            """print (' |')
                        for j in range(7):
                            print('%d' % self.gameBoard[i][j]),
                        print ('| ')"""
        print (' -----------------')

    # Output current game status to file
    def printGameBoardToFile(self):
        for row in self.gameBoard:
            self.gameFile.write(''.join(str(col) for col in row) + '\r\n')
        self.gameFile.write('%s\r\n' % str(self.currentTurn))

    # Place the current player's piece in the requested column
    def playPiece(self, column):
        if not self.gameBoard[0][column]:
            for i in range(5, -1, -1):
                if not self.gameBoard[i][column]:
                    self.gameBoard[i][column] = self.currentTurn
                    self.pieceCount += 1
                    return 1

    # The AI section. Currently plays randomly.
    def aiPlay(self, depth, computer):
        self.generateSuccessors(depth - 1, computer)
        column = self.selectBestMove(computer)
        result = self.playPiece(column)
        if not result:
            self.aiPlay(depth, computer)
        else:
            print('\n\n move %d: Player %d, column %d\n' % (self.pieceCount, self.currentTurn, column+1))
            """if self.currentTurn == 1:
                    self.currentTurn = 2
                elif self.currentTurn == 2:
                    self.currentTurn = 1"""
        return

    # Calculate the number of 4-in-a-row each player has
    def countScore(self):
        self.player1Score = 0
        self.player2Score = 0

        # Check horizontally
        for row in self.gameBoard:
        # Check player 1
            if row[0:4] == [1]*4:
                self.player1Score += 1
            if row[1:5] == [1]*4:
                self.player1Score += 1
            if row[2:6] == [1]*4:
                self.player1Score += 1
            if row[3:7] == [1]*4:
                self.player1Score += 1
            # Check player 2
            if row[0:4] == [2]*4:
                self.player2Score += 1
            if row[1:5] == [2]*4:
                self.player2Score += 1
            if row[2:6] == [2]*4:
                self.player2Score += 1
            if row[3:7] == [2]*4:
                self.player2Score += 1

        # Check vertically
        for j in range(7):
            # Check player 1
            if (self.gameBoard[0][j] == 1 and self.gameBoard[1][j] == 1 and
                   self.gameBoard[2][j] == 1 and self.gameBoard[3][j] == 1):
                self.player1Score += 1
            if (self.gameBoard[1][j] == 1 and self.gameBoard[2][j] == 1 and
                   self.gameBoard[3][j] == 1 and self.gameBoard[4][j] == 1):
                self.player1Score += 1
            if (self.gameBoard[2][j] == 1 and self.gameBoard[3][j] == 1 and
                   self.gameBoard[4][j] == 1 and self.gameBoard[5][j] == 1):
                self.player1Score += 1

            # Check player 2
            if (self.gameBoard[0][j] == 2 and self.gameBoard[1][j] == 2 and
                   self.gameBoard[2][j] == 2 and self.gameBoard[3][j] == 2):
                self.player2Score += 1
            if (self.gameBoard[1][j] == 2 and self.gameBoard[2][j] == 2 and
                   self.gameBoard[3][j] == 2 and self.gameBoard[4][j] == 2):
                self.player2Score += 1
            if (self.gameBoard[2][j] == 2 and self.gameBoard[3][j] == 2 and
                   self.gameBoard[4][j] == 2 and self.gameBoard[5][j] == 2):
                self.player2Score += 1

        # Check diagonally
        # Check player 1
        if (self.gameBoard[2][0] == 1 and self.gameBoard[3][1] == 1 and
               self.gameBoard[4][2] == 1 and self.gameBoard[5][3] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][0] == 1 and self.gameBoard[2][1] == 1 and
               self.gameBoard[3][2] == 1 and self.gameBoard[4][3] == 1):
            self.player1Score += 1
        if (self.gameBoard[2][1] == 1 and self.gameBoard[3][2] == 1 and
               self.gameBoard[4][3] == 1 and self.gameBoard[5][4] == 1):
            self.player1Score += 1
        if (self.gameBoard[0][0] == 1 and self.gameBoard[1][1] == 1 and
               self.gameBoard[2][2] == 1 and self.gameBoard[3][3] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][1] == 1 and self.gameBoard[2][2] == 1 and
               self.gameBoard[3][3] == 1 and self.gameBoard[4][4] == 1):
            self.player1Score += 1
        if (self.gameBoard[2][2] == 1 and self.gameBoard[3][3] == 1 and
               self.gameBoard[4][4] == 1 and self.gameBoard[5][5] == 1):
            self.player1Score += 1
        if (self.gameBoard[0][1] == 1 and self.gameBoard[1][2] == 1 and
               self.gameBoard[2][3] == 1 and self.gameBoard[3][4] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][2] == 1 and self.gameBoard[2][3] == 1 and
               self.gameBoard[3][4] == 1 and self.gameBoard[4][5] == 1):
            self.player1Score += 1
        if (self.gameBoard[2][3] == 1 and self.gameBoard[3][4] == 1 and
               self.gameBoard[4][5] == 1 and self.gameBoard[5][6] == 1):
            self.player1Score += 1
        if (self.gameBoard[0][2] == 1 and self.gameBoard[1][3] == 1 and
               self.gameBoard[2][4] == 1 and self.gameBoard[3][5] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][3] == 1 and self.gameBoard[2][4] == 1 and
               self.gameBoard[3][5] == 1 and self.gameBoard[4][6] == 1):
            self.player1Score += 1
        if (self.gameBoard[0][3] == 1 and self.gameBoard[1][4] == 1 and
               self.gameBoard[2][5] == 1 and self.gameBoard[3][6] == 1):
            self.player1Score += 1

        
        if (self.gameBoard[0][3] == 1 and self.gameBoard[1][2] == 1 and
               self.gameBoard[2][1] == 1 and self.gameBoard[3][0] == 1):
            self.player1Score += 1
        if (self.gameBoard[0][4] == 1 and self.gameBoard[1][3] == 1 and
               self.gameBoard[2][2] == 1 and self.gameBoard[3][1] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][3] == 1 and self.gameBoard[2][2] == 1 and
               self.gameBoard[3][1] == 1 and self.gameBoard[4][0] == 1):
            self.player1Score += 1
        if (self.gameBoard[0][5] == 1 and self.gameBoard[1][4] == 1 and
               self.gameBoard[2][3] == 1 and self.gameBoard[3][2] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][4] == 1 and self.gameBoard[2][3] == 1 and
               self.gameBoard[3][2] == 1 and self.gameBoard[4][1] == 1):
            self.player1Score += 1
        if (self.gameBoard[2][3] == 1 and self.gameBoard[3][2] == 1 and
               self.gameBoard[4][1] == 1 and self.gameBoard[5][0] == 1):
            self.player1Score += 1
        if (self.gameBoard[0][6] == 1 and self.gameBoard[1][5] == 1 and
               self.gameBoard[2][4] == 1 and self.gameBoard[3][3] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][5] == 1 and self.gameBoard[2][4] == 1 and
               self.gameBoard[3][3] == 1 and self.gameBoard[4][2] == 1):
            self.player1Score += 1
        if (self.gameBoard[2][4] == 1 and self.gameBoard[3][3] == 1 and
               self.gameBoard[4][2] == 1 and self.gameBoard[5][1] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][6] == 1 and self.gameBoard[2][5] == 1 and
               self.gameBoard[3][4] == 1 and self.gameBoard[4][3] == 1):
            self.player1Score += 1
        if (self.gameBoard[2][5] == 1 and self.gameBoard[3][4] == 1 and
               self.gameBoard[4][3] == 1 and self.gameBoard[5][2] == 1):
            self.player1Score += 1
        if (self.gameBoard[2][6] == 1 and self.gameBoard[3][5] == 1 and
               self.gameBoard[4][4] == 1 and self.gameBoard[5][3] == 1):
            self.player1Score += 1
        # Check player 2
        if (self.gameBoard[2][0] == 2 and self.gameBoard[3][1] == 2 and
               self.gameBoard[4][2] == 2 and self.gameBoard[5][3] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][0] == 2 and self.gameBoard[2][1] == 2 and
               self.gameBoard[3][2] == 2 and self.gameBoard[4][3] == 2):
            self.player2Score += 1
        if (self.gameBoard[2][1] == 2 and self.gameBoard[3][2] == 2 and
               self.gameBoard[4][3] == 2 and self.gameBoard[5][4] == 2):
            self.player2Score += 1
        if (self.gameBoard[0][0] == 2 and self.gameBoard[1][1] == 2 and
               self.gameBoard[2][2] == 2 and self.gameBoard[3][3] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][1] == 2 and self.gameBoard[2][2] == 2 and
               self.gameBoard[3][3] == 2 and self.gameBoard[4][4] == 2):
            self.player2Score += 1
        if (self.gameBoard[2][2] == 2 and self.gameBoard[3][3] == 2 and
               self.gameBoard[4][4] == 2 and self.gameBoard[5][5] == 2):
            self.player2Score += 1
        if (self.gameBoard[0][1] == 2 and self.gameBoard[1][2] == 2 and
               self.gameBoard[2][3] == 2 and self.gameBoard[3][4] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][2] == 2 and self.gameBoard[2][3] == 2 and
               self.gameBoard[3][4] == 2 and self.gameBoard[4][5] == 2):
            self.player2Score += 1
        if (self.gameBoard[2][3] == 2 and self.gameBoard[3][4] == 2 and
               self.gameBoard[4][5] == 2 and self.gameBoard[5][6] == 2):
            self.player2Score += 1
        if (self.gameBoard[0][2] == 2 and self.gameBoard[1][3] == 2 and
               self.gameBoard[2][4] == 2 and self.gameBoard[3][5] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][3] == 2 and self.gameBoard[2][4] == 2 and
               self.gameBoard[3][5] == 2 and self.gameBoard[4][6] == 2):
            self.player2Score += 1
        if (self.gameBoard[0][3] == 2 and self.gameBoard[1][4] == 2 and
               self.gameBoard[2][5] == 2 and self.gameBoard[3][6] == 2):
            self.player2Score += 1

        if (self.gameBoard[0][3] == 2 and self.gameBoard[1][2] == 2 and
               self.gameBoard[2][1] == 2 and self.gameBoard[3][0] == 2):
            self.player2Score += 1
        if (self.gameBoard[0][4] == 2 and self.gameBoard[1][3] == 2 and
               self.gameBoard[2][2] == 2 and self.gameBoard[3][1] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][3] == 2 and self.gameBoard[2][2] == 2 and
               self.gameBoard[3][1] == 2 and self.gameBoard[4][0] == 2):
            self.player2Score += 1
        if (self.gameBoard[0][5] == 2 and self.gameBoard[1][4] == 2 and
               self.gameBoard[2][3] == 2 and self.gameBoard[3][2] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][4] == 2 and self.gameBoard[2][3] == 2 and
               self.gameBoard[3][2] == 2 and self.gameBoard[4][1] == 2):
            self.player2Score += 1
        if (self.gameBoard[2][3] == 2 and self.gameBoard[3][2] == 2 and
               self.gameBoard[4][1] == 2 and self.gameBoard[5][0] == 2):
            self.player2Score += 1
        if (self.gameBoard[0][6] == 2 and self.gameBoard[1][5] == 2 and
               self.gameBoard[2][4] == 2 and self.gameBoard[3][3] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][5] == 2 and self.gameBoard[2][4] == 2 and
               self.gameBoard[3][3] == 2 and self.gameBoard[4][2] == 2):
            self.player2Score += 1
        if (self.gameBoard[2][4] == 2 and self.gameBoard[3][3] == 2 and
               self.gameBoard[4][2] == 2 and self.gameBoard[5][1] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][6] == 2 and self.gameBoard[2][5] == 2 and
               self.gameBoard[3][4] == 2 and self.gameBoard[4][3] == 2):
            self.player2Score += 1
        if (self.gameBoard[2][5] == 2 and self.gameBoard[3][4] == 2 and
               self.gameBoard[4][3] == 2 and self.gameBoard[5][2] == 2):
            self.player2Score += 1
        if (self.gameBoard[2][6] == 2 and self.gameBoard[3][5] == 2 and
               self.gameBoard[4][4] == 2 and self.gameBoard[5][3] == 2):
            self.player2Score += 1


    def selectBestMove(self, computer):
        alpha = -999
        beta  = 999
        i = self.AlphaBetaFun(computer, alpha, beta)
        for child in self.children:
            if child.utility == i:
                return child.column

    def MinMaxFun(self, computer):
        if self.utility is not None:
            return self.utility
        elif self.currentTurn == computer:
            i = -999
            for child in self.children:
                i = max(i, child.MinMaxFun(computer))
        else:
            i = 999
            for child in self.children:
                i = min(i, child.MinMaxFun(computer))
        self.utility = i
        return self.utility


    def generateSuccessors(self, depth, computer):
        if depth >= 0 and self.pieceCount < 42:
            self.children = []
            for gameCol in range(0, 7):

                if not self.gameBoard[0][gameCol]:

                    child = maxConnect4Game()
                    child.gameBoard = copy.deepcopy(self.gameBoard)
                    if self.currentTurn == 1:
                        child.currentTurn = 2
                    elif self.currentTurn == 2:
                        child.currentTurn = 1
                    child.evaluation = 0
                    child.pieceCount = self.pieceCount + 1

                    if computer == self.currentTurn:
                        self.evaluationFunc(computer)
                        child.evaluation = self.bestMove["utility"]
                        child.gameBoard[self.bestMove["row"]][self.bestMove["column"]] = self.currentTurn
                        child.column = self.bestMove["column"]
                        self.children.append(child)
                        break
                    else:
                        for k in range(5, -1, -1):
                            if not child.gameBoard[k][gameCol]:
                                child.gameBoard[k][gameCol] = self.currentTurn
                                child.column = gameCol
                                self.children.append(child)
                                break

            for child in self.children:
                child.generateSuccessors(depth - 1, computer)
        else:

            self.countScore()

            if computer == 1:
                self.utility = self.player1Score - self.player2Score + self.evaluation
            else:
                self.utility = self.player2Score - self.player1Score + self.evaluation


    def evaluationFunc(self, computer):
        if computer == 1:
            oppositePlayer = 2
        else:
            oppositePlayer = 1

        validMoves = []

        for col in range(0, 7):
            if not self.gameBoard[0][col]:
                for row in range(5, -1, -1):
                    if not self.gameBoard[row][col]:
                        validMoves.append({"row": row,"column":col})
                        break

        if len(validMoves) > 0:
            self.probMax = -1
            self.lose = -1
            self.win = -1
            self.probMove = None
            self.bestMoveLost = None
            self.bestMoveWin = None
            self.randomMove = validMoves[random.randrange(0, len(validMoves))]
            for curmove in validMoves:
                countLose = 0
                countWin = 0
                countProb = 0

                if curmove["column"] - 3 >= 0:
                    col_min = curmove["column"] - 3
                else:
                    col_min = 0

                if curmove["column"] + 3 <= 6:
                    col_max = curmove["column"] + 3
                else:
                    col_max = 6

                cur_row = self.gameBoard[curmove["row"]][:]
                cur_row[curmove["column"]] = oppositePlayer
                for i in range(col_min, col_max - 2, 1):
                    if cur_row[i:i+4] == [oppositePlayer]*4:
                        countLose += 1

                cur_row[curmove["column"]] = computer
                for i in range(col_min, col_max - 2, 1):
                    if cur_row[i:i+4] == [computer]*4:
                        countWin += 1
                    try:
                        if cur_row[i:i+4].index(oppositePlayer) >= 0:
                            pass
                    except:
                        countProb += 1

                if curmove["row"] + 3 <= 5:
                    if self.gameBoard[curmove["row"] + 3][curmove["column"]] == oppositePlayer and self.gameBoard[curmove["row"] + 2][curmove["column"]] == oppositePlayer and self.gameBoard[curmove["row"] + 1][curmove["column"]] == oppositePlayer:
                        countLose += 1

                    if self.gameBoard[curmove["row"] + 3][curmove["column"]] == computer and self.gameBoard[curmove["row"] + 2][curmove["column"]] == computer and self.gameBoard[curmove["row"] + 1][curmove["column"]] == computer:
                        countWin += 1

                    arrayProb = []
                    arrayProb.append(self.gameBoard[curmove["row"] + 3][curmove["column"]])
                    arrayProb.append(self.gameBoard[curmove["row"] + 2][curmove["column"]])
                    arrayProb.append(self.gameBoard[curmove["row"] + 1][curmove["column"]])
                    try:
                        if arrayProb.index(oppositePlayer) >= 0:
                            pass
                    except:
                        countProb += 1

                rowstart = curmove["row"]
                colstart = curmove["column"]
                i = -3
                while i != 0 and rowstart != 0 and colstart != 0:
                    rowstart = rowstart - 1
                    colstart = colstart - 1
                    i = i - 1

                rowend = curmove["row"]
                colend = curmove["column"]
                i = 3
                while i != 0 and rowend != 5 and colend != 6:
                    rowend = rowend + 1
                    colend = colend + 1
                    i = i - 1

                saverowstart = rowstart
                saverowend = rowend
                savecolstart = colstart
                savecolend = colend

                cur_map = copy.deepcopy(self.gameBoard)
                cur_map[curmove["row"]][curmove["column"]] = computer
                while rowstart <= rowend - 3:
                    if cur_map[rowstart][colstart] == computer and cur_map[rowstart+1][colstart+1] == computer and cur_map[rowstart+2][colstart+2] == computer and cur_map[rowstart+3][colstart+3] == computer:
                        countWin += 1

                    arrayProb = []
                    arrayProb.append(cur_map[rowstart][colstart])
                    arrayProb.append(cur_map[rowstart+1][colstart+1])
                    arrayProb.append(cur_map[rowstart+2][colstart+2])
                    arrayProb.append(cur_map[rowstart+3][colstart+3])

                    rowstart = rowstart + 1
                    colstart = colstart + 1

                    try:
                        if arrayProb.index(oppositePlayer) >= 0:
                            pass
                    except:
                        countProb += 1

                rowstart = saverowstart
                rowend = saverowend
                colstart = savecolstart
                colend = savecolend

                cur_map = copy.deepcopy(self.gameBoard)
                cur_map[curmove["row"]][curmove["column"]] = oppositePlayer
                while rowstart <= rowend - 3:
                    if cur_map[rowstart][colstart] == oppositePlayer and cur_map[rowstart+1][colstart+1] == oppositePlayer and cur_map[rowstart+2][colstart+2] == oppositePlayer and cur_map[rowstart+3][colstart+3] == oppositePlayer:
                        countLose += 1
                    rowstart = rowstart + 1
                    colstart = colstart + 1

                rowstart = curmove["row"]
                colstart = curmove["column"]
                i = -3
                while i != 0 and rowstart != 0 and colstart != 6:
                    rowstart = rowstart - 1
                    colstart = colstart + 1
                    i = i - 1

                rowend = curmove["row"]
                colend = curmove["column"]
                i = 3
                while i != 0 and rowend != 5 and colend != 0:
                    rowend = rowend + 1
                    colend = colend - 1
                    i = i - 1

                saverowstart = rowstart
                saverowend = rowend
                savecolstart = colstart
                savecolend = colend

                cur_map = copy.deepcopy(self.gameBoard)
                cur_map[curmove["row"]][curmove["column"]] = computer
                while rowstart <= rowend - 3:
                    if cur_map[rowstart][colstart] == computer and cur_map[rowstart+1][colstart-1] == computer and cur_map[rowstart+2][colstart-2] == computer and cur_map[rowstart+3][colstart-3] == computer:
                        countWin += 1

                    arrayProb = []
                    arrayProb.append(cur_map[rowstart][colstart])
                    arrayProb.append(cur_map[rowstart+1][colstart-1])
                    arrayProb.append(cur_map[rowstart+2][colstart-2])
                    arrayProb.append(cur_map[rowstart+3][colstart-3])

                    rowstart = rowstart + 1
                    colstart = colstart - 1

                    try:
                        if arrayProb.index(oppositePlayer) >= 0:
                            pass
                    except:
                        countProb += 1

                rowstart = saverowstart
                rowend = saverowend
                colstart = savecolstart
                colend = savecolend

                cur_map = copy.deepcopy(self.gameBoard)
                cur_map[curmove["row"]][curmove["column"]] = oppositePlayer
                while rowstart <= rowend - 3:
                    if cur_map[rowstart][colstart] == oppositePlayer and cur_map[rowstart+1][colstart-1] == oppositePlayer and cur_map[rowstart+2][colstart-2] == oppositePlayer and cur_map[rowstart+3][colstart-3] == oppositePlayer:
                        countLose += 1
                    rowstart = rowstart + 1
                    colstart = colstart - 1

                if countLose != 0 and countLose > self.lose:
                    self.lose = countLose
                    self.bestMoveLost = curmove

                if countWin != 0 and countWin > self.win:
                    self.win = countWin
                    self.bestMoveWin = curmove

                if countProb != 0 and countProb > self.probMax:
                    self.probMax = countProb
                    self.probMove = curmove

            if self.win >= self.lose and self.win != -1:
                self.bestMove = {"row" : self.bestMoveWin["row"],"column" : self.bestMoveWin["column"],"utility" : self.win * 4}
            elif self.win < self.lose:
                self.bestMove = {"row" : self.bestMoveLost["row"],"column" : self.bestMoveLost["column"],"utility" : self.lose * 4}
            elif self.probMax > 0:
                self.bestMove = {"row" : self.probMove["row"],"column" : self.probMove["column"],"utility" : self.probMax}
            else:
                self.bestMove = {"row" : self.randomMove["row"],"column" : self.randomMove["column"],"utility" : 0}
        else:
            self.bestMove = None


    def AlphaBetaFun(self, computer, alpha, beta):
        if self.utility is not None:
            return self.utility
        elif self.currentTurn == computer:
            i = -999
            for child in self.children:
                i = max(i, child.AlphaBetaFun(computer, alpha, beta))
                if alpha >= beta:
                    self.utility = i
                    return self.utility
                else:
                    alpha = max(alpha, i)
        else:
            i = 999
            for child in self.children:
                i = min(i, child.AlphaBetaFun(computer, alpha, beta))
                if beta <= alpha:

                    self.utility = i
                    return self.utility
                else:
                    beta = min(i, beta)
        self.utility = i
        return self.utility