
import java.util.*;
import java.io.*;

public class node
{
	ArrayList<node>children = new ArrayList<node>();
	node parent;
	String name;
	int cost;
    int heuristic;
	int depth;


	public node(String name,int depth, int cost,node parent,ArrayList<node>children) 
	{
		this.name = name;
		this.depth = depth;
		this.cost = cost;
		this.parent = parent;
		this.children = children;
	}

	public node(String name,int depth, int cost,node parent)
	{
		this.name = name;
		this.depth = depth;
		this.cost = cost;
		this.parent = parent;
	}

	public node(String name,int depth, int cost,int heuristic,node parent,ArrayList<node>children) 
	{
		this.name = name;
		this.depth = depth;
		this.cost = cost;
		this.heuristic = heuristic;
		this.parent = parent;
		this.children = children;
	}

	public node(String name,int depth, int cost,int heuristic, node parent)
	{
		this.name = name;
		this.depth = depth;
		this.cost = cost;
		this.heuristic = heuristic;
		this.parent = parent;
	}

    node get_Parent()
	{
		return this.parent;
	}

	String get_name()
	{
		return this.name;
	}
 
    int get_depth()
	{
		return this.depth;
	}

	int get_cost()
	{
		return this.cost;
	}
	int get_heuristic()
	{
		return this.heuristic;
	}
	
	ArrayList<node> get_children()
	{
		return this.children;
	}

	void set_children(ArrayList<node>children)
	{
		 this.children = children;

	}
}

    

