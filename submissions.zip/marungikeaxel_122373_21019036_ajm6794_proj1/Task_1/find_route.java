import java.util.*;
import java.io.*;


// Class
public class find_route {

    // Function to expand nodes
    public static void expand_node(node initial_city,ArrayList<file> Graph_edges) 
 	{	
        //Array list to store the children of the node
 		ArrayList<node> children_list=new ArrayList<node>(); 

 		for(file temp:Graph_edges) 
 		{	
            // create children of city A
 			if(temp.get_cityA().equals(initial_city.get_name())) 
 			{
 				node child = new node(temp.get_cityB(),initial_city.get_depth()+1,initial_city.get_cost()+temp.get_distance(),initial_city);
 				
 				children_list.add(child);
 			}

            // create children of city B
 			else if(temp.get_cityB().equals(initial_city.get_name())) 
 			{
 				node child = new node(temp.get_cityA(),initial_city.get_depth()+1,initial_city.get_cost()+temp.get_distance(),initial_city);
 				
 				children_list.add(child);
 			}
 		}
 		initial_city.set_children(children_list);
	}

    // Function to expand nodes with heuristic values 
    public static void expand_node_h(node initial_city,ArrayList<file> Graph_edges, ArrayList<file2> heur_values) 
 	{	
        //Array list to store the children of the node
 		ArrayList<node> children_list=new ArrayList<node>(); 

 		for(file temp:Graph_edges) 
 		{	
            // create children of city A
 			if(temp.get_cityA().equals(initial_city.get_name())) 
 			{
                for (file2 temp2:heur_values)
                {
                    if (temp.get_cityB().equals(temp2.get_city()))
                    {
                        node child = new node(temp.get_cityB(),initial_city.get_depth()+1,initial_city.get_cost()+temp.get_distance(),temp2.get_heuristic(),initial_city);
 				
                        children_list.add(child);
                    }
                    
                }
 				
 			}

            // create children of city B
 			else if(temp.get_cityB().equals(initial_city.get_name())) 
 			{
                for (file2 temp2:heur_values)
                {
                    if (temp.get_cityA().equals(temp2.get_city()))
                    {
                        node child = new node(temp.get_cityA(),initial_city.get_depth()+1,initial_city.get_cost()+temp.get_distance(),temp2.get_heuristic(),initial_city);
 				
                        children_list.add(child);
                    }
                    
                }
 			}
 		}
 		initial_city.set_children(children_list);
	}


    //Function to get distance between 2 edges on the graph 
    public static int get_distance(String origin_city,String destination_city,ArrayList<file>Graph_edges) 
    {	

    	int distance = 0;
    	
    	for(int i=0;i<Graph_edges.size();i++)
    	{
    		if(origin_city.equals(Graph_edges.get(i).cityA) || origin_city.equals(Graph_edges.get(i).cityB) ) 
            {
    			if(destination_city.equals(Graph_edges.get(i).cityB) || destination_city.equals(Graph_edges.get(i).cityA) )	
    			{
    				distance=Graph_edges.get(i).distance;
    			}
    		}
    		
    	}
    	return distance;
	}



    // Function to print solution output
    public static void print_route(node destination_city,ArrayList<file> Graph_edges) 
    {	
            //file distance=new file(); 
            ArrayList<String>parent_node= new ArrayList<String>();
            
            System.out.println("Distance: "+destination_city.get_cost()+ "km");   
            System.out.println("Route:");
            
            while(destination_city.get_Parent()!=null) // print the destination_city path
            {	
                
                System.out.println(destination_city.get_Parent().get_name()+" to "+ destination_city.get_name()+":"+ get_distance(destination_city.get_name(),destination_city.get_Parent().get_name(),Graph_edges)+ "km");
                
                parent_node.add(destination_city.get_name());   
                parent_node.add(destination_city.get_Parent().get_name());
                destination_city=destination_city.get_Parent();
            }   	
    }

    //Function to generate graph edges from each line of input file with distances between cities
    public static ArrayList<file> Generate_edges(String input,ArrayList<file> Graph_edges)
    {
        String input_lines;
        String inputL_array[];
        // Read input file and create graph edges
        try 
        {
           BufferedReader br = new BufferedReader(new FileReader(input));
           while((input_lines = br.readLine()) != null)
           {
               if (input_lines.equals("END OF INPUT"))
               {
                   break;
               }

               else 
               {
                   inputL_array= input_lines.split(" ");
           
                   file edge = new file();
                   edge.cityA = inputL_array[0]; 
                   edge.cityB = inputL_array[1];
                   edge.distance = Integer.parseInt(inputL_array[2]);
                   Graph_edges.add(edge);   
               }
                 
           }
           br.close();

           
       }
       catch (FileNotFoundException ex)
       {
           System.out.println("Couldn't retrieve file!");
       }
       catch (IOException ex)
       {
           System.out.println("Couldn't read file!");
       }
        return Graph_edges;


    }

    //Function to read through heuristics txt files 
    public static ArrayList<file2> generate_heur_values(String heuristics,ArrayList<file2> heur_values)
    {
        String input_lines;
        String inputL_array[];
        // Read input file and create graph edges
        try 
        {
           BufferedReader br = new BufferedReader(new FileReader(heuristics));
           while((input_lines = br.readLine()) != null)
           {
               if (input_lines.equals("END OF INPUT"))
               {
                   break;
               }

               else 
               {
                   inputL_array= input_lines.split(" ");
           
                   file2 city_h = new file2();
                   city_h.city = inputL_array[0]; 
                   city_h.heuristic = Integer.parseInt(inputL_array[1]);
                   heur_values.add(city_h);   
               }
                 
           }
           br.close();

           
       }
       catch (FileNotFoundException ex)
       {
           System.out.println("Couldn't retrieve file!");
       }
       catch (IOException ex)
       {
           System.out.println("Couldn't read file!");
       }
        return heur_values;


    }


    // Function to search through fringe for goal city
    public static void Search_fringe( PriorityQueue<node> fringe,ArrayList<file> Graph_edges,String destination_city,ArrayList<String> closed_set)
    {
        int nodes_p = 0;
        int nodes_e = 0;
        int nodes_g = 1;

        //Pop node from fringe check if its goal, check if it has been visited then expand if necessary 
        while(!fringe.isEmpty())
        {
            node node_pop = fringe.poll(); 
            nodes_p++;
            //Check if node is goal city
            if(node_pop.get_name().equals(destination_city))
            {
                System.out.println("Nodes Popped:"+nodes_p);
                System.out.println("Nodes Expanded:"+nodes_e);
                System.out.println("Nodes Generated:"+nodes_g);
                print_route(node_pop,Graph_edges);
                break;
            }
            //Check if node has already been visited
            if(!closed_set.contains(node_pop.get_name()))                 
            {	
                closed_set.add(node_pop.get_name());  

                expand_node(node_pop,Graph_edges);
                nodes_e++;
                //add children to fringe
                for(int i=0;i<node_pop.get_children().size();i++)
                    {
                        node child= node_pop.get_children().get(i);
                        fringe.add(child); 
                        nodes_g++;
                    }
            }
    
            if(fringe.isEmpty())
            {
                System.out.println("Nodes Popped:"+nodes_p);
                System.out.println("Nodes Expanded:"+nodes_e);
                System.out.println("Nodes Generated:"+nodes_g);
                System.out.println("Distance: infinity");
                System.out.println("Route:"+'\n'+"none");
            }
        }


    }

    // Function to search through fringe for goal city with heuristics
    public static void Search_fringe_h( PriorityQueue<node> fringe,ArrayList<file> Graph_edges,String destination_city,ArrayList<String> closed_set, ArrayList<file2> heur_values)
    {
        int nodes_p = 0;
        int nodes_e = 0;
        int nodes_g = 1;

        //Pop node from fringe check if its goal, check if it has been visited then expand if necessary 
        while(!fringe.isEmpty())
        {
            node node_pop = fringe.poll(); 
            nodes_p++;
            //Check if node is goal city
            if(node_pop.get_name().equals(destination_city))
            {
                System.out.println("Nodes Popped:"+nodes_p);
                System.out.println("Nodes Expanded:"+nodes_e);
                System.out.println("Nodes Generated:"+nodes_g);
                print_route(node_pop,Graph_edges);
                break;
            }
            //Check if node has already been visited
            if(!closed_set.contains(node_pop.get_name()))                 
            {	
                closed_set.add(node_pop.get_name());  

                expand_node_h(node_pop,Graph_edges,heur_values);
                nodes_e++;
                //add children to fringe
                for(int i=0;i<node_pop.get_children().size();i++)
                    {
                        node child= node_pop.get_children().get(i);
                        fringe.add(child); 
                        nodes_g++;
                    }
            }
    
            if(fringe.isEmpty())
            {
                System.out.println("Nodes Popped:"+nodes_p);
                System.out.println("Nodes Expanded:"+nodes_e);
                System.out.println("Nodes Generated:"+nodes_g);
                System.out.println("Distance: infinity");
                System.out.println("Route:"+'\n'+"none");
            }
        }


    }

    // Main function
     public static void main(String[] args)
     {
        String input= args[0]; // Name of txt file with cities and the distances between them
		String origin_city=args[1]; // Route origin
		String destination_city=args[2]; // Route goal state(city)
        //String heuristic = args[3];

		ArrayList<String> closed_set = new ArrayList<String>();
		ArrayList<file> Graph_edges = new ArrayList<file>();
        ArrayList<file2> heur_values = new ArrayList<file2>();

		//int distance;
		node initial_city=new node(origin_city,0,0,null);
        
  
         //Checking if length of args array is greater than 0
         if (args.length == 3) 
         {
  
             // Check informed search
             System.out.println("Uninformed search");

             Generate_edges(input,Graph_edges);

            // Setting up fringe as a priority queue to sort nodes by their cost
            PriorityQueue<node> fringe = new PriorityQueue<node>(1000, new Comparator<node>() //Priority queue using cost as comparator
            {
                    public int compare(node node1, node node2)
                    {
                        
                        if (node1.get_cost()>node2.get_cost()) 
                            {
                                return 1;
                            }
                        else if (node1.get_cost()==node2.get_cost())
                            {
                                return 0;
                            }
                        else
                            return -1;
                    }
                }
            );	
            
            // populate fringe with first node of the origin city
            fringe.add(initial_city);

            // search through fringe for goal city
            Search_fringe(fringe, Graph_edges,destination_city,closed_set);

        }
  
         
  
         else if (args.length == 4)
         {
            String heuristic = args[3];       
             // Check informed search
             System.out.println("Informed search");
              Generate_edges(input,Graph_edges);

              // Generate_heuristics(heuristic,heur_values) 
              generate_heur_values(heuristic,heur_values);
 
             // Setting up fringe as a priority queue to sort nodes by their cost

            PriorityQueue<node> fringe = new PriorityQueue<node>(1000, new Comparator<node>() //Priority queue using cost as comparator
                {
                        public int compare(node node1, node node2)
                        {
                            
                            if (node1.get_cost()+node1.get_heuristic()>node2.get_cost()+node2.get_heuristic()) 
                                {
                                    return 1;
                                }
                            else if (node1.get_cost()+node1.get_heuristic()==node2.get_cost()+node2.get_heuristic())
                                {
                                    return 0;
                                }
                            else
                                return -1;
                        }
                    }
                );	
             
             // populate fringe with first node of the origin city
             fringe.add(initial_city);

 
             // search through fringe for goal city
             Search_fringe_h(fringe, Graph_edges,destination_city,closed_set,heur_values);
         }

         else 
            System.out.println("Incorrect format");
     }
}
