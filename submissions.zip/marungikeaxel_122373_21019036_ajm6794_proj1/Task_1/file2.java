import java.util.*;
import java.io.*;

public class file2 {
    String city;
    int heuristic;

    int get_heuristic()
	{
		return heuristic;
	}

    String get_city()
	{
		return city;
	}

    
}
