Name: Axel Marungike
UTA ID: 1001756794

Programming language: Java
I have not checked if code is compatible with Omega. Code is compatible with 
"openjdk version "1.8.0_242-release"
OpenJDK Runtime Environment (build 1.8.0_242-release-1644-b01)
OpenJDK 64-Bit Server VM (build 25.242-b01, mixed mode)"

Structure: The main methods are found in find_route.java 

Instructions: 

1)javac find_route.java

2)java find_route input_filename origin_city destination_city heuristic_filename
					OR
  java find_route input_filename origin_city destination_city 


