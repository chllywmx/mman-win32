import java.util.*;
import java.io.*;


public class file {

	String cityA;
	String cityB;
	int distance;

	// get distance/cost of edge 
	int get_distance()
	{
		return distance;
	}
	// get name of city A
	String get_cityA()
	{
		return cityA;
	}
	// get name of city B
	String get_cityB()
	{
		return cityB;
	}



}
