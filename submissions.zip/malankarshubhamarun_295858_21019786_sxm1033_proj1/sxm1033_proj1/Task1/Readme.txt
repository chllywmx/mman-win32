############################################
Commandline should be in format for informed search- python find_route.py input.txt Bremen Kassel
Commandline should be in format for informed search- python find_route.py input.txt Bremen Kassel h_kassel.txt
cost and distance should be in INTEGER values
'END OF INPUT' should be present at the end of each text file
-Programming Language - Python
-The program is written in python 3.9
-The program is executed in pycharm terminal
-IDE used is pycharm
############################################
********************************************
My output -
Astar
PS F:\installedsoftwares\pycharm\pycharmProjects\AIProject\part1> python find_route.py input.txt Bremen Kassel h_kassel.txt
popped Node: 3
Expanded Node: 2
Generated Node: 8
Distance: 297 km
Routelist:
Route:
Bremen to Hannover 132 km
Hannover to Kassel 165 km
********************************************
UCS
PS F:\installedsoftwares\pycharm\pycharmProjects\AIProject\part1> python find_route.py input.txt Bremen Kassel
popped Node: 12
Expanded Node: 6
Generated Node: 20
Distance: 297 km
Route
Bremen to Hannover 132 km
Hannover to Kassel 165 km
********************************************
UCS
PS F:\installedsoftwares\pycharm\pycharmProjects\AIProject\part1> python find_route.py input.txt London Kassel
popped Node: 7
Expanded Node: 4
Generated Node: 7
Distance: Infinity
Route
None
********************************************