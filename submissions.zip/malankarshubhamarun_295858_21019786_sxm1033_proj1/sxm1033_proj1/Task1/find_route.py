import sys
from queue import PriorityQueue


class Distance:
    def __init__(self, start, end, cost):
        self.start = start
        self.end = end
        self.cost = int(cost)


class DistanceAstar:
    def __init__(self, start, end, gOfN, hOfN):
        self.start = start
        self.end = end
        self.gOfN = int(gOfN)  # cost to reach nth element
        self.hOfN = int(hOfN)  # cost to reach goal from nth element


class heuristic:
    def __init__(self, start, cost):
        self.city = start
        self.value = int(cost)

#read file from the commandline further is redirected to UCS and Astar
def read_file(arguments):
    heuristicList = []
    cityList = []
    start_city = sys.argv[2]
    destination_city = sys.argv[3]
    try:
        with open(sys.argv[1], 'r') as f:
            inputDistance = f.read().split("\n")
        for i1 in range(len(inputDistance)):
            if "END OF INPUT" in inputDistance[i1]:
                break
            else:
                cityList.append(Distance(inputDistance[i1].split(" ")[0], inputDistance[i1].split(" ")[1],
                                         inputDistance[i1].split(" ")[2]))
                cityList.append(Distance(inputDistance[i1].split(" ")[1], inputDistance[i1].split(" ")[0],
                                         inputDistance[i1].split(" ")[2]))
    except:
        print("Issue in citylist")
    if (len(sys.argv) == 5):
        try:
            if sys.argv[4] is not None:
                #print("Heuristic list is set")
                with open(sys.argv[4], 'r') as h:
                    heuristicDistance = h.read().split("\n")
                for i1 in range(len(heuristicDistance)):
                    if "END OF INPUT" in heuristicDistance[i1]:
                        break
                    else:
                        heuristicList.append(
                            heuristic(heuristicDistance[i1].split(" ")[0], heuristicDistance[i1].split(" ")[1]))

        except:
            print("Issue in heuristicList")
            # ucsSearch(cityList, start_city, destination_city)
    if (len(sys.argv) == 5):
        AstarSearch(cityList, heuristicList, start_city, destination_city)
    else:
        ucsSearch(cityList, start_city, destination_city)
    
#Astar search
def AstarSearch(cityList, heuristicList, start_city, destination_city) -> None:
    fringe = PriorityQueue()
    routeListAstar = []
    fringe.put((findGoalCost(start_city, heuristicList), None, start_city, 0))
    routeListAstar.append(DistanceAstar(None, start_city, 0, findGoalCost(start_city, heuristicList)))
    visitedCity = []
    poppedNode = 0
    # expandedNode = 0
    generatedNode = 1
    while True:
        if fringe.empty():  # if no solution exist
            break
        currentCity = fringe.get()  # currentCity (200, None, 'Bremen', 0)
        poppedNode += 1
        if currentCity[2] == destination_city:
            break
        if currentCity[2] in visitedCity:
            continue
        else:
            # expandedNode += 1
            visitedCity.append(currentCity[2])
            for cityitr in range(len(cityList)):
                if cityList[cityitr].start == currentCity[2]:  # compare with Bremen
                    fringe.put((currentCity[3] + cityList[cityitr].cost + findGoalCost(cityList[cityitr].end,
                                                                                       heuristicList), currentCity[2],
                                cityList[cityitr].end, currentCity[3] + cityList[cityitr].cost))
                    routeListAstar.append(DistanceAstar(cityList[cityitr].start, cityList[cityitr].end,
                                                        currentCity[3] + cityList[cityitr].cost,
                                                        findGoalCost(cityList[cityitr].end, heuristicList)))
                    generatedNode += 1

    print("popped Node:", poppedNode)
    print("Expanded Node:", len(visitedCity))
    print("Generated Node:", generatedNode)
    print("Distance:", currentCity[0], "km") if searchCityCostFlagCheckAstar(currentCity[0], destination_city,
                                                                             routeListAstar, cityList) else print(
        "Distance: Infinity")
    print("Routelist:")
    print("Route:")
    searchCityCostAstar(currentCity[0], destination_city, routeListAstar, cityList) if searchCityCostFlagCheckAstar(
        currentCity[0],
        destination_city,
        routeListAstar,
        cityList) else print(
        None)
    return 0


def findGoalCost(start_city, heuristicList) -> None:
    for heurItr in range(len(heuristicList)):
        if heuristicList[heurItr].city == start_city:
            return (heuristicList[heurItr].value)

#print the city of actual route
def searchCityCostAstar(totalCost, destination_city, routeListAstar, cityList):
    for i2 in range(len(routeListAstar)):
        if routeListAstar[i2].end == destination_city and routeListAstar[i2].gOfN == totalCost:
            if routeListAstar[i2].start is None:
                break
            totalCost = totalCost - getCityCostFromList(routeListAstar[i2].start, routeListAstar[i2].end, cityList)
            flag = searchCityCostAstar(totalCost, routeListAstar[i2].start, routeListAstar, cityList)
            print(routeListAstar[i2].start, "to", routeListAstar[i2].end,
                  getCityCostFromList(routeListAstar[i2].start, routeListAstar[i2].end, cityList), "km")
    return 0

#print the city required flag
def searchCityCostFlagCheckAstar(totalCost, destination_city, routeList, cityList):
    flag = False
    for i2 in range(len(routeList)):
        if routeList[i2].end == destination_city and routeList[i2].gOfN == totalCost:
            if routeList[i2].start is None:
                flag = True
                break
            totalCost = totalCost - getCityCostFromList(routeList[i2].start, routeList[i2].end, cityList)
            flag = searchCityCostFlagCheckAstar(totalCost, routeList[i2].start, routeList, cityList)
    return flag

#UCS search
def ucsSearch(cityList, start_city, destination_city) -> None:
    # print(1)
    fringe = PriorityQueue()
    routeList = []
    fringe.put((0, None, start_city))
    routeList.append(Distance(None, start_city, 0))
    visitedCity = []
    poppedNode = 0
    generatedNode = 1
    while True:
        if fringe.empty():  # if no solution exist
            break
        currentCity = fringe.get()
        poppedNode += 1
        if currentCity[2] in visitedCity:
            continue

        if currentCity[2] == destination_city:
            break
        else:
            visitedCity.append(currentCity[2])
            for cityitr in range(len(cityList)):
                if cityList[cityitr].start == currentCity[2]:
                    fringe.put((currentCity[0] + cityList[cityitr].cost, currentCity[2], cityList[cityitr].end))
                    routeList.append(Distance(cityList[cityitr].start, cityList[cityitr].end,
                                              currentCity[0] + cityList[cityitr].cost))
                    generatedNode += 1

    print("popped Node:", poppedNode)
    print("Expanded Node:", len(visitedCity))
    print("Generated Node:", generatedNode)
    print("Distance:", currentCity[0], "km") if searchCityCostFlagCheck(currentCity[0], destination_city, routeList,
                                                                        cityList) else print("Distance: Infinity")
    print("Route")
    searchCityCost(currentCity[0], destination_city, routeList, cityList) if searchCityCostFlagCheck(currentCity[0],
                                                                                                     destination_city,
                                                                                                     routeList,
                                                                                                     cityList) else print(
        None)
    return 0

#search city traversed for UCS
def searchCityCost(totalCost, destination_city, routeList, cityList):
    for i2 in range(len(routeList)):
        if routeList[i2].end == destination_city and routeList[i2].cost == totalCost:
            if routeList[i2].start is None:
                break
            totalCost = totalCost - getCityCostFromList(routeList[i2].start, routeList[i2].end, cityList)
            searchCityCost(totalCost, routeList[i2].start, routeList, cityList)
            print(routeList[i2].start, "to", routeList[i2].end,
                  getCityCostFromList(routeList[i2].start, routeList[i2].end, cityList), "km")
    return 0

#search city traversed flag
def searchCityCostFlagCheck(totalCost, destination_city, routeList, cityList):
    flag = False
    for i2 in range(len(routeList)):
        if routeList[i2].end == destination_city and routeList[i2].cost == totalCost:
            if routeList[i2].start is None:
                flag = True
                break
            totalCost = totalCost - getCityCostFromList(routeList[i2].start, routeList[i2].end, cityList)
            flag = searchCityCostFlagCheck(totalCost, routeList[i2].start, routeList, cityList)
    return flag


def getCityCostFromList(startCity, endCity, cityList):
    for i2 in range(len(cityList)):
        if (cityList[i2].end == endCity and cityList[i2].start == startCity):
            return cityList[i2].cost


if __name__ == '__main__':
    read_file(sys.argv)

# command line - python find_route.py input.txt Birmingham London
