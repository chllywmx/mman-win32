Name - Shubham Malankar
ID - 1002031033
Alpha Beta pruning with depth limited

Player1 is red/1 or makes the next move in interactive game
Player2 is green/2
-Programming Language - Python
-The program is written in python 3.9
-The program is executed in pycharm terminal
-Start point is maxconnect4.py
-IDE used is pycharm
	
command I tested with are (in pycharm terminal) -
        1. for One move mode - python maxconnect4.py one-move input1.txt output.txt 10
        2. for interactive mode - python maxconnect4.py interactive input1.txt computer-next 2
-New methods/functions implemented are:-
    -In MaxConnect4Game.py
        aiPlayComputer - takes the depth and calls alphaBetaDecisionDepth,
        alphaBetaDecisionDepth - find all the possible moves for max value and then assign each gameboard to minPlayer,
        maxPlayer - find all the successors of the node and calls minPlayer else if depth limit is reach
        calls the calculateEvalScore,
        minPlayer - find all the successors of the node and calls maxPlayer else if depth limit is reach
        calls the calculateEvalScore,
        calculateEvalScore - calculates the eval score for player 1 and player 2 to make a decision,
        countScoreHorizontal - it counts all the players count in row wise and return it to calculateEvalScore
    -In maxconnect4.py
        checkIfMoveValid - checks if the move made by human is valid or not
        isColoumnFull - checks if the coloumn is full or has space

My output -
************************************************
PS F:\installedsoftwares\pycharm\pycharmProjects\AIProject\Part2> python maxconnect4.py one-move input1.txt output.txt 3
one-move

MaxConnect-4 game

Game state before move:
 -----------------
 |0000000|
 |0000000|
 |0000000|
 |0000000|
 |0000000|
 |0000000|
 -----------------
pieceCount 0
Score: Player 1 = 0, Player 2 = 0



move 2: Player 1, column 0

Game state after move:
 -----------------
 |0000000|
 |0000000|
 |0000000|
 |0000000|
 |0000000|
 |1000000|
 -----------------
Score: Player 1 = 0, Player 2 = 0
************************************************

PS F:\installedsoftwares\pycharm\pycharmProjects\AIProject\Part2> python maxconnect4.py interactive input2.txt computer-next 2
interactive

MaxConnect-4 game

Game state before move:
 -----------------
 |0000000|
 |0000000|
 |0200000|
 |0100002|
 |0200111|
 |1100222|
 -----------------
pieceCount 12
Score: Player 1 = 0, Player 2 = 0



move 14: Player 1, column 0

Game state after move:
 -----------------
 |0000000|
 |0000000|
 |0200000|
 |0100002|
 |0200111|
 |1110222|
 -----------------
Score: Player 1 = 0, Player 2 = 0

human-next
Enter a coloumn number between 1 to 7:2
Move made by human -  2
AI is thinking...


move 16: Player 1, column 0

Game state after move:
 -----------------
 |0000000|
 |0200000|
 |0200000|
 |0100002|
 |0200111|
 |1111222|
 -----------------
Score: Player 1 = 1, Player 2 = 0

Enter a coloumn number between 1 to 7:3
Move made by human -  3
AI is thinking...


move 18: Player 1, column 0

Game state after move:
 -----------------
 |0000000|
 |0200000|
 |0200000|
 |0100002|
 |0221111|
 |1111222|
 -----------------
Score: Player 1 = 2, Player 2 = 0

Enter a coloumn number between 1 to 7:
******************************************
