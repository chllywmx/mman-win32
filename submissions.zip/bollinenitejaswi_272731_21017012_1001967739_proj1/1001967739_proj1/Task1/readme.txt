Tejaswi Bollineni - 1001967739 - Task1

Used Python for the Mini Project 1 - Didn't check for the Omega Compatibility
find_route.py is the program used to implement the UCS and A* Search Algorithms.
    The program has 4 Functions
    1.To read the input file.
    2.To read the heuristic file for the Informed Search
    3.To perform the Uniform Cost Search
    4.To perform the A* Search
Steps for execution:
1. py find_route.py input1.txt Bremen Kassel - for execution in UCS
2. py find_route.py input1.txt Bremen Kassel h_Kassel.txt - for execution in A*.

Conditions to be met for execution:
1. The city names must "start with the Uppercase" for example: Bremen,London if the names in input1.txt has the same format.
2. The input1.txt and h_Kassel.txt must have "END OF INPUT" in upper case only
