Tejaswi Bollineni - 1001967739 - Task2

Used Python for the Mini Project 1 - Didn't check for the Omega Compatibility
maxconnect4.py is the program used to implement Minmax,Alph-abeta with depthsearch in interactive mode and One-move mode.

Steps for execution:
1. py maxconnect4.py interactive input_file.txt computer-next 3
2. py maxconnect4.py one-move input_file.txt test.txt 2