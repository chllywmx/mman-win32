#Name: Raj Sharadbhai Patel
#UTA ID: 1001979565



from audioop import reverse
from cmath import cos
import sys
from operator import itemgetter

def op_print():
    print("Nodes expanded : ",node_expanded)
    print("Nodes generated: ",nodes_generated)
    print("Number of nodes poped:",nodespoped)
    

def pathh():
    n=len(path1)-1
    j=0
    while(j!=n):
        f=0
        while(f!=len(route)):
        
            if path1[j]==route[f][0] and path1[j+1]==route[f][1]:
                print(path1[j],"---->",path1[j+1], route[f][2])
            f=f+1
        j=j+1
arglist=sys.argv
z= len(sys.argv)

location= "C:/Users/RAJ PATEL/Downloads/raj_ai/"+arglist[1]
route=[]



with open(location,'r') as data_file:
    for line in data_file:
        data = line.split()
       
        if data[0]!="END":
            route.append(data)

o=len(route)
for i in range(o):
    route.append([route[i][1],route[i][0],route[i][2]])
costt=0
nodespoped=0
startnode=arglist[2]
goal=arglist[3]
temp=[[startnode,costt]]
closed_set=[]
nodes_generated=1
path=[]
g=0
a=0
node_expanded=0
if z==4:
    t=0
    while(t!=len(route)):
        route[t][2]=int(route[t][2])
        t=t+1
    while startnode!=goal:
      
       

        if startnode not in closed_set:
            node_expanded=node_expanded+1
           

            q=0
            while(q!=len(route)):
                
                if route[q][0]==startnode:   
                    nodes_generated=nodes_generated+1  
                
                        
                    tc=route[q][2] + g          
                    x=[route[q][1],tc]   
                    path.append([route[q][1],startnode,tc,g])    
                    temp.append(x)
                q=q+1
            
            temp=sorted(temp, key=itemgetter(1))        
            x=len(temp)
            
            closed_set.append(startnode)
            
            
        
        if not temp:
            print("Goal state is not reachable.") 
            print("distance to the goal = Unprdictable")
            op_print()
            break
        else:
            temp=sorted(temp, key=itemgetter(1))
            startnode=temp[0][0]
            
            g=temp[0][1]
            temp.pop(0)
            nodespoped=nodespoped+1
           
      
      
            
    else:
        print("Total cost: ",g)
        path1=[]
        path1.append(goal)
        state=goal
        pc=g
        i=0
        while pc!=0:
            i=0
            while(i!=len(path)):
                if (path[i][0]==state and path[i][2]==pc):
                    path1.append(path[i][1])
                    pc=path[i][3]
                    state=path[i][1]
                i=i+1
        path1.reverse()
        op_print()
        print("Path to the Goal :",path1)
        pathh()










else:
    h_goal_file=arglist[4]
    h_goal=[]
    hdic={}
    currentcost=0
    temp=[[startnode,costt,currentcost]]
    cc=0
    k=0
    
    location1="C:/Users/RAJ PATEL/Downloads/raj_ai/"+arglist[4]


    with open(location1,'r') as data_file:
        for line in data_file:
            data = line.split()
        
            if data[0]!="END":
                h_goal.append(data)

    h=0
    while h!= len(h_goal):
        hdic[h_goal[h][0]]=int(h_goal[h][1])
        h=h+1
        for t in range(len(route)):
            route[t][2]=int(route[t][2])
    while startnode!=goal :
      
        
        if startnode not in closed_set:
            node_expanded=node_expanded+1

       
            q=0    
            while(q!=len(route)):
                if route[q][0]==startnode:     
                    nodes_generated=nodes_generated+1
                    cc=  route[q][2] + k
                    tc=cc + hdic[route[q][1]]     
                    x=[route[q][1],tc,cc]   
                    path.append([route[q][1],startnode,tc,g])    
                    temp.append(x)
                q=q+1
            temp=sorted(temp, key=itemgetter(1))        
            x=len(temp)
            
            closed_set.append(startnode)
            
            
        
        if not temp:
            print("Goal state is not reachable") 
            op_print()
            break   
        temp=sorted(temp, key=itemgetter(1))
        startnode=temp[0][0]
        g=temp[0][1]
        k=temp[0][2]
        temp.pop(0)
        nodespoped=nodespoped+1
        
        

        
    if not temp:
        print("Goal state is not reachable.")
    else:
        print("Total cost: ",k)

        path1=[]
        path1.append(goal)
        state=goal
        pc=g
        i=0
        while pc!=0:
            i=0
            while(i!= len(path)):
                if (path[i][0]==state and path[i][2]==pc):
                    path1.append(path[i][1])
                    pc=path[i][3]
                    state=path[i][1]
                i=i+1
        path1.reverse()
        print("Path to the Goal :",path1)
        op_print()
        pathh()

