Name : Vishwamsh Aryan Vadloori

UTA ID : 1001957470

Programming Language : Python

Code Structure : The code is organized as two main functions and two other to read the input file and find the path.
			-informed - (no heuristic)
			-uninformed - (heuristic)
		
How to run the code: 	

Run code:  

1. py find_route.py input1.txt origin_city destination_city
	Ex:
	py find_route.py input1.txt Bremen Kassel

2. py find_route.py input1.txt origin_city destination_city h_kassel.txt
	Ex:
	py find_route.py input1.txt Bremen Kassel h_kassel.txt




