#


import sys

from queue import PriorityQueue


def file(inputfile):
    s = {}
    heuristic_set = {}

    if (inputfile) == sys.argv[1]:
        fileread = open(inputfile, 'r')
        data = fileread.readlines()
        fileread.close()

        for line in data[:-1]:
            arr = line.split()
            if (arr[0] in s):
                s[arr[0]].append((int(arr[2]), arr[1]))
            else:
                s[arr[0]] = [(int(arr[2]), arr[1])]
            if (arr[1] in s):
                s[arr[1]].append((int(arr[2]), arr[0]))
            else:
                s[arr[1]] = [(int(arr[2]), arr[0])]
        return s

    elif inputfile == sys.argv[4]:
        fileread = open(inputfile, 'r')
        data = fileread.readlines()
        fileread.close()

        for line in data[:-1]:
            arr = line.split()
            heuristic_set[arr[0]] = int(arr[1])
        return heuristic_set


def informed(route, startstate, goalstate, heuristic):
    nodes_popped = 0

    nodes_generated = 1
    nodes_set = []
    fringe = PriorityQueue()
    fringe.put([0, startstate])
    while not fringe.empty():
        nodes_popped += 1
        index = fringe.get()
        if index[-1] == goalstate:
            return nodes_popped, nodes_generated, index
        else:
            if index[-1] not in nodes_set:
                nodes_set.append(index[-1])

                for a in route[index[-1]]:
                    nodes_generated += 1
                    fringe.put([a[0] + heuristic[a[1]], index[1:], a[1]])
    return nodes_popped, nodes_generated, None


def uninformed(route, startstate, goalstate):
    nodes_popped = 0
    nodes_generated = 1
    nodes_set = []
    fringe = PriorityQueue()
    fringe.put([0, startstate])
    while not fringe.empty():
        nodes_popped += 1
        index = fringe.get()
        if index[-1] == goalstate:
            return nodes_popped, nodes_generated, index
        else:
            if index[-1] not in nodes_set:
                nodes_set.append(index[-1])

                for a in route[index[-1]]:
                    nodes_generated += 1
                    fringe.put([index[0] + a[0], index[1:], a[1]])
    return nodes_popped, nodes_generated, None


Route = []


def route_list(rou_1):
    for k in rou_1:
        if type(k) == list:
            route_list(k)
        else:
            Route.append(k)
    return Route


if len(sys.argv) == 4:
    path = file(sys.argv[1])
    strt = sys.argv[2]
    end = sys.argv[3]
    nodes_popped, nodes_generated, value = uninformed(path, strt, end)



elif len(sys.argv) == 5:
    path = file(sys.argv[1])
    strt = sys.argv[2]
    end = sys.argv[3]
    heuristic = file(sys.argv[4])
    nodes_popped, nodes_generated, value = informed(path, strt, end, heuristic)
else:
    print("Invalid\n")


print("Nodes Popped: " + str(nodes_popped))
print('Nodes Generated: ' + str(nodes_generated))

if value == None:
    print('Distance: infinity')
    print('Route:')
    print('None')
else:
    print("Distance: " + str(value[0]) + ".0 km")
    print('Route:')
    Route = route_list(value[1])
    Route.append(value[2])
    for y in range(len(Route) - 1):
        for i in path[Route[y]]:
            if (i[1] == Route[y + 1]):
                d = i[0]
        print(str(Route[y]) + " to " + str(Route[y + 1]) + ", " + str(d) + ".0 km")
