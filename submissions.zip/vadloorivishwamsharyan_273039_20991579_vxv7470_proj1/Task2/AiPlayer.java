// Vishwamsh Aryan Vadloori
//1001957470

public class AiPlayer {
    public AiPlayer() 
    {
	}
    public int findBestPlay( GameBoard currentGame,int depth ){		
		int player_choice=currentGame.getalphabetaDecision(currentGame,depth);
	return player_choice;
    }
}