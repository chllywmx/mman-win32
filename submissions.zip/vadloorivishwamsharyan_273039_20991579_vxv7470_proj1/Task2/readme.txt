Name: Vishwamsh Aryan Vadloori
 
ID: 1001957470

Programming Language used: Java

Structure of code:

-Included the sample code
-Files:maxconnect4.java,GameBoard.java, AiPlayer.java
-Methods are defined in GameBoard.java
getEval() to evaluate the game state. 
getalphabetaDecision() to decide on making the move.
chkPlayPiece() to check the validation of the piece to play next.
func_successor() to get the successor of the game state.
fullBoard() to check if the gameboard is full.
isValidPlay() to check is a play is valid or not.
end() to check if it is the end state.
printGameBoard() to print the game board.
printGameBoardToFile() to create the ouputfile.
 

Evaluation Function used:

Counts:4 in a row as c1, 3 in a row with a blank as c2, 2 in a row with 2 blanks as c3, 1 in a row and 3 blanks as c4.
Weights assigned: w1=1.00, w2=0.75, w3=0.50, w4=0.25.
Score: (w1*c1)+(w2*c2)+(w3*c3)+(w4*c4)

			
How to run the code:

To Compile:	javac maxconnect4.java GameBoard.java AiPlayer.java

To Run:
-Interactive Mode
	java maxconnect4 interactive [input_file] [computer-next/human-next] [depth] 
	Ex:
		java maxconnect4 interactive inputa.txt computer-next 7
		java maxconnect4 interactive inputa.txt human-next 7

-One-Move Mode
	 java maxconnect4 one-move [input_file] [output_file] [depth]
	 Ex:
	 	java maxconnect4 one-move inputa.txt outputa.txt 10
		java maxconnect4 one-move inputb.txt outputb.txt 5
			
