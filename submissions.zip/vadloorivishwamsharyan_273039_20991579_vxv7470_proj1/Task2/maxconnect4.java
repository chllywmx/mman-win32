// Vishwamsh Aryan Vadloori
//1001957470

import java.util.*;

public class maxconnect4
{
	
	public static void mode(GameBoard current_game,String next,int depth){
		
		int play_column = 99;				
		int current_player = current_game.getCurrentTurn();
		System.out.println("Next Player:"+current_player);
		AiPlayer player = new AiPlayer();
	   	if( current_game.getPieceCount() < 42 ){
	       if(next.equals("human-next")){
				int piece_column;
				System.out.println("Enter the choice:");
				Scanner sc =new Scanner(System.in);
				piece_column=sc.nextInt();			
				play_column= piece_column;
				while(!current_game.isValidPlay( piece_column ) ){
					System.out.println("Invalid, Try again");
				    System.out.println("Enter the choice:");
					Scanner sc1 =new Scanner(System.in);
					piece_column=sc.nextInt();
				    play_column = piece_column;
					sc.close();
					sc1.close();
				}
				System.out.println("Human:"+current_player);
			}
			if(next.equals("computer-next")){
				int play = player.findBestPlay( current_game,depth );
				play_column=play;
				System.out.println("Computer:"+current_player);
			}
			current_game.chkPlayPiece( play_column );
	       	if(next.equals("computer-next")){	       
	        	current_game.printGameBoardToFile( "computer.txt" );
	    	}
	    	else{
	    		current_game.printGameBoardToFile( "human.txt" );	
	    	}
	        System.out.println("move " + current_game.getPieceCount() + ": Player " + current_player+ ", column " + play_column);
	        System.out.print("game state after move:\n");
	        current_game.printGameBoard();
	    	System.out.println( "Score: Player 1 = " + current_game.getScore( 1 ) +
	                            ", Player2 = " + current_game.getScore( 2 ) + "\n " );
	       if(current_game.fullBoard()){
	        	System.out.println("*******-----GAMEOVER-----*******");
	        	exit(0);
	        }
	        if(next.equals("computer-next")){
				GameBoard current= new GameBoard("computer.txt");
		       	next="human-next";
		       	mode(current,next,depth);
		    }
	    	else if(next.equals("human-next")){
		    	GameBoard current= new GameBoard("human.txt");
		       	next="computer-next";
		       	mode(current,next,depth);    		
	    	}  
	    }
		  
    }
public static void main(String[] args) 
  {
   if( args.length!= 4 ) 
    {
      System.out.println("Four command-line arguments are needed");
                         
      exit( 0 );
     }
		
    String mode = args[0].toString();				
    String input = args[1].toString();					
    int depth = Integer.parseInt( args[3] );    
    GameBoard current_game = new GameBoard( input );   
    AiPlayer player= new AiPlayer();	
    int play_column = 99;
    
    
    if(mode.equalsIgnoreCase( "interactive" )){
	  String next = args[2].toString();
      mode(current_game,next,depth);
    } 
    else if(mode.equalsIgnoreCase( "one-move" )){
	    String output = args[2].toString();
    
    current_game.printGameBoard();
    System.out.println( "Score: Player 1 = " + current_game.getScore( 1 ) + ", Player2 = " + current_game.getScore( 2 ) + "\n " );
    
	if( current_game.getPieceCount() < 42 ) 
	    {
	        int current_player = current_game.getCurrentTurn();
		
		play_column = player.findBestPlay( current_game,depth);		
		current_game.chkPlayPiece( play_column );
	        	
	        System.out.println("move " + current_game.getPieceCount() 
	                           + ": Player " + current_player+ ", column " + play_column);
	        System.out.print("game state after move:\n");
	        current_game.printGameBoard();
	    
	        System.out.println( "Score: Player 1 = " + current_game.getScore( 1 ) + ", Player2 = " + current_game.getScore( 2 ) + "\n " );
	        current_game.printGameBoardToFile( output );
	    }

    	else{
			System.out.println("\nThe Board is Full!!\n\n-----Game Over-----");
    	}
	    
	}
	else if( !mode.equalsIgnoreCase( "one-move" ) && !mode.equalsIgnoreCase( "mode" ) ){
      System.out.println( "\nGame mode unrecognized.\nTry again.\n" );
      return;
    } 		    
    return;
    
} 
  private static void exit(int value)
  {
      System.out.println("Exit!\n\n");
      System.exit( value );
  }
} 
