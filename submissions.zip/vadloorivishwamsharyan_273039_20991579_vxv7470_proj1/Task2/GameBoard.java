// Vishwamsh Aryan Vadloori
//1001957470

import java.io.*;

public class GameBoard implements Cloneable
{    
    private int[][] game_board;
    private int piece_count;
    private int current_turn;
    private static int play,min_ply,max_ply;
	private static int row=5,column=0;

    public GameBoard( String input_file ) 
    {
	this.game_board = new int[6][7];
	this.piece_count = 0;
	int count = 0;
	BufferedReader br = null;
	String data = null;

	try 
	{
	    br = new BufferedReader( new FileReader(input_file) );
	} 
    catch( IOException e ) 
	{
	    System.out.println("\nProblem opening the file.Try again.\n");
	    e.printStackTrace();
	}
	for(int i= 0;i< 6; i++) 
	{
	    try 
	    {
		data = br.readLine();
		
		for( int j= 0;j< 7; j++ ) 
		{
		    this.game_board[i][j] = data.charAt( count++ ) - 48;
		    if( !( ( this.game_board[i][j] == 0 ) ||
			   ( this.game_board[i][j] == 1 ) ||
			   ( this.game_board[i][j] == 2 ) ) ) 
                {
			System.out.println("\nThe input must be 0 or 1 or 2" );
			this.exit( 0 );
		    }
		    
		    if( this.game_board[i][j] > 0 )
		    {
			this.piece_count++;
		    }
		}
	    } 
	    catch( Exception e ) 
	    {
		System.out.println("\nProblem reading the br file!Try again.\n");
		e.printStackTrace();
		this.exit( 0 );
	    }

	    count = 0;
	    
	} 
	try 
        {
	    data = br.readLine();
	} 
	catch( Exception e ) 
	{
	    System.out.println("\nProblem reading the next turn!\n");
	    e.printStackTrace();
	}
	this.current_turn = data.charAt( 0 ) - 48;
	
	
	if(!( ( this.current_turn == 1) || ( this.current_turn == 2 ) ) ) 
	{
	    System.out.println("\nThe current turn read is not a 1 or  2!");
	    this.exit( 0 );
	} 
	else if ( this.getCurrentTurn() != this.current_turn ) 
	{
	    System.out.println("The current turn read does not correspond to the number of pieces!");
	    this.exit( 0 );			
	}
    }
    public GameBoard( int gmarr[][] ) 
    {
	
	this.game_board = new int[6][7];
	this.piece_count = 0;

	for(int i= 0;i< 6; i++ ) 
	{
	    for( int j= 0;j< 7; j++) 
	    {
		this.game_board[i][j] = gmarr[i][j];
		
		if( this.game_board[i][j] > 0 )
		{
		    this.piece_count++;
		}
	    }
	}
    } 
    public int getScore( int player ) 
    {
	int player_score = 0;

	for(int i= 0;i< 6; i++ ) 
        {
	    for( int j= 0;j< 4; j++ ) 
	    {
		if( ( this.game_board[i][j] == player ) && ( this.game_board[i][j+1] == player ) && ( this.game_board[i][j+2] == player ) &&(this.game_board[i][j+3] == player ) ) 
		{
		    player_score++;
		}
	    }
	} 
	for(int i= 0;i< 3; i++ ) {
	    for( int j= 0;j< 7; j++ ) {
		if( ( this.game_board[i][j] == player ) &&( this.game_board[i+1][j] == player ) &&( this.game_board[i+2][j] == player ) &&( this.game_board[i+3][j] == player ) ) 
		{
		    player_score++;
		}
	    }
	} 
	    for(int i= 0;i< 3; i++ ){
		for( int j= 0;j< 4; j++ ) {
		    if( ( this.game_board[i][j] == player ) &&(this.game_board[i+1][j+1] == player ) &&( this.game_board[i+2][j+2] == player ) &&( this.game_board[i+3][j+3] == player ) )
			{
			player_score++;
		    }
		}
	    }
	    
	    for(int i= 0;i< 3; i++ ){
		for( int j= 0;j< 4; j++ ) {
		    if( ( this.game_board[i+3][j] == player ) &&( this.game_board[i+2][j+1] == player ) &&( this.game_board[i+1][j+2] == player ) &&( this.game_board[i][j+3] == player ) ) 
			{
			player_score++;
		    }
		}
	    }
	    
	    return player_score;
    } 

    public int getCurrentTurn() 
    {
	return ( this.piece_count % 2 ) + 1 ;
    } 

    public int getPieceCount() 
    {
	return this.piece_count;
    }

    public int[][] getGB() 
    {
		return this.game_board;
    }
    
	public GameBoard(){
		this.game_board = new int[6][7];
        this.piece_count = 0;

        for(int i= 0;i< 6; i++ ) 
        {
            for( int j= 0;j< 7; j++) 
            {
            this.game_board[i][j] = 0;
           }
        }
    }  
    public double getEval( int  a[][], int ply ){		
		double player_score = 0;
		int c1=0,c2=0,c3=0,c4=0;
		double w1=1.00,w2=0.75,w3=0.50,w4=0.25;
		for(int i= 0;i< 6; i++){
		    for( int j= 0;j<4; j++){
				if( (a[i][j] == ply) &&(a[i][j+1] == ply) &&(a[i][j+2] == ply) &&(a[i][j+3] == ply) ){
					c1++;
				}
				if( (a[i][j] == ply) &&(a[i][j+1] == ply) &&(a[i][j+2] == ply) &&(a[i][j+3] == 0 ) ){
					c2++;
				}
				else if( (a[i][j] == 0 ) &&(a[i][j+1] == ply) &&(a[i][j+2] == ply) &&(a[i][j+3] == ply) ){
					c2++;
				}
				if( (a[i][j] == ply) &&(a[i][j+1] == ply) &&(a[i][j+2] == 0 ) &&(a[i][j+3] == 0 ) ){
					c3++;
				}
				else if( (a[i][j] == 0 ) &&(a[i][j+1] == 0 ) &&(a[i][j+2] == ply) &&(a[i][j+3] == ply) ){
					c3++;
				}
				if( (a[i][j] == ply) &&(a[i][j+1] == 0 ) &&(a[i][j+2] == 0 ) &&(a[i][j+3] == 0 ) ){
					c4++;
				}
				else if( (a[i][j] == 0 ) &&(a[i][j+1] == 0 ) &&(a[i][j+2] == 0 ) &&(a[i][j+3] == ply) ){
					c4++;
				}
			}
		} 
		for(int i= 0;i<3; i++) {
		    for( int j= 0;j< 7; j++ ) {
				if( (a[i][j] == ply) &&(a[i+1][j] == ply) &&(a[i+2][j] == ply) &&(a[i+3][j] == ply) ) {
				    c1++;
				}
				if( (a[i][j] == ply) &&(a[i+1][j] == ply) &&(a[i+2][j] == ply) &&(a[i+3][j] == 0 ) ) {
				    c2++;
				}
				else if( (a[i][j] == 0) &&(a[i+1][j] == ply) &&(a[i+2][j] == ply) &&(a[i+3][j] == ply) ) {
				    c2++;
				}
				if( (a[i][j] == ply) &&(a[i+1][j] == ply) &&(a[i+2][j] == 0 ) &&(a[i+3][j] == 0 ) ) {
				    c3++;
				}
				else if( (a[i][j] == 0) &&(a[i+1][j] == 0 ) &&(a[i+2][j] == ply) &&(a[i+3][j] == ply) ) {
				    c3++;
				}
				if( (a[i][j] == ply) &&(a[i+1][j] == 0 ) &&(a[i+2][j] == 0 ) &&(a[i+3][j] == 0 ) ) {
				    c4++;
				}
				else if( (a[i][j] == 0) &&(a[i+1][j] == 0 ) &&(a[i+2][j] == 0 ) &&(a[i+3][j] == ply) ) {
				    c4++;
				}
		    }
		} 
		for(int i= 0;i<3; i++ ){
			for( int j= 0;j< 4; j++ ) {
			    if( (a[i][j] == ply) &&(a[i+1][j+1] == ply) &&(a[i+2][j+2] == ply) &&(a[i+3][j+3] == ply) ) {
					c1++;
			    }
			     if( (a[i][j] == ply) &&(a[i+1][j+1] == ply) &&(a[i+2][j+2] == ply) &&(a[i+3][j+3] == 0 ) ) {
					c2++;
			    }
			     else if( (a[i][j] == 0 ) &&(a[i+1][j+1] == ply) &&(a[i+2][j+2] == ply) &&(a[i+3][j+3] == ply) ) {
					c2++;
			    }
			     if( (a[i][j] == ply) &&(a[i+1][j+1] == ply) &&(a[i+2][j+2] == 0 ) &&(a[i+3][j+3] == 0 ) ) {
					c3++;
			    }
			    else if( (a[i][j] == 0 ) &&(a[i+1][j+1] == 0) &&(a[i+2][j+2] == ply) &&(a[i+3][j+3] == ply) ) {
					c3++;
			    }
			     if( (a[i][j] == ply) &&(a[i+1][j+1] == 0) &&(a[i+2][j+2] == 0 ) &&(a[i+3][j+3] == 0 ) ) {
					c4++;
			    }
			    else if( (a[i][j] == 0 ) &&(a[i+1][j+1] == 0) &&(a[i+2][j+2] == 0 ) &&(a[i+3][j+3] == ply) ) {
					c4++;
			    }
			}
		}
		for(int i= 0;i< 3; i++){
			for( int j= 0;j< 4; j++ ) {
			    if( (a[i+3][j] == ply) &&(a[i+2][j+1] == ply) &&(a[i+1][j+2] == ply) &&(a[i][j+3] == ply) ) {
					c1++;
			    }
			    if( (a[i+3][j] == ply) &&(a[i+2][j+1] == ply) &&(a[i+1][j+2] == ply) &&(a[i][j+3] == 0 ) ) {
					c2++;
			    }
			    else if( (a[i+3][j] == 0 ) &&(a[i+2][j+1] == ply) &&(a[i+1][j+2] == ply) &&(a[i][j+3] == ply) ) {
					c2++;
			    }
			    if( (a[i+3][j] == ply) &&(a[i+2][j+1] == ply) &&(a[i+1][j+2] == 0 ) &&(a[i][j+3] == 0 ) ) {
					c3++;
			    }
			    else if( (a[i+3][j] == 0 ) &&(a[i+2][j+1] == 0 ) &&(a[i+1][j+2] == ply) &&(a[i][j+3] == ply) ) {
					c3++;
			    }
			    if( (a[i+3][j] == ply) &&(a[i+2][j+1] == 0 ) &&(a[i+1][j+2] == 0 ) &&(a[i][j+3] == 0 ) ) {
					c4++;
			    }
			    else if( (a[i+3][j] == 0 ) &&(a[i+2][j+1] == 0 ) &&(a[i+1][j+2] == 0 ) &&(a[i][j+3] == ply) ) {
					c4++;
			    }
			}
		}
		player_score=((w1*c1)+(w2*c2)+(w3*c3)+(w4*c4));
		return player_score;
    } 
    public double max(double alpha,double beta,int d,int depth){
		play=max_ply;
		if((d==(depth))||end(this.game_board)){
        	double value=getEval(this.game_board,max_ply)-getEval(this.game_board,min_ply);
        	return value;
        }
        double tmp=0;
        int x=0;
	    int gm[][],arr[][];
	    gm=this.getGB();
	    GameBoard []s=new GameBoard[7];
	    int scc=this.getNoofSucc();
	    column=0;
	    row=5;
	    for(x=0;x<scc;x++){
			GameBoard temp_gameboard=new GameBoard();
		    s[x] = new GameBoard();
		    temp_gameboard.game_board=gm;
		    temp_gameboard.func_successor();
		    arr=temp_gameboard.getGB();
		    for(int i=0;i<6;i++){
		    
		    	for(int j=0;j<7;j++){
		    	   s[x].game_board[i][j]=arr[i][j];		
		    	}
			}		    
			temp_gameboard.empty(row,column);
		    column++;
	    } 
	    double v=Double.NEGATIVE_INFINITY;
	    for(x=0;x<scc;x++){
	    	tmp=s[x].min(alpha,beta,d+1,depth);
	    	if(v<tmp){
    			v=tmp;
    		}
    		if(v>=beta){
    			return v;
    		}
    		play=max_ply;
    		if(alpha<v){
    			alpha=v;
    		}
	    }
    	return v;
    }
    public double min(double alpha,double beta,int d,int depth){
        play=min_ply;
        if((d==(depth))||end(this.game_board)){
        	double value=getEval(this.game_board,max_ply)-getEval(this.game_board,min_ply);
        	return value;
        }
        double tmp=0;int x=0;
	    int arr[][];
		int gm[][];
	    gm=this.getGB();
	    GameBoard s[]=new GameBoard[7];
	    int scc=this.getNoofSucc();
	    column=0;row=5;
	    for(x=0;x<scc;x++){
	    	GameBoard temp_gameboard=new GameBoard();
		    s[x] = new GameBoard();
		    temp_gameboard.game_board=gm;
		    temp_gameboard.func_successor();
		    arr=temp_gameboard.getGB();
		    for(int i=0;i<6;i++){
		    	for(int j=0;j<7;j++){
		    	   s[x].game_board[i][j]=arr[i][j];		
		    	}
			}		    
			temp_gameboard.empty(row,column);
		    column++;
	    }
	    double v=Double.POSITIVE_INFINITY;
	    for(x=0;x<scc;x++){
	    	tmp=s[x].max(alpha,beta,d+1,depth);
	    	if(v>tmp){
    			v=tmp;
    		}
    		if(v<=alpha){
    			return v;
    		}
    		play=min_ply;
    		if(beta>v){
    			beta=v;
    		}
	    }
    	return v;
    }
	
    public void func_successor(){
      int i=5;
      int j=column;
      while(i>=0&&j<7){
           if(this.game_board[i][j]==0){
                if(play==1){
                    this.game_board[i][j]=1;
                    row=i;
                    column=j;
                }
                else{
                	this.game_board[i][j]=2;
                    row=i;
                    column=j;                            
                }
               break;
            }
            else{
            	i--;
            	if(i<0){
            		i=5;
            		j++;
            	}
            }
        };
    }
    public int getNoofSucc(){
    	int i=0,j=0;
    	int cnt=0;
    	for(j=0;j<7;j++){
    		for(i=0;i<6;i++){
    			if(this.game_board[i][j]==0){
    				cnt++;
    				i=6;
    			}
    		}
    	}
    	return cnt;
    }
    public int getalphabetaDecision(GameBoard current_game,int depth){
		int x=0;
    	int best=0;
    	double tmp=0;
    	int gm[][],arr[][];
    	int pcol=0;
    	int p_col[]={0,0,0,0,0,0,0};
		int d=0;
    	double alpha=Double.NEGATIVE_INFINITY;
    	double beta=Double.POSITIVE_INFINITY;
    	if(depth==0){
    		System.out.println("Minimum Depth 1");
    		exit(0);
    	}
    	row=5;column=0;
    	GameBoard s[]=new GameBoard[7];
    	int scc=current_game.getNoofSucc();
    	gm=current_game.getGB();
    	play=current_game.getCurrentTurn();
    	max_ply=play;
    	if(max_ply==1){
    		min_ply=2;
    	}
    	else min_ply=1;
		for(x=0;x<scc;x++){
			GameBoard temp_gameboard=new GameBoard();
		    s[x] = new GameBoard();
		    temp_gameboard.game_board=gm;
		    temp_gameboard.func_successor();
		    p_col[pcol]=column;
		    arr=temp_gameboard.getGB();
		    for(int i=0;i<6;i++){
		    	for(int j=0;j<7;j++){
		    	   s[x].game_board[i][j]=arr[i][j];		
		    	}
		    }
		    temp_gameboard.empty(row,column);
		   	column++;
		    pcol++;
    	}
    	double v=Double.NEGATIVE_INFINITY;
    	best=0;
    	pcol=0;
    	for(x=0;x<scc;x++){
    		tmp=s[x].min(alpha,beta,d+1,depth);
    		if(v<tmp){
    			v=tmp;
    			best=p_col[pcol];
    			if(alpha<v){
    				alpha=v;
    			}   			
    			if(v>=beta){
    				return best;
    			}   		
    		}
    		play=max_ply;
    		pcol++;
    	}
    	return best;
    }
    
    public boolean fullBoard(){
    	int i=0,j=0;
    	for(j=0;j<7;j++){
    		for(i=0;i<6;i++){
    			if(this.game_board[i][j]==0){
    				return false;
    			}
    		}
    	}	
    	return true;
    }

   
    public boolean isValidPlay( int column ) {
	
	if (!(column>=0&&column<=6)){
	    
	    return false;
	} else if(this.game_board[0][column]>0){
	    
	    return false;
	} else {
	    
	    return true;
	}
    }

    
    public boolean chkPlayPiece( int column ) {
	
	
	if( !this.isValidPlay(column)){
	    return false;
	} else {
	    for(int i= 5;i>= 0; i--){
		if( this.game_board[i][column] == 0 ) {
		    if( this.piece_count%2==0){
			this.game_board[i][column] = 1;
			this.piece_count++;
			
		    } else { 
			this.game_board[i][column] = 2;
			this.piece_count++;
		    }
		    return true;
		}
	    }
	    System.out.println("Something went wrong.");
	    
	    return false;
	}
    } 
    public void remove_piece( int column ) {
	for(int i= 0;i< 6; i++ ) {
	    if( this.game_board[i][ column ] > 0 ) {
		this.game_board[i][ column ] = 0;
		this.piece_count--;
		
		break;
	    }
	}
    } 
	public void empty(int row, int column){
    	for(int i=0;i<6;i++){
    		for(int j=0;j<7;j++){
    			if(i==row&&j==column){
    				this.game_board[i][j]=0;
    			}
    		}
    	}
    }
    public  Boolean end(int[][] a){
        for(int i=0;i<6;i++){
         	for(int j=0;j<7;j++){
         		 if(a[i][j]==0)
				  	return false;  
         	}  	
        }
        return true;
    }
    public void printGameBoard() 
    {
	System.out.println("-------------");
	
	for(int i=0;i<6;i++ ) 
        {
	    System.out.print(" | ");
	    for( int j= 0;j< 7;j++ ) 
            {
                System.out.print( this.game_board[i][j] + " " );
            }

	    System.out.println("| ");
	}
	
	System.out.println("------------");
    } 
    public void printGameBoardToFile( String outputFile ) {
	try {
	    BufferedWriter op = new BufferedWriter(new FileWriter(outputFile));
	    for(int i= 0;i< 6; i++) {
		for( int j= 0;j< 7; j++) {
		    op.write( this.game_board[i][j] + 48 );
		}
		op.write("\r\n");
	    }
	    
	    op.write( this.getCurrentTurn() + "\r\n");
	    op.close();
	    
	} catch( IOException e ) {
	    System.out.println("\nProblem writing to the output file!\nTry again.");
	    e.printStackTrace();
	}
    } 
    
    private void exit( int value ){
	System.out.println("exiting from GameBoard.java!\n\n");
	System.exit( value );
    }
    
} 
