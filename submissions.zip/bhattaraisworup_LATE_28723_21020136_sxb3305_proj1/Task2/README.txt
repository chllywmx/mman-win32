README.TXT
========


Sworup Bhattarai

TASK 2:
========
    
    Created on Python(3.9), ran on Spyder using Anaconda NOT Omega Comaptiable
    To execute Interactive Mode:
        maxconnect4 interactive [input_file] [computer-next/human-next] [depth]
        
    To execute One-Move Mode:
        maxconnect4 one-move [input_file] [output_file] [depth]
        
        
        