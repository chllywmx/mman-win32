import java.io.*;
import java.util.*;

/**
 * 
 * @author James Spargo
 * This class controls the game play for the Max Connect-Four game. 
 * To compile the program, use the following command from the maxConnectFour directory:
 * javac *.java
 *
 * the usage to run the program is as follows:
 * ( again, from the maxConnectFour directory )
 *
 *  -- for interactive mode:
 * java MaxConnectFour interactive [ input_file ] [ computer-next / human-next ] [ search depth]
 *
 * -- for one move mode
 * java maxConnectFour.MaxConnectFour one-move [ input_file ] [ output_file ] [ search depth]
 * 
 * description of arguments: 
 *  [ input_file ]
 *  -- the path and filename of the input file for the game
 *  
 *  [ computer-next / human-next ]
 *  -- the entity to make the next move. either computer or human. can be abbreviated to either C or H. This is only used in interactive mode
 *  
 *  [ output_file ]
 *  -- the path and filename of the output file for the game.  this is only used in one-move mode
 *  
 *  [ search depth ]
 *  -- the depth of the minimax search algorithm
 * 
 *   
 */

public class maxconnect4
{
	public static void main(String[] args) {		
		if( args.length != 4 ) 
		{
			System.out.println("Four command-line arguments are needed:\n"
					+ "Usage: java [program name] interactive [input_file] [computer-next / human-next] [depth]\n"
					+ " or:  java [program name] one-move [input_file] [output_file] [depth]\n");

			exit_function( 0 );
		}		
		String game_mode = args[0].toString();				
		String input = args[1].toString();							
		int depthLevel = Integer.parseInt(args[3]);

		// create and initialize the game board
		GameBoard currentGame = new GameBoard( input );

		// create the Ai Player
		AiPlayer calculon = new AiPlayer( depthLevel );
		
		int playColumn = 99;				//  the players choice of column to play
		boolean playMade = false;			//  set to true once a play has been made

		if( game_mode.equalsIgnoreCase( "interactive" ) ) 
		{
		String nMove = args[2].toString();
			if(nMove.equalsIgnoreCase("human-next"))
			{
				String movet_1 ="human";
				String movet_2="computer";
				String tempo_var;
				if(currentGame.getCurrentTurn()==2) {

					tempo_var=movet_1;
					movet_1=movet_2;
					movet_2=tempo_var;
				}
				currentGame.printGameBoard();
				System.out.println( "Score: " + movet_1 + " = " + currentGame.getScore( 1 ) +
						",  " +  movet_2 + " = " + currentGame.getScore( 2 ) + "\n " );
				while( currentGame.getPieceCount() < 42 )
				{
					Scanner inp_consol = new Scanner(System.in);
					System.out.println("Please make your move.");
					int usersinp = inp_consol.nextInt();
					while(!currentGame.playPiece(usersinp-1))
					{
						System.out.println("Invalid move!Please make valid move.");
						Scanner inp_consolopt = new Scanner(System.in);
						usersinp = inp_consolopt.nextInt();
					}
					currentGame.printGameBoardToFile( "human.txt" );
					System.out.println("game state after  move : human");
					currentGame.printGameBoard();
					System.out.println( "Score: " + movet_1 + " = " + currentGame.getScore( 1 ) +
							",  " +  movet_2 + " = " + currentGame.getScore( 2 ) + "\n " );
					playColumn = calculon.findBestPlay( currentGame );

					currentGame.playPiece( playColumn );
					System.out.println("move " + currentGame.getPieceCount()
					+ " : computer " + 
					"column " + (playColumn+1));
					System.out.println("game state after move : computer");
					currentGame.printGameBoard();

					// print the current scores
					System.out.println( "Score: " + movet_1 + " = " + currentGame.getScore( 1 ) +
							",  " +  movet_2 + " = " + currentGame.getScore( 2 ) + "\n " );

					currentGame.printGameBoardToFile( "computer.txt" );
				}



				System.out.println("\nI can't play.\nThe Board is Full\n\nGame Over");
				exit_function(0);
			}

			if(nMove.equalsIgnoreCase("computer-next"))
			{
				currentGame.printGameBoard();
				String movet_1 ="human";
				String movet_2="computer";
				String varTemp;
				if(currentGame.getCurrentTurn()==2) {
					
					varTemp=movet_1;
					movet_1=movet_2;
					movet_2=varTemp;
				}

				System.out.println("Score: " + movet_2 + " = " + currentGame.getScore( 1 ) +
						",  " +  movet_1 + " = " + currentGame.getScore( 2 ) + "\n " );
				while( currentGame.getPieceCount() < 42 )
				{
					playColumn = calculon.findBestPlay( currentGame );

					currentGame.playPiece( playColumn );

					
					System.out.println("move " + currentGame.getPieceCount()
					+ " : computer " + 
					"column " + (playColumn+1));
					System.out.println("game state after move : computer");
					currentGame.printGameBoard();

					// print the current scores
					System.out.println( "Score: " + movet_2 + " = " + currentGame.getScore( 1 ) +
							",  " +  movet_1 + " = " + currentGame.getScore( 2 ) + "\n " );

					currentGame.printGameBoardToFile( "computer.txt" );

					Scanner inp_consol = new Scanner(System.in);
					System.out.println("Proceed with your move.");
					int usersinp = inp_consol.nextInt();
					while(!currentGame.playPiece(usersinp-1))
					{
						System.out.println("Invalid move! Please make valid move.");
						Scanner inp_consolopt = new Scanner(System.in);
						usersinp = inp_consolopt.nextInt();
					}
					currentGame.printGameBoardToFile( "human.txt" );
					System.out.println("game state after  move : human");
					currentGame.printGameBoard();

					System.out.println( "Score: " + movet_2 + " = " + currentGame.getScore( 1 ) +
							",  " +  movet_1 + " = " + currentGame.getScore( 2 ) + "\n " );


				}
				System.out.println("\nI can't play.\nThe Board is Full\n\nGame Over");
				exit_function(0);
			}

		}


		else if( game_mode.equalsIgnoreCase( "one-move" ) )
		{


			String output = args[2].toString();

			System.out.print("\nMaxConnect-4 game\n");
			System.out.print("game state before move:\n");

			currentGame.printGameBoard();
			System.out.println( "Score: Player 1 = " + currentGame.getScore( 1 ) +
					", Player 2 = " + currentGame.getScore( 2 ) + "\n " );

			if( currentGame.getplayBoard() < 42 )
			{
				int current_player = currentGame.getCurrentTurn();
				double start = System.nanoTime();

				playColumn = calculon.findBestPlay( currentGame );
				double comput_time = System.nanoTime() - start;

				currentGame.playPiece(playColumn);

				System.out.println("move " + currentGame.getPieceCount()
				+ ": Player " + current_player
				+ ", column " + playColumn);
				System.out.print("game state after move:\n");
				currentGame.printGameBoard();

				System.out.println( "Score: Player 1 = " + currentGame.getScore( 1 ) +
						", Player 2 = " + currentGame.getScore( 2 ) + "\n " );

				currentGame.printGameBoardToFile(output);
				System.out.println("Time took = "+comput_time/1000000000);

			} 
			else{
			System.out.println("\nI can't play.\nThe Board is Full\n\nGame Over");
			}
			
			return;

		} 
	}
	// end of main()

	/**
	 * This method is used when to exit the program prematurly.
	 * @param value an integer that is returned to the system when the program exits.
	 */
	private static void exit_function( int value )
	{
		System.out.println("exiting from MaxConnectFour.java!\n\n");
		System.exit( value );
	}
} // end of class connectFour