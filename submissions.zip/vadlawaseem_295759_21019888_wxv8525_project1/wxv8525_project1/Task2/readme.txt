Student Name: Waseem Vadla
Student ID: 1002028525

Programming language used : JAVA



How to run:
javac maxconnect4.java GameBoard.java AiPlayer.java

Execution: 
1) one move node: java maxconnect4 one-move input2.txt output2.txt 10
2) Interactive: java maxconnect4 interactive input2.txt human-next 3


