import java.util.*;

/**
 * This is the AiPlayer class. It simulates a minimax player for the max connect
 * four game. The constructor essentially does nothing.
 * 
 * @author james spargo
 *
 */

public class AiPlayer {
	/**
	 * The constructor essentially does nothing except instantiate an AiPlayer
	 * object.
	 *
	 */


	int deep;
	
	public AiPlayer(int deep){
		
		
		this.deep=deep;
	}

	/**
	 * This method plays a piece randomly on the board
	 * @param currentGame The GameBoard object that is currently being used to play
	 *                    the game.
	 * @return an integer indicating which column the AiPlayer would like to play
	 *         in.
	 */
	public int findBestPlay(GameBoard currentGame) {
		int playersChoice = 99;		
		if (currentGame.getCurrentTurn() == 1) {
			int compareval;
			int val=1000000;
			for (int i = 0; i < 7; i++) {
				if (currentGame.isValidPlay(i)) {
					GameBoard crntMove = new GameBoard(currentGame.getGameBoard());
					crntMove.playPiece(i);
					compareval = valueH(crntMove, deep, -1000000, 1000000);
					if ( compareval<val) {
						playersChoice = i;
						val = compareval;
					}
				}
			}
		} else {
			int compareval;
			int  val=-1000000;
			for (int i = 0; i < 7; i++) {
				if (currentGame.isValidPlay(i)) {
					GameBoard crntMove = new GameBoard(currentGame.getGameBoard());
					crntMove.playPiece(i);
					compareval = valueH(crntMove, deep, -1000000, 1000000);
					if (compareval>val) {
						playersChoice = i;
						val = compareval;
					}

				}
			}
		}

		return playersChoice;
	}  


	public int valueH(GameBoard gameB,int deep,int top,int bottom) {
		if((gameB.getPieceCount()<42)&& deep >0) {
			int pruneValue =-100000;
			int pvalcomp;
			for(int i=0;i<7;i++) {
				if(gameB.isValidPlay(i)) {
					GameBoard ncrntMove1= new GameBoard(gameB.getGameBoard());
					ncrntMove1.playPiece(i);
					pvalcomp=valueL(ncrntMove1,deep-1,top,bottom);
					if(pruneValue<pvalcomp) {
						pruneValue=pvalcomp;
					}
					if(pruneValue>=bottom) {
						return pruneValue;
					}
					if(pruneValue>top) {
						top=pruneValue;

					}
				}
			}
			return pruneValue;
		}

		else{
			
				return (gameB.functionEval(2)*100)-(gameB.functionEval(1)*100);
					
		}
	}
	public int valueL(GameBoard gameB,int deep,int top,int bottom) {
		if((gameB.getPieceCount()<42)&& deep >0) {
			int npruneValue =100000;
			int npvalcomp;
			for(int i=0;i<7;i++) {
				if(gameB.isValidPlay(i)) {
					GameBoard ncrntMove1= new GameBoard(gameB.getGameBoard());
					ncrntMove1.playPiece(i);
					npvalcomp=valueH(ncrntMove1,deep-1,top,bottom);
					if(npruneValue>npvalcomp) {
						npruneValue=npvalcomp;
					}
					if(npruneValue<=top) {
						return npruneValue;
					}
					if(npruneValue<bottom) {
						bottom=npruneValue;

					}
				}
			}
			return npruneValue;
		}

		else{
		
				return (gameB.functionEval(2)*100)-(gameB.functionEval(1)*100);
					
		}
	}

}
