import sys


fringeData = []
recordVisit = []
heuristicData = []
nodeDistances = []
sampleDestination = "Kassel"
INPUT_ARGUMENTS = 4
HEURISTIC_FILE_ARGUMENT = 5
ZERO = 0

command_line_args = sys.argv

if (len(command_line_args) < INPUT_ARGUMENTS) :
    print("INVALID INPUT. REFER README FOR INPUT FORMAT")
    sys.exit()

sourceFile = open(command_line_args[1], "r")
source = str(command_line_args[2])
destination = str(command_line_args[3])

if (len(command_line_args) == HEURISTIC_FILE_ARGUMENT) :
    heuristic_file = open(command_line_args[4] , "r")
    line = heuristic_file.readline().replace("\n", "").replace("\r", "")

    while line != "END OF INPUT":
        citiesAndCost = line.split(" ")
        citiesAndCost[1] = float(citiesAndCost[1])

        sampleDestination = "Kassel"
        citiesAndCost.insert(ZERO, sampleDestination)
        heuristicData.append(citiesAndCost)
        line = heuristic_file.readline().replace("\n", "").replace("\r", "")

line = sourceFile.readline().replace("\n", "").replace("\r", "")
nodeDistances = []

while line != "END OF INPUT":
    citiesAndCost = line.split(" ")
    citiesAndCost[2] = float(citiesAndCost[2])
    nodeDistances.append(citiesAndCost)
    line = sourceFile.readline().replace("\n", "").replace("\r", "")

class find_route:
    def __init__(self, city, parent, routeCost, heuristic_value):
        self.parent = parent
        self.heuristic = heuristic_value
        self.city = city
        self.routeCost = routeCost

def succesors(node, nodeDistances, heuristicData):
    result = []
    for tuple in nodeDistances:
        source, destination, cost = tuple
        if node.city in [source, destination]:
            newRouteCost = node.routeCost + cost
            heuristicSource = nodeHeuristic(source, heuristicData)
            heuristicDestination = nodeHeuristic(destination, heuristicData)
            if source == node.city:
                child_node = find_route(destination, node, newRouteCost, heuristicDestination)
            else:
                child_node = find_route(source, node, newRouteCost, heuristicSource)
            result.append(child_node)
    return result

def nodeHeuristic(source, heuristicData):
    heuristic_value = ZERO
    for n in heuristicData:
        if n[1] == source:
            heuristic_value = n[2]
            break
    return heuristic_value

def visited(verify, recordVisit):
    for n in recordVisit:
        if n.city == verify.city:
            return True
    return False

root = find_route(source, None, ZERO, nodeHeuristic(source, heuristicData))
fringeData = []
fringeData.append(root)
nodesExpanded = ZERO
noOfNodes = ZERO
nodesPopped = ZERO
nodeFound = False
node = None

while len(fringeData) > ZERO:
    fringeData.sort(key=lambda node: (node.routeCost + node.heuristic))
    node = fringeData.pop(ZERO)
    nodesPopped = nodesPopped + 1
    if node.city == destination:
        nodeFound = True
        break
    if not visited(node, recordVisit) :
        nodesExpanded = nodesExpanded + 1
        childNodes = succesors(node, nodeDistances, heuristicData)
        fringeData.extend             (childNodes)
        noOfNodes = noOfNodes + len(childNodes)
    recordVisit.append(node)

print("Nodes Popped: " + str(nodesPopped) + '\n' + "Nodes Expanded: " + str(nodesExpanded)
      + '\n' + "Nodes Generated: " + str(noOfNodes+1) + '\n')

if nodeFound == False:
    print("Distance: infinity" + '\n' + "Route: None")
else:
    destinationNode = node
    path = []
    while destinationNode != None:
        path.insert(ZERO, destinationNode)
        destinationNode = destinationNode.parent
    prev = None
    print("Distance: " + str(node.routeCost) + " km" + '\n' + "Route:")
    for n in path:
        if prev != None:
            print(prev.city + " to " + n.city + ", " + str(n.routeCost - prev.routeCost) + " km")
            prev = n
        else:
            prev = n