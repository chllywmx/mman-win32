Student Name : Waseem Vadla
Student ID: 1002028525

Programming language used: Python3

How to run:
1) Uninformed Search - python find_route.py input1.txt source destination
2) Informed Search - python find_route.py input1.txt source destination h_kassel.txt 
