from copy import deepcopy
import AlphaBeta
import sys
from MaxConnect4Game import *


def oneMoveGame(PresentGame,depth):
    if PresentGame.piece_count == 42:
        print('Board is full\n\nGame completed!\n')
        sys.exit(0)
    if depth == 0:
        print('Give a depth greater than 0')
        sys.exit(0)

    value_of_a = AlphaBeta.AlphaBetadecision(PresentGame)
    PresentGame.playPiece(value_of_a)
    print('State of the game after the move:')
    PresentGame.printGameBoard()

    PresentGame.countScore()
    print('Score: Player 1 = %d, Player 2 = %d\n'.format(PresentGame.player1Score, PresentGame.player2Score))

    PresentGame.printGameBoardToFile()
    PresentGame.gameFile.close()


def interactiveGame(PresentGame, playerTurn):
    if playerTurn == 'human-first':
        PresentGame.PresentTurn = 2
    else:
        PresentGame.PresentTurn = 1
    while not PresentGame.piece_count == 42:
        if PresentGame.PresentTurn == 2:
            input_coloumn = int(input('please enter coloums number between 0 to 6: '))
            while input_coloumn > 6:
                input_coloumn = input('please enter valid number between 0 to 6: ')
            PresentGame.playPiece(input_coloumn)
            PresentGame.PresentTurn = 1
            try:
                PresentGame.gameFile = open('human.txt', 'w')

            except:
                pass

        else:

            PresentGame.PresentTurn = 2
            coloumn_number = AlphaBeta.AlphaBetadecision(PresentGame)
            PresentGame.PresentTurn = 1
            PresentGame.playPiece(coloumn_number)

            PresentGame.PresentTurn = 2
            try:
                PresentGame.gameFile = open('computer.txt', 'w')

            except:
                pass


        PresentGame.printGameBoardToFile()
        PresentGame.printGameBoard()
        PresentGame.gameFile.close()
        PresentGame.countScore()
        print('player1 score is: ', PresentGame.player1Score, 'Player2 score is: ', PresentGame.player2Score)

def main(argv):

    if len(argv) != 5:
        print('Four command-line arguments are needed:')
        print('Usage: %s interactive [input_file] [computer-next/human-next] [depth]' % argv[0])
        print('or: %s one-move [input_file] [output_file] [depth]' % argv[0])
        sys.exit(2)

    game_mode, inFile = argv[1:3]

    if not game_mode == 'interactive' and not game_mode == 'one-move':
        print('%s is an unrecognized game mode' % game_mode)
        sys.exit(2)

    PresentGame = maxConnect4Game()
    PresentGame.depth = int(sys.argv[4])

    try:
        PresentGame.gameFile = open(inFile, 'r')
    except IOError:
        sys.exit("\nError opening input file.\nCheck file name.\n")

    file_lines = PresentGame.gameFile.readlines()
    PresentGame.Boardofgame = [[int(char) for char in line[0:7]] for line in file_lines[0:-1]]
    PresentGame.PresentTurn = int(file_lines[-1][0])
    PresentGame.gameFile.close()

    print('\nMaxConnect 4 game\n')
    print('Game state before the move:')
    PresentGame.printGameBoard()
    PresentGame.checkPieceCount()
    PresentGame.countScore()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (PresentGame.player1Score, PresentGame.player2Score))

    if game_mode == 'interactive':
        player_turn = sys.argv[3]
        file_not_found = True
        interactiveGame(PresentGame, player_turn)
    else:
        outFile = argv[3]
        try:
            PresentGame.gameFile = open(outFile, 'w')
        except:
            sys.exit('Error opening the output file.')
        oneMoveGame(PresentGame)


if __name__ == '__main__':
    main(sys.argv)
