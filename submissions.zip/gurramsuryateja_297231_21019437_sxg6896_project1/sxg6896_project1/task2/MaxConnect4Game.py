from copy import copy
import random
import sys

class maxConnect4Game:
    def __init__(self):
        self.Boardofgame = [[0 for i in range(7)] for j in range(6)]
        self.PresentTurn = 1
        self.depth = 1
        self.piece_count = 0
        self.gameFile = None
        self.player1Score = 0
        self.player2Score = 0
        random.seed()

    # Count the number of pieces already played
    def checkPieceCount(self):
        self.piece_count = sum(1 for i in self.Boardofgame for piece in i if piece)
        return self.piece_count


    def scoreCount(self):
        if self.player1Score < self.player2Score:
            return (-1) * self.player2Score
        elif self.player1Score > self.player2Score:
            return self.player1Score
        else:
            return 0


    def printGameBoard(self):
        print(' -----------------')
        for i in range(6):
            print(' |', end='')
            for j in range(7):
                print('%d' % self.Boardofgame[i][j], end='')
            print('| \n')
        print(' -----------------')

    # Output current game status to file
    def printGameBoardToFile(self):
        for row in self.Boardofgame:
            self.gameFile.write(''.join(str(col) for col in row) + '\r\n')
        self.gameFile.write('%s\r\n' % str(self.PresentTurn))

    # Place the current player's piece in the requested column
    def playPiece(self, column):
        if not self.Boardofgame[0][column]:
            for i in range(5, -1, -1):
                if not self.Boardofgame[i][column]:
                    self.Boardofgame[i][column] = self.PresentTurn
                    self.piece_count += 1
                    return 1

    def aiPlay(self):
        randColumn = random.randrange(0,7)
        result = self.playPiece(randColumn)
        if not result:
            self.aiPlay()
        else:
            print('\n\nmove %d: Player %d, column %d\n' % (self.piece_count, self.PresentTurn, randColumn+1))
            if self.PresentTurn == 1:
                self.PresentTurn = 2
            elif self.PresentTurn == 2:
                self.PresentTurn = 1

    # Calculate the number of 4-in-a-row each player has
    def countScore(self):
        self.player1Score = 0
        self.player2Score = 0

        # Check horizontally
        for i in self.Boardofgame:
            # Check player 1
            if i[0:4] == [1]*4:
                self.player1Score += 1
            if i[1:5] == [1]*4:
                self.player1Score += 1
            if i[2:6] == [1]*4:
                self.player1Score += 1
            if i[3:7] == [1]*4:
                self.player1Score += 1
            # Check player 2
            if i[0:4] == [2]*4:
                self.player2Score += 1
            if i[1:5] == [2]*4:
                self.player2Score += 1
            if i[2:6] == [2]*4:
                self.player2Score += 1
            if i[3:7] == [2]*4:
                self.player2Score += 1

        # Check vertically
        for j in range(7):
            # Check player 1
            if (self.Boardofgame[0][j] == 1 and self.Boardofgame[1][j] == 1 and
                   self.Boardofgame[2][j] == 1 and self.Boardofgame[3][j] == 1):
                self.player1Score += 1
            if (self.Boardofgame[1][j] == 1 and self.Boardofgame[2][j] == 1 and
                   self.Boardofgame[3][j] == 1 and self.Boardofgame[4][j] == 1):
                self.player1Score += 1
            if (self.Boardofgame[2][j] == 1 and self.Boardofgame[3][j] == 1 and
                   self.Boardofgame[4][j] == 1 and self.Boardofgame[5][j] == 1):
                self.player1Score += 1
            # Check player 2
            if (self.Boardofgame[0][j] == 2 and self.Boardofgame[1][j] == 2 and
                   self.Boardofgame[2][j] == 2 and self.Boardofgame[3][j] == 2):
                self.player2Score += 1
            if (self.Boardofgame[1][j] == 2 and self.Boardofgame[2][j] == 2 and
                   self.Boardofgame[3][j] == 2 and self.Boardofgame[4][j] == 2):
                self.player2Score += 1
            if (self.Boardofgame[2][j] == 2 and self.Boardofgame[3][j] == 2 and
                   self.Boardofgame[4][j] == 2 and self.Boardofgame[5][j] == 2):
                self.player2Score += 1

        # Check player 1
        if (self.Boardofgame[0][1] == 1 and self.Boardofgame[1][2] == 1 and
               self.Boardofgame[2][3] == 1 and self.Boardofgame[3][4] == 1):
            self.player1Score += 1
        if (self.Boardofgame[2][0] == 1 and self.Boardofgame[3][1] == 1 and
               self.Boardofgame[4][2] == 1 and self.Boardofgame[5][3] == 1):
            self.player1Score += 1
        if (self.Boardofgame[2][1] == 1 and self.Boardofgame[3][2] == 1 and
               self.Boardofgame[4][3] == 1 and self.Boardofgame[5][4] == 1):
            self.player1Score += 1
        if (self.Boardofgame[0][0] == 1 and self.Boardofgame[1][1] == 1 and
               self.Boardofgame[2][2] == 1 and self.Boardofgame[3][3] == 1):
            self.player1Score += 1
        if (self.Boardofgame[1][0] == 1 and self.Boardofgame[2][1] == 1 and
               self.Boardofgame[3][2] == 1 and self.Boardofgame[4][3] == 1):
            self.player1Score += 1
        if (self.Boardofgame[1][1] == 1 and self.Boardofgame[2][2] == 1 and
               self.Boardofgame[3][3] == 1 and self.Boardofgame[4][4] == 1):
            self.player1Score += 1
        if (self.Boardofgame[2][2] == 1 and self.Boardofgame[3][3] == 1 and
               self.Boardofgame[4][4] == 1 and self.Boardofgame[5][5] == 1):
            self.player1Score += 1
        if (self.Boardofgame[2][3] == 1 and self.Boardofgame[3][4] == 1 and
               self.Boardofgame[4][5] == 1 and self.Boardofgame[5][6] == 1):
            self.player1Score += 1
        if (self.Boardofgame[1][2] == 1 and self.Boardofgame[2][3] == 1 and
               self.Boardofgame[3][4] == 1 and self.Boardofgame[4][5] == 1):
            self.player1Score += 1
        if (self.Boardofgame[0][3] == 1 and self.Boardofgame[1][4] == 1 and
               self.Boardofgame[2][5] == 1 and self.Boardofgame[3][6] == 1):
            self.player1Score += 1
        if (self.Boardofgame[1][3] == 1 and self.Boardofgame[2][4] == 1 and
               self.Boardofgame[3][5] == 1 and self.Boardofgame[4][6] == 1):
            self.player1Score += 1
        if (self.Boardofgame[0][2] == 1 and self.Boardofgame[1][3] == 1 and
               self.Boardofgame[2][4] == 1 and self.Boardofgame[3][5] == 1):
            self.player1Score += 1

        if (self.Boardofgame[2][3] == 1 and self.Boardofgame[3][2] == 1 and
               self.Boardofgame[4][1] == 1 and self.Boardofgame[5][0] == 1):
            self.player1Score += 1
        if (self.Boardofgame[1][3] == 1 and self.Boardofgame[2][2] == 1 and
               self.Boardofgame[3][1] == 1 and self.Boardofgame[4][0] == 1):
            self.player1Score += 1
        if (self.Boardofgame[0][3] == 1 and self.Boardofgame[1][2] == 1 and
               self.Boardofgame[2][1] == 1 and self.Boardofgame[3][0] == 1):
            self.player1Score += 1
        if (self.Boardofgame[0][6] == 1 and self.Boardofgame[1][5] == 1 and
               self.Boardofgame[2][4] == 1 and self.Boardofgame[3][3] == 1):
            self.player1Score += 1
        if (self.Boardofgame[1][6] == 1 and self.Boardofgame[2][5] == 1 and
               self.Boardofgame[3][4] == 1 and self.Boardofgame[4][3] == 1):
            self.player1Score += 1
        if (self.Boardofgame[0][4] == 1 and self.Boardofgame[1][3] == 1 and
               self.Boardofgame[2][2] == 1 and self.Boardofgame[3][1] == 1):
            self.player1Score += 1
        if (self.Boardofgame[2][5] == 1 and self.Boardofgame[3][4] == 1 and
               self.Boardofgame[4][3] == 1 and self.Boardofgame[5][2] == 1):
            self.player1Score += 1
        if (self.Boardofgame[1][4] == 1 and self.Boardofgame[2][3] == 1 and
               self.Boardofgame[3][2] == 1 and self.Boardofgame[4][1] == 1):
            self.player1Score += 1
        if (self.Boardofgame[2][6] == 1 and self.Boardofgame[3][5] == 1 and
               self.Boardofgame[4][4] == 1 and self.Boardofgame[5][3] == 1):
            self.player1Score += 1
        if (self.Boardofgame[1][5] == 1 and self.Boardofgame[2][4] == 1 and
               self.Boardofgame[3][3] == 1 and self.Boardofgame[4][2] == 1):
            self.player1Score += 1
        if (self.Boardofgame[0][5] == 1 and self.Boardofgame[1][4] == 1 and
               self.Boardofgame[2][3] == 1 and self.Boardofgame[3][2] == 1):
            self.player1Score += 1
        if (self.Boardofgame[2][4] == 1 and self.Boardofgame[3][3] == 1 and
               self.Boardofgame[4][2] == 1 and self.Boardofgame[5][1] == 1):
            self.player1Score += 1


        # Check player 2
        if (self.Boardofgame[2][3] == 2 and self.Boardofgame[3][4] == 2 and
               self.Boardofgame[4][5] == 2 and self.Boardofgame[5][6] == 2):
            self.player2Score += 1
        if (self.Boardofgame[0][3] == 2 and self.Boardofgame[1][4] == 2 and
               self.Boardofgame[2][5] == 2 and self.Boardofgame[3][6] == 2):
            self.player2Score += 1
        if (self.Boardofgame[2][2] == 2 and self.Boardofgame[3][3] == 2 and
               self.Boardofgame[4][4] == 2 and self.Boardofgame[5][5] == 2):
            self.player2Score += 1
        if (self.Boardofgame[2][0] == 2 and self.Boardofgame[3][1] == 2 and
               self.Boardofgame[4][2] == 2 and self.Boardofgame[5][3] == 2):
            self.player2Score += 1
        if (self.Boardofgame[0][0] == 2 and self.Boardofgame[1][1] == 2 and
               self.Boardofgame[2][2] == 2 and self.Boardofgame[3][3] == 2):
            self.player2Score += 1
        if (self.Boardofgame[2][1] == 2 and self.Boardofgame[3][2] == 2 and
               self.Boardofgame[4][3] == 2 and self.Boardofgame[5][4] == 2):
            self.player2Score += 1
        if (self.Boardofgame[0][2] == 2 and self.Boardofgame[1][3] == 2 and
               self.Boardofgame[2][4] == 2 and self.Boardofgame[3][5] == 2):
            self.player2Score += 1
        if (self.Boardofgame[1][1] == 2 and self.Boardofgame[2][2] == 2 and
               self.Boardofgame[3][3] == 2 and self.Boardofgame[4][4] == 2):
            self.player2Score += 1
        if (self.Boardofgame[1][2] == 2 and self.Boardofgame[2][3] == 2 and
               self.Boardofgame[3][4] == 2 and self.Boardofgame[4][5] == 2):
            self.player2Score += 1
        if (self.Boardofgame[1][3] == 2 and self.Boardofgame[2][4] == 2 and
               self.Boardofgame[3][5] == 2 and self.Boardofgame[4][6] == 2):
            self.player2Score += 1
        if (self.Boardofgame[0][1] == 2 and self.Boardofgame[1][2] == 2 and
               self.Boardofgame[2][3] == 2 and self.Boardofgame[3][4] == 2):
            self.player2Score += 1
        if (self.Boardofgame[1][0] == 2 and self.Boardofgame[2][1] == 2 and
               self.Boardofgame[3][2] == 2 and self.Boardofgame[4][3] == 2):
            self.player2Score += 1

        if (self.Boardofgame[2][3] == 2 and self.Boardofgame[3][2] == 2 and
               self.Boardofgame[4][1] == 2 and self.Boardofgame[5][0] == 2):
            self.player2Score += 1
        if (self.Boardofgame[0][3] == 2 and self.Boardofgame[1][2] == 2 and
               self.Boardofgame[2][1] == 2 and self.Boardofgame[3][0] == 2):
            self.player2Score += 1
        if (self.Boardofgame[0][6] == 2 and self.Boardofgame[1][5] == 2 and
               self.Boardofgame[2][4] == 2 and self.Boardofgame[3][3] == 2):
            self.player2Score += 1
        if (self.Boardofgame[1][3] == 2 and self.Boardofgame[2][2] == 2 and
               self.Boardofgame[3][1] == 2 and self.Boardofgame[4][0] == 2):
            self.player2Score += 1
        if (self.Boardofgame[0][5] == 2 and self.Boardofgame[1][4] == 2 and
               self.Boardofgame[2][3] == 2 and self.Boardofgame[3][2] == 2):
            self.player2Score += 1
        if (self.Boardofgame[1][4] == 2 and self.Boardofgame[2][3] == 2 and
               self.Boardofgame[3][2] == 2 and self.Boardofgame[4][1] == 2):
            self.player2Score += 1
        if (self.Boardofgame[2][5] == 2 and self.Boardofgame[3][4] == 2 and
               self.Boardofgame[4][3] == 2 and self.Boardofgame[5][2] == 2):
            self.player2Score += 1
        if (self.Boardofgame[0][4] == 2 and self.Boardofgame[1][3] == 2 and
               self.Boardofgame[2][2] == 2 and self.Boardofgame[3][1] == 2):
            self.player2Score += 1
        if (self.Boardofgame[1][5] == 2 and self.Boardofgame[2][4] == 2 and
               self.Boardofgame[3][3] == 2 and self.Boardofgame[4][2] == 2):
            self.player2Score += 1
        if (self.Boardofgame[2][6] == 2 and self.Boardofgame[3][5] == 2 and
               self.Boardofgame[4][4] == 2 and self.Boardofgame[5][3] == 2):
            self.player2Score += 1
        if (self.Boardofgame[1][6] == 2 and self.Boardofgame[2][5] == 2 and
               self.Boardofgame[3][4] == 2 and self.Boardofgame[4][3] == 2):
            self.player2Score += 1
        if (self.Boardofgame[2][4] == 2 and self.Boardofgame[3][3] == 2 and
               self.Boardofgame[4][2] == 2 and self.Boardofgame[5][1] == 2):
            self.player2Score += 1


