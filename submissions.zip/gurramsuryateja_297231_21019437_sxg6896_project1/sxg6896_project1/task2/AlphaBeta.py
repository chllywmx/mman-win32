import maxconnect4
from MaxConnect4Game import maxConnect4Game
from copy import deepcopy
import sys


def AlphaBetadecision(Presentgame):
    a_and_b_list = []
    for a, s in next(Presentgame):
        b = MinimumValue(Presentgame=s, minimuminteger=-2147483647, maximuminteger=2147483648,
                         depth=deepcopy(Presentgame.depth))
        a_and_b_list.append((a, b))
    c = 0
    for a_and_b in a_and_b_list:
        if c == 0:
            a = a_and_b[0]
            b = a_and_b[1]
            c = c + 1
            continue
        if a_and_b[1] > b:
            a = a_and_b[0]
            b = a_and_b[1]
        c = c + 1
    return a


def MinimumValue(Presentgame, minimuminteger, maximuminteger, depth):
    if Presentgame.checkPieceCount() == 42 or depth == 1:
        Presentgame.countScore()
        return Presentgame.scoreCount()
    b = 2147483648
    for a, s in next(Presentgame):
        b = min(b, MaximumValue(s, minimuminteger, maximuminteger, deepcopy(depth - 1)))
        if b <= minimuminteger:
            return b
        maximuminteger = min(maximuminteger, b)
    return b


def MaximumValue(Presentgame, minimuminteger, maximuminteger, depth):
    if Presentgame.checkPieceCount() == 42 or depth == 1:
        Presentgame.countScore()
        return Presentgame.scoreCount()

    b = -2147483647
    for a, s in next(Presentgame):
        b = max(b, MinimumValue(s, minimuminteger, maximuminteger, deepcopy(depth - 1)))
        if b >= maximuminteger:
            return b
        minimuminteger = max(minimuminteger, b)
    return b


def next(Presentgame):
    playPieceList = []
    if Presentgame.PresentTurn == 1:
        childTurn = 2
    else:
        childTurn = 1
    for i in range(7):
        new_gameBoard = maxConnect4Game()
        new_gameBoard.Boardofgame = deepcopy(Presentgame.gameBoard)
        new_gameBoard.PresentTurn = childTurn
        if new_gameBoard.playPiece(i):
            playPieceList.append((i, new_gameBoard))
    return playPieceList
