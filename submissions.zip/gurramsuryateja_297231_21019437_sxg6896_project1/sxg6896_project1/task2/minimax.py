import MaxConnect4Game
import maxconnect4


def minimaxdecision(state, depth):
    state = MaxConnect4Game()
    current_state = state.gameBoard


def maxvalue(state):
    state = MaxConnect4Game()
