programming mini project 1

Name: Surya teja Gurram
UTA ID: 1002036896

Programming language: Python3

Compilation Instructions:

To compile the Python3 code.
Install python3 in the system.

(1) Uninformed Search

Python3 find_route input1.txt origin_city destination_city	

E.g: python3 find_route input1.txt Bremen Kassel

(2) Informed Search with heuristic file as input

python3 find_route input1.txt origin_city destination_city h_kassel.txt		

E.g: python3 find_route input1.txt Bremen Kassel h_kassel.txt

Then you will the desired output.

