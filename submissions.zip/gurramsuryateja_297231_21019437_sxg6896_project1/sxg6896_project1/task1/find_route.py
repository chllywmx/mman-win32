import sys

def h_val(input1):
    for line in input1:
        if "END OF INPUT" in line:
            break
        else:
            record = line.split(" ")
            heuristics[listofcities.index(record[0])] = int(record[1])
    return


def getSrc(goalstate, nodes):
    nodePath = []

    def backTrackPath(destination, nodesTouch):
        if destination is None:
            return
        else:
            for visitNode in nodesTouch:
                if visitNode["node"] == destination:
                    nodePath.append(destination)
                    backTrackPath(visitNode["Parent"], nodesTouch)

    if goalstate:
        print("Distance is: " + str(goalstate["Total_Cost"])+".0 km")
        print("Route: ")
        backTrackPath(goalstate["Present"], nodes)
        nodePath.reverse()
        for i in range(0, len(nodePath) - 1):
            print(listofcities[nodePath[i]] + " TO " + listofcities[nodePath[i + 1]] + ", " + str(float(
                mapDict[nodePath[i]][nodePath[i + 1]])))
    else:
        print("Distance is: Infinity!!!")
        print("Route is:")
        print("None")
    return

def initialize(input1):
    for line in input1:
        if "END OF INPUT" in line:
            break
        else:
            tempVar = line.strip().split(" ")
            firstCity = tempVar[0]
            secondCity = tempVar[1]
            if firstCity in listofcities:
                pass
            else:
                listofcities.append(firstCity)
            if secondCity in listofcities:
                pass
            else:
                listofcities.append(secondCity)

    listofcities.sort()
    for i in range(len(listofcities)):
        mapDict.append([])
        for j in range(len(listofcities)):
            mapDict[i].append(-1)
        mapDict[i][i] = 0

    for line in input1:
        if "END OF INPUT" in line:
            break
        else:
            t = line.strip().split(" ")
            firstCity = t[0]
            secondCity = t[1]
            distance = t[2]
            mapDict[ listofcities.index(firstCity)][listofcities.index(secondCity)] = int(distance)
            mapDict[listofcities.index(secondCity)][listofcities.index(firstCity)] = int(distance)
    return


def prioritizingFringe(fringe, flag):
    if (len(fringe) > 1):
        for node_i in range(0, len(fringe) - 1):
            small = node_i
            for node_j in range(node_i + 1, len(fringe)):
                s = fringe[small]["Total_Cost"]
                n = fringe[node_j]["Total_Cost"]
                if flag:
                    s += fringe[small]["h_cost"]
                    n += fringe[node_j]["h_cost"]
                if (s > n):
                    small = node_j
            temp = fringe[small]
            fringe[small] = fringe[node_i]
            fringe[node_i] = temp
        return fringe
    else:
        return fringe


# Uninformed Cost search algorithm
def uninformedCostSearch():
    target = listofcities.index(targetState)
    nodes_generated = 1
    nodes_expanded = 0
    nodes_popped = 0
    max_fringe_size = 0
    uninformedFringe = []  
    nodes_visited_list = []
    searchEndFlag = False
    uninformedFringe.append({
        "Present": listofcities.index(srcstate),
        "Total_Cost": 0,
        "Parent": None
    })
    while (len(uninformedFringe) > 0):
        #nodes_expanded = nodes_expanded + 1
        nodes_popped = nodes_popped + 1
        if uninformedFringe[0]["Present"] == target:
            nodes_visited_list.append({
                "node": uninformedFringe[0]["Present"],
                "Parent": uninformedFringe[0]["Parent"]
            })
            searchEndFlag = uninformedFringe[0]
            break
        elif checkIfNodeAlreadyVisited(uninformedFringe[0]["Present"], nodes_visited_list):
            del uninformedFringe[0]
            continue
        else:
            nodes_visited_list.append({
                "node": uninformedFringe[0]["Present"],
                "Parent": uninformedFringe[0]["Parent"]
            })
            for i in range(len(mapDict[uninformedFringe[0]["Present"]])):
                if mapDict[uninformedFringe[0]["Present"]][i] > 0:
                    uninformedFringe.append({
                        "Present": i,
                        "Total_Cost": uninformedFringe[0]["Total_Cost"] + mapDict[uninformedFringe[0]["Present"]][i],
                        "Parent": uninformedFringe[0]["Present"]
                    })
                    nodes_generated = nodes_generated + 1
            nodes_expanded = nodes_expanded + 1
            del uninformedFringe[0]
            uninformedFringe = prioritizingFringe(uninformedFringe, False)

        if len(uninformedFringe) > max_fringe_size:
            max_fringe_size = len(uninformedFringe)
    print("Nodes Popped: " + str(nodes_popped))
    print("Nodes Expanded: " + str(nodes_expanded))
    print("Nodes Generated: " + str(nodes_generated))
    getSrc(searchEndFlag, nodes_visited_list)
    return


# Informed Search Algorithm
def InformedSearch():                         
    target = listofcities.index(targetState)
    nodes_generated = 1
    nodes_expanded = 0
    nodes_popped = 0
    max_fringe_size = 0
    informedFringe = []
    nodes_visited_list = []
    searchEndFlag = False
    informedFringe.append({
        "Present": listofcities.index(srcstate),
        "Total_Cost": 0,
        "h_cost": heuristics[listofcities.index(srcstate)],
        "Parent": None
    })
    while (len(informedFringe) > 0):
        nodes_popped = nodes_popped + 1
        if informedFringe[0]["Present"] == target:
            nodes_visited_list.append({
                "node": informedFringe[0]["Present"],
                "Parent": informedFringe[0]["Parent"]
            })

            searchEndFlag = informedFringe[0]
            break
        elif checkIfNodeAlreadyVisited(informedFringe[0]["Present"], nodes_visited_list):
            del informedFringe[0]
            continue
        else:
            nodes_visited_list.append({
                "node": informedFringe[0]["Present"],
                "Parent": informedFringe[0]["Parent"]
            })
            for i in range(len(mapDict[informedFringe[0]["Present"]])):
                if mapDict[informedFringe[0]["Present"]][i] > 0:
                    informedFringe.append({
                        "Present": i,
                        "Total_Cost": informedFringe[0]["Total_Cost"] + mapDict[informedFringe[0]["Present"]][i],
                        "h_cost": heuristics[i],
                        "Parent": informedFringe[0]["Present"]
                    })
                    nodes_generated = nodes_generated + 1
            nodes_expanded = nodes_expanded + 1
            del informedFringe[0]
            informedFringe = prioritizingFringe(informedFringe, True)

        if (len(informedFringe) > max_fringe_size):
            max_fringe_size = len(informedFringe)
    print("Nodes Popped: " + str(nodes_popped))
    print("Expanded Nodes: " + str(nodes_expanded))
    print("Generated Nodes: " + str(nodes_generated))
    getSrc(searchEndFlag, nodes_visited_list)
    return
def checkIfNodeAlreadyVisited(presentNodeIndex, hitNodes):
    for node in hitNodes:
        if presentNodeIndex == node["node"]:
            return True
    return False

if len(sys.argv) >= 4:
    listofcities = []
    mapDict = []

    initialize(open(sys.argv[1], "r").read().split("\n"))
    srcstate = sys.argv[2]
    targetState = sys.argv[3]
    if len(sys.argv) != 5:
        uninformedCostSearch()
    elif len(sys.argv) == 5:
        heuristics = [0] * len(listofcities)
        h_kassel = sys.argv[4]
        h_val(open(sys.argv[4], "r").read().split("\n"))
        InformedSearch()   
    else:
        print("Verify the number of arguments")
