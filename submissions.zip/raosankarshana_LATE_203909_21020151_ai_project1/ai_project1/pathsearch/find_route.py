#!/usr/bin/env python3

import pathsearch.pathfinder
import sys
import os

def find_route():
    if (len(sys.argv) < 4):
        print('Usage: python find_route.py <input_file> <src_city> <destination_city> [h_values_file]')
        sys.exit(-1)
        
    input_file = sys.argv[1]

    source_city = sys.argv[2]

    destination_city = sys.argv[3]

    heuristic_file = None

    if (len(sys.argv) >= 5):
        heuristic_file = sys.argv[4]
    
    path_finder = pathsearch.pathfinder.PathFinder()

    with open(input_file, 'r') as inputReader:
        for line in inputReader:
            if (line.strip() != 'END OF INPUT'):
                p1, p2, w = line.split()
                path_finder.add_edge(p1, p2, int(w))
            else:
                break
    
    path_finder.add_source(source_city)
    path_finder.add_destination(destination_city)

    if (heuristic_file):
        with open(heuristic_file, 'r') as inputReader:
            for line in inputReader:
                if (line.strip() != 'END OF INPUT'):
                    point, w = line.split()
                    path_finder.add_heuristic(point, int(w))
                else:
                    break

    path_finder.find()

    print(path_finder.summarize_solution())
    

if __name__ == '__main__':
    find_route()