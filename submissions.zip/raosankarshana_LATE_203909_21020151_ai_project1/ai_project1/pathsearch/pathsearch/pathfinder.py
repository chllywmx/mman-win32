from pathsearch.city import City
import heapq

from pathsearch.state import State

class PathFinder:
    no_expanded = 0
    no_generated = 0
    no_popped = 0
    sol = None

    def __init__(self):
        self.cities = dict()
        self.heurs = dict()

    def add_edge(self, point1, point2, weight):
        if (point1 not in self.cities):
            ncity = City(point1)
            self.cities[point1] = ncity
            self.heurs[ncity] = 0
        
        if (point2 not in self.cities):
            ncity = City(point2)
            self.cities[point2] = ncity
            self.heurs[ncity] = 0
        
        city1 = self.cities[point1]
        city2 = self.cities[point2]

        city1.add_neighbor(city2, weight)
        city2.add_neighbor(city1, weight)

    def add_source(self, city):
        self.src = self.cities[city]
    
    def add_destination(self, city):
        self.dest = self.cities[city]
    
    def add_heuristic(self, city, weight):
        self.heurs[self.cities[city]] = weight

    def find(self):
        self.closed = []

        self.fringe = []

        heapq.heappush(self.fringe, State(self.src, None, 0, 0, self.heurs[self.src]))
        self.no_generated +=1

        while (self.fringe):
            node = heapq.heappop(self.fringe)
            self.no_popped += 1

            if (node.what == self.dest):
                self.sol = node
                return
            
            if (node.what not in self.closed):
                self.closed.append(node.what)
                self.fringe += self.expand(node)
                heapq.heapify(self.fringe)

    def expand(self, node):
        expansion = []
        
        self.no_expanded += 1

        for neighbor in node.what.neigh:
            self.no_generated +=1
            new_state = State(
                neighbor, 
                node, 
                node.depth+1, 
                node.gn+node.what.neigh[neighbor],
                self.heurs[neighbor])
            expansion.append(new_state)

        

        return expansion

    def summarize_solution(self):
        solution = '''
Nodes Popped: %s
Nodes Expanded: %s
Nodes Generated: %s'''%(self.no_popped, self.no_expanded, self.no_generated)

        if (self.sol):
            return solution + '''
Distance: %1.1f km
Route:
'''%(self.sol.gn) + self.sol.trace_phi()
        else:
            return solution + '''
Distance: infinity
Route: 
None           
            '''

    def __str__(self) -> str:
        return '[noe: %s, nog: %s, nop: %s, src: %s, dest: %s, \ncities:%s,\nheurs:%s,\nsol:%s]'%(self.no_expanded, self.no_generated, self.no_popped, self.src, self.dest, list(self.cities.keys()), self.heurs, self.sol)
