import string

class City:
    def __init__(self, name:string) -> None:
        self.neigh = dict()
        self.name = name

    def add_neighbor(self, neighbor_city, weight: int) -> None:
        self.neigh[neighbor_city] = weight

    def __repr__(self) -> str:
        return self.name

    def to_string(self) -> str:
        return self.name + '(neighs: %s)'%(self.neigh)
    