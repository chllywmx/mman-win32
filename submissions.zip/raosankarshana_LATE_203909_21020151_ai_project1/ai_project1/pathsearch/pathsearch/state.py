class State:
    def __init__(self, what, phi, depth, gn, hn):
        self.phi = phi
        self.what = what
        self.depth = depth
        self.gn = gn
        self.hn = hn

    def trace_phi(self):
        response = ''

        node = self

        while (node.phi):
            response = '%s to %s: %1.1f km\n'%(node.phi.what, node.what, node.phi.what.neigh[node.what]) + response
            node = node.phi

        return response

    def __lt__(self, other):
        return (self.gn + self.hn) < (other.gn + other.hn)
    
    def __repr__(self):
        return 'S(%s, %s)'%(self.what, self.gn)