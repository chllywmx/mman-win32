=======================================
*****  Programming Mini-Project 1  ****
=======================================
Sankarshana Harish Rao - 1001846315
Python 3.9.9
Not Omega compatible. Python3 not available on Omega.
====================================

Uninformed & Informed Search
============================

Code Structure
-------------------
find_route.py - the main code to accept the command line arguments and pass to the PathFinder class.

pathsearch/ - contains all classes needed for path finding
pathsearch/city.py - models the city information
pathsearch/pathfinder.py - main class that implements search. Utilizes A* and UCS–in case of no heuristics. 
pathsearch/state.py - models the info held in state (eg. phi, g(n), depth)

Instructions to run
--------------------
No compilation needed. Standard Python 3.9.9 built-in library sufficient. No additional dependencies.

To run the code. 
    python3 find_route.py <inputfile> <source> <destination> [<heuristicfile]

Timing
---------------------
1) 
time python3 find_route.py input1.txt Bremen Kassel h_kassel.txt 

real    0m0.043s
user    0m0.028s
sys     0m0.010s

2)
time python3 find_route.py input1.txt Bremen Kassel

real    0m0.040s
user    0m0.029s
sys     0m0.009s

3)
time python3 find_route.py input1.txt London Kassel

real    0m0.045s
user    0m0.032s
sys     0m0.009s