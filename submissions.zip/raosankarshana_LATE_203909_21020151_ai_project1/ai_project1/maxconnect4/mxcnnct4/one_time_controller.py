from mxcnnct4.minmaxcontroller import MinmaxController

class OneTimeController(MinmaxController):
    def __init__(self, gameboard, depth, outputfile):
        super().__init__(gameboard, depth)
        self.outputfile = outputfile
    
    def next_play(self):
        print(self.str_current_board(self.gameboard))

        best_move = None

        if (self.gameboard.nextplay == '1'):
            best_move = self.next_play_1()
        else:
            best_move = self.next_play_2()

        if (not best_move):
            return

        self.persist_to_file(best_move, self.outputfile)
        print(self.str_current_board(best_move))
