from copy import deepcopy

direction_coes = [
    (0, 1),
    (1, 1),
    (1, 0),
    (1, -1)
    # (0, -1),
    # (-1, -1),
    # (-1, 0),
    # (-1, 1)
]

opp_target = {
    '1': '2',
    '2': '1',
    '0': '0'
}

class Gameboard:
    def __init__(self) -> None:
        self.board = [['0']*7 for _ in range(6)]
        self.nextplay = '1'
    
    def __str__(self) -> None:
        strboard = ''
        for row in self.board:
            for col in row:
                strboard+=str(col)
            strboard+='\n'
        
        strboard+=self.nextplay

        return strboard
    
    def set_board(self, board: list[list[str]]) -> None:
        self.board = board
    
    def set_nextplay(self, next:str) -> None:
        self.nextplay = next

    def score_board_4_one(self, target:str) -> tuple[int, int]:
        score = 0
        potential = 0
        for r, row in enumerate(self.board):
            for c, col in enumerate(row):
                if(col == target):
                    for direction in direction_coes:
                        seq4 = self.seq_connected4(target, (r, c), direction, 4)
                        if (len(seq4) == 4):
                            count4target = seq4.count(target)
                            if (count4target == 4):
                                score += 1
                            else:
                                potential += count4target
        
        return (score, potential)

    def seq_connected4(self, target:str, location: tuple[int, int], direction: tuple[int, int], how_far:int=4) -> str:
        row, col = location

        if (row < 0 or row >= 6 or col < 0 or col >= 7 or how_far <=0):
            return ''

        if (self.board[row][col] == opp_target[target]):
            return ''

        dir_r, dir_c = direction

        return self.board[row][col] + self.seq_connected4(target, (row+dir_r, col+dir_c), direction, how_far-1)

    def generate_next_board_for_col(self, col):
        if (col < 0 or col >=7):
            return

        new_piece_row = -1

        while (new_piece_row+1 < 6 and self.board[new_piece_row+1][col] == '0'):
            new_piece_row+=1
        
        if (new_piece_row != -1):
            new_gameboard = Gameboard()
            new_gameboard.set_board(deepcopy(self.board))
            new_gameboard.board[new_piece_row][col] = self.nextplay
            new_gameboard.nextplay = opp_target[self.nextplay]
            return new_gameboard

    def generate_next_boards(self) -> list:
        list_of_next_boards = []
        for col in range(7):
            next_board = self.generate_next_board_for_col(col)
            if (next_board):
                list_of_next_boards.append(next_board)
        
        list_of_next_boards.sort(key=lambda x: x.evaluate(), reverse=True)
        return list_of_next_boards

    def score(self) -> tuple[int, int]:
        return (self.score_board_4_one('1')[0], self.score_board_4_one('2')[0])
    
    def evaluate(self) -> float:
        score1, potential1 = self.score_board_4_one('1')
        score2, potential2 = self.score_board_4_one('2')

        return (score1 - score2) + (potential1 - potential2)/10