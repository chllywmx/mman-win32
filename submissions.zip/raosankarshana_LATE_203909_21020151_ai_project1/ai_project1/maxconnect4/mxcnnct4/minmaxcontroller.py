from ctypes import Union
from mxcnnct4.gameboard import Gameboard

class MinmaxController:
    def __init__(self, gameboard: Gameboard, depth: int):
        self.gameboard = gameboard
        self.depth = depth
    
    def min_play(self, gameboard: Gameboard, depth:int=7, alpha:int=-50, beta:int=50):
        if (depth==0):
            # depth limit reached
            return gameboard.evaluate()
        
        next_moves = gameboard.generate_next_boards()

        if (not next_moves):
            # terminal
            score1, score2 = gameboard.score()
            return score1 - score2
        
        v = 100
        for next_move in next_moves:
            v = min(v, self.max_play(next_move, depth-1, alpha, beta))
            if (v <= alpha):
                return v
            alpha = min(v, beta)
        
        return v

    def max_play(self, gameboard: Gameboard, depth:int=7, alpha:int=-50, beta:int=50):
        if (depth==0):
            # depth limit reached
            return gameboard.evaluate()
        
        next_moves = gameboard.generate_next_boards()

        if (not next_moves):
            # terminal
            score1, score2 = gameboard.score()
            return score1 - score2
        
        v = -100
        for next_move in next_moves:
            v = max(v, self.min_play(next_move, depth-1, alpha, beta))
            if (v >= beta):
                return v
            alpha = max(v, alpha)
        
        return v
        
    def str_current_board(self, gameboard: Gameboard):
        retstr = 'Score: %s\n'%(str(gameboard.score()))

        retstr += str(gameboard)

        return retstr
    
    def next_play_1(self):
        next_moves = self.gameboard.generate_next_boards()

        if (next_moves):
            best_move = Gameboard()
            best_score = -100

            for next_move in next_moves:
                v = self.max_play(next_move, self.depth)
                if (v > best_score):
                    best_score = v
                    best_move = next_move
            return best_move
        else:
            return None
    
    def next_play_2(self):
        next_moves = self.gameboard.generate_next_boards()

        if (next_moves):
            best_move = Gameboard()
            best_score = 100

            for next_move in next_moves:
                v = self.min_play(next_move, self.depth)
                if (v < best_score):
                    best_score = v
                    best_move = next_move
            return best_move
        else:
            return None

    def persist_to_file(self, gameboard: Gameboard, output_file:str = 'human.txt',):
        with open(output_file, 'w+') as outputer:
            outputer.write(str(gameboard))