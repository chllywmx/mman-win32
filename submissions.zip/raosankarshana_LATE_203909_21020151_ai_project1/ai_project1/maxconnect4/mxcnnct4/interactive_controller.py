from shutil import move
from mxcnnct4.minmaxcontroller import MinmaxController

class InteractiveController(MinmaxController):
    def __init__(self, gameboard, depth, computernext):
        super().__init__(gameboard, depth)
        self.computer_next = computernext == 'computer-next'
    
    def start_play(self):       
        while True:
            if (self.computer_next):
                # computer plays
                print(self.str_current_board(self.gameboard))
                best_move = self.next_computer_play()

                if (not best_move):
                    return
                
                self.gameboard = best_move

                self.persist_to_file('computer.txt')

                print(self.str_current_board(self.gameboard))

                self.computer_next = not self.computer_next

            if (not self.computer_next):
                next_move = None
                while(not next_move):
                    col = int(input('Row?'))
                    if (col >=0 and col <7):
                        next_move = self.gameboard.generate_next_board_for_col(col)

                self.gameboard = next_move

                self.persist_to_file('human.txt')

                self.computer_next = not self.computer_next
        
    def next_computer_play(self):
        best_move = None

        if (self.gameboard.nextplay == '1'):
            best_move = self.next_play_1()
        else:
            best_move = self.next_play_2()

        return best_move