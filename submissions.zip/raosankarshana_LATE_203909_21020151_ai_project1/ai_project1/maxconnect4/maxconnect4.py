#!/usr/bin/env python3
import sys
import mxcnnct4.gameboard
from mxcnnct4.interactive_controller import InteractiveController
from mxcnnct4.one_time_controller import OneTimeController

def read_input_file(inputfilepath) -> mxcnnct4.gameboard.Gameboard:
    new_gameboard = mxcnnct4.gameboard.Gameboard()
    board = []
    try:
        with open(inputfilepath, 'r+') as input_reader:
            for line in input_reader:
                board.append(list(line.removesuffix('\n')))
            new_gameboard.set_board(board[0:-1])
            new_gameboard.set_nextplay(board[-1][0])
    except FileNotFoundError:
        pass

    return new_gameboard

def maxconnect4():
    if (len(sys.argv) != 5):
        print('Usage: ./maxconnect4.py [interactive <inputfile> [computer-next|human-next] <depth>][one-move <input_file> <output_file> <depth>]')

    run_mode = sys.argv[1]

    new_gameboard = read_input_file(sys.argv[2])

    depth = int(sys.argv[4])

    if (run_mode == 'interactive'):
        who_next = sys.argv[3]
        interactive_player = InteractiveController(new_gameboard, depth, who_next)
        interactive_player.start_play()
    elif (run_mode == 'one-move'):
        output_file = sys.argv[3]
        one_timer = OneTimeController(new_gameboard, depth, output_file)
        one_timer.next_play()
    else:
        print('Usage: ./maxconnect4.py [interactive <inputfile> [computer-next|human-next] <depth>][one-move <input_file> <output_file> <depth>]')

if (__name__ == '__main__'):
    maxconnect4()