=======================================
*****  Programming Mini-Project 1  ****
=======================================
Sankarshana Harish Rao - 1001846315
Python 3.9.9
Not Omega compatible. Python3 not available on Omega.
====================================

Game Playing
============================

Code Structure
-------------------
maxconnect4.py - the main code to accept the command line arguments and pass to the MinmaxController classes.

mxcnnct4/ - contains all classes needed for game playing
mxcnnct4/minmaxcontroller.py - implements the Minmax algorithm
mxcnnct4/interactive_controller.py - implements interactive playing
mxcnnct4/one_time_controller.py - implements one-time playing

Instructions to run
--------------------
No compilation needed. Standard Python 3.9.9 built-in library sufficient. No additional dependencies.

To run the code. 
    python3 ./maxconnect4.py [interactive <inputfile> [computer-next|human-next] <depth>][one-move <input_file> <output_file> <depth>]'

Timing
---------------------
1) 
time python3 maxconnect4.py one-move input1.txt output1.txt 1

real    0m0.062s
user    0m0.047s
sys     0m0.012s

2)
time python3 maxconnect4.py one-move input1.txt output1.txt 2

real    0m0.111s
user    0m0.096s
sys     0m0.012s

3)
time python3 maxconnect4.py one-move input1.txt output1.txt 3

real    0m0.199s
user    0m0.185s
sys     0m0.011s

4)
time python3 maxconnect4.py one-move input1.txt output1.txt 4

real    0m0.539s
user    0m0.523s
sys     0m0.012s

5)
time python3 maxconnect4.py one-move input1.txt output1.txt 5

real    0m1.295s
user    0m1.276s
sys     0m0.013s

6)
time python3 maxconnect4.py one-move input1.txt output1.txt 6

7)
time python3  maxconnect4.py one-move input1.txt output1.txt 7

real    0m9.505s
user    0m9.468s
sys     0m0.021s

8)
time python3 maxconnect4.py one-move input1.txt output1.txt 8

real    0m30.036s
user    0m29.811s
sys     0m0.067s

9)
time python3 maxconnect4.py one-move input1.txt output1.txt 9

real    1m5.073s
user    1m4.533s
sys     0m0.148s

10)
time python3  maxconnect4.py one-move input1.txt output1.txt 10
real    1m29.947s
user    1m29.658s
sys     0m0.067s