Name: Deepika Betha
Id: 1002039457
Language Used: Python

MaxConnect4Game is our only file in the folder but it has multiple classes which in turn create multiple objects
and store multiple functions. The other classes and helper class maxconnect4 and node.
node is used to store current and all upcoming boards and decision function is written in it. Helper class maxconnect4 has all the functions for nextStep, output the file written in it.



Command to run the code: python ./maxConnect4Game.py one-move input1.txt output1.txt 10
Command to run the code: python ./maxConnect4Game.py interactive input1.txt computer-next 7
