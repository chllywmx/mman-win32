
#Name: Deepika Betha
#Id: 1002039457



from copy import copy
import random
import sys



import sys
from maxConnect4Game import *
#from node import *


from maxConnect4Game import *
import copy


def possibleMoves_func(board):
    possibleMoves = []
    for col, colVal in enumerate(board[0]):
        if colVal == 0:
            possibleMoves.append(col)
    return possibleMoves

def result(old_Game, column):
    new_Game = maxConnect4Game()

    try:
        new_Game.nodeDepth = old_Game.nodeDepth + 1
    except AttributeError:
        new_Game.nodeDepth = 1

    new_Game.pieces_played_count = old_Game.pieces_played_count
    new_Game.game_current_board = copy.deepcopy(old_Game.game_current_board)
    if not new_Game.game_current_board[0][column]:
        for i in range(5, -1, -1):
            if not new_Game.game_current_board[i][column]:
                new_Game.game_current_board[i][column] = old_Game.whose_current_turn
                new_Game.pieces_played_count += 1
                break

    if old_Game.whose_current_turn == 1:
        new_Game.whose_current_turn =2
    elif old_Game.whose_current_turn == 2:
        new_Game.whose_current_turn = 1


    new_Game.checkPieceCount()
    new_Game.calculate_Score()

    return new_Game


class node:
    def __init__(self, game, depth):
        self.whose_current_turn = game.whose_current_turn
        self.game = game
        self.maxDepth = int(depth)
    
    def make_next_move_decision(self):
        minVal = []
        possibleMoves = possibleMoves_func(self.game.game_current_board)

        for move in possibleMoves:
            result_move = result(self.game, move)
            minVal.append(self.minVal_func(result_move, 999, -999))

        chosen = possibleMoves[minVal.index(max(minVal))]
        
        return chosen



    def minVal_func(self, state, al, be):
        if state.pieces_played_count == 42 or state.nodeDepth == self.maxDepth:
            return self.miscellaneoua(state)
        v = 999

        for move in possibleMoves_func(state.game_current_board):
            new_State = result(state, move)

            v = min(v, self.maxVal_func(new_State, al, be))
            if v <= al:
                return v
            be = min(be, v)

        return v


    def maxVal_func(self, state, al, be):
        if state.pieces_played_count == 42 or state.nodeDepth == self.maxDepth:
            return self.miscellaneoua(state)
        
        v = -999

        for move in possibleMoves_func(state.game_current_board):
            new_State = result(state, move)

            v = max(v, self.minVal_func(new_State, al, be))
            if v >= be:
                return v
            al = max(al, v)

        return v

    
    def miscellaneoua(self, state):
        if self.whose_current_turn == 1:
            miscellaneoua = state.player_one_Score * 2 - state.player_two_Score
        elif self.whose_current_turn == 2:
            miscellaneoua = state.player_two_Score * 2 - state.player_one_Score

        return miscellaneoua






def oneMoveFunction(present_game_board, intensity):
    if present_game_board.pieces_played_count == 42:    # board full
        print('BOARD IS FULL\nGame Over!\n')
        sys.exit(0)

    #present_game_board.aiPlay() # Make a action (only random is implemented)

    node_tree = node(present_game_board, intensity)
    action = node_tree.make_next_move_decision()
    result = present_game_board.playPiece_Turn(action)
    game_Process(present_game_board, action)
    present_game_board.game_file_name.close() # not sure if this should be here or not

def game_Process(present_game_board, action):

    print('\n Move number: %d: Player playing %d, column on the board %d\n' % (present_game_board.pieces_played_count, present_game_board.whose_current_turn, action + 1))
    if present_game_board.whose_current_turn == 1:                #these statements determine who moves next
        present_game_board.whose_current_turn = 2
    elif present_game_board.whose_current_turn == 2:
        present_game_board.whose_current_turn = 1

    print('Game state after move:')
    present_game_board.printGame_Current_Board()

    present_game_board.calculate_Score()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (present_game_board.player_one_Score, present_game_board.player_two_Score))

    present_game_board.printGameBoardToFile()
    #present_game_board.game_file_name.close() # not sure if this should be here or not


def interactiveGame(present_game_board, intensity):
    # Fill me in

    while not present_game_board.pieces_played_count == 42:
        if present_game_board.whose_current_turn == 1:
            user_action = int(input("Enter the column [1-7] where you would like to play :  "))
            if not 0 < user_action < 8: 
                print("Invalid column number!")
                continue
            if not present_game_board.playPiece_Turn(user_action - 1):
                print("This column is full!")
                continue
            try:
                present_game_board.game_file_name = open("humanplayer.txt", "w")
            except:
                sys.exit("error opening the file")
            game_Process(present_game_board, user_action - 1)


        elif not present_game_board.pieces_played_count == 42:
            node_tree = node(present_game_board, intensity)
            action = node_tree.make_next_move_decision()
            result = present_game_board.playPiece_Turn(action)

            try:
                present_game_board.game_file_name = open("computerplayer.txt", "w")
            except:
                sys.exit("Error opening file")
            game_Process(present_game_board, action)

    present_game_board.game_file_name.close() # not sure if this should be here or not

    if present_game_board.player_one_Score > present_game_board.player_two_Score:
        print("Player 1 wins")
    elif present_game_board.player_two_Score > present_game_board.player_one_Score:
        print("Computer wins")
    else:
        print("Draw")

def main(argv):
    # Make sure we have enough command line arguments
    if len(argv) != 5:
        print('Four command-line arguments are needed:')
        print('Usage: %s interactive [input_file] [computer-next/human-next] [depth]' % argv[0])
        print('or: %s one-move [input_file] [output_file] [depth]' % argv[0])
        sys.exit(2)

    mode_of_game, myFile = argv[1:3]

    if not mode_of_game == 'interactive' and not mode_of_game == 'one-move':
        print('%s is an unrecognized game mode' % mode_of_game)
        sys.exit(2)

    present_game_board = maxConnect4Game() # Create a game

    # Try to open the input file
    try:
        present_game_board.game_file_name = open(myFile, 'r')
    except IOError:
        sys.exit("\nInput file is not present.\nCheck file name.\n")

    # Read the initial game state from the file and save in a 2D list
    file_lines = present_game_board.game_file_name.readlines()
    present_game_board.game_current_board = [[int(char) for char in line[0:7]] for line in file_lines[0:-1]]
    present_game_board.whose_current_turn = int(file_lines[-1][0])
    present_game_board.game_file_name.close()

    print('\nMaxConnect-4 game\n')
    print('Game state before move:')
    present_game_board.printGame_Current_Board()

    # Update a few game variables based on initial state and print the score
    present_game_board.checkPieceCount()
    present_game_board.calculate_Score()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (present_game_board.player_one_Score, present_game_board.player_two_Score))

    if mode_of_game == 'interactive':
        if argv[3] == 'computer-next':
            present_game_board.whose_current_turn = 2
        else:
            present_game_board.whose_current_turn = 1
        interactiveGame(present_game_board, argv[4]) # Be sure to pass whatever else you need from the command line
    else: # mode_of_game == 'one-move'
        # Set up the output file
        outFile = argv[3]
        try:
            present_game_board.game_file_name = open(outFile, 'w')
        except:
            sys.exit('Error opening output file.')
        oneMoveFunction(present_game_board, argv[4]) # Be sure to pass any other arguments from the command line you might need.


if __name__ == '__main__':
    main(sys.argv)





class maxConnect4Game:
    def __init__(self):
        self.game_current_board = [[0 for i in range(7)] for j in range(6)]
        self.whose_current_turn = 1
        self.player_one_Score = 0
        self.player_two_Score = 0
        self.pieces_played_count = 0
        self.game_file_name = None
        random.seed()

    # Count the number of pieces already played
    def checkPieceCount(self):
        self.pieces_played_count = sum(1 for row in self.game_current_board for piece in row if piece)

    # Output current game status to console
    def printGame_Current_Board(self):
        print (' -----------------')
        for i in range(6):
            print (' |',end=" ")
            for j in range(7):
                print(self.game_current_board[i][j],end=" ")
            print ('| ')
        print (' -----------------')

    # Output current game status to file
    def printGameBoardToFile(self):
        for row in self.game_current_board:
            self.game_file_name.write(''.join(str(col) for col in row) + '\r')
        self.game_file_name.write('%s\r' % str(self.whose_current_turn))

    # Place the current player's piece in the requested column
    def playPiece_Turn(self, column):
        if not self.game_current_board[0][column]:
            for i in range(5, -1, -1):
                if not self.game_current_board[i][column]:
                    self.game_current_board[i][column] = self.whose_current_turn
                    self.pieces_played_count += 1
                    return 1

    # The AI section. Currently plays randomly.
    def aiPlay(self):
        randColumn = random.randrange(0,7)
        result = self.playPiece_Turn(randColumn)
        if not result:
            self.aiPlay()
        else:
            print('\n\nmove %d: Player %d, column %d\n' % (self.pieces_played_count, self.whose_current_turn, randColumn+1))
            if self.whose_current_turn == 1:
                self.whose_current_turn = 2
            elif self.whose_current_turn == 2:
                self.whose_current_turn = 1

    # Calculate the number of 4-in-a-row each player has
    def calculate_Score(self):
        self.player_one_Score = 0;
        self.player_two_Score = 0;

        # Check horizontally
        for row in self.game_current_board:
            # Check player 1
            if row[0:4] == [1]*4:
                self.player_one_Score += 1
            if row[1:5] == [1]*4:
                self.player_one_Score += 1
            if row[2:6] == [1]*4:
                self.player_one_Score += 1
            if row[3:7] == [1]*4:
                self.player_one_Score += 1
            # Check player 2
            if row[0:4] == [2]*4:
                self.player_two_Score += 1
            if row[1:5] == [2]*4:
                self.player_two_Score += 1
            if row[2:6] == [2]*4:
                self.player_two_Score += 1
            if row[3:7] == [2]*4:
                self.player_two_Score += 1

        # Check vertically
        for j in range(7):
            # Check player 1
            if (self.game_current_board[0][j] == 1 and self.game_current_board[1][j] == 1 and
                   self.game_current_board[2][j] == 1 and self.game_current_board[3][j] == 1):
                self.player_one_Score += 1
            if (self.game_current_board[1][j] == 1 and self.game_current_board[2][j] == 1 and
                   self.game_current_board[3][j] == 1 and self.game_current_board[4][j] == 1):
                self.player_one_Score += 1
            if (self.game_current_board[2][j] == 1 and self.game_current_board[3][j] == 1 and
                   self.game_current_board[4][j] == 1 and self.game_current_board[5][j] == 1):
                self.player_one_Score += 1
            # Check player 2
            if (self.game_current_board[0][j] == 2 and self.game_current_board[1][j] == 2 and
                   self.game_current_board[2][j] == 2 and self.game_current_board[3][j] == 2):
                self.player_two_Score += 1
            if (self.game_current_board[1][j] == 2 and self.game_current_board[2][j] == 2 and
                   self.game_current_board[3][j] == 2 and self.game_current_board[4][j] == 2):
                self.player_two_Score += 1
            if (self.game_current_board[2][j] == 2 and self.game_current_board[3][j] == 2 and
                   self.game_current_board[4][j] == 2 and self.game_current_board[5][j] == 2):
                self.player_two_Score += 1

        # Check diagonally

        # Check player 1
        if (self.game_current_board[2][0] == 1 and self.game_current_board[3][1] == 1 and
               self.game_current_board[4][2] == 1 and self.game_current_board[5][3] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[1][0] == 1 and self.game_current_board[2][1] == 1 and
               self.game_current_board[3][2] == 1 and self.game_current_board[4][3] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[2][1] == 1 and self.game_current_board[3][2] == 1 and
               self.game_current_board[4][3] == 1 and self.game_current_board[5][4] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[0][0] == 1 and self.game_current_board[1][1] == 1 and
               self.game_current_board[2][2] == 1 and self.game_current_board[3][3] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[1][1] == 1 and self.game_current_board[2][2] == 1 and
               self.game_current_board[3][3] == 1 and self.game_current_board[4][4] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[2][2] == 1 and self.game_current_board[3][3] == 1 and
               self.game_current_board[4][4] == 1 and self.game_current_board[5][5] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[0][1] == 1 and self.game_current_board[1][2] == 1 and
               self.game_current_board[2][3] == 1 and self.game_current_board[3][4] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[1][2] == 1 and self.game_current_board[2][3] == 1 and
               self.game_current_board[3][4] == 1 and self.game_current_board[4][5] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[2][3] == 1 and self.game_current_board[3][4] == 1 and
               self.game_current_board[4][5] == 1 and self.game_current_board[5][6] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[0][2] == 1 and self.game_current_board[1][3] == 1 and
               self.game_current_board[2][4] == 1 and self.game_current_board[3][5] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[1][3] == 1 and self.game_current_board[2][4] == 1 and
               self.game_current_board[3][5] == 1 and self.game_current_board[4][6] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[0][3] == 1 and self.game_current_board[1][4] == 1 and
               self.game_current_board[2][5] == 1 and self.game_current_board[3][6] == 1):
            self.player_one_Score += 1

        if (self.game_current_board[0][3] == 1 and self.game_current_board[1][2] == 1 and
               self.game_current_board[2][1] == 1 and self.game_current_board[3][0] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[0][4] == 1 and self.game_current_board[1][3] == 1 and
               self.game_current_board[2][2] == 1 and self.game_current_board[3][1] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[1][3] == 1 and self.game_current_board[2][2] == 1 and
               self.game_current_board[3][1] == 1 and self.game_current_board[4][0] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[0][5] == 1 and self.game_current_board[1][4] == 1 and
               self.game_current_board[2][3] == 1 and self.game_current_board[3][2] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[1][4] == 1 and self.game_current_board[2][3] == 1 and
               self.game_current_board[3][2] == 1 and self.game_current_board[4][1] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[2][3] == 1 and self.game_current_board[3][2] == 1 and
               self.game_current_board[4][1] == 1 and self.game_current_board[5][0] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[0][6] == 1 and self.game_current_board[1][5] == 1 and
               self.game_current_board[2][4] == 1 and self.game_current_board[3][3] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[1][5] == 1 and self.game_current_board[2][4] == 1 and
               self.game_current_board[3][3] == 1 and self.game_current_board[4][2] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[2][4] == 1 and self.game_current_board[3][3] == 1 and
               self.game_current_board[4][2] == 1 and self.game_current_board[5][1] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[1][6] == 1 and self.game_current_board[2][5] == 1 and
               self.game_current_board[3][4] == 1 and self.game_current_board[4][3] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[2][5] == 1 and self.game_current_board[3][4] == 1 and
               self.game_current_board[4][3] == 1 and self.game_current_board[5][2] == 1):
            self.player_one_Score += 1
        if (self.game_current_board[2][6] == 1 and self.game_current_board[3][5] == 1 and
               self.game_current_board[4][4] == 1 and self.game_current_board[5][3] == 1):
            self.player_one_Score += 1

        # Check player 2
        if (self.game_current_board[2][0] == 2 and self.game_current_board[3][1] == 2 and
               self.game_current_board[4][2] == 2 and self.game_current_board[5][3] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[1][0] == 2 and self.game_current_board[2][1] == 2 and
               self.game_current_board[3][2] == 2 and self.game_current_board[4][3] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[2][1] == 2 and self.game_current_board[3][2] == 2 and
               self.game_current_board[4][3] == 2 and self.game_current_board[5][4] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[0][0] == 2 and self.game_current_board[1][1] == 2 and
               self.game_current_board[2][2] == 2 and self.game_current_board[3][3] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[1][1] == 2 and self.game_current_board[2][2] == 2 and
               self.game_current_board[3][3] == 2 and self.game_current_board[4][4] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[2][2] == 2 and self.game_current_board[3][3] == 2 and
               self.game_current_board[4][4] == 2 and self.game_current_board[5][5] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[0][1] == 2 and self.game_current_board[1][2] == 2 and
               self.game_current_board[2][3] == 2 and self.game_current_board[3][4] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[1][2] == 2 and self.game_current_board[2][3] == 2 and
               self.game_current_board[3][4] == 2 and self.game_current_board[4][5] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[2][3] == 2 and self.game_current_board[3][4] == 2 and
               self.game_current_board[4][5] == 2 and self.game_current_board[5][6] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[0][2] == 2 and self.game_current_board[1][3] == 2 and
               self.game_current_board[2][4] == 2 and self.game_current_board[3][5] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[1][3] == 2 and self.game_current_board[2][4] == 2 and
               self.game_current_board[3][5] == 2 and self.game_current_board[4][6] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[0][3] == 2 and self.game_current_board[1][4] == 2 and
               self.game_current_board[2][5] == 2 and self.game_current_board[3][6] == 2):
            self.player_two_Score += 1

        if (self.game_current_board[0][3] == 2 and self.game_current_board[1][2] == 2 and
               self.game_current_board[2][1] == 2 and self.game_current_board[3][0] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[0][4] == 2 and self.game_current_board[1][3] == 2 and
               self.game_current_board[2][2] == 2 and self.game_current_board[3][1] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[1][3] == 2 and self.game_current_board[2][2] == 2 and
               self.game_current_board[3][1] == 2 and self.game_current_board[4][0] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[0][5] == 2 and self.game_current_board[1][4] == 2 and
               self.game_current_board[2][3] == 2 and self.game_current_board[3][2] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[1][4] == 2 and self.game_current_board[2][3] == 2 and
               self.game_current_board[3][2] == 2 and self.game_current_board[4][1] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[2][3] == 2 and self.game_current_board[3][2] == 2 and
               self.game_current_board[4][1] == 2 and self.game_current_board[5][0] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[0][6] == 2 and self.game_current_board[1][5] == 2 and
               self.game_current_board[2][4] == 2 and self.game_current_board[3][3] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[1][5] == 2 and self.game_current_board[2][4] == 2 and
               self.game_current_board[3][3] == 2 and self.game_current_board[4][2] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[2][4] == 2 and self.game_current_board[3][3] == 2 and
               self.game_current_board[4][2] == 2 and self.game_current_board[5][1] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[1][6] == 2 and self.game_current_board[2][5] == 2 and
               self.game_current_board[3][4] == 2 and self.game_current_board[4][3] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[2][5] == 2 and self.game_current_board[3][4] == 2 and
               self.game_current_board[4][3] == 2 and self.game_current_board[5][2] == 2):
            self.player_two_Score += 1
        if (self.game_current_board[2][6] == 2 and self.game_current_board[3][5] == 2 and
               self.game_current_board[4][4] == 2 and self.game_current_board[5][3] == 2):
            self.player_two_Score += 1

