Name: Deepika Betha
Id: 1002039457

Language Used: Python

The code contains mainly two different functions for search:
> Uninformed search using a Uniform Cost Search.
> Informed search using a* search.

Code finds a route if present and if route is not present it displays distance as infinity.

To run the code type:

python find_route.py input_file source destination heuristic_file (for informed search)

python find_route.py input_file source destination (for uninformed search)
