Jamunaa Jayashree Selvaprabhu - 1001966627

Task 2 

The Alpha Beta Pruning with depth limited is implemented using python. 

Development Environment
Python version = Python 3.10.1
Code Editor = Visual Studio Code

Command to run the code:
python maxconnect4.py interactive input1.txt computer-next 2

python maxconnect4.py one-move input1.txt red.txt 1


Main Python File: maxconnect4.py

What programming language is used for this task : Python 
How the code is structured : The entry point is maxconnect4.py main() method
How to run the code: Run the code in any code editor which has python path using the above command
