import queue
import sys

q = queue.PriorityQueue()
fringe = queue.PriorityQueue()
copy_list = []


class CityRoute:
    def __init__(self, city1, city2, distance):
        self.city1 = city1
        self.city2 = city2
        self.distance = int(distance)


class Heuristics:
    def __init__(self, city_name, city_heuristic):
        self.city_name = city_name
        self.city_heuristic = int(city_heuristic)

# Method to find the routes between 2 cities using Uniform Cost Search


def find_route(input_filename, origin_city, destination_city):
    pop_counter = 0
    city_routes = read_cities_file(input_filename)
    fringe.put((0, "blank", origin_city))
    copy_list.append(CityRoute("blank", origin_city, 0))
    push_counter = 1
    visited_nodes = []
    while(not fringe.empty()):
        pop_element = fringe.get()
        pop_counter = pop_counter+1
        if(pop_element[2] == destination_city):
            break
        if(pop_element[2] in visited_nodes):
            continue
        else:
            for city_route in city_routes:
                if(city_route.city1 == pop_element[2]):

                    new_distance = city_route.distance+pop_element[0]
                    fringe.put(
                        (new_distance, city_route.city1, city_route.city2))
                    copy_list.append(
                        CityRoute(city_route.city1, city_route.city2, new_distance))
                    push_counter = push_counter+1
        visited_nodes.append(pop_element[2])
    print("Nodes Popped: "+str(pop_counter))
    print("Nodes Expanded: "+str(len(set(visited_nodes))))
    print("Nodes Generated: "+str(push_counter))
    if(fringe.empty()):
        print("Distance: Infinity")
        print("No Route Exist")
    else:
        print("Distance: "+str(pop_element[0]) + " kms")
        print("Route")
        print_path(pop_element[0], destination_city, copy_list, city_routes)
    return

# Method to find the routes between 2 cities using A* Search


def find_route_astar(input_filename, origin_city, destination_city, heuristics_filename):
    pop_counter = 0
    city_routes = read_cities_file(input_filename)
    city_heuristics_dict = read_heuristics_file(heuristics_filename)
    fringe.put((city_heuristics_dict.get(origin_city),
               "blank", origin_city, 0))
    #print(fringe.queue)
    copy_list.append(CityRoute("blank", origin_city, 0))
    push_counter = 1
    visited_nodes = []
    while(not fringe.empty()):
        pop_element = fringe.get()
        pop_counter = pop_counter+1
        if(pop_element[2] == destination_city):
            break
        if(pop_element[2] in visited_nodes):
            continue
        else:
            for city_route in city_routes:
                if(city_route.city1 == pop_element[2]):
                    new_distance = city_route.distance+pop_element[3]
                    val = city_heuristics_dict.get(
                        city_route.city2)+city_route.distance+pop_element[3]
                    fringe.put(
                        (val, city_route.city1, city_route.city2, new_distance))
                    copy_list.append(
                        CityRoute(city_route.city1, city_route.city2, new_distance))
                    push_counter = push_counter+1
        #print(fringe.queue)
        visited_nodes.append(pop_element[2])
    print("Nodes Popped: "+str(pop_counter))
    print("Nodes Expanded: "+str(len(set(visited_nodes))))
    print("Nodes Generated: "+str(push_counter))
    if(fringe.empty()):
        print("Distance: Infinity")
    else:
        print("Distance: "+str(pop_element[0]) + " kms")
        print_path(pop_element[0], destination_city, copy_list, city_routes)
    return


# Method to print the path of the route
def print_path(final_cost, destination_city, copy_list, city_routes):
    for route in copy_list:
        if route.city2 == destination_city and route.distance == final_cost:
            if route.city1 == "blank":
                break
            final_cost = final_cost - \
                get_cost_of_routes(route.city1, route.city2, city_routes)
            print_path(final_cost, route.city1, copy_list, city_routes)
            print(route.city1, "to", route.city2,
                  get_cost_of_routes(route.city1, route.city2, city_routes), "km")
    return 0

# Method to read the heuristics file


def read_heuristics_file(input_filename):
    heuristics = []
    heuristics_dict = {}
    with open(input_filename) as f:
        lines = f.readlines()
    for i in lines:
        if("END OF INPUT" in i):
            break
        else:
            each_line = i.split()
            city_heuristic = Heuristics(each_line[0], each_line[1])
            heuristics.append(city_heuristic)
            heuristics_dict[city_heuristic.city_name] = city_heuristic.city_heuristic
    return heuristics_dict

# Method to get the cost of routes
def get_cost_of_routes(city1, city2, city_routes):
    for i in city_routes:
        if(i.city1 == city1 and i.city2 == city2):
            return i.distance

# Method to read the input file
def read_cities_file(input_filename):
    with open(input_filename) as f:
        lines = f.readlines()
    city_routes = []
    for i in lines:
        if("END OF INPUT" in i):
            break
        else:
            each_line = i.split()
            city_route = CityRoute(each_line[0], each_line[1], each_line[2])
            city_route1 = CityRoute(each_line[1], each_line[0], each_line[2])
            city_routes.append(city_route)
            city_routes.append(city_route1)
    return city_routes


def main():
    if(len(sys.argv) == 4):
        print("We have 3 arguments, running Uniform Cost Search")
        find_route(sys.argv[1], sys.argv[2], sys.argv[3])
    else:
        print("We have 4 arguments, running A* Cost Search")
        find_route_astar(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])


if __name__ == "__main__":
    main()
