Jamunaa Jayashree Selvaprabhu - 1001966627

Task 1 

The Uniform Cost Search and A* Search algorithm are written in Python language. 

Development Environment
Python version = Python 3.10.1
Code Editor = Visual Studio Code

Command to run the code:
For UCS:
[python.exe path] [File path ucs_astar_search.py] "input1.txt" "London" "Kassel"
For A*:
[python.exe path] [File path ucs_astar_search.py] "input1.txt" "London" "Kassel" "h_kassel.txt"


What programming language is used for this task : Python 
How the code is structured : The entry point is ucs_astar_search.py main() method
How to run the code: Run the code in any code editor which has python path using the above command

Output:

UCS : 
 C:/Users/jamun/AppData/Local/Programs/Python/Python310/python.exe "c:/Users/jamun/OneDrive/Desktop/CSE 5360/Mini Project 1/ucs_astar_search.py" "input1.txt" "Bremen" "Kassel"
We have 3 arguments, running Uniform Cost Search
Nodes Popped: 12
Nodes Expanded: 6
Nodes Generated: 20
Distance: 297 kms
Route
Bremen to Hannover 132 km
Hannover to Kassel 165 km

A*
 C:/Users/jamun/AppData/Local/Programs/Python/Python310/python.exe "c:/Users/jamun/OneDrive/Desktop/CSE 5360/Mini Project 1/ucs_astar_search.py" "input1.txt" "Bremen" "Kassel" "h_kassel.txt"
We have 4 arguments, running A* Cost Search
Nodes Popped: 3
Nodes Expanded: 2
Nodes Generated: 8
Distance: 297 kms
Route
Bremen to Hannover 132 km
Hannover to Kassel 165 km