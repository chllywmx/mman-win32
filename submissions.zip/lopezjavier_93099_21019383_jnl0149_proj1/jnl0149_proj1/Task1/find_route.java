import java.io.*;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.Vector;

class find_route
{
    public static String search(String origin_city, String destination_city, Vector<String> list1,
        Vector<String> list2, Vector<Double> distance, boolean has_heuristic, Vector<String> h_city, Vector<Double> h_distance)
    {

        int popped = 0, expanded = 0, generated = 1;
        Node current_node = new Node(origin_city,null,0.0,0.0);

        LinkedList<Node> fringe = new LinkedList<Node>();
        Vector<String> closed = new Vector<String>();
        fringe.add(current_node);

        while( !fringe.isEmpty() )
        {
            current_node = fringe.pop();
            popped++;
            if( current_node.city_name.equals(destination_city) )
            {
                String final_path = "";
                if( expanded != 0 )
                {
                    LinkedList<Node> path = new LinkedList<Node>();
                    Node node = current_node;
                    while( node != null )
                    {
                        path.addFirst(node);;
                        node = node.previous_city;
                    }
                    for (int i = 0; i < path.size()-1; i++) {
                        final_path += path.get(i).city_name+" to "+ path.get(i+1).city_name + ", " + path.get(i+1).distance_from_previous + " km\n";
                    }
                }
                else final_path = "None";
                return "Nodes Popped: " + popped + "\nNodes Expanded: " + expanded + "\nGenerated: " + generated + "\nDistance: " + current_node.total_distance + "\nRoute:\n"+final_path;
            }
            if( !closed.contains(current_node.city_name) )
            {
                closed.add(current_node.city_name);
                expanded++;
                for(int i = 0; i < list1.size(); i++)
                {
                    if( current_node.city_name.equals(list1.get(i)) )
                    {
                        generated++;
                        Node node = new Node(list2.get(i), current_node, distance.get(i), (current_node.total_distance+distance.get(i)));
                        fringe.add(node);
                    }
                    else if( current_node.city_name.equals(list2.get(i)) )
                    {
                        generated++;
                        Node node = new Node(list1.get(i), current_node, distance.get(i), (current_node.total_distance+distance.get(i)));
                        fringe.add(node);
                    }
                }
                fringe.sort(new Comparator<Node>()
                {
                    public int compare(Node city1, Node city2)
                    {
                        if(has_heuristic)
                        {
                            Double h_city1 = 0.0, h_city2 = 0.0;
                            for(int i = 0; i < h_city.size(); i++)
                            {
                                if( h_city.get(i).equals(city1.city_name) ) h_city1 = h_distance.get(i);
                                if( h_city.get(i).equals(city2.city_name) ) h_city2 = h_distance.get(i);
                            }
                            if( (city1.total_distance + h_city1) > (city2.total_distance + h_city2) ) return 1;
                            return -1;
                        }
                        else
                        {
                            if( city1.total_distance > city2.total_distance ) return 1;
                            return -1;
                        }
                    }
                });
            }
        }
        return "Nodes Popped: " + popped + "\nNodes Expanded: " + expanded + "\nGenerated: " + generated + "\nDistance: Infinity\nRoute:\nNone";
    }

    public static void main(String[] args) {
        if( (args.length < 3) || (args.length > 4) )
        {
            System.out.println("Required format:\tjava  find_route  input_filename  origin_city  destination_city  heuristic_filename");
            System.exit(0);
        }

        Vector<String> list1 = new Vector<String>();
        Vector<String> list2 = new Vector<String>();
        Vector<Double> distance = new Vector<Double>();

        Vector<String> h_city = new Vector<String>();
        Vector<Double> h_distance = new Vector<Double>();
        
        String origin_city = args[1];
        String destination_city = args[2];
        
        boolean has_heuristic = false;

        try
        {
            FileInputStream in = new FileInputStream(args[0]);
            Scanner scan = new Scanner(in);
            String line;
            while( scan.hasNextLine() )
            {
                line = scan.nextLine();
                if( !line.equals("END OF INPUT") )
                {
                    StringTokenizer st = new StringTokenizer(line," ");
                    while( st.hasMoreTokens() )
                    {
                        list1.add(st.nextToken());
                        list2.add(st.nextToken());
                        distance.add(Double.parseDouble(st.nextToken()));
                    }
                }
            }
            scan.close();
            in.close();
            if( args.length == 4 ){
                in = new FileInputStream(args[3]);
                scan = new Scanner(in);
                has_heuristic = true;

                while( scan.hasNextLine() )
                {
                    line = scan.nextLine();
                    if( !line.equals("END OF INPUT") )
                    {
                        StringTokenizer st = new StringTokenizer(line," ");
                        while( st.hasMoreTokens() )
                        {
                            h_city.add(st.nextToken());
                            h_distance.add(Double.parseDouble(st.nextToken()));
                        }
                    }
                }
                scan.close();
                in.close();
            }
        }
        catch (Exception e) { System.out.println(e); }
        
        System.out.println( search(origin_city,destination_city,list1,list2,distance,has_heuristic,h_city,h_distance) );
    }
}