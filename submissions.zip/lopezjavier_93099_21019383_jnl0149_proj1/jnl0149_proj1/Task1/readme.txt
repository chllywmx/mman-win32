Javier Lopez 1001650149



Java 18.0.1.1 (not compatible with Omega)



There are two files: find_route.java and Node.java. This program uses an implementatoin of uniform cost search and A* search to
find the shortest path between two cities. If if a heuristic file is given, the program will use A* search, otherwise it will
use uniform cost search. The find_route.java file contains the function for the algorithms and a script to read the given input
files. The Node.java file contains a Node class used to store individual city information that is used by find_route.java.



To compile this program, use the following command:
	javac *.java

To execute this program, use:
	java find_route [input_filename] [origin_city] [destination_city] [heuristic_filename]

(heuristic_filename not required)



Example 1:
	javac *.java
	java find_route input1.txt Bremen Kassel
	
Example 2:
	javac *.java
	java find_route input1.txt Bremen Kassel h_kassel.txt