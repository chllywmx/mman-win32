public class Node {
    String city_name;
    Node previous_city;
    Double distance_from_previous;
    Double total_distance;
    Node(String _city_name, Node _previous_city, Double _distance_from_previous, Double _total_distance)
    {
        this.city_name = _city_name;
        this.previous_city = _previous_city;
        this.distance_from_previous = _distance_from_previous;
        this.total_distance = _total_distance;
    }
}