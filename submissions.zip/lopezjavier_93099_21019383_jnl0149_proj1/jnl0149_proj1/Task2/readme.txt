Javier Lopez 1001650149



Java 18.0.1.1 (not compatible with Omega)



There are three files (given by the professor): maxconnect4.java, GameBoard.java, and AiPlayer.java. The file maxconnect4.java
was modified to implement interactive mode but it does not use minimax - it randomly selects a column to play.



To compile this program, use the following command:
	javac *.java

To execute program, use either:
    java maxconnect4 interactive [input_file] [computer-next/human-next] [depth]
Or Use:
    java maxconnect4 one-move [input_file] [output_file] [depth]



Example 1:
	javac *.java
	java maxconnect4 interactive input1.txt computer-next 7

Example 2:
    javac *.java
	java maxconnect4 one-move input1.txt output.txt 3