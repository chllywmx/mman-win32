David Reichert 1001642549

Python3 was used for this programming task. Not tested on omega but should work with any Python 3 compiler.

The code is unfinished and might not work fully. This is a partial submission using the sample code from the assignment page.

To run, do "python3 maxconnect4.py one-move input1.txt output1.txt 10
