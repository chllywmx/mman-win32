import sys

class Node: 
    def __init__(node, parent, city, totalDistance, distance):
        node.parent = parent
        node.totalDistance = totalDistance
        node.dist = distance
        node.city = city

def search(route, start, destination):
    closed = []
    fringe = []
    popped = expanded = generated = 0
    fringe.append(Node(None, start, 0, 0))
    generated += 1

    def loop(generated, expanded, popped):
        if(len(fringe) == 0 ):
            print("Nodes Popped:", popped)
            print("Nodes Expanded:", expanded)
            print("Nodes Generated:", generated)
            print("Distance: infinity")
            print("Route: \nNone")
        node = fringe.pop()
        popped += 1
        if(node.city == destination):
            parentCity = node.parent
            path = []
            distance = []
            totalDistance = node.totalDistance
            while parentCity != None:
                path.append(node.city)
                path.append(parentCity.city)
                distance.append(node.dist)
                parentCity = parentCity.parent
                node = node.parent 
            print("Nodes popped:", popped)
            print("Nodes expanded:", expanded)
            print("Nodes generated", generated)
            print("Distance:", totalDistance, "\b.0 km")
            print("Route:")
            while len(path) != 0:    
                print(path.pop(), "to", path.pop() + ",", distance.pop(),"\b.0 km")
            return

        if(node.city in closed):
            return loop(generated, expanded, popped)
        else:
            expanded += 1
            closed.append(node.city)
            for city in route[node.city]:
                generated += 1
                fringe.append(Node(node, city, route[node.city][city] + node.totalDistance, route[node.city][city]))
            fringe.sort(key = (lambda x: x.totalDistance), reverse = True)
        loop(generated, expanded, popped)
    loop(generated, expanded, popped)
    return

def informedSearch(route, start, destination, huer):
    closed = []
    fringe = []
    popped = expanded = generated = 0
    fringe.append(Node(None, start, 0, 0))
    generated += 1

    def loop(generated, expanded, popped, huer):
        if(len(fringe) == 0 ):
            print("Nodes Popped:", popped)
            print("Nodes Expanded:", expanded)
            print("Nodes Generated:", generated)
            print("Distance: infinity")
            print("Route: \nNone")
            quit() 
        node = fringe.pop()
        popped += 1
        if(node.city == destination):
            parentCity = node.parent
            path = []
            distance = []
            totalDistance = node.totalDistance
            while parentCity != None:
                path.append(node.city)
                path.append(parentCity.city)
                distance.append(node.dist)
                parentCity = parentCity.parent
                node = node.parent 
            print("Nodes popped:", popped)
            print("Nodes expanded:", expanded)
            print("Nodes generated:", generated)
            print("Distance:", totalDistance, "\b.0 km")
            print("Route:")                
            while len(path) != 0:    
                print(path.pop(), "to", path.pop() + ",", distance.pop(),"\b.0 km")
            return
        if(node.city in closed):
            return loop(generated, expanded, popped, huer)
        else:
            expanded += 1
            closed.append(node.city)
            for city in route[node.city]:
                generated += 1
                fringe.append(Node(node, city, route[node.city][city] + node.totalDistance, route[node.city][city]))
            fringe.sort(key = (lambda x: x.totalDistance + huer[x.city]), reverse = True)
        loop(generated, expanded, popped, huer)
    loop(generated, expanded, popped, huer)
    return

file = open(sys.argv[1], "r")
input = file.readline()
start = sys.argv[2]
destination = sys.argv[3]
route = {}
    
while("END OF INPUT" not in input):
    input = input.split()
    route.setdefault(input[0], {})[input[1]] = int(input[2])
    route.setdefault(input[1], {})[input[0]] = int(input[2])
    input = file.readline()
if(len(sys.argv) == 5):
    file = sys.argv[4]
    heuristic = {}
    f = open(file, 'r')
    input = f.readline()

    while("END OF INPUT" not in input):
        input = input.split()
        distance = int(input[1])
        heuristic[input[0]] = distance
        input = f.readline()

    informedSearch(route, start, destination, heuristic)
else:
    search(route, start, destination)
