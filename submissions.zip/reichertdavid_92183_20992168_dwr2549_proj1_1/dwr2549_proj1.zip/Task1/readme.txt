David Reichert 1001642549

Python 3 was used for this programming task. Not tested on omega but should work with any Python 3 compiler.

The code is structured around two search functions, search(), which performs the uninformed search when not provided a heuristic file, and informedSearch(), which takes an additional command line argument for a heuristic file. There is also a class that defines each node in the search, and the main block of the code reads the file and calls its respective search function as appropriate.

To run uninformed search, do "python3 find_route.py [Input file] [Starting city] [Destination city]"

To run informed search, do "python3 find_route.py [Input file] [Starting city] [Destination city] [Heuristic file name]"
