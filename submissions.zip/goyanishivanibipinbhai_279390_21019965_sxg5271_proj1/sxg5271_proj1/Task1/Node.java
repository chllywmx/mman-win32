/* 
 * Name: Shivani Bipinbhai Goyani
 * UTA ID: 1001995271
*/

/*
 * Node structure
 * uninformed search --> [new_generated_city, parentNode, total_distance]
 * informed search --> [new_generated_city, parentNode, total_distance, cumulative_distance] where cumulative_distance = total_distance + heuristic_value
 */

class Node {	// creates a node to add it to the fringe 
    String city;
    Node parentNode;
    double total_distance;
    double cumulative_distance;     // total_distance + heuristic_value

    Node(String city, Node parentNode, double trackCost) {		// constructor for uninformed search
        this.city = city;
        this.parentNode = parentNode;
        this.total_distance = trackCost;
    }

    Node(String city, Node parentNode, double total_distance, double cumulative_distance) {		// constructor for informed search
        this.city = city;
        this.parentNode = parentNode;
        this.total_distance = total_distance;
        this.cumulative_distance = cumulative_distance;
    }
}