/* 
 * Name: Shivani Bipinbhai Goyani
 * UTA ID: 1001995271
*/

import java.util.Comparator;

class HeuristicNodeComparator implements Comparator<Node> {		// heuristic node comparator class to sort the fringe based on cumulative_distance (for informed search)
    
	public int compare(Node self, Node other) {		// Override compare method of Comparator
    	
        if (other.cumulative_distance > self.cumulative_distance)
        	return -1;
        
        else if (other.cumulative_distance < self.cumulative_distance) 
        	return 1;
        
        else 
        	return 0;
    }
}