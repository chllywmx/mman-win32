Name: Shivani Bipinbhai Goyani
UTA ID: 1001995271
Programming Language: Java

How to run the code: (This code was tested in omega)

Assumption: input_filename and heuristic_filename should be in the same folder with find_route.java, Node.java, NodeComparatoe.java and HeuristicNodeComparator.java

1.	To compile: javac find_route.java Node.java NodeComparator.java HeuristicNodeComparator.java
2.	To run:	
		uninformed search:	java find_route input_filename origin_city destination_city
		example:			java find_route input1.txt Bremen Kassel
		informed search:		java find_route input_filename origin_city destination_city heuristic_filename
		example:			java find_route input1.txt Bremen Kassel h_kassel.txt

Code Structure:

1.	Program takes arguments from the user as inputs and throws error if incorrect inputs provided
2.	Based on the no. of arguments, it calls uniformed_search(for 3 arguments) or informed_search(for 4 arguments)
3.	Node class is used to create a node. It contains has 2 constructors(for uninformed & informed search respectively)
4.	The fringe is implemented by PriorityQueue<Node>
4.	NodeComparator(uninformed search) and HeuristicNodeComparator(informed search) classes implements Comparator class of Java to sort the fringe based on total_distance(uninformed search) and cumulative_distance(informed search)
5.	Input file and Heuristic file parsed into maps input_city_map & input_heuristic_map by methods parse_input_file & parse_heuristic_file respectively
6.	Output is displayed using display_output method

For Uninformed Search:

7.	Parse the input file and create map mentioned in step 5
8.	Expanded cities will be saved in closed set
9.	Nodes are taken from the top of the fringe and checks if city is destination_city. If no, it visits its succcessor cities and add them to the fringe. Straight line distance is added to the successor distance and fringe will be sorted based on this(total_distance)
10.	These continues unless the destination city is not found or the fringe is not empty

For Informed Search:

11.	This methods implements A* method.
11.	Similar to uninformed serach, the only difference is, cumulative distance is added to the node.
12.	For each successor, cumulative distance is calculated based on total_distance + heuristic_value. The fringe will be sorted based on cumulative distance

References:
https://www.freecodecamp.org/news/priority-queue-implementation-in-java/
https://www.programiz.com/java-programming/priorityqueue
https://beginnersbook.com/2014/01/how-to-read-file-in-java-using-bufferedreader/
https://www.w3schools.com/java/java_hashset.asp
https://www.javatpoint.com/java-priorityqueue