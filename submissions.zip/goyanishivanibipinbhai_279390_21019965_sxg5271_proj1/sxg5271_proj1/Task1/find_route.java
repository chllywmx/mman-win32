/* 
 * Name: Shivani Bipinbhai Goyani
 * UTA ID: 1001995271
*/

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.Stack;


public class find_route {
	
    public static int popped_count = 0;									// increment by 1 for every popped node
    
    public static int generated_count = 0;								// increment by 1 for every generated node
    
    public static Node goalNode;										// goal Node for destination city
    
    public static boolean routeExistFlag = false;						// sets to true if route exists
    
    public static HashMap<String, Double> input_heuristic_map;			// to create heuristic map from heuristic file
    
    public static Map<String, ArrayList<String[]>> input_city_map;		// to create city map from input file
    
    public static PriorityQueue<Node> fringe;
    
    public static Set<String> closed;									// to add visited city to closed set
    
    public static void parse_input_file(String input_filename) {		// helps to create successor function and step cost function
        
    	File inputFile = new File(input_filename);
        BufferedReader reader = null;
        
        try {
            
        	reader = new BufferedReader(new FileReader(inputFile.getPath()));
            String eachLine;                                                    // Luebeck Hamburg 63
            
            while (!(eachLine = reader.readLine()).equals("END OF INPUT")) {
            	
                String origin_city = eachLine.split(" ")[0];             		// 'Luebeck'
                String destination_city = eachLine.split(" ")[1];       		// 'Hamburg'
                String distance = eachLine.split(" ")[2];						// 63
                
                copyDataToMap(origin_city, destination_city, distance);     	// { "Luebeck": ["Hamburg", "63"] }
                copyDataToMap(destination_city, origin_city, distance);    		// { "Hamburg": ["Luebeck", "63"] }
            
            }
        } catch (FileNotFoundException e) {
            System.out.println(input_filename + " not found. Please try again");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void copyDataToMap(String origin_city, String destination_city, String distance) {
        
    	String[] tempStringArray = {destination_city, distance};     // ["Hamburg", "63"]
        
        if (input_city_map.containsKey(origin_city)) {
            
        	input_city_map.get(origin_city).add(tempStringArray);
        } 
        
        else {
            
        	ArrayList<String[]> tempArrayList = new ArrayList<String[]>();
            tempArrayList.add(tempStringArray);
            input_city_map.put(origin_city, tempArrayList);   // { "Luebeck": ["Hamburg", "63"] }
            
        }
    }
    
    public static void parse_heuristic_file(String heuristic_filename) {
    	
        File inputHeuristicFile = new File(heuristic_filename);
        BufferedReader reader = null;
        
        try {
            
        	reader = new BufferedReader(new FileReader(inputHeuristicFile.getPath()));
            String eachLine;
            
            while (!(eachLine = reader.readLine()).equals("END OF INPUT")) {
                
            	String city_name = eachLine.split(" ")[0];
                Double heuristic_value = Double.parseDouble((eachLine.split(" ")[1]));
                input_heuristic_map.put(city_name, heuristic_value);
                
            }
        } catch (FileNotFoundException e) {
            System.out.println(heuristic_filename + " not found. Please try again");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void uniformed_search(String input_filename, String origin_city, String destination_city) {
        
    	input_city_map = new HashMap<String, ArrayList<String[]>>();
    	
    	parse_input_file(input_filename);
    	
    	closed = new HashSet<String>();								
        
    	fringe = new PriorityQueue<Node>(10, new NodeComparator());		// creates fringe
    	
    	Node parentNode = null;
    	double total_distance = 0.0;
        
    	fringe.add(new Node(origin_city, parentNode, total_distance));	// creates initial Node for origin_city --> ['Bremen', null, 0.0]
        
    	generated_count += 1;
        
    	while (!fringe.isEmpty()) {
            
    		Node currentNode = fringe.poll();		// takes the first node from the fringe
            
    		if (currentNode.city.equals(destination_city)) {
                
    			popped_count += 1;
    			routeExistFlag = true;
    			goalNode = currentNode;
                break;
            }
            
    		if(!closed.contains(currentNode.city)) {
                
            	popped_count += 1;
                
            	closed.add(currentNode.city);
                
            	for (String[] tempStringArray : input_city_map.get(currentNode.city)) {
            		
                	total_distance = 0.0;
            		
            		double straight_line_distance = Double.parseDouble(tempStringArray[1]);		// finds straight line distance from input_City_Map 
            		
            		total_distance = currentNode.total_distance + straight_line_distance;		// 0.0 + 116
            		
            		String new_city = tempStringArray[0];										// 'Hamburg'
            		
                    Node newGeneratedNode = new Node(new_city, currentNode, total_distance);	// ['Hamburg', ['Bremen', null, 0.0] ,116.0]
                    
                    fringe.add(newGeneratedNode);
                    
                    generated_count += 1;
                }
            } 
    		
    		else {
            	
    			popped_count += 1;
            }
        }
    	
    	display_output();
    }

    public static void informed_search(String input_filename, String origin_city, String destination_city, String heuristic_filename) {
        
    	input_city_map = new HashMap<String, ArrayList<String[]>>();
    	parse_input_file(input_filename);
    	
    	input_heuristic_map = new HashMap<String, Double>();
    	parse_heuristic_file(heuristic_filename);
    	
    	closed = new HashSet<String>();										// to add visited city to closedSet
    	
        fringe = new PriorityQueue<Node>(10, new HeuristicNodeComparator());	// creates fringe
        
    	Node parentNode = null;
    	double total_distance = 0.0;
    	double cumulative_distance = 0.0;
        
        fringe.add(new Node(origin_city, parentNode, total_distance, cumulative_distance));		// creates initial Node for origin_city --> ['Bremen', null, 0.0, 0.0]
        
        generated_count += 1;
        
        while (!fringe.isEmpty()) {
        	
        	Node currentNode = fringe.poll();		// takes the first node from the fringe
            
        	if (currentNode.city.equals(destination_city)) {
        		
        		popped_count += 1;
        		routeExistFlag = true;
        		goalNode = currentNode;
        		break;
            }
        	
            if (!closed.contains(currentNode.city)) {
                
            	popped_count += 1;
                closed.add(currentNode.city);
                
                for (String[] tempStringArray : input_city_map.get(currentNode.city)) {
                	
                	double straight_line_distance = Double.parseDouble(tempStringArray[1]);		// finds straight line distance from input_City_Map 
                	
                	total_distance = currentNode.total_distance + straight_line_distance;		// 0.0 + 116
                	
                	String new_city = tempStringArray[0];										// 'Hamburg'
                    
                	double heuristic_value = input_heuristic_map.get(tempStringArray[0]);		// 200.0
                	
                    cumulative_distance = total_distance + heuristic_value;						// 116.0 + 200.0
                    
                    Node newGeneratedNode = new Node(new_city, currentNode, total_distance, cumulative_distance);	// ['Hamburg', ['Bremen', null, 0.0, 0.0] ,116.0, 316.0]
                    
                    fringe.add(newGeneratedNode);
                    
                    generated_count += 1;
                }
            } 
            else {
            	
            	popped_count += 1;
            }
        }
        
        display_output();
    }

    public static void display_output() {		// to display output

        System.out.println("Nodes Popped: " + popped_count);
        System.out.println("Nodes Expanded: " + closed.size());
        System.out.println("Nodes Generated: " + generated_count);

        if (routeExistFlag == true) {
            
        	double total_distance = goalNode.total_distance;
            
        	Stack<String> route = new Stack<String>();
            
            while (goalNode.parentNode != null) {
                
            	double individual_distance = goalNode.total_distance - goalNode.parentNode.total_distance;
                route.push(goalNode.parentNode.city + " to " + goalNode.city + ", " + individual_distance + " km");
                goalNode = goalNode.parentNode;
                
            }
            
            System.out.println("Distance: " + total_distance + " km");
            System.out.println("Route:");
                       
            while (!route.isEmpty()) {
                System.out.println(route.pop());
            }
        } 
        
        else {
        	
            System.out.println("Distance: infinity");
            System.out.println("Route:");
            System.out.println("None");
            
        }
    }

    public static void main(String[] args) {

        if (args.length == 3) {
        	
        	String input_filename = args[0];
        	String origin_city = args[1];
        	String destination_city = args[2];
        	uniformed_search(input_filename, origin_city, destination_city);
        
        }
   
        else {
            if (args.length == 4) {
            	
            	String input_filename = args[0];
            	String origin_city = args[1];
            	String destination_city = args[2];
            	String heuristic_filename = args[3];
            	informed_search(input_filename, origin_city, destination_city, heuristic_filename);
            	
            } else {
            	
                System.out.println("Please enter valid arguments");
                
            }
        }
    }
}