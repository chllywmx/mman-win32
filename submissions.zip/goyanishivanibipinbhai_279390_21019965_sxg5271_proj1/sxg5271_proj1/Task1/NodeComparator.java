/* 
 * Name: Shivani Bipinbhai Goyani
 * UTA ID: 1001995271
*/

import java.util.Comparator;

class NodeComparator implements Comparator<Node> {		// regular node comparator class to sort the fringe based on total_distance (for uninformed search)
    
	public int compare(Node self, Node other) {		// Override compare method of Comparator
        
		if (other.total_distance > self.total_distance) 
			return -1;
        
		else if (other.total_distance < self.total_distance) 
			return 1;
        
		else 
			return 0;
    }
}