import java.util.*;

/**
 * This is the AiPlayer class.  It simulates a minimax player for the max
 * connect four game.
 * The constructor essentially does nothing. 
 * 
 * @author james spargo
 *
 */

public class AiPlayer
{
    /**
     * The constructor essentially does nothing except instantiate an
     * AiPlayer object.
     *
     */
    public AiPlayer()
    {
	// nothing to do here
    }

    private int depthLevel;

    public AiPlayer(int depthLevel) {
        this.depthLevel = depthLevel;
    }

    int calculateMINValue(GameBoard currentGameBoard, int alphaValue, int betaValue, int depthLevel)   // MIN  move
    {
        if (currentGameBoard.getPieceCount() != 42)    // terminal nodes
        {
            if (depthLevel == 0)
                return evaluationFunction(currentGameBoard);
            else {
                ArrayList<GameBoard> child_Node ;
                child_Node = getAllPossibleGameBoards(currentGameBoard);

                int currentMaxValue = Integer.MAX_VALUE;
                for (int i = 0; i < child_Node.size(); i++) {

                    currentMaxValue = Math.min(currentMaxValue, calculateMAXValue(child_Node.get(i), alphaValue, betaValue, depthLevel - 1));
                    if (currentMaxValue <= alphaValue) {
                        return currentMaxValue;
                    }
                    betaValue = Math.min(betaValue, currentMaxValue);
                }
                return currentMaxValue;

            }
        } else {
            return utilityFunction(currentGameBoard);
        }
    }

    int calculateMAXValue(GameBoard currentGameBoard, int alphaValue, int betaValue, int depthLevel)    // MAX move
    {
        if (currentGameBoard.getPieceCount() != 42) {   // terminal nodes
            if (depthLevel == 0)
                return evaluationFunction(currentGameBoard);
            else {
                ArrayList<GameBoard> child_Node;
                child_Node = getAllPossibleGameBoards(currentGameBoard);

                int currentMinValue = Integer.MIN_VALUE;
                for (int i = 0; i < child_Node.size(); i++) {

                    currentMinValue = Math.max(currentMinValue, calculateMAXValue(child_Node.get(i), alphaValue, betaValue, depthLevel - 1));

                    if (currentMinValue < betaValue) {
                        alphaValue = Math.max(alphaValue, currentMinValue);
                    } else {
                        return currentMinValue;
                    }
                }
                return currentMinValue;
            }
        } else {
            return utilityFunction(currentGameBoard);
        }
    }

    public int findBestPlay(GameBoard currentGameBoard ) // alpha-beta pruning with minimax
    {

        int alphaValue = Integer.MIN_VALUE;     // alpha= -infinity
        int betaValue = Integer.MAX_VALUE;      // beta= +infinity
        int currentMinValue = Integer.MIN_VALUE;
        int bestColumnNumberToPlay = -1;

        for (int i=0; i<7; i++) {
            if(currentGameBoard.isValidPlay(i)) {

                GameBoard nextGameBoard = new GameBoard(currentGameBoard.getGameBoard());
                nextGameBoard.playPiece(i);
                int calculatedMinValue = calculateMINValue(nextGameBoard,alphaValue,betaValue,depthLevel-1);

                if (currentMinValue >= calculatedMinValue) {
                    continue;
                }
                currentMinValue = calculatedMinValue;
                bestColumnNumberToPlay = i;
            }
        }
        return bestColumnNumberToPlay;
    }

    ArrayList<GameBoard> getAllPossibleGameBoards(GameBoard state) {    // gets all successors

        ArrayList<GameBoard> child_Node = new ArrayList<GameBoard>();

        for (int i=0; i<7; i++) {

            if (!state.isValidPlay(i)) {
                continue;
            }

            GameBoard tempChild = new GameBoard(state.getGameBoard());
            tempChild.playPiece(i);
            child_Node.add(tempChild);
        }
        return child_Node;

    }

    // utility function
    public int utilityFunction(GameBoard currentGame) {
        if (currentGame.getScore(1) <= currentGame.getScore(2)) {
            if (currentGame.getScore(2) <= currentGame.getScore(1)) {
                int utility_value=0;
                return utility_value;
            } else {
                int utility_value = Integer.MIN_VALUE;
                return utility_value;
            }
        } else {
            int utility_value = Integer.MAX_VALUE;
            return utility_value;
        }
    }

    // evaluation function
    public int evaluationFunction(GameBoard currentGameBoard){
        return currentGameBoard.getScore(1) - currentGameBoard.getScore(2);
    }

}
