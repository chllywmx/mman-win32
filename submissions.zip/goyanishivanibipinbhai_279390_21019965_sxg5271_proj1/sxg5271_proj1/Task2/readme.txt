Name: Shivani Bipinbhai Goyani
UTA ID: 1001995271
Programming Language: Java

How to run the code: (This code was tested in omega)

Assumption: input_filename and heuristic_filename should be in the same folder with find_route.java, Node.java, NodeComparatoe.java and HeuristicNodeComparator.java

1.	To compile: javac maxconnect4.java GameBoard.java AiPlayer.java
2.	To run:	
		one-move mode:		java maxconnect4 one-move [input_file] [output_file] [depth]
		example:			java maxconnect4 one-move input1.txt output1.txt 1
		interactive mode:		java maxconnect4 interactive [input_file] [computer-next/human-next] [depth]
		example:			java maxconnect4 interactive input2.txt computer-next 1

Execution Time:

depth	time_taken
1	0m0.054s	
2	0m0.041s
3	0m0.102s
4	0m0.099s
5	0m0.114s
6	0m0.263s
7	0m0.465s
8	0m1.477s
9	0m9.884s
10	1m10.142s

Code Structure:

maxconnect4.java
Calcualtes the best possible move for the computer in both one-move and interactive mode. Asks user to to enter column number when its their turn

GameBoard.java
Class responsible for creating gameboard, updating gameboard, printing game board for before and after state, calculating scores for players

AiPlayer.java

findBestPlay -- Determins the best possible move for the player

calculateMAXValue -- Inorder to get maximum value

calculateMINValue -- Inorder to get minimum value

getAllPossibleGameBoards -- find the successors of current game board

utilityFunction -- calculates utility for terminal nodes

evaluationFunction -- performs evaluation when depth is 0