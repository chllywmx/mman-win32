// Prathibha Lakkidi
// UTA ID - 1001962876


import java.io.*;

public class GameBoard implements Cloneable
{
    private int[][] board;
    private int piece;
    private int current;
	private static int row=5,col=0;
    private  static int playing,max,min;
   	public GameBoard( String inputFile ) 
    {
	this.board = new int[6][7];
	this.piece = 0;
	int counter = 0;
	BufferedReader inp = null;
	String game = null;
	try 
	{
	    inp = new BufferedReader( new FileReader( inputFile ) );
	} 
        catch( IOException e ) 
	{
	    System.out.println("Try again.\n");
	    e.printStackTrace();
	}
	for(int i= 0;i< 6; i++) 
	{
	    try 
	    {
		game = inp.readLine();	
		for( int j= 0;j< 7; j++ ) 
		{  
			this.board[i][j] = game.charAt( counter++ ) - 48;		    
		    if( !( ( this.board[i][j] == 0 ) ||
			   ( this.board[i][j] == 1 ) ||
			   ( this.board[i][j] == 2 ) ) ) 
                    {
			System.out.println("The input was not a 1 or 2 or 0" );
			this.exit_function( 0 );
		    }
		    
		    if( this.board[i][j] > 0 )
		    {
			this.piece++;
		    }
		}
	    } 
	    catch( Exception e ) 
	    {
		System.out.println("Try again.\n");
		e.printStackTrace();
		this.exit_function( 0 );
	    }	    
	    counter = 0;
	} 	
	try 
    {
	    game = inp.readLine();
	} 
	catch( Exception e ) 
	{
	    System.out.println("Try again.\n");
	    e.printStackTrace();
	}
	this.current = game.charAt( 0 ) - 48;	
	if(!( ( this.current == 1) || ( this.current == 2 ) ) ) 
	{
	    System.out.println("The input read is not a 1 or a 2!");
	    this.exit_function( 0 );
	} 
	else if ( this.currentTurn() != this.current ) 
	{
	    System.out.println("The input does not correspond to the number of pieces played!");
	    this.exit_function( 0 );			
	}
    }     
    public GameBoard( int Game[][] ) 
    {	
	this.board = new int[6][7];
	this.piece = 0;
	for( int i= 0;i< 6; i++ ) 
	{
	    for( int j= 0;j< 7; j++) 
	    {
		this.board[i][j] = Game[i][j];
		
		if( this.board[i][j] > 0 )
		{
		    this.piece++;
		}
	    }
	}
    }     
    public int score( int player ) 
    {
	int score = 0;	
	for( int i= 0;i< 6; i++ ) 
        {
	    for( int j= 0;j< 4; j++ ) 
	    {
		if( ( this.board[i][j] == player ) &&
		    ( this.board[i][j+1] == player ) &&
		    ( this.board[i][j+2] == player ) &&
		    ( this.board[i][j+3] == player ) ) 
		{
		    score++;
		}
	    }
	}	
	for( int i= 0;i< 3; i++ ) {
	    for( int j= 0;j< 7; j++ ) {
		if( ( this.board[i][j] == player ) &&
		    ( this.board[i+1][j] == player ) &&
		    ( this.board[i+2][j] == player ) &&
		    ( this.board[i+3][j] == player ) ) {
		    score++;
		}
	    }
	} 
	for( int i= 0;i< 3; i++ ){
		for( int j= 0;j< 4; j++ ) {
		    if( ( this.board[i][j] == player ) &&
			( this.board[i+1][j+1] == player ) &&
			( this.board[i+2][j+2] == player ) &&
			( this.board[i+3][j+3] == player ) ) {
			score++;
		    }
		}
	}	    
	for( int i= 0;i< 3; i++ ){
		for( int j= 0;j< 4; j++ ) {
		    if( ( this.board[i+3][j] == player ) &&
			( this.board[i+2][j+1] == player ) &&
			( this.board[i+1][j+2] == player ) &&
			( this.board[i][j+3] == player ) ) {
			score++;
		    }
		}
	}    
	return score;
    }     
    public int currentTurn() 
    {
		return ( this.piece % 2 ) + 1 ;
    }     
    public int pieceCount() 
    {
	return this.piece;
    }    
    public int[][] gameBoard() 
    {
		return this.board;
    }	
	public GameBoard(){
		this.board = new int[6][7];
        this.piece = 0;
        for( int i= 0;i< 6; i++ ) 
        {
            for( int j= 0;j< 7; j++) 
            {
            this.board[i][j] = 0;
           }
        }
    }    
    public double evaluate(int arr[][], int plr ){	
		double score = 0;		
		double w1=1.00,w2=0.80,w3=0.60,w4=0.40;		
		int f1=0,f2=0,f3=0,f4=0;		
		for( int i= 0;i< 6; i++ ){
		    for( int j= 0;j< 4; j++ ){				
				if( ( arr[i][j] == plr ) &&( arr[i][j+1] == plr ) &&( arr[i][j+2] == plr ) &&( arr[i][j+3] == plr ) ){
					f1++;
				}				
				if( ( arr[i][j] == plr ) &&( arr[i][j+1] == plr ) &&( arr[i][j+2] == plr ) &&( arr[i][j+3] == 0 ) ){
					f2++;
				}				else if( ( arr[i][j] == 0 ) &&( arr[i][j+1] == plr ) &&( arr[i][j+2] == plr) &&( arr[i][j+3] == plr ) ){
					f2++;
				}				
				if( ( arr[i][j] == plr ) &&( arr[i][j+1] == plr ) &&( arr[i][j+2] == 0 ) &&( arr[i][j+3] == 0 ) ){
					f3++;
				}
				else if( ( arr[i][j] == 0 ) &&( arr[i][j+1] == 0 ) &&( arr[i][j+2] == plr ) &&( arr[i][j+3] == plr ) ){
					f3++;
				}				
				if( ( arr[i][j] == plr ) &&( arr[i][j+1] == 0 ) &&( arr[i][j+2] == 0 ) &&( arr[i][j+3] == 0 ) ){
					f4++;
				}
				else if( ( arr[i][j] == 0 ) &&( arr[i][j+1] == 0 ) &&( arr[i][j+2] == 0 ) &&( arr[i][j+3] == plr ) ){
					f4++;
				}
			}
		} 
		for( int i= 0;i< 3; i++ ) {
		    for( int j= 0;j< 7; j++ ){		    	
				if( ( arr[i][j] == plr ) &&( arr[i+1][j] == plr ) &&(arr[i+2][j] == plr ) &&( arr[i+3][j] == plr ) ) {
				    f1++;
				}				
				if( ( arr[i][j] == plr ) &&( arr[i+1][j] == plr ) &&(arr[i+2][j] == plr ) &&( arr[i+3][j] == 0 ) ) {
				    f2++;
				}
				else if( ( arr[i][j] == 0 ) &&( arr[i+1][j] == plr ) &&(arr[i+2][j] == plr ) &&( arr[i+3][j] == plr ) ) {
				    f2++;
				}				
				if( ( arr[i][j] == plr ) &&( arr[i+1][j] == plr ) &&(arr[i+2][j] == 0 ) &&( arr[i+3][j] == 0 ) ) {
				    f3++;
				}
				else if( ( arr[i][j] == 0 ) &&( arr[i+1][j] == 0 ) &&(arr[i+2][j] == plr ) &&( arr[i+3][j] == plr ) ) {
				    f3++;
				}				
				if( ( arr[i][j] == plr ) &&( arr[i+1][j] == 0 ) &&(arr[i+2][j] == 0 ) &&( arr[i+3][j] == 0 ) ) {
				    f4++;
				}
				else if( ( arr[i][j] == 0 ) &&( arr[i+1][j] == 0 ) &&(arr[i+2][j] == 0 ) &&( arr[i+3][j] == plr ) ) {
				    f4++;
				}
		    }
		} 
		for(int i= 0;i< 3; i++ ){
			for( int j= 0;j< 4; j++ ){			   
			    if( ( arr[i][j] == plr ) &&( arr[i+1][j+1] == plr) &&( arr[i+2][j+2] == plr ) &&( arr[i+3][j+3] == plr ) ) {
					f1++;
			    }			    
			     if( ( arr[i][j] == plr ) &&( arr[i+1][j+1] == plr) &&( arr[i+2][j+2] == plr ) &&( arr[i+3][j+3] == 0 ) ) {
					f2++;
			    }
			     else if( ( arr[i][j] == 0 ) &&( arr[i+1][j+1] == plr) &&( arr[i+2][j+2] == plr ) &&( arr[i+3][j+3] == plr ) ) {
					f2++;
			    }			    
			     if( ( arr[i][j] == plr ) &&( arr[i+1][j+1] == plr) &&( arr[i+2][j+2] == 0 ) &&( arr[i+3][j+3] == 0 ) ) {
					f3++;
			    }
			    else if( ( arr[i][j] == 0 ) &&( arr[i+1][j+1] == 0) &&( arr[i+2][j+2] == plr ) &&( arr[i+3][j+3] == plr ) ) {
					f3++;
			    }			    
			     if( ( arr[i][j] == plr ) &&( arr[i+1][j+1] == 0) &&( arr[i+2][j+2] == 0 ) &&( arr[i+3][j+3] == 0 ) ) {
					f4++;
			    }
			    else if( ( arr[i][j] == 0 ) &&( arr[i+1][j+1] == 0) &&( arr[i+2][j+2] == 0 ) &&( arr[i+3][j+3] == plr ) ) {
					f4++;
			    }
			}
		}
		for(int i= 0;i< 3; i++){
			for( int j= 0;j< 4; j++ ){			    
			    if( ( arr[i+3][j] == plr ) &&( arr[i+2][j+1] == plr ) &&( arr[i+1][j+2] == plr ) &&( arr[i][j+3] == plr ) ) {
					f1++;
			    }			    
				if( ( arr[i+3][j] == plr ) &&( arr[i+2][j+1] == plr ) &&( arr[i+1][j+2] == plr ) &&( arr[i][j+3] == 0 ) ) {
					f2++;
			    }
			    else if( ( arr[i+3][j] == 0 ) &&( arr[i+2][j+1] == plr ) &&( arr[i+1][j+2] == plr ) &&( arr[i][j+3] == plr ) ) {
					f2++;
			    }			    
			    if( ( arr[i+3][j] == plr ) &&( arr[i+2][j+1] == plr ) &&( arr[i+1][j+2] == 0 ) &&( arr[i][j+3] == 0 ) ) {
					f3++;
			    }
			    else if( ( arr[i+3][j] == 0 ) &&( arr[i+2][j+1] == 0 ) &&( arr[i+1][j+2] == plr ) &&( arr[i][j+3] == plr ) ) {
					f3++;
			    }			    
			    if( ( arr[i+3][j] == plr ) &&( arr[i+2][j+1] == 0 ) &&( arr[i+1][j+2] == 0 ) &&( arr[i][j+3] == 0 ) ) {
					f4++;
			    }
			    else if( ( arr[i+3][j] == 0 ) &&( arr[i+2][j+1] == 0 ) &&( arr[i+1][j+2] == 0 ) &&( arr[i][j+3] == plr ) ) {
					f4++;
			    }
			}
		}
		score=((f1*w1)+(f2*w2)+(f3*w3)+(f4*w4));
		return score;
    }     
    public Boolean func(int[][] arr){
        for(int q=0;q<6;q++){
         	for(int w=0;w<7;w++)
			{         		
         		 if(arr[q][w]==0)
				  return false;  
         	}  	
        }
        return true;
    }   
    public  double maxValue(double alpha,double beta,int d,int depth){
		playing=max;		
        if((d==(depth))||func(this.board)){        	
        	double sum_eval=evaluate(this.board,max)-evaluate(this.board,min);
        	return sum_eval;
        }
        double x=0;
        int z=0;
	    int gb[][],s[][];	    
	   	gb=this.gameBoard();
	    GameBoard []succ=new GameBoard[7];	     
	    int no_suc=this.noOfSucc();
	    col=0;
	    row=5;	    
	    for(z=0;z<no_suc;z++){			
			GameBoard temp_gb=new GameBoard();
		    succ[z] = new GameBoard();
		    temp_gb.board=gb;		     
		    temp_gb.funcSucc();
		    s=temp_gb.gameBoard();		    
		    for(int i=0;i<6;i++)
			{	    
		    	for(int j=0;j<7;j++){
		    	   succ[z].board[i][j]=s[i][j];		
		    	}
			}		    
			temp_gb.rmPieces(row,col);
		    col++;
	    } 
	    double val=Double.NEGATIVE_INFINITY;	   
	    for(z=0;z<no_suc;z++){
	    	x=succ[z].minValue(alpha,beta,d+1,depth);
	    	if(val<x){
    			val=x;
    		}
    		
    		if(val>=beta){
    			return val;
    		}
    		playing=max;
    		if(alpha<val){
    			alpha=val;
    		}
	    }
    	return val;
    }    
    public void rmPieces(int row, int col){
    	for(int i=0;i<6;i++){
    		for(int j=0;j<7;j++){
    			if(i==row&&j==col){
    				this.board[i][j]=0;
    			}
    		}
    	}
    }
    public  double minValue(double alpha,double beta,int d,int depth)
	{
        playing=min;        
        if((d==(depth))|| func(this.board)){
        	
        	double sum_eval=evaluate(this.board,max)-evaluate(this.board,min);
        	return sum_eval;
        }
        double x=0;int z=0;
	    int gb[][],s[][];	    
	    gb=this.gameBoard();
	    GameBoard []succ=new GameBoard[7];	    
	    int no_suc=this.noOfSucc();
	    col=0;
	    row=5;	   
	    for(z=0;z<no_suc;z++){	    	
			GameBoard temp_gb=new GameBoard();
		    succ[z] = new GameBoard();
		    temp_gb.board=gb;		    
		    temp_gb.funcSucc();
		    s=temp_gb.gameBoard();		    
		    for(int i=0;i<6;i++){
		    	for(int j=0;j<7;j++){
		    	   succ[z].board[i][j]=s[i][j];		
		    	}
			}		    
			temp_gb.rmPieces(row,col);
		    col++;
	    }
	    double val=Double.POSITIVE_INFINITY;	    
	    for(z=0;z<no_suc;z++){
	    	x=succ[z].maxValue(alpha,beta,d+1,depth);	    	
	    	if(val>x){
    			val=x;
    		}    		
    		if(val<=alpha){
    			return val;
    		}
    		playing=min;
    		if(beta>val){
    			beta=val;
    		}
	    }
    	return val;
    }    
    public  void funcSucc(){
      int i=5;
      int j=col;
      while(i>=0&&j<7){
           if(this.board[i][j]==0){                
                if(playing==1){
                    this.board[i][j]=1;
                    row=i;
                    col=j;
                }
                else{
                	this.board[i][j]=2;
                    row=i;
                    col=j;                            
                }
               break;
            }
            else{
            	i--;
            	if(i<0){
            		i=5;
            		j++;
            	}
            }
        };
    }    
    public int noOfSucc(){
    	int i=0,j=0;
    	int c=0;
    	for(j=0;j<7;j++){
    		for(i=0;i<6;i++){
    			if(this.board[i][j]==0){
    				c++;
    				i=6;
    			}
    		}
    	}
    	return c;
    }    
    public int alphabeta(GameBoard cur_game,int depth){
    	int best=0;
    	double x=0;
    	int z=0;
    	int gb[][],s[][];
    	int pcol=0;    	
    	int plrcol[]={0,0,0,0,0,0,0};    	
    	double alpha=Double.NEGATIVE_INFINITY;
    	double beta=Double.POSITIVE_INFINITY;
    	int d=0;    	
    	if(depth==0){
    		System.out.println("Minimum Depth 1");
    		exit_function(0);
    	}
    	row=5;
    	col=0;    	
    	GameBoard []succ=new GameBoard[7];    	
    	int no_suc=cur_game.noOfSucc();
    	gb=cur_game.gameBoard();    	
    	playing=cur_game.currentTurn();    	
    	max=playing;    	
    	if(max==1){
    		min=2;
    	}
    	else min=1;		
		for(z=0;z<no_suc;z++){			
			GameBoard temp_gb=new GameBoard();
		    succ[z] = new GameBoard();
		    temp_gb.board=gb;		    
		    temp_gb.funcSucc();		    
		    plrcol[pcol]=col;
		    s=temp_gb.gameBoard();		     
		    for(int i=0;i<6;i++){
		    	for(int j=0;j<7;j++){
		    	   succ[z].board[i][j]=s[i][j];		
		    	}
		    }
		    	    
		    temp_gb.rmPieces(row,col);
		   	col++;
		    pcol++;
    	}
    	double val=Double.NEGATIVE_INFINITY;
    	best=0;
    	pcol=0;    	
    	for(z=0;z<no_suc;z++){
    		x=succ[z].minValue(alpha,beta,d+1,depth);    		
    		if(val<x){
    			val=x;    			
    			best=plrcol[pcol];
    			if(alpha<val){
    				alpha=val;
    			}       			
 				if(val>=beta){
    				return best;
    			}   		
    		}
    		playing=max;
    		pcol++;
    	}    	
      return best;
    }    
    public boolean fullGameBoard(){
    	int i=0,j=0;
    	for(j=0;j<7;j++){
    		for(i=0;i<6;i++){
    			if(this.board[i][j]==0){
    				return false;
    			}
    		}
    	}	
    	return true;
    }    
    public boolean isValid(int clmn) 
	{	
	if ( !( clmn >= 0 && clmn <= 6 ) ) {	    
	    return false;
	} else if( this.board[0][ clmn ] > 0 ) {
	    
	    return false;
	} else {
	    
	    return true;
	}
    }    
    public boolean pieceToPlay( int clmn ) {	
	if( !this.isValid( clmn ) ) {
	    return false;
	} else {	   
	    for(int i= 5;i>= 0; i-- ) 
		{
		if( this.board[i][clmn] == 0 ) {
		    if( this.piece % 2 == 0 ){
			this.board[i][clmn] = 1;
			this.piece++;			
		    } else { 
			this.board[i][clmn] = 2;
			this.piece++;
		    }		   
		    return true;
		}
	    }	   
	    System.out.println("Something went wrong");	    
	    return false;
	}
    }    
    public void rmPiece( int clmn ) {	
	for(int i= 0;i< 6; i++ ) {
	    if( this.board[i][ clmn ] > 0 ) {
		this.board[i][ clmn ] = 0;
		this.piece--;		
		break;
	    }
	}	
    } 
	private void exit_function( int val ){
		System.out.println("Exiting!\n\n");
		System.exit(val);
	}	   
    public void printGB() 
    {
	System.out.println("  ________________\n");	
	for(int i= 0;i< 6; i++ ) 
        {
	    System.out.print(" | ");
	    for( int j= 0;j< 7; j++ ) 
            {
                System.out.print( this.board[i][j] + " " );
            }

	    System.out.println("| ");
	}	
	System.out.println("  _________________");
    } 
    public void outputGBtoFile( String outputFile ) {
	try {
	    BufferedWriter file = new BufferedWriter(new FileWriter( outputFile ) );	    
	    for(int i= 0;i< 6; i++ ) {
		for( int j= 0;j< 7; j++ ) {
		    file.write(this.board[i][j] + 48);
		}
		file.write("\r\n");
	    }    
	    file.write( this.currentTurn() + "\r\n");
	    file.close();	    
	} catch( IOException e ) {
	    System.out.println("Try again.");
	    e.printStackTrace();
	}
    }     
}  
