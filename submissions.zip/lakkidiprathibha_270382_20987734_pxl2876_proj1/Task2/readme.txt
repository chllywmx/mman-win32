Name: Prathibha Lakkidi
ID: 1001962876
Programming Language used: Java

Code Structure:(Used the sample code)
maxconnect4.java,GameBoard.java, AiPlayer.java
-All the methods are defined in GameBoard.java
	-evaluate() evaluates the game state.
	-func() checks if the state is terminal. 
	-alphabeta() for making the move to the index.
	-fullGameBoard() checks if the gameboard is full.
	-pieceToPlay() finds the validation of the piece to play next.
	-funcSucc() gets the successor of a particular game state
	-outputGBtoFile() to cretae the ouputfile.

			
How to run the code:

Compile:
	javac maxconnect4.java GameBoard.java AiPlayer.java

Run:

-Interactive Mode
	java maxconnect4 interactive [input_file] [computer-next/human-next] [depth] 
	Ex:
		java maxconnect4 interactive input1.txt computer-next 7

-One-Move Mode
	 java maxconnect4 one-move [input_file] [output_file] [depth]
	 Ex:
	 	java maxconnect4 one-move input1.txt output1.txt 10
			
			
