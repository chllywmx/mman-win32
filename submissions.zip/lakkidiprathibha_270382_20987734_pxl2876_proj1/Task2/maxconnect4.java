// Prathibha Lakkidi
// UTA ID - 1001962876


import java.util.*;
public class maxconnect4
{
	public static void interactive(GameBoard cur_game,String nxt,int depth){		
		int ply_col = 99;				
		int cur_plyr = cur_game.currentTurn();
		System.out.println("Next:"+cur_plyr);
	   	if( cur_game.pieceCount() < 42 ){
	       if(nxt.equals("human-next")){
				int piece_col;
				System.out.println("Enter the next move:");
				Scanner sc =new Scanner(System.in);
				piece_col=sc.nextInt();			
				ply_col= piece_col;
				while(!cur_game.isValid(piece_col))
				{
					System.out.println("Invalid! Try again");
				    System.out.println("Enter the column to put the piece(0-6)");
					Scanner inp =new Scanner(System.in);
					piece_col=inp.nextInt();
				    ply_col = piece_col;
					sc.close();
					inp.close();
				}
				System.out.println("Human:"+cur_plyr);
			}
			if(nxt.equals("computer-next")){
				System.out.println("Computer:"+cur_plyr);
			}		
			cur_game.pieceToPlay(ply_col);	       	
	       	if(nxt.equals("computer-next")){	       
	        	cur_game.outputGBtoFile( "computer.txt" );
			}
	    	else{
	    		cur_game.outputGBtoFile( "human.txt" );	
	    	}
	        System.out.println("move " + cur_game.pieceCount() + ": Player " + cur_plyr + ", column " + ply_col);
	        System.out.print("game state after move:\n");
	        cur_game.printGB();
	        System.out.println( "Score: Player1 = " + cur_game.score( 1 ) + ", Player2 = " + cur_game.score( 2 ) + "\n " );
	        if(cur_game.fullGameBoard()){
	        	System.out.println("--------------------GAME OVER--------------------");
	        	exit_function(0);
	        }
	        if(nxt.equals("computer-next")){
				GameBoard cur= new GameBoard("computer.txt");
		       	nxt="human-next";
		        interactive(cur,nxt,depth);
		    }
	    	else if(nxt.equals("human-next")){
		    	GameBoard cur= new GameBoard("human.txt");
		       	nxt="computer-next";
		       	interactive(cur,nxt,depth);    		
	    	}  
	    }
		  
    }
  public static void main(String[] args) 
  {
    if( args.length != 4 ) 
    {
      System.out.println("Command-line arguments are needed:\n");
      exit_function( 0 );
     }
    String game_mode = args[0].toString();				
    String input = args[1].toString();					
    int depth = Integer.parseInt( args[3] );  	    
    GameBoard cur_game = new GameBoard( input );    
    int ply_col = 99;							
    System.out.print("\nMaxConnect-4 game\n");
    System.out.print("game state before move:\n");    
    cur_game.printGB();    
    System.out.println( "Score: Player 1 = " + cur_game.score( 1 ) +	", Player2 = " + cur_game.score( 2 ) + "\n " );    
    if(game_mode.equalsIgnoreCase( "interactive" ))
	{
	  String nxt = args[2].toString();
      interactive(cur_game,nxt,depth); 
    }    
    else if(game_mode.equalsIgnoreCase( "one-move" )){
	    String output = args[2].toString();				     
	    if( cur_game.pieceCount() < 42 ) 
	    {
	        int cur_plyr = cur_game.currentTurn();		
			cur_game.pieceToPlay( ply_col );	        
	        System.out.println("move " + cur_game.pieceCount()+ ": Player " + cur_plyr + ", column " + ply_col);
	        System.out.print("game state after move:\n");
	        cur_game.printGB();	        
	        System.out.println( "Score: Player1 = " + cur_game.score( 1 ) +", Player2 = " + cur_game.score( 2 ) + "\n " );	        
	        cur_game.outputGBtoFile( output );
	    }
    	else{
			System.out.println("\\nGame Board Full!\n\nGame Over!!");
    	}	    
	}
	else if(!game_mode.equalsIgnoreCase( "one-move" ) && !game_mode.equalsIgnoreCase( "interactive" ) )
	{
      System.out.println( "\nUnrecognized game mode.\nTry again. \n" );
      return;
    } 	   
    return;
	} 	
  
  private static void exit_function( int val )
  {
      System.out.println("Exiting!\n\n");
      System.exit( val );
  }
}