// Prathibha Lakkidi
// UTA ID - 1001962876

public class AiPlayer 
{
    public AiPlayer() 
    {
    }
    public int best(GameBoard cur_game,int depth ){
		int ac=cur_game.alphabeta(cur_game,depth);
		int choice=ac;	
	return choice;
    }
}
