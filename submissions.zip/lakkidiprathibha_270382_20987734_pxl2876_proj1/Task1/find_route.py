# Prathibha Lakkidi
# UTA ID - 1001962876


import sys
from queue import PriorityQueue


def inp(filename):
    val_set = {}
    file = open(filename, 'r')
    data = file.readlines()
    file.close()
    for line in data[:-1]:
        data = line.split()
        if data == 'END OF INPUT':
            return val_set
        else:
            if data[0] in val_set:
                val_set[data[0]][data[1]] = float(data[2])
            else:
                val_set[data[0]] = {data[1]: float(data[2])}
            if data[1] in val_set:
                val_set[data[1]][data[0]] = float(data[2])
            else:
                val_set[data[1]] = {data[0]: float(data[2])}
    return val_set


def inp_heuristic(filename):
    value = {}
    file = open(filename, 'r')
    data = file.readlines()
    file.close()
    for line in data[:-1]:
        data = line.split()
        if data == 'END OF INPUT':
            return value
        else:
            value[data[0]] = float(data[1])
    return value


def uninformed_search(snode, gnode, val_set):
    popped = 1
    expanded = 0
    arr = PriorityQueue()
    arr.put((0, snode))
    visited = {snode: ("", 0)}
    ordered = []
    max = 0
    while not arr.empty():
        if len(arr.queue) > max:
            max = len(arr.queue)
        _, node_p = arr.get()
        expanded += 1
        if node_p == gnode:
            break
        if node_p in ordered:
            continue
        ordered.append(node_p)
        for i in val_set[node_p]:
            popped += 1
            arr.put((val_set[node_p][i]+visited[node_p][1], i))
            if i not in visited:
                visited[i] = (node_p, val_set[node_p][i]+visited[node_p][1])
    route = []
    distance = "infinity"
    if gnode in visited:
        distance = 0.0
        node_p = gnode
        while node_p != snode:
            distance += val_set[visited[node_p][0]][node_p]
            route.append(node_p)
            node_p = visited[node_p][0]
    return route, expanded, popped, distance, max


def informed_search(snode, gnode, val_set, value):
    popped = 1
    expanded = 0
    arr = PriorityQueue()
    arr.put((0, snode))
    visited = {snode: ("", 0)}
    ordered = []
    max = 0
    while not arr.empty():
        if len(arr.queue) > max:
            max = len(arr.queue)
        _, node = arr.get()
        expanded += 1
        if node == gnode:
            break
        if node in ordered:
            continue
        ordered.append(node)
        for i in val_set[node]:
            popped += 1
            if i not in visited:
                visited[i] = (node, val_set[node][i] + visited[node][1])
            arr.put((val_set[node][i] + visited[node][1] + value[i], i))
    route = []
    distance = "infinity"
    if gnode in visited:
        distance = 0.0
        node = gnode
        while node != snode:
            distance += val_set[visited[node][0]][node]
            route.append(node)
            node = visited[node][0]
    return route, expanded, popped, \
           distance, max

if len(sys.argv) == 4:
    file_name = sys.argv[1]
    source = sys.argv[2]
    destination = sys.argv[3]
    val_set = inp(file_name)
    route, expanded, popped, distance, max = uninformed_search(source, destination, val_set)
    print("Nodes Popped: {}".format(expanded))
    print("Nodes popped: {}".format(popped))
    print("Distance: {} km".format(distance))
    print("Route:")
    node_p = source
    if len(route) == 0:
        print("None")
    else:
        for path in route[::-1]:
            print("{} to {}, {} km".format(node_p, path, val_set[node_p][path]))
            node_p = path
elif len(sys.argv) == 5:
    file_name = sys.argv[1]
    source = sys.argv[2]
    destination = sys.argv[3]
    fname_h = sys.argv[4]
    val_set = inp(file_name)
    value = inp_heuristic(fname_h)
    route, expanded, popped, distance, max = informed_search(source, destination, val_set, value)
    print("Nodes Popped: {}".format(expanded))
    print("Nodes popped: {}".format(popped))
    print("Distance: {} km".format(distance))
    print("Route:")
    node_p = source
    if len(route) == 0:
        print("None")
    else:
        for path in route[::-1]:
            print("{} to {}, {} km".format(node_p, path, val_set[node_p][path]))
            node_p = path