Name - Prathibha Lakkidi

UTA ID - 1001962876

Programming Language used: Python

Code Structure : The code is organized as two main functions
			-uninformed_search - (if there is no heuristic to be considered)
			-informed_search - (if the heuristic is to be considered)

			Two other functions are defined to read the input file and find the route.

How to run the code: 	

Run code using:  

Uninformed search:
py find_route.py input1.txt origin_city destination_city
Example:
py find_route.py input1.txt Bremen Kassel


Informed search:
py find_route.py input1.txt origin_city destination_city h_kassel.txt
Example:
py find_route.py input1.txt Bremen Kassel h_kassel.txt

