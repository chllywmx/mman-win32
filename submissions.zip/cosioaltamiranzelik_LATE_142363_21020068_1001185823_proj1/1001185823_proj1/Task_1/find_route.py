# 
# Part 1 of Assignment 1
# Shortest path program for a given graph 
#

import sys


class Node: 
    def __init__(self, CityName, PrevCity, DistTravel, Depthlvl, HCheck, HValue):
        self.CityName = CityName
        self.PrevCity = PrevCity
        self.DistTravel = DistTravel
        self.Depthlvl = Depthlvl
        self.HCheck = HCheck 
        self.HValue = HValue
    

def main(argv):
    
    # Make sure we have enough command-line arguments
    if len(argv) < 4 :
        print ('\nAt least Three command-line arguments are needed to run program:')
        print('for Uninformed Search : %s [input_filename] [origin_city] [destination_city]' % argv[0])
        print('for Informed Search :  %s [input_filename] [origin_city] [destination_city] [heuristic_filename] \n' % argv[0])
        sys.exit(2)
   
    # If heuristic file is being used
    if len(argv) == 5 : 
        print(' Performing Informed Search. ')
        HeurFile = argv[4]
        informed = True 
    else : 
        print(' Performing Uninformed Search. ')
        informed = False 

    # Assign input file, origin city, and Destination city to variables 
    inFile = argv[1] 
    Origin = argv[2]
    Destin = argv[3]

    # try and open file 
    try:
        MapFile = open(inFile, 'r')
    except IOError:
        sys.exit("\nError opening Map input file.\nCheck file name.\n")

## Creating data base of cities
# Data is {Origin: [[Destination, Distance],[Destination_2, Distance_2],..]}
    MapData = {}
    for fileLine in MapFile: 
        fileLine = fileLine.rstrip('\n')    # to remove NL and CR 
        fileLine = fileLine.rstrip('\r')    
        if not fileLine == 'END OF INPUT':
            data = fileLine.split(' ')
                # Checks duplicates and adds multiple destinations from a single city 
            if not data[0] in MapData:
                MapData[data[0]] = [[data[1], int(data[2])]]
            else :
                MapData[data[0]].append([data[1], int(data[2])])    
                
                # Makes sure that MapData points in both directions 
            if not data[1] in MapData:
                MapData[data[1]] = [[data[0], int(data[2])]]
            else : 
                MapData[data[1]].append([data[0], int(data[2])])
        else : 
            break
    MapFile.close()
    # end of Creating city database    

## if needed, Creates Heuristics database for INformed search 
#   Data is {City : Distance}
    HeurData = {}
    if informed: 
        try:
            HFile = open(HeurFile, 'r')
        except IOError:
            sys.exit("\nError opening input file.\nCheck file name.\n")
        
        for fileLine in HFile:
            fileLine = fileLine.rstrip('\n')    # to remove NL and CR 
            fileLine = fileLine.rstrip('\r')
            if not fileLine == 'END OF INPUT':
                data = fileLine.split(' ')
                HeurData[data[0]] = int(data[1])
            else : 
                break
        HFile.close()
    
    # end of Creating Heuristics database

# ready to start searching but need variables to keep track of...  
    Expand = 0      # Expanded Nodes
    Generate = 0    # Generated Nodes
    Popped = 0      # Popped Nodes 
    Visited_Nodes = []  # Visited Nodes/ Closed set
    Fringe = []     #  the Fringe to keep track of the nodes 
    
    
# Determines Whether to include Heuristic value 
#    Syntax of Node: (CityName, PrevCity, DistTravel, Depthlvl, HCheck, HValue)
    if informed: 
        FirstN = Node(Origin, None, 0, 0, informed, HeurData[Origin])
    else: 
        FirstN = Node(Origin, None, 0, 0, informed, 0)
    Fringe.append(FirstN)
    
# If the goal has not been met, and As long as the Fringe is full, keep going
    while len(Fringe) > 0 :
        CurrNode = Fringe.pop(0)    # pops node
        Popped = 1 + Popped       # increments popped counter
         
            # checks if at goal and prints data 
        if CurrNode.CityName == Destin:    
            Total = CurrNode.DistTravel
            Route = []                  # to Create route to print 
            while CurrNode is not None:
                Prev = CurrNode.PrevCity
                if Prev is not None:
                    Distance = abs(Prev.DistTravel - CurrNode.DistTravel)
                    Route.append(Prev.CityName + ' to ' + CurrNode.CityName+ ', ' + str(Distance) + ' km')
                CurrNode = Prev            
            Route.reverse()             # Reverse list as it goes from Destination to Origin
           
            print('\n You have arrived at your Destination of ' + Destin)
            print(' Nodes Popped: ' + str(Popped))
            print(' Nodes Expanded: ' + str(Expand))
            print(' Nodes Generated: ' + str(Generate))
            print(' Distance: ' + str(Total) + ' km') 
            print(' Route: ')
            for i in Route: print (i)
            sys.exit()      # Goal was achieved, now to exit 
            
        else: 
                #check if current node is in closed set, else add and generate successors 
            if not CurrNode.CityName in Visited_Nodes:  
                Visited_Nodes.append(CurrNode.CityName)     # Added current Node to Visited/Closed Set 
                Expand = 1 + Expand                         # Increment Expanded count 
                CityOptions = MapData[CurrNode.CityName]    # Get the list of possible travel cities. 
                    
                for i in CityOptions:                           # Genterating the Successors list 
                    TotalDist = CurrNode.DistTravel + i[1]      # increases travel distance 
                    if CurrNode.HCheck:                         # checks for Heursitic value 
                        NewNode = Node(i[0], CurrNode, TotalDist, CurrNode.Depthlvl + 1, informed, TotalDist + HeurData[i[0]])
                    else: 
                        NewNode = Node(i[0], CurrNode, TotalDist, CurrNode.Depthlvl + 1, informed, 0)
                    Generate = Generate + 1             # New successor node generated and incremeneted Generate
                    Fringe.append(NewNode)
                
                # This will sort the Fringe based on Informed or Uninformed Search
                if informed:           
                    index = 0
                    while index + 1 < len(Fringe):
                        if Fringe[index].HValue > Fringe[index + 1].HValue :
                            N = Fringe.pop(index)
                            Fringe.append(N)
                        else:
                            index = index + 1
                else: 
                    index = 0
                    while index + 1 < len(Fringe):
                        if Fringe[index].DistTravel > Fringe[index + 1].DistTravel :
                            N = Fringe.pop(index)
                            Fringe.append(N)
                        else:
                            index = index + 1
                    
        # Only runs if while loop ends, meaning Failure 
    print('\nWelcome to the end of the fringe. We have done a search and did not find a connection to the destination.')
    print(' Nodes Popped: ' + str(Popped))
    print(' Nodes Expanded: ' + str(Expand))
    print(' Nodes Generated: ' + str(Generate))
    print(' Distance: Uncalculateable \n Route: Not Found' )
    
if __name__ == '__main__':
    main(sys.argv)
