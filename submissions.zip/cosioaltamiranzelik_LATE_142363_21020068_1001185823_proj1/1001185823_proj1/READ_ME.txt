ReadMe file. 

Zelik Cosio-Altamirano,  UTA ID: 100185823 
I used the Python programming language, version 3.10.5 and I did not test the code on Omega.

	Task 1 - code to run: find_route.py
For the First part of the assignment, All the code runs sequentially and there are few 
 functions to scroll too. I didn't think it was necessary to create multiple functions so
 all the instructions are in order. 

	Task 2 - code to run: maxconnect4.py
For the Second part, I was not able to accomplish as much as I would have liked due to 
 starting late. I believe I got the Interactive part of the code working perfectly, as 
 it should do everything the game would expect, limits on choices and reminding of boundaries. 
 The AI is short and sweet and will probabaly fail but Thank you for your time on this project. 

The code does not need anything special done to be run, as it can be run in the Powershell terminal 
 of Windows. You can check the latest version of python you have with command (python --version)
 and the code just needs to be run as stated in the assignment with everything in the same directory. 
 Also, Both of my programs will Let You Know if you put in the command line arguments in incorrectly. 
 Showing an example of the correct implimentation. 

