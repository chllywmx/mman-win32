# ID: 1002029995
# Name: Yaswanth
# Part 1, Programming Mini-Project 1

class nodeObject:
    def __init__(self, parent, city, g, d, f, uninformed):
        self.parent = parent
        self.city = city
        self.g = g 
        self.d = d
        self.f = f 
        self.uninformed = uninformed


def expandNode(node, map, heuristic, SearchType):
    actions = map[node.city]
    next_nodes = []
    for i in actions:
        cost = node.g + i[1]
        if node.uninformed:
            next_nodes.append(nodeObject(node, i[0], cost, node.d + 1, 0, node.uninformed))
        else:
            next_nodes.append(nodeObject(node, i[0], cost, node.d + 1, cost + heuristic[i[0]], node.uninformed))
    return next_nodes

def backtrace(node, map, SearchType):
    route = []
    distance = node.g
    while node is not None:
        _parent = node.parent
        if _parent is not None:
            steps = (s for s in map[_parent.city] if s[0] == node.city)
            s = next(steps)
            route.append(_parent.city + " to " + node.city + ", " + str(s[1]) + " km")
        node = _parent
    route.reverse()
    print("distance: " + str(distance) + " km")
    print("route:")
    for segment in route:
        print(segment)