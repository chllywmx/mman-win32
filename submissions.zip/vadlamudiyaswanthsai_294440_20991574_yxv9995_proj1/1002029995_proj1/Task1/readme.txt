ID: 1002029995
Name: Yaswanth
Programming Language : Python



Running the code:
If using heuristic file, use the following commands.

        python find_route.py (name of input_file.txt) (start city) (end city) (heuristic_file.txt)
        Example:
        python find_route.py input1.txt Bremen Kassel h_kassel.txt

If using only input without heuristic file, use the following commands.

        python find_route.py (name of input_file.txt) (start city) (end city)
        Example:
        python find_route.py input1.txt London Kassel
