# ID: 1002029995
# Name: Yaswanth
# Part 1, Programming Mini-Project 1

import sys           
import operator      
import fringe as fr  


def readInput(fname):
    filedata = open(fname, 'r')
    _input = {}

    for route in filedata:
        route = route.lstrip()
        route = route.rstrip()
        if route != 'END OF INPUT':
            city_segment = route.split(' ')
            city_segment[2] = float(city_segment[2])
            if city_segment[0] in _input:
                _input[city_segment[0]].append( [city_segment[1], city_segment[2]] )
            else:
                _input[city_segment[0]] = [[city_segment[1], city_segment[2]]]
            if city_segment[1] in _input:
                _input[city_segment[1]].append( [city_segment[0], city_segment[2]] )
            else:
                _input[city_segment[1]] = [[city_segment[0], city_segment[2]]]
        else:
            return _input


def readHeuristic(fname):
    filedata = open(fname, 'r')
    heuristic = {}

    for h in filedata:
        h = h.lstrip()
        h = h.rstrip()
        if h != 'END OF INPUT':
            data = h.split(' ')
            data[1] = float(data[1])
            heuristic[data[0]] = data[1]
        else:
            return heuristic


def main():
    
    #checking which search is to be performed
    if len(sys.argv) == 5:
        uninformed = False 
    else:
        uninformed = True   

   #checking file input
    if len(sys.argv) != 1:
       map = readInput(sys.argv[1])
    else:
        print("No input file present")   
        sys.exit()

   
    nodesExpanded  = 0   
    nodesPopped = 0   
    nodesGenerated = 0  
    heuristic = {}

    if not uninformed:
        heuristic = readHeuristic(sys.argv[4])

    fringe = []

    if uninformed:
        fringe.append(fr.nodeObject(None, sys.argv[2], 0, 0, 0, uninformed))
        nodesGenerated += 1
    else:
        fringe.append(fr.nodeObject(None, sys.argv[2], 0, 0, heuristic[sys.argv[2]], uninformed))
        nodesGenerated += 1 

    closed = []
    
   
    while len(fringe) > 0:
        #nodesExpanded += 1

        node = fringe.pop(0)
        nodesPopped=nodesPopped+1

       
        if node.city != sys.argv[3]:
            if node.city not in closed:
                closed.append(node.city)
                next_node = fr.expandNode(node, map, heuristic, nodesExpanded)
                nodesExpanded += 1

                for i in next_node:
                    fringe.append(i)
                nodesGenerated += len(next_node)

                if uninformed:
                    fringe = sorted(fringe, key=operator.attrgetter('g'))
                else:
                    fringe = sorted(fringe, key=operator.attrgetter('f'))

        else:
            print("nodes popped: " + str(nodesPopped))
            print("nodes expanded: "  + str(nodesExpanded))
            print("nodes generated: " + str(nodesGenerated))
            fr.backtrace(node, map, nodesExpanded)
            sys.exit() 
 
    else:
        print("nodes popped: " + str(nodesPopped))
        print("nodes expanded: "  + str(nodesExpanded))
        print("nodes generated: " + str(nodesGenerated))
        print("distance: infinity")
        print("route: \nnone")


main()
