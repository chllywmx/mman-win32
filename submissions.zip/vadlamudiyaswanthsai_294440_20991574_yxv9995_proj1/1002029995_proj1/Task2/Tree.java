import java.util.ArrayList;

public class Tree {
	//class fields
	public GameBoard present_grid;
	public int max_intensity;
	public int present_col; // current column in the grid
	public int value;
	public ArrayList<Tree> next_nodes;
	
	//constructor
	public Tree(GameBoard game, int depth, int col) {
		present_grid = game;
		max_intensity = depth;
		present_col = col;
	}
	
	public ArrayList<Tree> get_children_nodes() {
		ArrayList<Tree> parents = new ArrayList<Tree>();
		for(int col = 0; col < GameBoard.number_of_columns; col++) {
			if(present_grid.is_move_possible(col)) {
				GameBoard t = new GameBoard(present_grid);
				t.playTurn(col);
				parents.add(new Tree(t, max_intensity+1, col));
			}
		}
		
		return parents;
	}
}
