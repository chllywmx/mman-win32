// ID: 1002029995
//Name: Yaswanth
//Part 2, Programming Mini-Project 1

public class AIPlayer {
	//class member variables
	public int curent_player_id;
	public int intensity_limit;
	
	// constructors
	public AIPlayer(){
		//default constructor
	}
	public AIPlayer(int play, int inten) {
		curent_player_id = play;
		intensity_limit = inten;
	}
	public int find_optimize_play(GameBoard board) {
		if(intensity_limit == 0) { 
			for(int c = 0; c < GameBoard.number_of_columns; c++)
			{
				if(board.is_move_possible(c)) {
					return c;
				}
			}
		}
		
		Tree tree = new Tree(board, 0, -1);
		int bestValue = calc_greatest(tree, -999999, 999999);
		for(Tree next : tree.next_nodes ) {
			if(next.value == bestValue)
			{
				return next.present_col;
			}
		}
		
		return -1;
	}
	
	private int calc_greatest(Tree tree, int first, int second) {
		if(tree.present_grid.isGameOver() || tree.max_intensity == intensity_limit) {
			tree.value = tree.present_grid.calculatePossibiliy(curent_player_id);
			return tree.value;
		}
		
		int value = -999999;
		tree.next_nodes = tree.get_children_nodes();
		for(Tree next : tree.next_nodes) {
			value = Math.max(value, calc_least(next, first, second));
			if(value >= second) {
				tree.value = value;
				return value;
			}
			
			first = Math.max(first, value);
		}
		tree.value = value;
		return value;
	}
	
	private int calc_least(Tree tree, int first, int second) {
		if(tree.present_grid.isGameOver() || tree.max_intensity == intensity_limit) {
			tree.value = tree.present_grid.calculatePossibiliy(curent_player_id);
			return tree.value;
		}
		
		int value = 999999;
		tree.next_nodes = tree.get_children_nodes();
		for(Tree next : tree.next_nodes) {
			value = Math.min(value, calc_greatest(next, first, second));
			if(value <= first) {
				tree.value = value;
				return value;
			}
			
			second = Math.min(second, value);
		}
		
		tree.value = value;
		return value;
	}
}
