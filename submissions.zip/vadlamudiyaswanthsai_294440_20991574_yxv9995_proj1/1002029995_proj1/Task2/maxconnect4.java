import java.util.Scanner;

public class maxconnect4 {
	public static void main(String[] args) {
		try {
			//check for correct number of parameters
			if(args.length != 4) {
				System.out.println("Four command-line arguments are needed:\n"
									+"Usage: java [program name] interactive [input_file] [computer-next / human-next] [depth]\n"
									+ " or:  java [program name] one-move [input_file] [output_file] [depth]\n");
									ending_func( 0 );
			}
			
			//Process arguments
			String grid_mode = args[0].toString(); //specifies interactive or one-move mode
			String game_file_input = args[1].toString(); //name of input game file
			int intensity_level = Integer.parseInt(args[3]); //depth level of AI depth-limited search
			 	
			//Create game board and AI Player
			GameBoard present_player_grid = new GameBoard(game_file_input);
			
			//Play specified mode 
			if(grid_mode.equalsIgnoreCase("interactive")) {
				String Player_one = args[2].toString();
				Interactive_player_func(present_player_grid, Player_one, intensity_level);
			} else if(grid_mode.equalsIgnoreCase("one-move")) {
				String output_F = args[2].toString();
				oneMove_game_func(present_player_grid, output_F, intensity_level);
			} else {
				System.out.println("ERROR: '" + grid_mode + "' is an unsupported game mode! Try agautomaticn.");
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	private static void Interactive_player_func(GameBoard present_player_grid, String Player_one, int intensity_level) throws Exception {
		int no; //values on board are either 1 or 2. based on input file and program arguments, player's value will either be 1 or 2
		if(Player_one.equalsIgnoreCase("human-next")) {
			no = present_player_grid.getCurrentTurn();
		} else {
			no = GameBoard.addition_of_player_turns - present_player_grid.getCurrentTurn(); 
		}
		
		AIPlayer automatic = new AIPlayer(GameBoard.addition_of_player_turns - no, intensity_level);
		
		Scanner sc = new Scanner(System.in);
		while(!present_player_grid.isGameOver()) {
			if(present_player_grid.getCurrentTurn() == no) {
				present_player_grid.print_board();
				System.out.print("Enter column to play (" + present_player_grid.numberToString(no) + "): ");
				try {
					int co = Integer.parseInt(sc.next());
					if(present_player_grid.is_move_possible(co)) {
						present_player_grid.playTurn(co);
						present_player_grid.save_current_grid("human.txt");
					} else {
						System.out.println("\n***ERROR: Invalid move!***");
					}
				} catch(Exception e) {
					System.out.println("\n***ERROR: " + e.getMessage() + "***");
				}
			} else {
				present_player_grid.print_board();
				present_player_grid.playTurn(automatic.find_optimize_play(present_player_grid));
				present_player_grid.save_current_grid("computer.txt");
			}
		}
		
		present_player_grid.print_board();
		System.out.println("The game is over.");
		sc.close();
	}
	
	private static void oneMove_game_func(GameBoard present_player_grid, String out, int limit_depth) throws Exception {
		present_player_grid.print_board();
		if(!present_player_grid.isGameOver()) {
			AIPlayer automatic = new AIPlayer(present_player_grid.getCurrentTurn(), limit_depth);
			present_player_grid.playTurn(automatic.find_optimize_play(present_player_grid));
			present_player_grid.print_board();
		}
		
		present_player_grid.save_current_grid(out);
	}

   private static void ending_func( int value )
   {
	   System.out.println("exiting from MaxConnectFour.java!\n\n");
	   System.exit( value );
   }
  // end of class connectFour
}
