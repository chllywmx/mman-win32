ID: 1002029995
Name: Yaswanth
Part 2, Programming Mini-Project 1

Programming Language : Java

Code structure:
1: AIPlayer.java: 
    to store information about any player
2: maxconnect4.java: 
    to take input and give output
3: GameBoard.java: 
    to store allsteps of game and advancing boards.
4: Info.java: 
    to store all boards, current and next.

Command to runcode: 
javac maxconnect4.java
java maxconnect4 one-move input1.txt output.txt 3