import java.io.*;
import java.util.ArrayList;
import java.util.Collections;


public class GameBoard implements Cloneable {
	//Board dimensions
	public static final int number_of_rows = 6;
	public static final int number_of_columns = 7;
	public static final int addition_of_player_turns = 3; 
	
	//Class fields
	private int[][] GAME_current_grid;
	private int player_current_turn;
	private int Pieces_Number_Count;
	
	//Constructor
	public GameBoard(String myFile) throws Exception {
		GAME_current_grid = new int[number_of_rows][number_of_columns];
		Pieces_Number_Count = 0;
		BufferedReader bufferFile=null;
		
		try {
			//Open bufferFile 
			bufferFile = new BufferedReader(new FileReader(myFile));
			
			//Read game data
			ArrayList<String> append_data = new ArrayList<String>();
			String grid_data = null;
			while((grid_data = bufferFile.readLine()) != null) { 
				append_data.add(grid_data); 
			}
			bufferFile.close();
			
			//Set GAME_current_grid items
			for(int i = 0; i < number_of_rows; i++) {
				String string_line = append_data.get(i);
				
				for(int j= 0; j< number_of_columns; j++) {
					int x = Character.getNumericValue(string_line.charAt(j));
					
					if(x == 0 || x == 1 || x ==2) {
						GAME_current_grid[i][j] = x;
					} else {
						throw new Exception("Invalid value at block [" + i + ", " + j+ "].\n");
					}
					
					if(x != 0) {
						Pieces_Number_Count++;
					}
				}
			}
			
			//Get whose turn it is (last line in data)
			player_current_turn = Integer.parseInt(append_data.get(append_data.size() - 1));
			if(player_current_turn != 1 && player_current_turn != 2) { 
				throw new Exception("Invalid turn value at block.\n"); 
			}
		} catch(Exception e) { 
			player_current_turn = 1;
		}
	}
	
	public GameBoard(GameBoard otherGame) {
		player_current_turn = otherGame.player_current_turn;
		Pieces_Number_Count = otherGame.Pieces_Number_Count;
		GAME_current_grid = new int[number_of_rows][number_of_columns];
		
		//copy GAME_current_grid
		for(int r = 0; r < number_of_rows; r++) {
			for(int j= 0; j< number_of_columns; j++)
			{
				this.GAME_current_grid[r][j] = otherGame.GAME_current_grid[r][j];
			}
		}
	}
	
	public int compute_player_score(int player) {
		int rate = 0;
		
		for(int r = 0; r < number_of_rows; r++) {
			for(int j= 0; j< number_of_columns; j++) {
				//check horizontal (3 spaces to right of current space)
				if(j+ 3 < number_of_columns) {
					if(GAME_current_grid[r][j] == player && GAME_current_grid[r][j+1] == player && GAME_current_grid[r][j+2] == player && GAME_current_grid[r][j+3] == player) {
						rate++;
					}
				}
				
				//check vertical (3 spaces down of current space)
				if(r + 3 < number_of_rows) {
					if(GAME_current_grid[r][j] == player && GAME_current_grid[r+1][j] == player && GAME_current_grid[r+2][j] == player && GAME_current_grid[r+3][j] == player) {
						rate++;
					}
				}
				//check diagonal / (3 spaces down and to left of current space)
				if(r + 3 < number_of_rows && j- 3 >= 0) {
					if(GAME_current_grid[r][j] == player && GAME_current_grid[r + 1][j- 1] == player && GAME_current_grid[r + 2][j- 2] == player && GAME_current_grid[r + 3][j- 3] == player) {
						rate++;
					}
				}
				
				//check diagonal \ (3 spaces down and to right of current space)
				if(r + 3 < number_of_rows && j+ 3 < number_of_columns) {
					if(GAME_current_grid[r][j] == player && GAME_current_grid[r + 1][j+ 1] == player && GAME_current_grid[r + 2][j+ 2] == player && GAME_current_grid[r + 3][j+ 3] == player) {
						rate++;
					}
				}
			}
		}
		
		return rate;
	}
	
	//accounts for completed connect 4s as well as "connect" 1s, 2s, and 3s that have potential to be a connect 4 
	public int calculatePossibiliy(int playerNumber) {
		int useful = 0;
		int enemyPosition = addition_of_player_turns - playerNumber; //only options are 1 or 2; if turn is 1, 3 - 1 = 2 and if turn is 2, 3 - 2 = 1
		
		for(int r = 0; r < number_of_rows; r++) {
			for(int j= 0; j< number_of_columns; j++) {
				ArrayList<Integer> items = new ArrayList<Integer>();
				
				//-----check horizontal (3 spaces to right of current space)------
				if(j+ 3 < number_of_columns) {
					items.add(GAME_current_grid[r][j]);
					items.add(GAME_current_grid[r][j+1]);
					items.add(GAME_current_grid[r][j+2]);
					items.add(GAME_current_grid[r][j+3]);
					
					useful = update_possibility(useful, items, playerNumber, enemyPosition);
				}
				
				//check vertical (3 spaces down of current space)
				if(r + 3 < number_of_rows) {
					items.clear();
					items.add(GAME_current_grid[r][j]);
					items.add(GAME_current_grid[r+1][j]);
					items.add(GAME_current_grid[r+2][j]);
					items.add(GAME_current_grid[r+3][j]);
					
					useful = update_possibility(useful, items, playerNumber, enemyPosition);
				}
				//check diagonal / (3 spaces down and to left of current space)
				if(r + 3 < number_of_rows && j- 3 >= 0) {
					items.clear();
					items.add(GAME_current_grid[r][j]);
					items.add(GAME_current_grid[r+1][j-1]);
					items.add(GAME_current_grid[r+2][j-2]);
					items.add(GAME_current_grid[r+3][j-3]);
					
					useful = update_possibility(useful, items, playerNumber, enemyPosition);
				}
				
				//check diagonal \ (3 spaces down and to right of current space)
				if(r + 3 < number_of_rows && j + 3 < number_of_columns) {
					items.clear();
					items.add(GAME_current_grid[r][j]);
					items.add(GAME_current_grid[r+1][j+1]);
					items.add(GAME_current_grid[r+2][j+2]);
					items.add(GAME_current_grid[r+3][j+3]);
				
					useful = update_possibility(useful, items, playerNumber, enemyPosition);
				}
			}	
		}
		return useful;
	}
	
	private int update_possibility(int useful, ArrayList<Integer> items, int playerNumber, int enemyPosition) {
		if(!items.contains(enemyPosition)) //if only contains player chips or empty space, contains connect 4 or possible connect 4
		{
			int count = Collections.frequency(items, playerNumber);
			switch(count) {
			case 1:
				useful += 1;
				break;
			case 2:
				useful += 10;
				break;
			case 3:
				useful += 25;
				break;
			case 4:
				useful += 100;
				break;
			}
		} else if(!items.contains(playerNumber)) { //if only contains enemy chips or empty space, contains connect 4 or possible connect 4
			int count = Collections.frequency(items, enemyPosition);
			switch(count) {
			case 1:
				useful -= 1;
				break;
			case 2:
				useful -= 10;
				break;
			case 3:
				useful -= 25;
				break;
			case 4:
				useful -= 100;
				break;
			}
		}
		
		return useful;
	}
	
	public int getCurrentTurn() {
		return player_current_turn;
	}
	
	public int getNumPieces() {
		return Pieces_Number_Count;
	}
	
	public int[][] getBoard() {
		return GAME_current_grid;
	}
	
	public boolean is_move_possible(int column) {
		//return true if column if within bounds and column is not full (top space of column is empty)
		return ((0 <= column && column < number_of_columns) && GAME_current_grid[0][column] == 0);
	}
	
	public void playTurn(int j) {
		for(int r = number_of_rows - 1; r >= 0; r--) {
			if(GAME_current_grid[r][j] == 0) {
				GAME_current_grid[r][j] = player_current_turn;
				Pieces_Number_Count++;
				whose_next_player();
				break;
			}
		}
	}
	
	public void print_board() {
		//print divider line
		System.out.println("_________________________");
		//print first line with column indicator numbers
		String emptyString = "";
		for(int y = 0; y < number_of_columns; y++) {
			emptyString += " " + String.valueOf(y); 
		} 
		System.out.println(emptyString);
		
		//print GAME_current_grid
		for(int[] i : GAME_current_grid) {
			String line = "|";
			for(int num : i) {
				line += numberToString(num);
				line += "|";
			}
			
			System.out.println(line);
		}
		
		//print rates
		System.out.println(numberToString(1) + " Score: " + String.valueOf(compute_player_score(1)));
		System.out.println(numberToString(2) + " Score: " + String.valueOf(compute_player_score(2)));
	}
	
	public void save_current_grid(String file) throws Exception {
		//open output file
		BufferedWriter output = new BufferedWriter(new FileWriter(file));
		
		//save GAME_current_grid
		for(int[] i : GAME_current_grid) {
			for(int n : i) {
				output.write(String.valueOf(n));
			}
			output.newLine();
		}
		
		//save next turn
		output.write(String.valueOf(player_current_turn));
		
		//close output file
		output.close();
	}
	
	public boolean isGameOver() {
		return (getNumPieces() == number_of_rows * number_of_columns);
	}
	
	public String numberToString(int turn) {
		String result;
		switch(turn) {
		case 0: //blank space for empty space
			result = "-";
			break;
		case 1:
			result = "X";
			break;
		case 2:
			result = "O";
			break;
		default:
			result = "e"; //e for error
		}
		
		return result;
	}
	
	private void whose_next_player() {
		if(player_current_turn == 1) {
			player_current_turn = 2;
		} else {
			player_current_turn = 1;
		}
	}
}
