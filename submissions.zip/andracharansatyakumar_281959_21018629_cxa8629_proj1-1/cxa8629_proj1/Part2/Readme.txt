Name: charan satya kumar andra
UTA ID: 1002008629
Programming Language: Python
-----------------------------------
Structure of the code: 
It has Maxconnect4game.py, Playmodes.py and Scorecalculator.py

In playmode.py, It has the two mode; one-move mode and interactive mode. It calls the functions in the other py file MaxConnect4Game.py
In scorecalculator.py, implemented will calculate the score of the board using scorecount function.
In Maxconnect4game.py has minmax, alpha beta, beta aplha and evaluation functions.
----------------------------------------
To execute this program:

Interactive Mode: 

python PlayModes.py interactive inputfile.txt computer-next/human-next depth_level

One-move Mode: 

python PlayModes.py one-move inputfile.txt outputfile.txt depth_level

