'''

MaxConnect4Game.py has minmax, alpha beta, beta aplha and evaluation functions
'''
import copy # deepcopy is used to copy the objects
import random
# importing all sys file
from ScoreCalculator import ScoreCalculator
utilityVal = {}     # storing the utility val
infinity = float('inf')     # defining a infinite val

class MaxConnect4game:
    def __init__(self):  # intializing the function
        self.GameBoard = [[0 for i in range(7)] for j in range(6)]
        self.currentMove = 0
        self.pieceCount = 0
        self.player1Score = 0
        self.player2Score = 0
        self.gameFile = None
        self.computerColumn = None
        self.depth = 1

    def checkPieceCount(self):  # checks whether number of piece already played
        self.pieceCount = sum(1 for row in self.GameBoard for piece in row if piece)

    def getPieceCount(self):    # returns the occupied pieces on the borad
        return sum(1 for row in self.GameBoard for piece in row if piece)

    def displayGB(self):    # game board will be displayed through this function
        print(' -----------------')
        for i in range(6):
            print(' |'),
            for j in range(7):
                print('%d' % int(self.GameBoard[i][j])),
            print('| ')
        print(' -----------------')

    def printGameBoardToFile(self): # function prints the game borad to file
        for row in self.GameBoard:
            self.gameFile.write(''.join(str(col) for col in row) + '\r')
        self.gameFile.write('%s\r' % str(self.currentMove))

    def playPiece(self, column):    # function is used to place the current player in the column
        if not self.GameBoard[0][column]:
            for i in range(5, -1, -1):
                if not self.GameBoard[i][column]:
                    self.GameBoard[i][column] = self.currentMove
                    self.pieceCount += 1
                    return 1

    def checkValidity(self, column, opponent):     # function is used to validate piece
        if not self.GameBoard[0][column]:
            for i in range(5, -1, -1):
                if not self.GameBoard[i][column]:
                    self.GameBoard[i][column] = opponent
                    self.pieceCount += 1
                    return 1

    def maximumValue(self, currentNode):  # function is used to restore the state for the maximun value
        node = copy.deepcopy(currentNode)
        childNode = []
        for i in range(7):
            currentState = self.playPiece(i)
            if currentState != None:
                childNode.append(self.GameBoard)
                self.GameBoard = copy.deepcopy(node)
        return childNode

    def minimumValue(self, currentNode):  #  function is used to restore the state for the minimum value
        node = copy.deepcopy(currentNode)
        if self.currentMove == 1:
            opponent = 2
        elif self.currentMove == 2:
            opponent = 1
        childNode = []
        for i in range(7):
            currentState = self.checkValidity(i, opponent)
            if currentState != None:
                childNode.append(self.GameBoard)
                self.GameBoard = copy.deepcopy(node)
        return childNode

    def alphaBeta(self, currentNode, alpha, beta, depth):   # alpha beta puring max value
        value = -infinity
        childNode = self.maximumValue(currentNode)
        if childNode == [] or depth == 0:
            ScoreCalculator.scoreCount(self)
            return self.evalCalc(self.GameBoard)
        else:
            for node in childNode:
                self.GameBoard = copy.deepcopy(node)
                value = max(value, self.betaAlpha(node, alpha, beta, depth - 1))
                if value >= beta:
                    return value
                alpha = max(alpha, value)
            return value

    def minMax(self, depth):    # simple min max algorithm
        currentState = copy.deepcopy(self.GameBoard)
        for i in range(7):
            if self.playPiece(i) != None:
                if self.pieceCount == 42 or self.depth == 0:
                    self.GameBoard = copy.deepcopy(currentState)
                    return i
                else:
                    val = self.betaAlpha(self.GameBoard, -infinity, infinity, depth - 1)
                    utilityVal[i] = val
                    self.GameBoard = copy.deepcopy(currentState)
        maxUtilityVal = max([i for i in utilityVal.values()])
        for i in range(7):
            if i in utilityVal:
                if utilityVal[i] == maxUtilityVal:
                    utilityVal.clear()
                    return i

    def verticalCheck(self, row, column, state, streak):    # vertical piece in the row will be checked
        consecutiveCount = 0
        for i in range(row, 6):
            if state[i][column] == state[row][column]:
                consecutiveCount += 1
            else:
                break
        if consecutiveCount >= streak:
            return 1
        else:
            return 0

    def betaAlpha(self,currentNode, alpha, beta, depth):    # beta alpha puring min value
        value = infinity
        childNode = self.minimumValue(currentNode)
        if childNode == [] or depth == 0:
            ScoreCalculator.scoreCount(self)
            return self.evalCalc(self.GameBoard)
        else:
            for node in childNode:
                self.GameBoard = copy.deepcopy(node)
                value = min(value, self.alphaBeta(node, alpha, beta, depth - 1))
                if value <= alpha:
                    return value
                beta = min(beta, value)
        return value

    def horizontalCheck(self, row, column, state, streak):  # horizontal piece in the column will be checked
        count = 0
        for j in range(column, 7):
            if state[row][j] == state[row][column]:
                count += 1
            else:
                break
        if count >= streak:
            return 1
        else:
            return 0

    def diagonalCheck(self, row, column, state, streak):    # diagonal check in the borad will be checked
        total = 0
        count = 0
        j = column
        for i in range(row, 6):
            if j > 6:
                break
            elif state[i][j] == state[row][column]:
                count += 1
            else:
                break
            j += 1
        if count >= streak:
            total += 1
        count = 0
        j = column
        for i in range(row, -1, -1):
            if j > 6:
                break
            elif state[i][j] == state[row][column]:
                count += 1
            else:
                break
            j += 1
        if count >= streak:
            total += 1
        return total

    def streakCalc(self, state, color, streak):     # which type of connectfour goes will be checked in this function
        count = 0
        for i in range(6):
            for j in range(7):
                if state[i][j] == color:
                    count += self.verticalCheck(i, j, state, streak)
                    count += self.horizontalCheck(i, j, state, streak)
                    count += self.diagonalCheck(i, j, state, streak)
        return count

    def playerEvalCalc(self, state):    # non computer player streak will be calculated
        playerFours = self.streakCalc(state, self.currentMove, 4)
        playerThrees = self.streakCalc(state, self.currentMove, 3)
        playerTwos = self.streakCalc(state, self.currentMove, 2)
        return (playerFours * 37044 + playerThrees * 882 + playerTwos * 21) # permutation for each fours in a row, threes in a row and twos in a row

    def evalFunc(self): # function used to know the next color
        if self.currentMove == 1:
            oneMoveColor = 2
        elif self.currentMove == 2:
            oneMoveColor = 1
        return oneMoveColor

    def compEvalCalc(self, state):  # computer streak will be calculated
        oneMoveColor = self.evalFunc()
        compFours = self.streakCalc(state, oneMoveColor, 4)
        compThrees = self.streakCalc(state, oneMoveColor, 3)
        compTwos = self.streakCalc(state, oneMoveColor, 2)
        return (compFours * 37044 + compThrees * 882 + compTwos * 21)

    def evalCalc(self, state):  #function is used to calucate the difference between computer and  non computer streak count
        return self.playerEvalCalc(state) - self.compEvalCalc(state)

    def changeMove(self):   # function for changing to next player 
        if self.currentMove == 1:
            self.currentMove = 2
        elif self.currentMove == 2:
            self.currentMove = 1

    def computerPlay(self):   # function for computing the computer move
        randomCol = self.minMax(int(self.depth))
        result = self.playPiece(randomCol)
        if not result:
            print('No Result')
        else:
            print('Player: %d, Column: %d\n' % (self.currentMove, randomCol + 1))
            self.changeMove()