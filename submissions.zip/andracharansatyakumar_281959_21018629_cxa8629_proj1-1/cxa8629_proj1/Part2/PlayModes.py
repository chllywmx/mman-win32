'''

Main file. It has the two mode; one-move mode and interactive mode. It calls the functions in the other py file MaxConnect4Game.py
'''
import sys  #used to import all system file
from MaxConnect4game import MaxConnect4game     # used to create object of other file
from ScoreCalculator import ScoreCalculator

def humanPlay(game):       # function is used to take the input and putting the element in it
    while game.getPieceCount() != 42:  # checking whether board is empty
        print(" Human's turn")
        print(" ------- ----")
        UsersMove = int(input("Enter a column number (1-7): "))  # input field to enter column number from 1 to 7
        if not 0 < UsersMove < 8:    # checking if it is valid input or not
            print("Column invalid! Enter Again.")
            continue
        if not game.playPiece(UsersMove - 1):
            print("Column number: %d is full. Try other column." % UsersMove)
            continue
        print("Your made move: " + str(UsersMove))
        game.displayGB()   # will display the game board
        game.gameFile = open("human.txt", 'w')  # will display the txt file
        game.printGameBoardToFile()
        game.gameFile.close()  # function closes the file
        if game.getPieceCount() == 42:     # checks whether the borad is full
            print("No more moves possible, Game Over!")
            #game.scoreCount()  # is used to print score
            ScoreCalculator.scoreCount(game)
            print('Score: PlayerA = %d, PlayerB = %d\n' % (game.player1Score, game.player2Score))
            break
        else:   # computer move
            print("Computer is conputing based on next " + str(game.depth) + " steps...")
            game.changeMove()  # changing player
            game.computerPlay()  # computer to move with the minmax alpha beta puring
            game.displayGB()   # used to display game borad
            game.gameFile = open('computer.txt', 'w')  # printing output to file
            game.printGameBoardToFile()
            game.gameFile.close()  # used to close file
            ScoreCalculator.scoreCount(game)
            print('Score: PlayerA = %d, PlayerB = %d\n' % (game.player1Score, game.player2Score))

def interactiveMode(game, nextPlayer):   # interactive mode function
    print('Current Board state')
    game.displayGB()   # displays game board
    ScoreCalculator.scoreCount(game)
    print('Score: PlayerA = %d, PlayerB = %d\n' % (game.player1Score, game.player2Score))
    if nextPlayer == 'human-next':  # checks the next player from argv
        humanPlay(game)    # human function
    else:
        game.computerPlay()  # computing the computer move
        game.gameFile = open('computer.txt', 'w')  # results will be printed to file
        game.printGameBoardToFile()
        game.gameFile.close()  # closing the file
        game.displayGB()   # displays the game board
        ScoreCalculator.scoreCount(game)
        print('Score: PlayerA = %d, PlayerB = %d\n' % (game.player1Score, game.player2Score))
        humanPlay(game)    # human turn next

    if game.getPieceCount() == 42: # displays the final result after all the piece in the borad are full
        if game.player1Score > game.player2Score:
            print("Player 1 wins")
        if game.player1Score == game.player2Score:
            print("The game is a Tie")
        if game.player1Score < game.player2Score:
            print("Player 2 wins")
        print("Game Over")


def oneMoveMode(game):     # one move mode function
    if game.pieceCount >= 42:  # checks whether all the piece are filled and then exit
        print('Game board is full !\n Game Over...')
        sys.exit(0)
    print ('GameBoard state before move:')
    game.displayGB()   # displays game board
    game.computerPlay()      # Computing the computer move
    print ('GameBoard state after move:')
    game.displayGB()   # displays game board
    ScoreCalculator.scoreCount(game)
    print('Score: PlayerA = %d, PlayerB = %d\n' % (game.player1Score, game.player2Score))
    game.printGameBoardToFile()    # prints the game board into file
    game.gameFile.close()      # close file

def main(argv):
    game = MaxConnect4game()
    try:
        game.gameFile = open(argv[2], 'r')     #used to read input file
        fileLines = game.gameFile.readlines()
        game.GameBoard = [[int(char) for char in line[0:7]] for line in fileLines[0:-1]]
        game.currentMove = int(fileLines[-1][0])
        game.gameFile.close()
    except:
        print('File not found, begin new game.')
        game.currentMove = 1
    game.checkPieceCount()     # checks whether all the elements added is true or not
    game.depth = argv[4]   # depth taken from argv
    if argv[1] == 'one-move':   #used for one move mode play
        try:
            game.gameFile = open(argv[3], 'w')
        except:
            sys.exit('Error while opening output file.')
        oneMoveMode(game)
    else:   # for interactive mode play
        interactiveMode(game, argv[3])

main(sys.argv)
# main function
