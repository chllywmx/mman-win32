'''

Main file. It has score calculator, where it calls the functions in MaxConnect4Game.py
'''
class ScoreCalculator:

    def scoreCount(MaxConnect4game):
        MaxConnect4game.player1Score = 0;
        MaxConnect4game.player2Score = 0;

        # calculating score in horizontal paths.
        for row in MaxConnect4game.GameBoard:
            # Check player 1
            if row[0:4] == [1] * 4:
                MaxConnect4game.player1Score += 1
            if row[1:5] == [1] * 4:
                MaxConnect4game.player1Score += 1
            if row[2:6] == [1] * 4:
                MaxConnect4game.player1Score += 1
            if row[3:7] == [1] * 4:
                MaxConnect4game.player1Score += 1
            # Check player 2
            if row[0:4] == [2] * 4:
                MaxConnect4game.player2Score += 1
            if row[1:5] == [2] * 4:
                MaxConnect4game.player2Score += 1
            if row[2:6] == [2] * 4:
                MaxConnect4game.player2Score += 1
            if row[3:7] == [2] * 4:
                MaxConnect4game.player2Score += 1

        # calculating score in vertical paths
        for j in range(7):
            if (MaxConnect4game.GameBoard[0][j] == MaxConnect4game.GameBoard[1][j] and
                    MaxConnect4game.GameBoard[1][j] == MaxConnect4game.GameBoard[2][j] and
                    MaxConnect4game.GameBoard[2][j] == MaxConnect4game.GameBoard[3][j]):
                if (MaxConnect4game.GameBoard[0][j] == 1) :
                    MaxConnect4game.player1Score += 1
                elif (MaxConnect4game.GameBoard[0][j] == 2) :
                    MaxConnect4game.player2Score += 1

            if (MaxConnect4game.GameBoard[1][j] == MaxConnect4game.GameBoard[2][j] and
                    MaxConnect4game.GameBoard[2][j] == MaxConnect4game.GameBoard[3][j] and
                    MaxConnect4game.GameBoard[3][j] == MaxConnect4game.GameBoard[4][j]):
                if (MaxConnect4game.GameBoard[1][j] == 1) :
                    MaxConnect4game.player1Score += 1
                elif (MaxConnect4game.GameBoard[1][j] == 2) :
                    MaxConnect4game.player2Score += 1

            if (MaxConnect4game.GameBoard[2][j] == MaxConnect4game.GameBoard[3][j] and
                    MaxConnect4game.GameBoard[3][j] == MaxConnect4game.GameBoard[4][j] and
                    MaxConnect4game.GameBoard[4][j] == MaxConnect4game.GameBoard[5][j]):
                if (MaxConnect4game.GameBoard[2][j] == 1) :
                    MaxConnect4game.player1Score += 1
                elif (MaxConnect4game.GameBoard[2][j] == 2) :
                    MaxConnect4game.player2Score += 1


        # calculating score in diagonal paths.
        if (MaxConnect4game.GameBoard[2][0] == MaxConnect4game.GameBoard[3][1] and
                MaxConnect4game.GameBoard[3][1] == MaxConnect4game.GameBoard[4][2] and
                MaxConnect4game.GameBoard[4][2] == MaxConnect4game.GameBoard[5][3]):
            if (MaxConnect4game.GameBoard[2][0] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[2][0] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[1][0] == MaxConnect4game.GameBoard[2][1] and
                MaxConnect4game.GameBoard[2][1] == MaxConnect4game.GameBoard[3][2] and
                MaxConnect4game.GameBoard[3][2] == MaxConnect4game.GameBoard[4][3]):
            if (MaxConnect4game.GameBoard[1][0] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[1][0] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[2][1] == MaxConnect4game.GameBoard[3][2] and
                MaxConnect4game.GameBoard[3][2] == MaxConnect4game.GameBoard[4][3] and
                MaxConnect4game.GameBoard[4][3] == MaxConnect4game.GameBoard[5][4]):
            if (MaxConnect4game.GameBoard[2][1] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[2][1] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[0][0] == MaxConnect4game.GameBoard[1][1] and
                MaxConnect4game.GameBoard[1][1] == MaxConnect4game.GameBoard[2][2] and
                MaxConnect4game.GameBoard[2][2] == MaxConnect4game.GameBoard[3][3]):
            if (MaxConnect4game.GameBoard[0][0] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[0][0] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[1][1] == MaxConnect4game.GameBoard[2][2] and
                MaxConnect4game.GameBoard[2][2] == MaxConnect4game.GameBoard[3][3] and
                MaxConnect4game.GameBoard[3][3] == MaxConnect4game.GameBoard[4][4]):
            if (MaxConnect4game.GameBoard[1][1] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[1][1] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[2][2] == MaxConnect4game.GameBoard[3][3] and
                MaxConnect4game.GameBoard[3][3] == MaxConnect4game.GameBoard[4][4] and
                MaxConnect4game.GameBoard[4][4] == MaxConnect4game.GameBoard[5][5]):
            if (MaxConnect4game.GameBoard[2][2] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[2][2] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[0][1] == MaxConnect4game.GameBoard[1][2] and
                MaxConnect4game.GameBoard[1][2] == MaxConnect4game.GameBoard[2][3] and
                MaxConnect4game.GameBoard[2][3] == MaxConnect4game.GameBoard[3][4]):
            if (MaxConnect4game.GameBoard[0][1] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[0][1] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[1][2] == MaxConnect4game.GameBoard[2][3] and
                MaxConnect4game.GameBoard[2][3] == MaxConnect4game.GameBoard[3][4] and
                MaxConnect4game.GameBoard[3][4] == MaxConnect4game.GameBoard[4][5]):
            if (MaxConnect4game.GameBoard[1][2] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[1][2] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[2][3] == MaxConnect4game.GameBoard[3][4] and
                MaxConnect4game.GameBoard[3][4] == MaxConnect4game.GameBoard[4][5] and
                MaxConnect4game.GameBoard[4][5] == MaxConnect4game.GameBoard[5][6]):
            if (MaxConnect4game.GameBoard[2][3] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[2][3] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[0][2] == MaxConnect4game.GameBoard[1][3] and
                MaxConnect4game.GameBoard[1][3] == MaxConnect4game.GameBoard[2][4] and
                MaxConnect4game.GameBoard[2][4] == MaxConnect4game.GameBoard[3][5]):
            if (MaxConnect4game.GameBoard[2][3] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[2][3] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[1][3] == MaxConnect4game.GameBoard[2][4] and
                MaxConnect4game.GameBoard[2][4] == MaxConnect4game.GameBoard[3][5] and
                MaxConnect4game.GameBoard[3][5] == MaxConnect4game.GameBoard[4][6]):
            if (MaxConnect4game.GameBoard[1][3] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[1][3] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[0][3] == MaxConnect4game.GameBoard[1][4] and
                MaxConnect4game.GameBoard[1][4] == MaxConnect4game.GameBoard[2][5] and
                MaxConnect4game.GameBoard[2][5] == MaxConnect4game.GameBoard[3][6]):
            if (MaxConnect4game.GameBoard[0][3] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[0][3] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[0][4] == MaxConnect4game.GameBoard[1][3] and
                MaxConnect4game.GameBoard[1][3] == MaxConnect4game.GameBoard[2][2] and
                MaxConnect4game.GameBoard[2][2] == MaxConnect4game.GameBoard[3][1]):
            if (MaxConnect4game.GameBoard[0][4] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[0][4] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[1][3] == MaxConnect4game.GameBoard[2][2] and
                MaxConnect4game.GameBoard[2][2] == MaxConnect4game.GameBoard[3][1] and
                MaxConnect4game.GameBoard[3][1] == MaxConnect4game.GameBoard[4][0]):
            if (MaxConnect4game.GameBoard[1][3] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[1][3] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[0][5] == MaxConnect4game.GameBoard[1][4] and
                MaxConnect4game.GameBoard[1][4] == MaxConnect4game.GameBoard[2][3] and
                MaxConnect4game.GameBoard[2][3] == MaxConnect4game.GameBoard[3][2]):
            if (MaxConnect4game.GameBoard[0][5] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[0][5] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[1][4] == MaxConnect4game.GameBoard[2][3] and
                MaxConnect4game.GameBoard[2][3] == MaxConnect4game.GameBoard[3][2] and
                MaxConnect4game.GameBoard[3][2] == MaxConnect4game.GameBoard[4][1]):
            if (MaxConnect4game.GameBoard[1][4] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[1][4] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[2][3] == MaxConnect4game.GameBoard[3][2] and
                MaxConnect4game.GameBoard[3][2] == MaxConnect4game.GameBoard[4][1] and
                MaxConnect4game.GameBoard[4][1] == MaxConnect4game.GameBoard[5][0]):
            if (MaxConnect4game.GameBoard[2][3] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[2][3] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[0][6] == MaxConnect4game.GameBoard[1][5] and
                MaxConnect4game.GameBoard[1][5] == MaxConnect4game.GameBoard[2][4] and
                MaxConnect4game.GameBoard[2][4] == MaxConnect4game.GameBoard[3][3]):
            if (MaxConnect4game.GameBoard[0][6] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[0][6] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[1][5] == MaxConnect4game.GameBoard[2][4] and
                MaxConnect4game.GameBoard[2][4] == MaxConnect4game.GameBoard[3][3] and
                MaxConnect4game.GameBoard[3][3] == MaxConnect4game.GameBoard[4][2]):
            if (MaxConnect4game.GameBoard[1][5] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[1][5] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[2][4] == MaxConnect4game.GameBoard[3][3] and
                MaxConnect4game.GameBoard[3][3] == MaxConnect4game.GameBoard[4][2] and
                MaxConnect4game.GameBoard[4][2] == MaxConnect4game.GameBoard[5][1]):
            if (MaxConnect4game.GameBoard[2][4] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[2][4] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[1][6] == MaxConnect4game.GameBoard[2][5] and
                MaxConnect4game.GameBoard[2][5] == MaxConnect4game.GameBoard[3][4] and
                MaxConnect4game.GameBoard[3][4] == MaxConnect4game.GameBoard[4][3]):
            if (MaxConnect4game.GameBoard[1][6] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[1][6] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[2][5] == MaxConnect4game.GameBoard[3][4] and
                MaxConnect4game.GameBoard[3][4] == MaxConnect4game.GameBoard[4][3] and
                MaxConnect4game.GameBoard[4][3] == MaxConnect4game.GameBoard[5][2]):
            if (MaxConnect4game.GameBoard[2][5] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[2][5] == 2):
                MaxConnect4game.player2Score += 1

        if (MaxConnect4game.GameBoard[2][6] == MaxConnect4game.GameBoard[3][5] and
                MaxConnect4game.GameBoard[3][5] == MaxConnect4game.GameBoard[4][4] and
                MaxConnect4game.GameBoard[4][4] == MaxConnect4game.GameBoard[5][3]):
            if (MaxConnect4game.GameBoard[2][6] == 1):
                MaxConnect4game.player1Score += 1
            elif (MaxConnect4game.GameBoard[2][6] == 2):
                MaxConnect4game.player2Score += 1