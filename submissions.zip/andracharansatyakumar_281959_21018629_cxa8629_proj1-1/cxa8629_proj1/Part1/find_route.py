import sys
from queue import PriorityQueue

def readFile(fileName) :
    file = open(fileName, 'r')
    lines = file.readlines()
    file.close()
    return lines

def getGraphByfile(fileName): # Parses through the input file and creates a dictionary with locations and respective costs
    graph = {}
    for line in readFile(fileName)[:-1]:
        data = line.split()
        if data == 'END OF INPUT':
            return graph
        else:
            if data[0] in graph:
                graph[data[0]][data[1]] = float(data[2])
            else:
                graph[data[0]] = {data[1]: float(data[2])}
            if data[1] in graph:
                graph[data[1]][data[0]] = float(data[2])
            else:
                graph[data[1]] = {data[0]: float(data[2])}
    return graph


def getGraphByheuristicfile(fileName): # Parses through the heuristic file and creates a dictionary
    val = {}
    for line in readFile(fileName)[:-1]:
        data = line.split()
        if data == 'END OF INPUT':
            return val
        else:
            val[data[0]] = float(data[1])
    return val


def uninformed_search(origin, destination, graph): # graph based uniform cost search

    fringe = PriorityQueue()
    fringe.put((0, origin))
    visited = {}
    parsed = []
    generated = 1
    nodesPopped = 0
    nodesExpanded = 1
    visited[origin] = ("", 0)
    while not fringe.empty():
        _, node_count = fringe.get()
        nodesPopped += 1
        if node_count == destination:
            break
        if node_count in parsed:
            nodesExpanded += 1
            continue
        parsed.append(node_count)
        for i in graph[node_count]:
            generated += 1
            fringe.put((graph[node_count][i]+visited[node_count][1], i))
            if i not in visited:
                visited[i] = (node_count, graph[node_count][i]+visited[node_count][1])

    route, distance = getRoute(graph,visited,origin)
    return route, nodesPopped, nodesExpanded,generated, distance

def getRoute(graph,visited,origin):
    route = []
    distance = "infinity"
    if destination in visited:
        distance = 0.0
        toCity = destination
        while toCity != origin:
            distance += graph[visited[toCity][0]][toCity]
            route.append(toCity)
            toCity = visited[toCity][0]
    return route ,distance

def informed_search(origin, destination, graph, heuristicGraph): # Implements A* search
    generated = 1
    nodesPopped = 0
    nodesExpanded = 1
    fringe = PriorityQueue()
    fringe.put((0, origin))
    visited = {}
    visited[origin] = ("", 0)
    explored = []
    mnode = 0
    while not fringe.empty():
        if len(fringe.queue) > mnode:
            mnode = len(fringe.queue)
        _, countnode = fringe.get()
        nodesPopped += 1
        if countnode == destination:
            nodesExpanded += 1
            break
        if countnode in explored:
            nodesExpanded += 1
            continue
        explored.append(countnode)
        for i in graph[countnode]:
            generated += 1
            if i not in visited:
                visited[i] = (countnode, graph[countnode][i] + visited[countnode][1])
            fringe.put((graph[countnode][i] + visited[countnode][1] + heuristicGraph[i], i))
    route,distance = getRoute(graph,visited,origin)
    return route, nodesPopped,nodesExpanded, generated, distance, mnode


# Formulating and formatting output
if len(sys.argv) == 4:
    fileName = sys.argv[1]
    source = sys.argv[2]
    destination = sys.argv[3]
    graph = getGraphByfile(fileName)
    route, nodesPopped,nodesExpanded, generated, distance = uninformed_search(source, destination, graph)
    print("Nodes Popped: {}".format(nodesPopped))
    print("Nodes Expanded: {}".format(nodesExpanded))
    print("Nodes Generated: {}".format(generated))
    print("Distance: {} km".format(distance))
    print("Route:")
    fromCity = source
    if len(route) == 0:
        print("none")
    else:
        for path in route[::-1]:
            print("{} to {}, {} km".format(fromCity, path, graph[fromCity][path]))
            fromCity = path

elif len(sys.argv) == 5:
    file_name = sys.argv[1]
    origin = sys.argv[2]
    destination = sys.argv[3]
    fname_h = sys.argv[4]
    graph = getGraphByfile(file_name)
    heuristicGraph = getGraphByheuristicfile(fname_h)
    route, nodesPopped,nodesExpanded, generated, distance, max_node = informed_search(origin, destination, graph, heuristicGraph)
    print("Nodes Popped: {}".format(nodesPopped))
    print("Nodes Expanded: {}".format(nodesExpanded))
    print("Nodes Generated: {}".format(generated))
    print("Distance: {} km".format(distance))
    print("Route:")
    fromCity = origin
    if len(route) == 0:
        print("none")
    else:
        for path in route[::-1]:
            print("{} to {}, {} km".format(fromCity, path, graph[fromCity][path]))
            fromCity = path