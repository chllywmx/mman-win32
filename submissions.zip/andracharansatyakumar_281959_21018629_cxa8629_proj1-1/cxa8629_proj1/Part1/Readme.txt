Name: charan satya kumar andra
UTA ID: 1002008629
Programming language: Python
----------------------------------------------

This folder has find_route.py, input1.txt and h_kassel.txt

In find_route.py file i used uniform cost search method for unformed search 
Implemented informed search i used A* search
----------------------------------------------
To Execute the program

Uniformed Serach: 
Python find_route.py input1.txt Bremen Kassel

Informed Search: 
python find_route.py input1.txt Bremen Kassel h_kassel.txt