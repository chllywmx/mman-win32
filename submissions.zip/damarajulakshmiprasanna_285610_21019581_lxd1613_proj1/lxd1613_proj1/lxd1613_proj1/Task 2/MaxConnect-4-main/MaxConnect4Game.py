import copy 
import random
import sys

utilityVal = {}
class MaxConnect4game:
    def __init__(self):
        self.board = [[0 for i in range(7)] for j in range(6)]
        self.currentMove = 0
        self.pieceCount = 0
        self.p1Score = 0
        self.p2Score = 0
        self.gameFile = None
        self.computerColumn = None
        self.depth = 1

    def checkPieceCount(self):
        self.pieceCount = sum(1 for row in self.board for piece in row if piece)

    def getPieceCount(self):    # returning the total piece of the borad which are occupied
        return sum(1 for row in self.board for piece in row if piece)

    def displayBoard(self):    # function for diplaying the game borad
        print(' -----------------')
        for i in range(6):
            print(' |', end =" "),
            for j in range(7):
                print('%d' % int(self.board[i][j]), end =" ")
            print('| ')
        print(' -----------------')

    def writeBoardInFile(self): # function for writing the board to file
        for row in self.board:
            self.gameFile.write(''.join(str(col) for col in row) + '\r')
        self.gameFile.write('%s\r' % str(self.currentMove))

    def play(self, column):    # function for placing the current player piece in the column
        if not self.board[0][column]:
            for i in range(5, -1, -1):
                if not self.board[i][column]:
                    self.board[i][column] = self.currentMove
                    self.pieceCount += 1
                    return 1

    def check(self, checkPieceColumn, opponent):     # function for checking if the piece is valid or not
        if not self.board[0][checkPieceColumn]:
            for i in range(5, -1, -1):
                if not self.board[i][checkPieceColumn]:
                    self.board[i][checkPieceColumn] = opponent
                    self.pieceCount += 1
                    return 1

    def alphaBeta(self, currentNode, alpha, beta, depth):   #alpha beta pruning
        value = -float('inf')
        node = copy.deepcopy(currentNode)
        childNodes = []
        for i in range(7):
            currentState = self.play(i)
            if currentState != None:
                childNodes.append(self.board)
                self.board = copy.deepcopy(node)
        if depth == 0 or childNodes == []:
            self.score()
            return self.playerEvalCalc(self.board) - self.computerStreakCalc(self.board)
        else:
            for node in childNodes:
                self.board = copy.deepcopy(node)
                value = max(value, self.betaAlpha(node, alpha, beta, depth - 1))
                if value >= beta:
                    return value
                alpha = max(alpha, value)
            return value

    def betaAlpha(self,currentNode, alpha, beta, depth):    #beta alpha pruning
        value = float('inf')
        node = copy.deepcopy(currentNode)
        if self.currentMove == 1:
            opponent = 2
        elif self.currentMove == 2:
            opponent = 1
        childNodes = []
        for i in range(7):
            currentState = self.check(i, opponent)
            if currentState != None:
                childNodes.append(self.board)
                self.board = copy.deepcopy(node)
        if depth == 0 or childNodes == []:
            self.score()
            return self.playerEvalCalc(self.board) - self.computerStreakCalc(self.board)
        else:
            for node in childNodes:
                self.board = copy.deepcopy(node)
                value = min(value, self.alphaBeta(node, alpha, beta, depth - 1))
                if value <= alpha:
                    return value
                beta = min(beta,value)
        return value

    def minMax(self, depth):    # plain min-max
        currentState = copy.deepcopy(self.board)
        for i in range(7):
            if self.play(i) != None:
                if self.pieceCount == 42 or self.depth == 0:
                    self.board = copy.deepcopy(currentState)
                    return i
                else:
                    val = self.betaAlpha(self.board, -float('inf'), float('inf'), depth - 1)
                    utilityVal[i] = val
                    self.board = copy.deepcopy(currentState)
        maxUtilityVal = max([i for i in utilityVal.values()])
        for i in range(7):
            if i in utilityVal:
                if utilityVal[i] == maxUtilityVal:
                    utilityVal.clear()
                    return i

    def verticalCheck(self, row, column, state, streak):    # checking the vertical piece in the row
        consecutiveCount = 0
        for i in range(row, 6):
            if state[i][column] == state[row][column]:
                consecutiveCount += 1
            else:
                break
        if consecutiveCount >= streak:
            return 1
        else:
            return 0

    def horizontalCheck(self, row, column, state, streak):  # checking for the horizontal piece in the column
        count = 0
        for j in range(column, 7):
            if state[row][j] == state[row][column]:
                count += 1
            else:
                break
        if count >= streak:
            return 1
        else:
            return 0

    def diagonalCheck(self, row, column, state, streak):    # checking for the diagonal check in the borad
        total = 0
        count = 0
        j = column
        for i in range(row, 6):
            if j > 6:
                break
            elif state[i][j] == state[row][column]:
                count += 1
            else:
                break
            j += 1
        if count >= streak:
            total += 1
        count = 0
        j = column
        for i in range(row, -1, -1):
            if j > 6:
                break
            elif state[i][j] == state[row][column]:
                count += 1
            else:
                break
            j += 1
        if count >= streak:
            total += 1
        return total

    def streakCalc(self, state, color, streak):     # function for checking which type of connectfour goes
        count = 0
        for i in range(6):
            for j in range(7):
                if state[i][j] == color:
                    count += self.verticalCheck(i, j, state, streak)
                    count += self.horizontalCheck(i, j, state, streak)
                    count += self.diagonalCheck(i, j, state, streak)
        return count

    def playerEvalCalc(self, state):    # calculating the streak for the non computer player
        playerFours = self.streakCalc(state, self.currentMove, 4)
        playerThrees = self.streakCalc(state, self.currentMove, 3)
        playerTwos = self.streakCalc(state, self.currentMove, 2)
        return (playerFours * 37044 + playerThrees * 882 + playerTwos * 21) # numbers are the permutation for each fours in a row, threes in a row and twos in a row

    def evalFunc(self): # next color
        if self.currentMove == 1:
            oneMoveColor = 2
        elif self.currentMove == 2:
            oneMoveColor = 1
        return oneMoveColor

    def computerStreakCalc(self, state):  # calculating the streak for the computer
        oneMoveColor = self.evalFunc()
        compFours = self.streakCalc(state, oneMoveColor, 4)
        compThrees = self.streakCalc(state, oneMoveColor, 3)
        compTwos = self.streakCalc(state, oneMoveColor, 2)
        return (compFours * 37044 + compThrees * 882 + compTwos * 21)

    def changeMove(self):
        if self.currentMove == 1:
            self.currentMove = 2
        elif self.currentMove == 2:
            self.currentMove = 1

    def aiPlay(self):
        randomCol = self.minMax(int(self.depth))
        result = self.play(randomCol)
        if not result:
            print('No Result')
        else:
            print('Player: %d, Column: %d\n' % (self.currentMove, randomCol + 1))
            self.changeMove()

    def score(self):
        self.p1Score = 0;
        self.p2Score = 0;
        for row in self.board:
            for i in range(4):
                if row[i:i+4] == [1] * 4:
                    self.p1Score += 1
                if row[i:i+4] == [2] * 4:
                    self.p2Score += 1
        for j in range(7):
            for i in range(3):
                if (self.board[i][j] == 1 and self.board[i+1][j] == 1 and
                        self.board[i+2][j] == 1 and self.board[i+3][j] == 1):
                    self.p1Score += 1
                if (self.board[i][j] == 2 and self.board[i+1][j] == 2 and
                        self.board[i+2][j] == 2 and self.board[i+3][j] == 2):
                    self.p1Score += 1              
        for i in range(3):
            for j in range(7):
                if j < 3:
                    if (self.board[i][j] == 1 and self.board[i+1][j+1] == 1 and
                            self.board[i+2][j+2] == 1 and self.board[i+3][j+3] == 1):
                        self.p1Score += 1
                    if (self.board[i][j] == 2 and self.board[i+1][j+1] == 2 and
                            self.board[i+2][j+2] == 2 and self.board[i+3][j+3] == 2):
                        self.p2Score += 1
                if j == 3:
                    if (self.board[i][j] == 1 and self.board[i+1][j+1] == 1 and
                            self.board[i+2][j+2] == 1 and self.board[i+3][j+3] == 1):
                        self.p1Score += 1
                    if (self.board[i][j] == 1 and self.board[i+1][j-1] == 1 and
                            self.board[i+2][j-2] == 1 and self.board[i+3][j-3] == 1):
                        self.p1Score += 1
                        
                    if (self.board[i][j] == 2 and self.board[i+1][j+1] == 2 and
                            self.board[i+2][j+2] == 2 and self.board[i+3][j+3] == 2):
                        self.p2Score += 1
                    if (self.board[i][j] == 2 and self.board[i+1][j-1] == 2 and
                            self.board[i+2][j-2] == 2 and self.board[i+3][j-3] == 2):
                        self.p2Score += 1
                if j > 3:
                    if (self.board[i][j] == 1 and self.board[i+1][j-1] == 1 and
                            self.board[i+2][j-2] == 1 and self.board[i+3][j-3] == 1):
                        self.p1Score += 1
                    if (self.board[i][j] == 2 and self.board[i+1][j-1] == 2 and
                            self.board[i+2][j-2] == 2 and self.board[i+3][j-3] == 2):
                        self.p2Score += 1