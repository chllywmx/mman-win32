Name: Damaraju, Lakshmi Prasanna

UTA ID: 1002021613
-----------------------------------
Programming Language: Python

Task2 File path : Task2 -> MaxConnect-4-main -> maxconnect4.py

Used PyCharm IDE for executing programs. Open terminal in PyCharm and give the following commands:

One-Move Mode:

python maxconnect4.py one-move input1.txt output.txt 1

Interactive Mode:

python maxconnect4.py interactive input1.txt computer-next 2

python maxconnect4.py interactive input1.txt human-next 3

