#!/bin/bash

time python maxconnect4.py one-move input1.txt output.txt 10

/bin/bash