import sys
from MaxConnect4Game import MaxConnect4game


def humanPlay(board):       # human function taking the input and putting the element in it
    while board.getPieceCount() != 42:  # checking if the board is empty or not
        print("Your turn") 
        print(" ------- ----")
        print("Enter a column number between 1 and 7:")
        userMove = int(input())  # taking input which column number should be entered
        if not 0 < userMove < 8:    # checking if it is valid input or not
            print("Column must be between 1 and 7.")
            continue
        if not board.play(userMove - 1):
            print("Column %d is full. Try other column." % userMove)
            continue
        print("The move you made: " + str(userMove))
        board.displayBoard()   # displaying the game board
        board.gameFile = open("human.txt", 'w')  # displaying it in the txt file
        board.writeBoardInFile()
        board.gameFile.close()  # file closing
        if board.getPieceCount() == 42:     # checking if the borad is full
            print("No more moves possible, Game Over!")
            board.score()  # printing the score
            print('Score: PlayerA = %d, PlayerB = %d\n' % (board.p1Score, board.p2Score))
            break
        else:   # computer move
            print("Computer is conputing based on next " + str(board.depth) + " steps...")
            board.changeMove()  # changing the player to other player
            board.aiPlay()  # computing the computer move with the minmax alpha beta puring
            board.displayBoard()   # displaying game borad
            board.gameFile = open('computer.txt', 'w')  # printing output to file
            board.writeBoardInFile()
            board.gameFile.close()  # file closing
            board.score()  # printing score count
            print('Score: PlayerA = %d, PlayerB = %d\n' % (board.p1Score, board.p2Score))

def interactiveMode(board, nextPlayer):     # interactive mode
    print('Current board : ')
    board.displayBoard()   # displaying the game board
    board.score()  # displaying score
    print('Score: PlayerA = %d, PlayerB = %d\n' % (board.p1Score, board.p2Score))
    if nextPlayer == 'human-next':
        humanPlay(board)
    else:
        board.aiPlay()  # computign the computer move
        board.gameFile = open('computer.txt', 'w')  # printing the result into the file
        board.writeBoardInFile()
        board.gameFile.close()
        board.displayBoard()   # dislaying the game board
        board.score()  # displaying score 
        print('Score: PlayerA = %d, PlayerB = %d\n' % (board.p1Score, board.p2Score))
        humanPlay(board)    # human turn next

    if board.getPieceCount() == 42:
        if board.p1Score > board.p2Score:
            print("Player 1 wins")
        if board.p1Score == board.p2Score:
            print("The game is a tie")
        if board.p1Score < board.p2Score:
            print("Player 2 wins")
        print("Game Over!")


def oneMoveMode(board):     # one move mode
    if board.pieceCount >= 42:  # checking if all the piece are filled, then exit
        print('Board is full !\n Game Over...')
        sys.exit(0)
    print ('board state before move:')
    board.displayBoard()   # displaying game board
    board.aiPlay()      # Computing the computer move
    print ('board state after move:')
    board.displayBoard()   # displaying game board
    board.score()  # displaying score
    print('Score: Player1 = %d, Player2 = %d\n' % (board.p1Score, board.p2Score))
    board.writeBoardInFile()    # printing the game board into file
    board.gameFile.close()      # close file

def main(argv): 
    # Make sure we have enough command-line arguments
    if len(argv) != 5:
        print('Four command-line arguments are needed:')
        print('Usage: %s interactive [input_file] [computer-next/human-next] [depth]' % argv[0])
        print('or: %s one-move [input_file] [output_file] [depth]' % argv[0])
        sys.exit(2)

    board = MaxConnect4game()   #object of other file
    try:
        board.gameFile = open(argv[2], 'r')     #reading the input file
        fileLines = board.gameFile.readlines()
        board.board = [[int(char) for char in line[0:7]] for line in fileLines[0:-1]]
        board.currentMove = int(fileLines[-1][0])
        board.gameFile.close()
    except:
        print('File not found, begin new game.')
        board.currentMove = 1
    board.checkPieceCount()     # checking all the elements added is true or not
    board.depth = argv[4]   # depth taken from input arguments
    if sys.argv[1] == 'one-move':   #for one move mode
        try:
            board.gameFile = open(argv[3], 'w')
        except:
            sys.exit('Error while opening output file.')
        oneMoveMode(board)
    else:   # for interactive mode
        interactiveMode(board, argv[3])

if __name__ == '__main__':
    main(sys.argv)