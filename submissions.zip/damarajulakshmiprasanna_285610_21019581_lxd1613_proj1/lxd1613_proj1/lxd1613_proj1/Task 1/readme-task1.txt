Name: Damaraju, Lakshmi Prasanna

UTA ID: 1002021613
-----------------------------------------
Programming Language: Python 

Task1 File path : Task1 -> find_route.py

Used PyCharm IDE for executing programs. Open terminal in PyCharm and give the following commands:

Uninformed Search:

python find_route.py input1.txt Bremen Kassel

Informed Search:

python find_route.py input1.txt Bremen Kassel h_kassel.txt