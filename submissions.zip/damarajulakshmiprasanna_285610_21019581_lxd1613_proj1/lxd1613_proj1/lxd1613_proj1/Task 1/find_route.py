import sys
from collections import deque

class Node:
    def __init__(self, city, totalCost, distance):
        self.city = city
        self.parents = None
        self.totalCost = totalCost
        self.distance = distance      
        
def generateGraph():
    paths = []
    inputFile = open(sys.argv[1])
    for row in inputFile:
        if row != 'END OF INPUT':
            data = row.split()
            source = data[0]
            destination = data[1]
            dist = data[2]
            paths.append([source, destination, dist])
            paths.append([destination, source, dist])
        else:
            break
    return paths		

def uninformedSearch(source, destination):
    Expanded = []
    paths = generateGraph()
    Fringe = deque()
    Fringe.append(Node(source, 0, 0))
    NodesExpanded = 0
    NodesPopped = 0
    NodesGenerated = 1
    NotInRange = 0

    while True:
        if len(Fringe) != 0:
            ExpandedNodes = Fringe.popleft()
            NodesPopped += 1
            if ExpandedNodes.city == destination:
                break
            else:
                if ExpandedNodes.city not in Expanded:
                    Expanded.append(ExpandedNodes.city)
                    NodesExpanded += 1
                    for data in paths:
                        if data[0] == ExpandedNodes.city:
                            cost = ExpandedNodes.totalCost+float(data[2])
                            node1 = Node(data[1], cost, ExpandedNodes.distance+1)
                            node1.parents= ExpandedNodes
                            Fringe.append(node1)
                            NodesGenerated += 1
                            Fringe=deque(sorted(Fringe, key=lambda Node:Node.totalCost))
        else:
            NotInRange = 1
            break
    if(NotInRange == 1):
        print("Nodes Popped :", NodesPopped)
        print("Nodes Expanded:" , NodesExpanded)
        print("Nodes Generated:", NodesGenerated)
        print("Distance: infinity")
        print("Route:\nNone")

    else:
        print("Nodes Popped:", NodesPopped)
        print("Nodes Expanded:" , NodesExpanded)
        print("Nodes Generated:", NodesGenerated)
        print("Distance: " + str(ExpandedNodes.totalCost) + "km")
        print("Route:")
        path = []
        path.append(destination)
        while ExpandedNodes.parents != None:
            path.append(ExpandedNodes.parents.city)
            ExpandedNodes = ExpandedNodes.parents
        path.reverse()
        Loc=0
        while Loc < len(path)-1:
            for p in paths:
                if path[Loc] == p[0] and path[Loc + 1] == p[1]:
                    print (p[0], "to", p[1] + ", " + str(float(p[2])) + "km")
            Loc = Loc + 1

def informedSearch(Heuristic, source, destination):
    Expanded = []
    Fringe = deque()
    paths = generateGraph()
    Fringe.append(Node(source, 0, 0))
    NodesExpanded=0
    NotInRange = 0
    NodesPopped = 0
    NodesGenerated = 1
    while True:
        if len(Fringe) != 0:
            ExpandedNodes = Fringe.popleft()
            NodesPopped += 1
            if ExpandedNodes.city == destination:
                break
            else:
                if ExpandedNodes.city not in Expanded:
                    Expanded.append(ExpandedNodes.city)
                    NodesExpanded += 1
                    for data in paths:
                        if data[0] == ExpandedNodes.city:
                            for huer in Heuristic:
                                if huer[0] == data[1]:
                                    heuristicvalue=huer[1]

                            informedSearchCost = Node(data[1], (float(ExpandedNodes.totalCost) + float(data[2])) , (float(ExpandedNodes.totalCost) + float(data[2]) + float(heuristicvalue)))
                            informedSearchCost.parents= ExpandedNodes
                            Fringe.append(informedSearchCost)
                            NodesGenerated += 1
                            Fringe=deque(sorted(Fringe, key=lambda Node:Node.distance))
        else:
            NotInRange = 1
            break
    if(NotInRange == 1):
        print("Nodes Popped:", NodesPopped)
        print("Nodes Expanded:" , NodesExpanded)
        print("Nodes Generated:", NodesGenerated)
        print("Distance: infinity")
        print("Route:\nNone")
        
    else:
        print("Nodes Popped:", NodesPopped)
        print("Nodes Expanded:" , NodesExpanded)
        print("Nodes Generated:", NodesGenerated)
        print("Distance: " + str(ExpandedNodes.totalCost) + "km")
        print("Route: ")
        path = []
        path.append(destination)
        while ExpandedNodes.parents != None:
            path.append(ExpandedNodes.parents.city)
            ExpandedNodes = ExpandedNodes.parents
        path.reverse()
        Loc=0
        while Loc < len(path) - 1:
            for p in paths:
                if path[Loc] == p[0] and path[Loc + 1] == p[1]:
                    print (p[0], "to", p[1] + ", " + str(float(p[2])) + "km")
            Loc = Loc + 1

source = sys.argv[2]
destination = sys.argv[3]
Heuristic=[]
if len(sys.argv) == 4:
    uninformedSearch(source, destination)
else:
    heuristicfile = sys.argv[4]
    Heu_File = open(heuristicfile)
    for row in Heu_File:
        if row != 'END OF INPUT':
            heuristic = row.split()
            hpaths = heuristic[0]
            hvalue = heuristic[1]
            Heuristic.append([hpaths, hvalue])
        else:
            break
    informedSearch(Heuristic, source, destination)



    