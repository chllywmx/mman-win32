Name:Goutham Sai Kumar Andhe
UTA ID:1001968090
Project 1

I have used python as the Programming language (Not omega compatible)

Get the input from the Command line arguments
Algorithm used for uninformed graph search: Uniform Cost search algorithm
Algorithm used for informed graph search  : A* search algorithm.

Logics are built to compare the fringe nodes and path is calculated based on the arguments passed during running the code.


We need to Run the python source code file in the python source and provide the parameters in the command line accordingly.

Case 1:

Route Exist

Sample Output:

Nodes Popped =  5
Nodes Expanded =  4
Nodes Generated =  10
Distance =  291
Route =  [['Berlin', 'Magdeburg', 166], ['Magdeburg', 'Leipzig', 125]]

Process finished with exit code 0

Case 2:

No Route Exist

Sample Output:

Nodes Popped =  40
Nodes Expanded =  40
Nodes Generated =  40
Distance =  infinity
Route =  None

Process finished with exit code 0

Case 3:

Optimal path

Sample Output:

Nodes Popped =  5
Nodes Expanded =  4
Nodes Generated =  10
Distance =  291
Route =  [['Berlin', 'Magdeburg', 166], ['Magdeburg', 'Leipzig', 125]]

Process finished with exit code 0

Case 4:

Informed Search : h-kassel.txt as heuristic 

Sample Output:

Nodes Popped =  3
Nodes Expanded =  2
Nodes Generated =  6
Distance =  291
Route =  [['Berlin', 'Magdeburg', 166], ['Magdeburg', 'Leipzig', 125]]

Process finished with exit code 0