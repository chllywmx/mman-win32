import sys
from queue import PriorityQueue
def uninformed_search(input_filename, origin_city, destination_city):
    routes = []
    count1, count2, count3 = 0, 0, 0
    s_route = []
    e_route = []
    d_route = []
    all_routes = []
    with open(input_filename) as file:
        for i in file:
            if i.rstrip() != "END OF INPUT":
                routes.append(i.rstrip())
            else:
                break
    start_list = []
    dest_list = []
    distance = []
    for i in routes:
        s = i.split(" ")
        start_list.append(s[0])
        dest_list.append(s[1])
        distance.append(s[2])
    graph = dict()
    for i in range(len(start_list)):
        if start_list[i] in graph:
            graph[start_list[i]].append([dest_list[i], distance[i]])
        else:
            graph[start_list[i]] = []
            graph[start_list[i]].append([dest_list[i], distance[i]])
    for i in range(len(dest_list)):
        if dest_list[i] in graph:
            graph[dest_list[i]].append([start_list[i], distance[i]])
        else:
            graph[dest_list[i]] = []
            graph[dest_list[i]].append([start_list[i], distance[i]])
    start_node = origin_city
    end_node = destination_city
    nodes_visited = []
    traveller = PriorityQueue()
    traveller.put((0, start_node))
    count1 += 1
    total_dist = 0
    while not traveller.empty():
        temp = traveller.get()
        count2 += 1
        node_now = temp[1]
        dist_so_far = temp[0]
        nodes_visited.append(node_now)
        if node_now == end_node:
            total_dist += dist_so_far
            break
        else:
            count3 += 1
            for i in graph[node_now]:
                dist_new = int(i[1])
                node_new = i[0]
                if node_new in nodes_visited:
                    pass
                else:
                    traveller.put([dist_so_far + dist_new, node_new])
                    s_route.append(node_now)
                    e_route.append(node_new)
                    d_route.append(dist_new)
                    count1 += 1
    if destination_city in e_route:
        endi = destination_city
        while endi != origin_city:
            temp = endi
            ind = e_route.index(endi)
            endi = s_route[ind]
            all_routes.append([endi, temp, d_route[ind]])
        all_routes.reverse()
        print("Nodes Popped = ", count2)
        print("Nodes Expanded = ", count3)
        print("Nodes Generated = ", count1)
        print("Distance = ", total_dist)
        print("Route = ", all_routes)
    else:
        print("Nodes Popped = ", count2)
        print("Nodes Expanded = ", count3)
        print("Nodes Generated = ", count1)
        print("Distance = ", "infinity")
        print("Route = ", "None")

def informed_search(input_filename, origin_city, destination_city, heuristic_file):
    routes = []
    total_route = []
    count1, count2, count3 = 0, 0, 0
    all_routes = []
    s_route = []
    e_route = []
    d_route = []
    with open(input_filename) as file:
        for i in file:
            if i.rstrip() != "END OF INPUT":
                routes.append(i.rstrip())
            else:
                break
    start_list = []
    dest_list = []
    distance = []
    for i in routes:
        s = i.split(" ")
        start_list.append(s[0])
        dest_list.append(s[1])
        distance.append(s[2])
    graph = dict()
    heuristics = dict()
    for i in range(len(start_list)):
        if start_list[i] in graph:
            graph[start_list[i]].append([dest_list[i], distance[i]])
        else:
            graph[start_list[i]] = []
            graph[start_list[i]].append([dest_list[i], distance[i]])
    for i in range(len(dest_list)):
        if dest_list[i] in graph:
            graph[dest_list[i]].append([start_list[i], distance[i]])
        else:
            graph[dest_list[i]] = []
            graph[dest_list[i]].append([start_list[i], distance[i]])
    heu = []
    with open(heuristic_file) as file:
        for i in file:
            if i.rstrip() != "END OF INPUT":
                heu.append(i.rstrip())
            else:
                break
    place = []
    distance_from_goal = []
    for i in heu:
        s = i.split(" ")
        place.append(s[0])
        distance_from_goal.append(s[1])
    for i in range(len(place)):
        if place[i] in heuristics:
            heuristics[place[i]].append([distance_from_goal[i]])
        else:
            heuristics[place[i]] = []
            heuristics[place[i]].append([distance_from_goal[i]])
    start_node = origin_city
    end_node = destination_city
    nodes_visited = []
    traveller = PriorityQueue()
    traveller.put((0 + int(heuristics[start_node][0][0]), start_node))
    count1 += 1
    total_dist = 0
    while not traveller.empty():
        temp = traveller.get()
        count2 += 1
        node_now = temp[1]
        dist_so_far = temp[0]
        nodes_visited.append(node_now)
        if node_now == end_node:
            total_dist += dist_so_far - int(heuristics[node_now][0][0])
            break
        else:
            count3 += 1
            for i in graph[node_now]:
                dist_new = int(i[1])
                node_new = i[0]
                if node_new in nodes_visited:
                    pass
                else:
                    traveller.put((dist_so_far + dist_new + int(heuristics[node_new][0][0]) - int(heuristics[node_now][0][0]), node_new))
                    s_route.append(node_now)
                    e_route.append(node_new)
                    d_route.append(dist_new)
                    count1 += 1
    if destination_city in e_route:
        endi = destination_city
        while endi != origin_city:
            temp = endi
            ind = e_route.index(endi)
            endi = s_route[ind]
            all_routes.append([endi, temp, d_route[ind]])
        all_routes.reverse()
        print("Nodes Popped = ", count2)
        print("Nodes Expanded = ", count3)
        print("Nodes Generated = ", count1)
        print("Distance = ", total_dist)
        print("Route = ", all_routes)
    else:
        print("Nodes Popped = ", count2)
        print("Nodes Expanded = ", count3)
        print("Nodes Generated = ", count1)
        print("Distance = ", "infinity")
        print("Route = ", "None")

if len(sys.argv) == 5:
    informed_search(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
else:
    uninformed_search(sys.argv[1], sys.argv[2], sys.argv[3])