Name : Kedar Kiran Penurkar
Id : 1002033676

Python version ~ 3.10

TASK 2: Game Play

1. To execute code please use below command format
    
    a. For One move 
   
        python maxconnect4.py one-move input1.txt output.txt 4

    b. For Interactive  
 
        python maxconnect4.py interactive input1.txt output.txt 2


Reference:
https://github.com/KeithGalli/Connect4-Python/blob/master/connect4_with_ai.py