

import sys
from MaxConnect4Game import *


def oneMoveGame(currentGame, depth):
    if currentGame.pieceCount == 42:  # Is the board full already?
        print('BOARD IS FULL\n')
        sys.exit(0)

    currentGame.aiPlay(currentGame, depth)  # Make a move (only random is implemented)

    print('Game Board after move:')
    currentGame.printGameBoard()

    currentGame.countScore()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))

    currentGame.printGameBoardToFile()
    currentGame.gameFile.close()


def interactiveGame(currentGame, nxt_player, depth):
    if nxt_player == 'human-next':
        while not currentGame.checkPieceCount() == 42:
            if currentGame.checkPieceCount == 42:
                print('BOARD IS FULL\n')
                sys.exit(0)
            print("It is Your turn.")
            currentGame.cng_mv()
            userMove = int(input("Enter the Column number between 1 and 7 : "))
            if not 0 < userMove < 8:
                print("Enter valid column.")
                continue
            if not currentGame.playPiece(userMove - 1):
                print("Column: %d is full. Try to choose other column." % userMove)
                continue
            print("You have selected column: " + str(userMove))
            currentGame.printGameBoard()
            currentGame.gameFile = open("hum.txt", 'w')
            currentGame.printGameBoardToFile()
            currentGame.gameFile.close()
            if currentGame.checkPieceCount() == 42:
                print("Game Over !")
                currentGame.count_score()
                print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))
                break
            else:
                print("Computer's Turn ")
                currentGame.cng_mv()
                currentGame.aiPlay(currentGame, depth)
                currentGame.printGameBoard()
                currentGame.gameFile = open('cmp.txt', 'w')
                currentGame.printGameBoardToFile()
                currentGame.gameFile.close()
                currentGame.countScore()
                print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))
    else:
        if currentGame.checkPieceCount == 42:
            print('BOARD FULL\n')
            sys.exit(0)
        currentGame.aiPlay(currentGame, depth)
        currentGame.gameFile = open('cmp.txt', 'w')
        currentGame.printGameBoardToFile()
        currentGame.gameFile.close()
        currentGame.printGameBoard()
        currentGame.countScore()
        print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))
        interactiveGame(currentGame, 'human-next', depth)

    if currentGame.checkPieceCount() == 42:
        if currentGame.player1Score > currentGame.player2Score:
            print("Player 1 won!!")
        if currentGame.player1Score == currentGame.player2Score:
            print("Tie..!!")
        if currentGame.player1Score < currentGame.player2Score:
            print("Player 2 won!!")
        print("Game Over..!!")


def main(argv):
    # Make sure we have enough command-line arguments
    if len(argv) != 5:
        print('Four command-line arguments are needed:')
        print('Usage: %s interactive [input_file] [computer-next/human-next] [depth]' % argv[0])
        print('or: %s one-move [input_file] [output_file] [depth]' % argv[0])
        sys.exit(2)

    game_mode, inFile = argv[1:3]

    if not game_mode == 'interactive' and not game_mode == 'one-move':
        print('%s is an unrecognized game mode' % game_mode)
        sys.exit(2)

    currentGame = maxConnect4Game()  # Create a game

    # Try to open the input file
    try:
        currentGame.gameFile = open(inFile, 'r')
    except IOError:
        sys.exit("\nError opening input file.\nCheck file name.\n")

    # Read the initial game state from the file and save in a 2D list
    file_lines = currentGame.gameFile.readlines()
    currentGame.gameBoard = [[int(char) for char in line[0:7]] for line in file_lines[0:-1]]
    currentGame.currentTurn = int(file_lines[-1][0])
    currentGame.gameFile.close()

    print('\n**** MaxConnect-4 game ****\n')
    print('Game Board before move:')
    currentGame.printGameBoard()

    # Update a few game variables based on initial state and print the score
    currentGame.checkPieceCount()
    currentGame.countScore()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))

    if game_mode == 'interactive':
        interactiveGame(currentGame, argv[2], argv[4])  # Be sure to pass whatever else you need from the command line
    else:  # game_mode == 'one-move'
        # Set up the output file
        outFile = argv[3]
        try:
            currentGame.gameFile = open(outFile, 'w')
        except:
            sys.exit('Error opening output file.')
        oneMoveGame(currentGame, argv[4])  # Be sure to pass any other arguments from the command line you might need.


if __name__ == '__main__':
    main(sys.argv)
