import sys


def rInputFile(infileName):
    for line in infileName:
        if "END OF INPUT" in line:
            break
        else:
            tmp = line.strip().split(" ")
            fc = tmp[0]
            sc = tmp[1]
            if fc in cl:
                pass
            else:
                cl.append(fc)
            if sc in cl:
                pass
            else:
                cl.append(sc)

    cl.sort()
    for i in range(len(cl)):
        md.append([])
        for j in range(len(cl)):
            md[i].append(-1)
        md[i][i] = 0

    for line in infileName:
        if "END OF INPUT" in line:
            break
        else:
            t = line.strip().split(" ")
            fc = t[0]
            sc = t[1]
            dist = t[2]
            md[cl.index(fc)][cl.index(sc)] = int(dist)
            md[cl.index(sc)][cl.index(fc)] = int(dist)
    return


def rHeuristicFile(infileName):
    for line in infileName:
        if "END OF INPUT" in line:
            break
        else:
            r = line.split(" ")
            hst[cl.index(r[0])] = int(r[1])
    return


def route(pDest, node):
    nPath = []

    def btPath(dest, nTch):
        if dest is None:
            return
        else:
            for vNode in nTch:
                if vNode["node"] == dest:
                    nPath.append(dest)
                    btPath(vNode["Parent_Node"], nTch)

    if pDest:
        print("Distance: " + str(pDest["Tl_Cost"]) + " km")
        print("Route: ")
        btPath(pDest["Present_Node"], node)
        nPath.reverse()
        for i in range(0, len(nPath) - 1):
            print(cl[nPath[i]] + " to " + cl[nPath[i + 1]] + ", " + str(
                md[nPath[i]][nPath[i + 1]]))
    else:
        print("Distance: infinity")
        print("Route:")
        print("None")
    return


def alreadyVist(pNodeI, hNodes):
    for node in hNodes:
        if pNodeI == node["node"]:
            return True
    return False


def pFring(fringe, flg):
    if (len(fringe) > 1):
        for i in range(0, len(fringe) - 1):
            sm = i
            for j in range(i + 1, len(fringe)):
                s = fringe[sm]["Tl_Cost"]
                n = fringe[j]["Tl_Cost"]
                if flg:
                    s += fringe[sm]["hucost"]
                    n += fringe[j]["hucost"]
                if (s > n):
                    sm = j
            tmp = fringe[sm]
            fringe[sm] = fringe[i]
            fringe[i] = tmp
        return fringe
    else:
        return fringe


def ucs():
    g = cl.index(gs)
    nG = 1
    nP = 0
    nE = 1
    mFS = 0
    unFringe = []
    n_vl = []
    seFlag = False
    unFringe.append({"Present_Node": cl.index(ss), "Tl_Cost": 0, "Parent_Node": None})
    while len(unFringe) > 0:
        nP = nP + 1
        if unFringe[0]["Present_Node"] == g:
            n_vl.append({"node": unFringe[0]["Present_Node"], "Parent_Node": unFringe[0]["Parent_Node"]})
            seFlag = unFringe[0]
            break
        elif alreadyVist(unFringe[0]["Present_Node"], n_vl):
            del unFringe[0]
            nE = nE + 1
            continue
        else:
            n_vl.append({"node": unFringe[0]["Present_Node"], "Parent_Node": unFringe[0]["Parent_Node"]})
            for i in range(len(md[unFringe[0]["Present_Node"]])):
                if md[unFringe[0]["Present_Node"]][i] > 0:
                    unFringe.append({"Present_Node": i, "Tl_Cost": unFringe[0]["Tl_Cost"] + md[unFringe[0]["Present_Node"]][i], "Parent_Node": unFringe[0]["Present_Node"]})
                    nG = nG + 1
            del unFringe[0]
            unFringe = pFring(unFringe, False)

        if len(unFringe) > mFS:
            mFS = len(unFringe)
    print("Nodes Popped: " + str(nP))
    print("Nodes Expanded: " + str(nE))
    print("Nodes Generated: " + str(nG))
    route(seFlag, n_vl)
    return


def ifs():
    g = cl.index(gs)
    nG = 1
    nP = 0
    nE = 0
    mFS = 0
    inFringe = []
    n_vl = []
    seFlag = False
    inFringe.append({
        "Present_Node": cl.index(ss),
        "Tl_Cost": 0,
        "hucost": hst[cl.index(ss)],
        "Parent_Node": None
    })
    while (len(inFringe) > 0):
        nP = nP + 1
        if inFringe[0]["Present_Node"] == g:
            n_vl.append({
                "node": inFringe[0]["Present_Node"],
                "Parent_Node": inFringe[0]["Parent_Node"]
            })
            seFlag = inFringe[0]
            break
        elif alreadyVist(inFringe[0]["Present_Node"], n_vl):
            del inFringe[0]
            continue
        else:
            n_vl.append({
                "node": inFringe[0]["Present_Node"],
                "Parent_Node": inFringe[0]["Parent_Node"]
            })
            for i in range(len(md[inFringe[0]["Present_Node"]])):
                if md[inFringe[0]["Present_Node"]][i] > 0:
                    inFringe.append({
                        "Present_Node": i,
                        "Tl_Cost": inFringe[0]["Tl_Cost"] + md[inFringe[0]["Present_Node"]][i],
                        "hucost": hst[i],
                        "Parent_Node": inFringe[0]["Present_Node"]
                    })
                    nG = nG + 1
            del inFringe[0]
            nE = nE + 1
            inFringe = pFring(inFringe, True)

        if (len(inFringe) > mFS):
            mFS = len(inFringe)

    print("Nodes Popped: " + str(nP))
    print("Nodes Expanded: " + str(nE))
    print("Nodes Generated: " + str(nG))
    route(seFlag, n_vl)
    return


if len(sys.argv) >= 4:
    cl = []
    md = []

    rInputFile(open(sys.argv[1], "r").read().split("\n"))
    ss = sys.argv[2]
    gs = sys.argv[3]

    if len(sys.argv) == 4:
        print("User selected Uninformed Search..\n")
        ucs()
    elif len(sys.argv) == 5:
        print('User selected Informed Search..\n')
        hst = [0] * len(cl)
        hstIn = sys.argv[4]
        rHeuristicFile(open(sys.argv[4], "r").read().split("\n"))
        ifs()
    else:
        print("\nEntered incorrect parameters. Please enter correct parameters")
