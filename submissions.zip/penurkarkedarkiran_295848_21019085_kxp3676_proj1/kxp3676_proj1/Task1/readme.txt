MINI PROJECT 1

Name: Kedar Kiran Penurkar
UTA ID: 1002033676

Python version ~ 3.10

TASK 1: Find the optimal path.

1. To execute code please use below command format
    
    a. For uninformed search 

        python find_route.py input1.txt Bremen Kassel

    b. For informed search
 
        python find_route.py input1.txt Bremen Kassel h_kassel.txt
