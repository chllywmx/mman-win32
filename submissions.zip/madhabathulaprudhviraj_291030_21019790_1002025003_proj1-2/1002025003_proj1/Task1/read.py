# Name: Prudhvi Raj Madhabathula
# ID: 1002025003
# Task 1:4308; Uninformed & Informed Search; Game Playing
def readIFile(fname):
    filecontents = open(fname, 'r')
    inputcontents = {}

    for r in filecontents:
        r = r.lstrip()
        r = r.rstrip()
        if r != 'END OF INPUT':
            part = r.split(' ')
            part[2] = float(part[2])
            if part[0] in inputcontents:
                inputcontents[part[0]].append( [part[1], part[2]] )
            else:
                inputcontents[part[0]] = [[part[1], part[2]]]
            if part[1] in inputcontents:
                inputcontents[part[1]].append( [part[0], part[2]] )
            else:
                inputcontents[part[1]] = [[part[0], part[2]]]
        else:
            return inputcontents


def readHFile(fname):
    filecontents = open(fname, 'r')
    heuristiccontents = {}

    for h in filecontents:
        h = h.lstrip()
        h = h.rstrip()
        if h != 'END OF INPUT':
            data = h.split(' ')
            data[1] = float(data[1])
            heuristiccontents[data[0]] = data[1]
        else:
            return heuristiccontents
