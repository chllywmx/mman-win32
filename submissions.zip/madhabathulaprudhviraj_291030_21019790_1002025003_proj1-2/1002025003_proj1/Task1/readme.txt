
Name : Prudhvi Raj Madhabathula
UTA ID : 1002025003
Programming Language : Python

How To Run The Code:

    1. Open terminal in a Linux machine, navigate to unzipped project folder

    2. To run an Informed Search, type into the command line and then press enter:

        python find_route.py [input_file.txt] [City_1] [City_2] [heuristic_file.txt]

        Example:
        python find_route.py input1.txt Bremen Kassel h_kassel.txt

    3. To run an Uninformed Search, type into the command line and then press enter:

        python find_route.py [input_file.txt] [City_1] [City_2]
        Example:
        python find_route.py input1.txt Bremen Kassel
