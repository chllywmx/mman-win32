# Name: Prudhvi Raj Madhabathula
# ID: 1002025003
# Task 1:4308; Uninformed & Informed Search; Game Playing

import sys           
import operator      
import read as read  
import node_fringe as fr  


def main():
    
    #checking which search is to be performed
    if len(sys.argv) == 5:
        uninformed = False 
    else:
        uninformed = True   

   #checking file input
    if len(sys.argv) != 1:
       map = read.readIFile(sys.argv[1])  
    else:
        print("Could not find input file, please enter it correctly")   
        sys.exit()

   
    nodes_expanded  = 0   
    nodes_popped = 0   
    nodes_generated = 0  
    heuristic_nodes = {}

    if not uninformed:
        heuristic_nodes = read.readHFile(sys.argv[4])

    fringe = []

    if uninformed:
        fringe.append(fr.ObjectOfNode(None, sys.argv[2], 0, 0, 0, uninformed))
        nodes_generated += 1
    else:
        fringe.append(fr.ObjectOfNode(None, sys.argv[2], 0, 0, heuristic_nodes[sys.argv[2]], uninformed))
        nodes_generated += 1 

    closed = []
    
   
    while len(fringe) > 0:
        #nodesExpanded += 1

        node = fringe.pop(0)
        nodes_popped=nodes_popped+1

       
        if node.city != sys.argv[3]:
            if node.city not in closed:
                closed.append(node.city)
                next_node = fr.expansionOfNodes(node, map, heuristic_nodes, nodes_expanded)
                nodes_expanded += 1

                for i in next_node:
                    fringe.append(i)
                nodes_generated += len(next_node)

                if uninformed:
                    fringe = sorted(fringe, key=operator.attrgetter('a'))
                else:
                    fringe = sorted(fringe, key=operator.attrgetter('c'))

        else:
            print("Nodes Popped: " + str(nodes_popped))
            print("Nodes Expanded: "  + str(nodes_expanded))
            print("Nodes Generated: " + str(nodes_generated))
            fr.backtrack_nodes(node, map, nodes_expanded)
            sys.exit() 
 
    else:
        print("Nodes Popped: " + str(nodes_popped))
        print("Nodes Expanded: "  + str(nodes_expanded))
        print("Nodes Generated: " + str(nodes_generated))
        print("Minimum Distance found: infinity")
        print("Route: \nnone")


main()
