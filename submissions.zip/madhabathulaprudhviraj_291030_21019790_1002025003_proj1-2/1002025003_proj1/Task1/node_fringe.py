# Name: Prudhvi Raj Madhabathula
# ID: 1002025003
# Task 1:4308; Uninformed & Informed Search; Game Playing

def backtrack_nodes(node, map, SearchType):
    route = []
    distance = node.a
    while node is not None:
        _parent = node.parent
        if _parent is not None:
            steps = (s for s in map[_parent.city] if s[0] == node.city)
            s = next(steps)
            route.append(_parent.city + " to " + node.city + ", " + str(s[1]) + " Km")
        node = _parent
    route.reverse()
    print("Minimum Distance found: " + str(distance) + " Km")
    print("route:")
    for segment in route:
        print(segment)

class ObjectOfNode:
    def __init__(self, parent, city, a, b, c, uninformed):
        self.parent = parent
        self.city = city
        self.a = a 
        self.b = b
        self.c = c
        self.uninformed = uninformed


def expansionOfNodes(node, map, heuristic, SearchType):
    forward_nodes = []
    todo = map[node.city]
    for i in todo:
        cost = node.a + i[1]
        if node.uninformed:
            forward_nodes.append(ObjectOfNode(node, i[0], cost, node.b + 1, 0, node.uninformed))
        else:
            forward_nodes.append(ObjectOfNode(node, i[0], cost, node.b+ 1, cost + heuristic[i[0]], node.uninformed))
    return forward_nodes