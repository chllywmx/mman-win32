Name : Prudhvi Raj Madhabathula
UTA ID : 1002025003
Programming Language : Python

maxconnect4.py : Main python file that is compiled, It takes input and calls other classes.
MaxConnect4Game.py : This file contains the game details like grid and all the functions for nextStep, output the file are written in it.
node.py : This class stores the current bode and all the successor boards for this current node. The decision function is written in it.


Command to run the code: python ./maxconnect4.py one-move input1.txt output1.txt 10
Command to run the code: python ./maxconnect4.py interactive input2.txt computerplayer.txt 3