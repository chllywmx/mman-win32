#Name: Prudhvi Raj Madhabathula
#UTA ID: 1002025003
#Language: Python

import sys
from maxConnect4Game import *
from node import *

def oneMoveFunction(present_game_board, intensity):
    if present_game_board.pieces_played_count == 42:    # board full
        print('BOARD IS FULL\nGame Over!\n')
        sys.exit(0)

    #present_game_board.aiPlay() # Make a action (only random is implemented)

    node_tree = node(present_game_board, intensity)
    action = node_tree.make_next_move_decision()
    result = present_game_board.playPiece_Turn(action)
    game_Process(present_game_board, action)
    present_game_board.game_file_name.close() # not sure if this should be here or not

def game_Process(present_game_board, action):

    print('\n Move number: %d: Player playing %d, column on the board %d\n' % (present_game_board.pieces_played_count, present_game_board.whose_current_turn, action + 1))
    if present_game_board.whose_current_turn == 1:                #these statements determine who moves next
        present_game_board.whose_current_turn = 2
    elif present_game_board.whose_current_turn == 2:
        present_game_board.whose_current_turn = 1

    print('Game state after move:')
    present_game_board.printGame_Current_Board()

    present_game_board.calculate_Score()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (present_game_board.player_one_Score, present_game_board.player_two_Score))

    present_game_board.printGameBoardToFile()
    #present_game_board.game_file_name.close() # not sure if this should be here or not


def interactiveGame(present_game_board, intensity):
    # Fill me in

    while not present_game_board.pieces_played_count == 42:
        if present_game_board.whose_current_turn == 1:
            user_action = int(input("Enter the column [1-7] where you would like to play :  "))
            if not 0 < user_action < 8: 
                print("Invalid column number!")
                continue
            if not present_game_board.playPiece_Turn(user_action - 1):
                print("This column is full!")
                continue
            try:
                present_game_board.game_file_name = open("humanplayer.txt", "w")
            except:
                sys.exit("error opening the file")
            game_Process(present_game_board, user_action - 1)


        elif not present_game_board.pieces_played_count == 42:
            node_tree = node(present_game_board, intensity)
            action = node_tree.make_next_move_decision()
            result = present_game_board.playPiece_Turn(action)

            try:
                present_game_board.game_file_name = open("computerplayer.txt", "w")
            except:
                sys.exit("Error opening file")
            game_Process(present_game_board, action)

    present_game_board.game_file_name.close() # not sure if this should be here or not

    if present_game_board.player_one_Score > present_game_board.player_two_Score:
        print("Player 1 wins")
    elif present_game_board.player_two_Score > present_game_board.player_one_Score:
        print("Computer wins")
    else:
        print("Draw")

def main(argv):
    # Make sure we have enough command line arguments
    if len(argv) != 5:
        print('Four command-line arguments are needed:')
        print('Usage: %s interactive [input_file] [computer-next/human-next] [depth]' % argv[0])
        print('or: %s one-move [input_file] [output_file] [depth]' % argv[0])
        sys.exit(2)

    mode_of_game, myFile = argv[1:3]

    if not mode_of_game == 'interactive' and not mode_of_game == 'one-move':
        print('%s is an unrecognized game mode' % mode_of_game)
        sys.exit(2)

    present_game_board = maxConnect4Game() # Create a game

    # Try to open the input file
    try:
        present_game_board.game_file_name = open(myFile, 'r')
    except IOError:
        sys.exit("\nInput file is not present.\nCheck file name.\n")

    # Read the initial game state from the file and save in a 2D list
    file_lines = present_game_board.game_file_name.readlines()
    present_game_board.game_current_board = [[int(char) for char in line[0:7]] for line in file_lines[0:-1]]
    present_game_board.whose_current_turn = int(file_lines[-1][0])
    present_game_board.game_file_name.close()

    print('\nMaxConnect-4 game\n')
    print('Game state before move:')
    present_game_board.printGame_Current_Board()

    # Update a few game variables based on initial state and print the score
    present_game_board.checkPieceCount()
    present_game_board.calculate_Score()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (present_game_board.player_one_Score, present_game_board.player_two_Score))

    if mode_of_game == 'interactive':
        if argv[3] == 'computer-next':
            present_game_board.whose_current_turn = 2
        else:
            present_game_board.whose_current_turn = 1
        interactiveGame(present_game_board, argv[4]) # Be sure to pass whatever else you need from the command line
    else: # mode_of_game == 'one-move'
        # Set up the output file
        outFile = argv[3]
        try:
            present_game_board.game_file_name = open(outFile, 'w')
        except:
            sys.exit('Error opening output file.')
        oneMoveFunction(present_game_board, argv[4]) # Be sure to pass any other arguments from the command line you might need.


if __name__ == '__main__':
    main(sys.argv)



