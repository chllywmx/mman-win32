
from maxConnect4Game import *
import copy

def possibleMoves_func(board):
    possibleMoves = []
    for col, colVal in enumerate(board[0]):
        if colVal == 0:
            possibleMoves.append(col)
    return possibleMoves

def result(old_Game, column):
    new_Game = maxConnect4Game()

    try:
        new_Game.nodeDepth = old_Game.nodeDepth + 1
    except AttributeError:
        new_Game.nodeDepth = 1

    new_Game.pieces_played_count = old_Game.pieces_played_count
    new_Game.game_current_board = copy.deepcopy(old_Game.game_current_board)
    if not new_Game.game_current_board[0][column]:
        for i in range(5, -1, -1):
            if not new_Game.game_current_board[i][column]:
                new_Game.game_current_board[i][column] = old_Game.whose_current_turn
                new_Game.pieces_played_count += 1
                break

    if old_Game.whose_current_turn == 1:
        new_Game.whose_current_turn =2
    elif old_Game.whose_current_turn == 2:
        new_Game.whose_current_turn = 1


    new_Game.checkPieceCount()
    new_Game.calculate_Score()

    return new_Game


class node:
    def __init__(self, game, depth):
        self.whose_current_turn = game.whose_current_turn
        self.game = game
        self.maxDepth = int(depth)
    
    def make_next_move_decision(self):
        minVal = []
        possibleMoves = possibleMoves_func(self.game.game_current_board)

        for move in possibleMoves:
            result_move = result(self.game, move)
            minVal.append(self.minVal_func(result_move, 999, -999))

        chosen = possibleMoves[minVal.index(max(minVal))]
        
        return chosen



    def minVal_func(self, state, al, be):
        if state.pieces_played_count == 42 or state.nodeDepth == self.maxDepth:
            return self.miscellaneoua(state)
        v = 999

        for move in possibleMoves_func(state.game_current_board):
            new_State = result(state, move)

            v = min(v, self.maxVal_func(new_State, al, be))
            if v <= al:
                return v
            be = min(be, v)

        return v


    def maxVal_func(self, state, al, be):
        if state.pieces_played_count == 42 or state.nodeDepth == self.maxDepth:
            return self.miscellaneoua(state)
        
        v = -999

        for move in possibleMoves_func(state.game_current_board):
            new_State = result(state, move)

            v = max(v, self.minVal_func(new_State, al, be))
            if v >= be:
                return v
            al = max(al, v)

        return v

    
    def miscellaneoua(self, state):
        if self.whose_current_turn == 1:
            miscellaneoua = state.player_one_Score * 2 - state.player_two_Score
        elif self.whose_current_turn == 2:
            miscellaneoua = state.player_two_Score * 2 - state.player_one_Score

        return miscellaneoua




