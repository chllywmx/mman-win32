Brandon Stibich
1001290758
Python 3.10

I was not able to get Task 2 fuctioning so there will be no need to run it however this is the command I was using to run it
	maxconnect4.py one-move input2.txt green_next.txt 5
As an attempt for some partial credit however I will explain how I planned all that I had done so far.

First was creating a Node class (connect4_minimax_node) to be used in the minimax tree.
	It had some relavent information as well as parent and children
	Inside this class was the eval function (evalMove), which is admitely very simple albeit works correctly.
		What this did was clone the current game state and record the current score of both players
		It then performed the move asked and recorded the scores again
		If the player gained a point an eval score of 1 was awarded
		If the opponent gained a point an eval score of -1 was awarded
		If neither than 0
I also modified the countScore function so that it could be used to count the score without changing the current score of the game.

I understand the code that doesn't run is only graded up to 75% however I hope the work I did complete as well as my explanation 
	can garner me at least a few points.