Brandon Stibich
1001290758
Python 3.10
The code is structured as such
    classes.py - for the classes such as Path and Nodes
    find_route.py - the main driver program of the assignment
    uninformed_search.py - implementation of the uninformed search (using uniform cost search)
    informed_search.py - implementation of the informed search (using A* search)


for uninformed search the CMD command I used was
  py find_route.py <input.txt> <start> <goal>
ex: py find_route.py input1.txt Bremen Kassel

for uninformed search the CMD command I used was
  py find_route.py <input.txt> <start> <goal> <heuristic file>
ex: py find_route.py input1.txt Bremen Kassel h_kassel.txt
