from classes import *

def informed_search(paths, start, dest, heur):
    closed = []
    fringe = []
    route = []
    popped = 0
    expanded = 0
    generated = 0
    loops = 0
    curr = Node_i(start, 0, 0,None)
    while curr.city != dest:
        loops += 1
        if loops > 10000:
            print(dest, "Not Reached...")
            print("Popped: ", popped)
            print("Expanded: ", expanded)
            print("Generated: ", generated)
            print("Distance: infinity")
            print("Route: None")
            return route
        if curr not in closed:
            before = len(fringe)
            fringe = expand_node(curr, fringe, paths,heur, generated)
            generated += before
            expanded += 1
            fringe.sort(key=lambda x: x.fn)
            closed.append(curr)
            if fringe:
                curr = fringe.pop(0)
                popped += 1
            else:
                print("Search Failed")
                break
            if curr.city == dest:
                print(dest, "Reached!")
                print("Popped: ", popped)
                print("Expanded: ", expanded)
                print("Generated: ", generated)
                print("Distance: ", curr.gn)
                route = find_route(curr)
                print("Route: ")
                for node in route:
                    print(" ", node.city, "to")
                print(" ", curr.city)
                return route

def expand_node(curr, fringe, paths, heur ,generated):
    for path in paths:
        if path.src == curr.city:
            for h in heur:
                if h.city == curr.city:
                    curr_heur = h.hn
            new_node = Node_i(path.dest, (curr.gn + path.dist), curr_heur,  curr)
            curr.children.append(new_node)
            fringe.append(new_node)
            generated += 1
        elif path.dest == curr.city:
            for h in heur:
                if h.city == curr.city:
                    curr_heur = h.hn
            new_node = Node_i(path.src, (curr.gn + path.dist), curr_heur, curr)
            curr.children.append(new_node)
            fringe.append(new_node)
            generated += 1
    return fringe

def find_route(curr):
    route = []
    while curr.parent:
        curr = curr.parent
        route.append(curr)
    route.reverse()
    return route
