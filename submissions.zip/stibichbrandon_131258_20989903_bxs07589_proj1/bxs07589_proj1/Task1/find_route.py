import sys
from uninformed_search import *
from informed_search import *

def sort_input_paths(fname):
    list_of_paths = []
    with open(fname, 'r') as f:
        f_lines = f.readlines()
        for line in f_lines:
            x = line.split()
            if x[0] == "END":
                break
            list_of_paths.append(Path(x[0], x[1], x[2]))
    return list_of_paths

def sort_input_heur(fname):
    list_of_heruistics = []
    with open(fname, 'r') as f:
        f_lines = f.readlines()
        for line in f_lines:
            x = line.split()
            if x[0] == "END":
                break
            list_of_heruistics.append(Heuristic(x[0], x[1]))
    return list_of_heruistics


def main():
    paths = sort_input_paths((sys.argv[1]))

    if len(sys.argv) == 4:
        uninformed_search(paths, sys.argv[2], sys.argv[3])
    elif len(sys.argv) == 5:
        heur = sort_input_heur(sys.argv[4])
        informed_search(paths, sys.argv[2], sys.argv[3], heur)
    else:
        print("Invalid Input")


if __name__ == "__main__":
    main()
