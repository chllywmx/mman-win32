class Path:
    def __init__(self, src, dest, dist):
        self.src = src
        self.dest = dest
        self.dist = int(dist)

class Node_ui:
    def __init__(self, city, gn, parent):
        self.parent = parent
        self.children = []
        self.city = city
        self.gn = int(gn)
class Node_i:
    def __init__(self, city, gn, hn, parent):
        self.parent = parent
        self.children = []
        self.city = city
        self.gn = int(gn)
        self.hn = int(hn)
        self.fn = gn + hn

class Heuristic:
    def __init__(self,city, hn):
        self.city = city
        self.hn = int(hn)
