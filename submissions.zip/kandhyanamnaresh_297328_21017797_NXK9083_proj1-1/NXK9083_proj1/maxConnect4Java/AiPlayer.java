import java.util.*;

/**
 * This is the AiPlayer class.  It simulates a minimax player for the max
 * connect four game.
 * The constructor essentially does nothing. 
 * 
 * @author james spargo
 *
 */

public class AiPlayer 
{
    int states=42;
    /**
     * The constructor essentially does nothing except instantiate an
     * AiPlayer object.
     *
     */
    public AiPlayer(int depth) 
    {
	// nothing to do here
    }

    /**
     * This method plays a piece randomly on the board
     * @param currentGame The GameBoard object that is currently being used to
     * play the game.
     * @return an integer indicating which column the AiPlayer would like
     * to play in.
     */
    public int findBestPlay( GameBoard currentGame, int depth) 
    {
        // start random play code
	Random randy = new Random();
	int playChoice = 99;

	playChoice = randy.nextInt( 7 );

	while(!currentGame.isValidPlay( playChoice ))
	    playChoice = randy.nextInt( 7 );

	 //end random play code*/
    return playChoice;
    }
   
    public int Alpha_Beta(GameBoard currentGame, int alpha, int beta, int depth){
        return Max_Value(currentGame,alpha,beta,depth);
    }

    public int Utility(GameBoard currentGame)
    {
        int utility=0;
		if(currentGame.getScore(1) < currentGame.getScore(2)) 
        {
			utility=Integer.MIN_VALUE;
			return utility;
		}
		else if(currentGame.getScore(2) < currentGame.getScore(1)) {
			utility=Integer.MAX_VALUE;
			return utility;
		}
		else {
			return utility;
		}
	}
    public int Eval_Function(GameBoard currentGame)
    {
        int eval_fun=currentGame.getScore(1)-currentGame.getScore(2);
        return eval_fun;
    }
  
    public int Min_Value(GameBoard currentGame,int alpha, int beta, int depth)
    {  
        if(currentGame.getPieceCount()==states)
        return Utility(currentGame);
        if(depth!=0)
        {
            int i=0, value=Integer.MAX_VALUE;
            while(i<7)
                {
                    value=Math.min(value,Max_Value(currentGame,alpha,beta,depth-1));
                
                    if(alpha <= value)
                    {
                        return value;
                    }
                    beta=Math.min(beta,value);
                    i++;
                }
            return value;
        }
        else
        {
            return Eval_Function(currentGame);
        }
    }
  
    public int  Max_Value(GameBoard currentGame, int alpha, int beta, int depth)
    {
       if(currentGame.getPieceCount()==states) 
        {
            return Utility(currentGame);
        }
       if(depth!=0)
        {
                int i=0, value=Integer.MIN_VALUE;
            while(i<7)
                {
                    value=Math.max(value,Min_Value(currentGame,alpha,beta,depth-1));
                    if(beta<=value)
                    {
                        return value;
                    }
                    alpha = Math.max(alpha, value);
                    i++;
                }
                return value;
        }
        else
        {
            return Eval_Function(currentGame);
        }   
    }

}
