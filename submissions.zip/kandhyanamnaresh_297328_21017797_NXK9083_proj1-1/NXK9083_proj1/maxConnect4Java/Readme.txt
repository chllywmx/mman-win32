Name:Naresh Kandhyanam
UTA ID:1002039083

Programming Language: Java


Code Structure:

Class maxconnect4 :
Provides best move if it is computer chance to play in both interactive and one-move mode. Asks to enter column number if it is a human chance.

Class GameBoard:
GameBoard class create a new gameboard and updates its state. Print the states before ad after move.


Class AiPlayer :
This class has AlphaBeta algorithm which returns the value returned by  Max_Value method.
When game reaches terminal node Min_Value and Max_Value functions returns Utility value return by Utility function.
When depth is not equal to Zero Min_value and Max_value functions are invoked recursively. 

Process to Compile and Run Program:

1.Compile the program by using below command
    javac  maxconnect.java GameBoard.java AiPlayer.java

2.Run the program by using below commands according to the move.
    One move mode: java maxconnect4 one-move input1.txt output.txt 2
I   nteractive mode: java maxconnect4 interactive input1.txt computer-next 2

To calculate runtime: time java maxconnect4 one-move input1.txt output.txt 2

Reffered links:

https://www.mkyong.com/java/how-to-read-input-from-console-java/
https://www.mkyong.com/java/how-to-loop-arraylist-in-java/
https://crystal.uta.edu/~gopikrishnav/classes/common/4308_5360/slides/Game_Search.pdf