/*Name: Naresh Kandhyanam
 UTA ID:1002039083
 
*/
import java.util.*;
import java.io.*;

public class find_route
{
	int nodesPopped=0;
	int nodesExpanded=0;
	int nodesGenerated=0;
	Node goalNode;
	boolean routeExists=false;

class Node{
	String cityName;
	Node parentNode;
	double pathCost; //g(n)
	double heuristicCost; //h(n)
	// Parametered constructor for Uninformed Search(UCS)
	Node(String cityName, Node parentNode, double pathCost){
		this.cityName=cityName;
		this.parentNode=parentNode;
		this.pathCost=pathCost;
	}
	//Parametered Constructor for Informed Search(A*)
	Node(String cityName, Node parentNode, double pathCost, double heuristicCost){
		this.cityName=cityName;
		this.parentNode=parentNode;
		this.pathCost=pathCost;  
		this.heuristicCost=heuristicCost; 
	}
}

//Comparator interface implementations UFCS and IFS for comparing two nodes 

Comparator<Node> UISNodeComparator = new Comparator<Node>()
{  
	@Override
	public int compare(Node Node1, Node Node2) 
	{
		if(Node1.pathCost>Node2.pathCost) return 1;
		
		else if(Node1.pathCost<Node2.pathCost) return -1;
		
		else return 0;
	}
};

Comparator<Node> IFSNodeComparator= new Comparator<Node>()
{
	@Override
	public int compare(Node Node1, Node Node2) 
	{
		if(Node1.heuristicCost>Node2.heuristicCost) return 1;
		else if (Node1.heuristicCost<Node2.heuristicCost) return -1;
		else return 0;
	}
};

HashMap<String, List<String[]>> ufs_map = new HashMap<String, List<String[]>>();

    private void parseInputFile(String input_filename) {
        File inputFile = new File(input_filename);
        BufferedReader br = null;
        try 
        { 
            br = new BufferedReader(new FileReader(inputFile.getPath()));
            String line_content;
			int i;
			String temp;
            while((line_content=br.readLine())!=null) 
            {   
				if(line_content.equals("END OF INPUT"))
				{
					break;
				}
				else
				{
					String[] tempArr=line_content.split(" "); //Temp string Array to store values after splitting with delimiter " "
					String origin_city = tempArr[0];
					String destination_city = tempArr[1];
					String distance = tempArr[2];
					for(i=0;i<=1;i++)
					{
						String[] valArr = {destination_city, distance};
						if(!ufs_map.containsKey(origin_city))   
						{
							List<String[]> inpArr = new ArrayList<String[]>(); 
							inpArr.add(valArr);
							ufs_map.put(origin_city, inpArr);
						}
						else
						{
							ufs_map.get(origin_city).add(valArr);
						}
						temp=origin_city;
						origin_city=destination_city;
						destination_city=temp;
					}
				}
            }
        } 
        catch (FileNotFoundException ex) 
        {
            System.out.println("Input file with the provided name is not found");
        } 
        catch (IOException ex) 
        {
            ex.printStackTrace();
        } 
        finally 
        {
            try 
            {
				if(br!=null)
                	br.close();
            } 
            catch (IOException ex) 
            {
                ex.printStackTrace();
            }
        }
    }
	
	HashMap<String, Double> ifs_map = new HashMap<String, Double>();
	private void parseHeuriFile(String heuristic_filename) 
	{
		File inputFile = new File(heuristic_filename);
		BufferedReader br = null;
	    try 
	    {
	        br = new BufferedReader(new FileReader(inputFile.getPath()));
	        String line_content;
	        while((line_content=br.readLine())!=null)
			{
				if(line_content.equals("END OF INPUT"))
				{
					break;
				}
				else
				{
				String[] tempArr=line_content.split(" "); //Temp string Array to store values after splitting with delimiter " "
	            String cityName = tempArr[0]; 
	            String heuristicCostvalue = tempArr[1]; //heuristic cost 
	            Double k= Double.parseDouble(heuristicCostvalue);
	            ifs_map.put(cityName,k);
				}
	        }
	    } 
	    catch (FileNotFoundException ex) 
	    {
	        System.out.println("Heuristic file not found");
	    } 
	    catch (IOException ex) 
	    {
	        ex.printStackTrace();
	    } 
	    finally 
	    {
	        try 
	        {	
				if(br!=null)
		            br.close();
	        } 
	        catch (IOException ex) 
	        {
	            ex.printStackTrace();
	        }
	    }
	}
	
	
	private void UFCS(String inp_filename, String src, String dest) 
	{	
		double cumCost=0;//cumulative cost of all nodes from root
		parseInputFile(inp_filename);
		PriorityQueue<Node> fringe= new PriorityQueue<Node>(10,  UISNodeComparator);
		Set<String> closedSet=new HashSet<String>();
		//System.out.println(fringe.size());
		fringe.add(new Node(src, null, 0));
		nodesGenerated++;
		try
		{
		while(fringe.size()!=0) 
		{
			Node currentNode=fringe.poll();
			if(!currentNode.cityName.equals(dest) && closedSet.contains(currentNode.cityName))
				{ 
					nodesPopped++;
				}
			else if(!currentNode.cityName.equals(dest) && !closedSet.contains(currentNode.cityName))
				{
					for (String[] strArray : ufs_map.get(currentNode.cityName)) 
					{
					cumCost=currentNode.pathCost + Double. parseDouble(strArray[1]); 
					//System.out.println(cumCost); 
					Node nodeP = new Node(strArray[0], currentNode, cumCost);
					fringe.add(nodeP);	
					nodesGenerated++;
					}
					closedSet.add(currentNode.cityName);
					nodesExpanded++;
					nodesPopped++;
					
				}
					
			else
			{
				routeExists=true;
				goalNode=currentNode;
				nodesPopped++;
				break;
			}
		}
	}
	catch(NullPointerException ex)
	{
		System.out.println("Please check the input arguments provided.\n");
		ex.printStackTrace();
	}
		OutPut();
	}
	
	private void IFS(String input_filename, String src, String dest, String heuristic_filename)
	{
		double cumCost=0;  //cumulative cost
		double f=0; //f(x)=g(x)+h(x)
		parseInputFile(input_filename);
		parseHeuriFile(heuristic_filename);
		PriorityQueue<Node> fringe= new PriorityQueue<Node>(10, IFSNodeComparator);
		Set<String> closedSet=new HashSet<String>();
		fringe.add(new Node(src, null, 0, ifs_map.get(src)));
		nodesGenerated++;
		try{
			while(fringe.size()!=0)
		    {
		    	Node currentNode = fringe.poll();
		    	if(!currentNode.cityName.equals(dest) && closedSet.contains(currentNode.cityName))
				{ 
		    		nodesPopped++; 
		    	}
				
				else if(!currentNode.cityName.equals(dest) && !closedSet.contains(currentNode.cityName))
		    	{
		    		for (String[] strArray : ufs_map.get(currentNode.cityName)) 
		    		{
		    		 cumCost=currentNode.pathCost + Double. parseDouble(strArray[1]); 
		    		 f=cumCost+ifs_map.get(strArray[0]);	
					 //System.out.println(cumCost+":"+f); 
                 	 Node nodeP = new Node(strArray[0], currentNode,cumCost, f);
		   			 fringe.add(nodeP);	
		   			 nodesGenerated++;
		    		}
					closedSet.add(currentNode.cityName);
					nodesExpanded++;
		    		nodesPopped++;
		    	}
				else
		    	{   
		    		routeExists=true;
		    		goalNode=currentNode;
		    		nodesPopped++;
					break;
		    	}
			}
		}
			 catch (NullPointerException ex) {
				System.out.println("Please check the input arguments provided.\n");
				ex.printStackTrace();
			}
		    
		OutPut();
		}

	
	private void OutPut() 
	{
		  if(routeExists==false)
		  {
			  System.out.println("Nodes Popped: "+nodesPopped);
			  System.out.println("Nodes Expanded: "+nodesExpanded);
			  System.out.println("Nodes Generated: "+nodesGenerated);
			  System.out.println("Distance: infinity");
			  System.out.println("Route:\nNone");
		  }
		  else
		  {
			double tot_dist=goalNode.pathCost;
			int i,size=0;
			List<String> route_List= new ArrayList<String>();
			while(goalNode.parentNode!=null)
			{
			  route_List.add(goalNode.parentNode.cityName + " to " + goalNode.cityName + ", "+(goalNode.pathCost-goalNode.parentNode.pathCost) +" km");
			  goalNode=goalNode.parentNode;
			 
			}
			System.out.println("Nodes Popped: "+nodesPopped);
			System.out.println("Nodes Expanded: "+nodesExpanded);
			System.out.println("Nodes Generated: "+nodesGenerated);
			System.out.println("Distance: "+tot_dist+"km");
			System.out.println("Route:");
			size=route_List.size();
			for(i=size;i>0;i--)
			{
				System.out.println(route_List.get(i-1));
				
			}
		}
		  
	}
	
	public static void main(String[] args) 
	{
		find_route findroute = new find_route();
		if(args.length == 3 && (args[0]!=null || args[0]!="")  && (args[1]!=null || args[1]!="")  && (args[2]!=null || args[2]!=""))
		{
			findroute.UFCS(args[0], args[1], args[2]);
		}
		else if(args.length == 4 && (args[0]!=null || args[0]!="") && (args[1]!=null || args[1]!="") && (args[2]!=null || args[2]!="") && (args[3]!=null || args[3]!=""))
		{
	        findroute.IFS(args[0], args[1], args[2], args[3]);
		}
		else 
		{
	        System.out.println("");
	    }	
	}
}
	