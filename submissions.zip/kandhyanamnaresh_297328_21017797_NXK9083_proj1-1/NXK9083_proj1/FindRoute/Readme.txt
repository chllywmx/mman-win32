Name: Naresh Kandhyanam
UTA ID:1002039083


Programming Language Used: Java

Code Structure:
1. Input is provided as string arguments to execute.
2.Based on the number of input arguments a serach alogorithm is invoked.
    If 3 arguments are passed as an input with input1.txt Uninformed search (UCS)is invoked.
    If 4 arguments are passed as an input with input1.txt and heristic file Informed search algorithm is invoked 
3. Node class is created for creatig nodes and Parameter constructor is defined for both Uninformed and Informed searches.
4.Comparator inerafce implemented compares two nodes
5. ParseInputFile parse the input file. bufferedreader is used to read input filecontent and maps city with destination and distance using Haspmap
6. ParseHeurifile parses the heuristic file. BufferedReader is used to read file contents and maps cities with thier heuristic values using Hashmap<String,Double>.

Uinformed Cost Search:
1.PriorityQueue is used to create a fringe which implements UFSnodecomparator and store nodes in the frings based on their pathcost.
2.If a new node is expanded it gets added to closed set which is created using a hashset.
3.If a node is already available in closedset algorithm will just pop node form fringe.
4.The process is repeated till the desired path is found or fringe is empty.
5. Output method is used to print the output such as route, nodesexpanded, nodesgenerated, nodesPopped, Distance and Path from start node to goal node.

Informed search:
1.PriorityQueue is used to create a fringe which implements IFSnodecomparator and store nodes in the frings based on their pathcost.
2.If a new node is expanded it gets added to closed set which is created using a hashset.
3.If a node is already available in closedset algorithm will just pop node form fringe.
4.The process is repeated till the desired path is found or fringe is empty.
5. Output method is used to print the output such as route, nodesexpanded, nodesgenerated, nodesPopped, Distance and Path from start node to goal node.


Process to execute Program.
___________________________

Command to compile the program.

javac find_route.java

Command to run the the program.

Uninformed Search:

    java find_route input_filename origin_city destination_city 
    Eg: java find_route input1.txt Bremen Kassel

For Informed search:

	java find_route input_filename origin_city destination_city heuristic_filename 
	Example: java find_route input1.txt Bremen Kassel h_kassel.txt 


Note: Before executing the program please make sure to put the input files(input file & heuristic file) in project directory.



References:

https://www.geeksforgeeks.org/priority-queue-class-in-java/
https://www.guru99.com/buffered-reader-in-java.html
https://javarevisited.blogspot.com/2014/01/java-comparator-example-for-custom.html
https://www.geeksforgeeks.org/java-util-hashmap-in-java-with-examples/

