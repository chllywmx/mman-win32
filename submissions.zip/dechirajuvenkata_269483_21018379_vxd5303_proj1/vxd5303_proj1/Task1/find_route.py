importing the  sys                          #importing the  system library to access txt files
from queue importing the  PriorityQueue     #importing the  Priority queue for uniform cost search	



def text_file_loading(textinput):
    tree = {}
    heuristic = {}
    if textinput == sys.argv[1]:
        readFile = open(textinput, 'r')
        text = readFile.readlines()
        readFile.close()
        for lines in text[:-1]:
            node = lines.split()
            if(node[0] in tree):
                tree[node[0]].append((int(node[2]), node[1]))
            else:
                tree[node[0]] = [(int(node[2]), node[1])]
            if(node[1] in tree):
                tree[node[1]].append((int(node[2]), node[0]))
            else:
                tree[node[1]] = [(int(node[2]), node[0])]
        return tree
    
    elif textinput == sys.argv[4]:
        readFile = open(textinput,'r')
        text = readFile.readlines()
        readFile.close()
        for lines in text[:-1]:
            node = lines.split()
            heuristic[node[0]] = int(node[1])
        return heuristic

#UCS
def ucs_func(tree_search, source, destination):
    no_of_nodes_popped = 0
    no_of_nodes_expanded = 0
    no_of_nodes_generated = 1 
    nodes_closed = []
    fringe = PriorityQueue()
    fringe.put([0, source])
    while not fringe.empty():
        positions = fringe.get()
        no_of_nodes_popped += 1
        if positions[-1] == destination:
            return no_of_nodes_popped, no_of_nodes_expanded, no_of_nodes_generated, positions
        else:
            if positions[-1] not in nodes_closed:
                nodes_closed.append(positions[-1])
                no_of_nodes_expanded += 1
                for x in tree_searh[positions[-1]]:
                    no_of_nodes_generated += 1
                    fringe.put([positions[0]+x[0], positions[1:], x[1]])
    return no_of_nodes_popped, no_of_nodes_expanded, no_of_nodes_generated, None

 
def search_all_star(search_tree, source, destination, heuristic):
    no_of_nodes_popped = 0
    no_of_nodes_expanded = 0
    no_of_nodes_generated = 1 
    nodes_closed = []
    fringe = PriorityQueue()
    fringe.put([0, source])
    while not fringe.empty():
        positions = fringe.get()
        no_of_nodes_popped += 1                            
        if positions[-1] == destination:
            return no_of_nodes_popped, no_of_nodes_expanded, no_of_nodes_generated, positions
        else:
            if positions[-1] not in nodes_closed:
                nodes_closed.append(positions[-1])
                no_of_nodes_expanded += 1                  
                for m in search_tree[positions[-1]]:
                    no_of_nodes_generated += 1
                    fringe.put([m[0] + heuristic[m[1]], positions[1:], m[1]])
    return no_of_nodes_popped, no_of_nodes_expanded, no_of_nodes_generated, None

list_of_routes = []
def routes_list(route_1):
	for m in route_1:
		if type(m) == list:
			routes_list(m)
		else:
			list_of_routes.append(m)
	return list_of_routes

 
if len(sys.argv) == 4:
    buildTree = text_file_loading(sys.argv[1])
    source = sys.argv[2]
    destination = sys.argv[3]
    no_of_nodes_popped, no_of_nodes_expanded, no_of_nodes_generated, routes = ucs_func(buildTree, source, destination)

 
elif len(sys.argv) == 5:
    print("Using Heuristic")
    buildTree = text_file_loading(sys.argv[1])
    source = sys.argv[2]
    destination = sys.argv[3]
    heuristic = text_file_loading(sys.argv[4])
    no_of_nodes_popped, no_of_nodes_expanded, no_of_nodes_generated, routes = search_all_star(buildTree, source, destination, heuristic)

else:
    print("Given were wrong arguments, Please pass the right number of arguments\n")


no_of_nodes_popped
print("Nodes Popped: " + str(no_of_nodes_popped))
print("Nodes Expanded: " + str(no_of_nodes_expanded))
print("Nodes Generated: " + str(no_of_nodes_generated))

if routes != None:  
    dist_traversed_sum = 0
    list_of_routes = routes_list(routes[1])
    list_of_routes.append(routes[2])
    for m in range(len(list_of_routes) - 1):
        for n in buildTree[list_of_routes[m]]:
            if(n[1] == list_of_routes[m + 1]):
                distrance = n[0]
                dist_traversed_sum += distrance;
    print("Distance: " + str(float(dist_traversed_sum)) + " km")
    print('Route: ')
    for m in range(len(list_of_routes) - 1):
        for n in buildTree[list_of_routes[m]]:
            if(n[1] == list_of_routes[m + 1]):
                distrance = n[0]
                dist_traversed_sum += distrance;
        print(str(list_of_routes[m]) + " to "+  str(list_of_routes[m + 1]) + ", " + str(float(distrance)) + " km")
else:
    print('Distance is NA')
    print('No route found')
