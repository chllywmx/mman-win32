Task1

Name: Venkata Krishna Rohith Dechiraju
UTA ID: 1001955303

Programming Language used: 'Python' 3

Code Structure: This code is structured as functions for informed and UCS, it will be executed in the order in which the inputs are provided.
Heuristic is specified, the program will have to perform an uninformed search. 
UCS has been implemented for uninformed search, and A* Search has been implemented for informed search algorithms.

Instructions to run the code:

Command to use:
python find_route.py <input_file.txt> <source> <destination>

Example:
python find_route.py input1.txt London Kassel