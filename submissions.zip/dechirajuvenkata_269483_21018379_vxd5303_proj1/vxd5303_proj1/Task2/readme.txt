Task2

Name: Venkata Krishna Rohith Dechiraju
UTA ID: 1001955303

Programming Language used: Python 3

Instructions to run the code:

1. Interactive Mode

python maxconnect4.py interactive inputfile.txt computer-next/human-next depth_level

Example: 
python maxconnect4.py interactive input1.txt computer.txt 3



2. One-Move Node

python maxconnect4.py one-move inputfile.txt outputfile.txt depth_level

Example: 
python maxconnect4.py one-move input1.txt output.txt 3

We have added the time recording code from cmd before entering the input as below 

@echo off
set startTime=%time%
java maxconnect4 one-move red_next.txt green_next.txt 10
echo Start Time: %startTime%
echo Finish Time: %time%

then we have found the difference between times, that will be the time taken.