import sys 
from MaxConnect4Game import MaxConnect4game       

def human_play(gme_brd):     
    while gme_brd.getPieceCount() != 42:  
        print("~~ Human's turn ~~") 
        print(" ~~~~~~~~~~~~~~~~~~")
        UsersMove = int(input("Enter a column number (1-7) - ")) 
        if not 0 < UsersMove < 8:    
            print("Column invalid! Try Again.")
            continue
        
        if not gme_brd.playPiece(UsersMove - 1):
            print("Column Number - %d is full. Try Other Column." % UsersMove)
            continue
        
        print("Your made move - " + str(UsersMove))
        gme_brd.displayGB()   
        gme_brd.gameFile = open("human.txt", 'w')  
        gme_brd.printGameBoardToFile()
        gme_brd.gameFile.close()  
        
        if gme_brd.getPieceCount() == 42:    
            print("No more moves possible, Game Over!")
            gme_brd.scoreCount()  
            print('Score :: PlayerA = %d, PlayerB = %d\n' % (gme_brd.player1Score, gme_brd.player2Score))
            break
        else: 
            print("Computer is computing based on next " + str(gme_brd.depth) + " steps...")
            gme_brd.changeMove() 
            gme_brd.aiPlay() 
            gme_brd.displayGB()  
            gme_brd.gameFile = open('computer.txt', 'w')  
            gme_brd.printGameBoardToFile()
            gme_brd.gameFile.close() 
            gme_brd.scoreCount() 
            print('Score :: PlayerA = %d, PlayerB = %d\n' % (gme_brd.player1Score, gme_brd.player2Score))

def interactive_mode(gme_brd, next_player):   
    print('Current Board State')
    gme_brd.displayGB()  
    gme_brd.scoreCount() 
    print('Score: PlayerA = %d, PlayerB = %d\n' % (gme_brd.player1Score, gme_brd.player2Score))
    
    if next_player == 'human-next':  
        human_play(gme_brd)   
    else:
        gme_brd.aiPlay() 
        gme_brd.gameFile = open('computer.txt', 'w')  
        gme_brd.printGameBoardToFile()
        gme_brd.gameFile.close() 
        gme_brd.displayGB()  
        gme_brd.scoreCount() 
        print('Score: PlayerA = %d, PlayerB = %d\n' % (gme_brd.player1Score, gme_brd.player2Score))
        human_play(gme_brd)   

    if gme_brd.getPieceCount() == 42:
        if gme_brd.player1Score > gme_brd.player2Score:
            print("Player 1 WINS")
        if gme_brd.player1Score == gme_brd.player2Score:
            print("The game is a TIE")
        if gme_brd.player1Score < gme_brd.player2Score:
            print("Player 2 WINS")
        print("Game Over!!!")


def one_move_mode(gme_brd):    
    if gme_brd.pieceCount >= 42: 
        print('Game board is full !\n Game Over...')
        sys.exit(0)

    print ('GameBoard state before move:')
    gme_brd.displayGB()  
    gme_brd.aiPlay()

    print ('GameBoard state after move:')
    gme_brd.displayGB()   
    gme_brd.scoreCount() 
    
    print('Score: PlayerA = %d, PlayerB = %d\n' % (gme_brd.player1Score, gme_brd.player2Score))
    gme_brd.printGameBoardToFile()    
    gme_brd.gameFile.close()     


def main(argv): 
    gme_brd = MaxConnect4game()  
    try:
        gme_brd.gameFile = open(argv[2], 'r')    
        fileLines = gme_brd.gameFile.readlines()
        gme_brd.GameBoard = [[int(char) for char in line[0:7]] for line in fileLines[0:-1]]
        gme_brd.currentMove = int(fileLines[-1][0])
        gme_brd.gameFile.close()
    except:
        print('File Not Found, Start New Game.')
        gme_brd.currentMove = 1
    gme_brd.checkPieceCount()    
    gme_brd.depth = argv[4]   
    if argv[1] == 'one-move':
        try:
            gme_brd.gameFile = open(argv[3], 'w')
        except:
            sys.exit('Error Opening Output File.')
        one_move_mode(gme_brd)
    else:  
        interactive_mode(gme_brd, argv[3])


if __name__ == '__main__':
    main(sys.argv)
