'''

MaxConnect4Game.py contains the minmax, alpha , beta and eval functions. 
It also contains the required functions to calculate the quadraples

'''
import copy                 
import random
import sys                  

util_value = {}              
infi = float('inf')      

class MaxConnect4game:        
    def __init__(self):      
        self.gameboard = [[0 for i in range(7)] for j in range(6)]
        self.current_turn = 0
        self.pieceCount = 0
        self.score_player1 = 0
        self.score_player2 = 0
        self.gameFile = None
        self.computerColumn = None
        self.depth = 1

    def get_piece_count(self):                   
        return sum(1 for row in self.gameboard for piece in row if piece)

    def checkPieceCount(self):                  
        self.pieceCount = sum(1 for row in self.gameboard for piece in row if piece)



    def displayGB(self):          
        print(' -----------------')
        for i in range(6):
            print(' |'),
            for j in range(7):
                print('%d' % int(self.gameboard[i][j])),
            print('| ')
        print(' -----------------')
        
        
    def playPiece(self, column):               
        if not self.gameboard[0][column]:
            for i in range(5, -1, -1):
                if not self.gameboard[i][column]:
                    self.gameboard[i][column] = self.current_turn
                    self.pieceCount += 1
                    return 1

    def printGameBoardToFile(self):              
        for row in self.gameboard:
            self.gameFile.write(''.join(str(col) for col in row) + '\r')
        self.gameFile.write('%s\r' % str(self.current_turn))

    

    def checkPiece(self, column, opponent):    
        if not self.gameboard[0][column]:
            for i in range(5, -1, -1):
                if not self.gameboard[i][column]:
                    self.gameboard[i][column] = opponent
                    self.pieceCount += 1
                    return 1

    def value_maximum(self, node_current):             
        node = copy.deepcopy(node_current)
        node_child = []
        for i in range(7):
            state_current = self.playPiece(i)
            if state_current != None:
                node_child.append(self.gameboard)
                self.gameboard = copy.deepcopy(node)
        return node_child

    def value_minimum(self, node_current):            
        node = copy.deepcopy(node_current)
        if self.current_turn == 1:
            opponent = 2
        elif self.current_turn == 2:
            opponent = 1
        node_child = []
        for i in range(7):
            state_current = self.checkPiece(i, opponent)
            if state_current != None:
                node_child.append(self.gameboard)
                self.gameboard = copy.deepcopy(node)
        return node_child

    def alpha_beta_maximum(self, node_current, alpha, beta, depth): 
        value = -infi
        node_child = self.value_maximum(node_current)
        if node_child == [] or depth == 0:
            self.scoreCount()
            return self.claculation_evaluation(self.gameboard)
        else:
            for node in node_child:
                self.gameboard = copy.deepcopy(node)
                value = max(value, self.beta_alpha(node, alpha, beta, depth - 1))
                if value >= beta:
                    return value
                alpha = max(alpha, value)
            return value

    def beta_alpha(self,node_current, alpha, beta, depth): 
        value = infi
        node_child = self.value_minimum(node_current)
        if node_child == [] or depth == 0:
            self.scoreCount()
            return self.claculation_evaluation(self.gameboard)
        else:
            for node in node_child:
                self.gameboard = copy.deepcopy(node)
                value = min(value, self.alpha_beta_maximum(node, alpha, beta, depth - 1))
                if value <= alpha:
                    return value
                beta = min(beta, value)
        return value

    def minimum_maximum(self, depth):
        state_current = copy.deepcopy(self.gameboard)
        for i in range(7):
            if self.playPiece(i) != None:
                if self.pieceCount == 42 or self.depth == 0:
                    self.gameboard = copy.deepcopy(state_current)
                    return i
                else:
                    val = self.beta_alpha(self.gameboard, -infi, infi, depth - 1)
                    util_value[i] = val
                    self.gameboard = copy.deepcopy(state_current)
        utility_maximum_value = max([i for i in util_value.values()])
        for i in range(7):
            if i in util_value:
                if util_value[i] == utility_maximum_value:
                    util_value.clear()
                    return i

    def Check_vertical(self, row, column, state, streak): 
        count_consec = 0
        for i in range(row, 6):
            if state[i][column] == state[row][column]:
                count_consec += 1
            else:
                break
        if count_consec >= streak:
            return 1
        else:
            return 0

    def check_horizontal(self, row, column, state, streak): 
        count = 0
        for j in range(column, 7):
            if state[row][j] == state[row][column]:
                count += 1
            else:
                break
        if count >= streak:
            return 1
        else:
            return 0

    def diagonalCheck(self, row, column, state, streak): 
        total = 0
        count = 0
        j = column
        for i in range(row, 6):
            if j > 6:
                break
            elif state[i][j] == state[row][column]:
                count += 1
            else:
                break
            j += 1
        if count >= streak:
            total += 1
        count = 0
        j = column
        for i in range(row, -1, -1):
            if j > 6:
                break
            elif state[i][j] == state[row][column]:
                count += 1
            else:
                break
            j += 1
        if count >= streak:
            total += 1
        return total

    def calc_streak(self, state, color, streak): 
        count = 0
        for i in range(6):
            for j in range(7):
                if state[i][j] == color:
                    count += self.Check_vertical(i, j, state, streak)
                    count += self.check_horizontal(i, j, state, streak)
                    count += self.diagonalCheck(i, j, state, streak)
        return count

    def playerEvalCalculation(self, state): 
        playerFours = self.calc_streak(state, self.current_turn, 4)
        playerThrees = self.calc_streak(state, self.current_turn, 3)
        playerTwos = self.calc_streak(state, self.current_turn, 2) 
        return (playerFours * 37044 + playerThrees * 882 + playerTwos * 21)

    def evalFunction(self):            
        if self.current_turn == 1:
            oneMoveColor = 2
        elif self.current_turn == 2:
            oneMoveColor = 1
        return oneMoveColor

    def compEvalCalculation(self, state):        
        oneMoveColor = self.evalFunction()
        compFours = self.calc_streak(state, oneMoveColor, 4)
        compThrees = self.calc_streak(state, oneMoveColor, 3)
        compTwos = self.calc_streak(state, oneMoveColor, 2)
        return (compFours * 37044 + compThrees * 882 + compTwos * 21)

    def claculation_evaluation(self, state):    
        return self.playerEvalCalculation(state) - self.compEvalCalculation(state)

    def changeMove(self):      
        if self.current_turn == 1:
            self.current_turn = 2
        elif self.current_turn == 2:
            self.current_turn = 1

    def aiPlay(self):            
        randomCol = self.minimum_maximum(int(self.depth))
        result = self.playPiece(randomCol)
        if not result:
            print('No Result')
        else:
            print('Player: %d, Column: %d\n' % (self.current_turn, randomCol + 1))
            self.changeMove()

    def scoreCount(self):                      
        self.score_player1 = 0;
        self.score_player2 = 0;

        # Check horizontal 
        
        for row in self.gameboard:
            
            # Check player 1
            
            if row[0:4] == [1] * 4:
                self.score_player1 += 1
            if row[1:5] == [1] * 4:
                self.score_player1 += 1
            if row[2:6] == [1] * 4:
                self.score_player1 += 1
            if row[3:7] == [1] * 4:
                self.score_player1 += 1
            
            # Check player 2
            
            if row[0:4] == [2] * 4:
                self.score_player2 += 1
            if row[1:5] == [2] * 4:
                self.score_player2 += 1
            if row[2:6] == [2] * 4:
                self.score_player2 += 1
            if row[3:7] == [2] * 4:
                self.score_player2 += 1
        
        # Check vertical 
        
        for j in range(7):
            
            # Check player 1
            
            if (self.gameboard[0][j] == 1 and self.gameboard[1][j] == 1 and
                    self.gameboard[2][j] == 1 and self.gameboard[3][j] == 1):
                self.score_player1 += 1
            if (self.gameboard[1][j] == 1 and self.gameboard[2][j] == 1 and
                    self.gameboard[3][j] == 1 and self.gameboard[4][j] == 1):
                self.score_player1 += 1
            if (self.gameboard[2][j] == 1 and self.gameboard[3][j] == 1 and
                    self.gameboard[4][j] == 1 and self.gameboard[5][j] == 1):
                self.score_player1 += 1
            
            # Check player 2
            
            if (self.gameboard[0][j] == 2 and self.gameboard[1][j] == 2 and
                    self.gameboard[2][j] == 2 and self.gameboard[3][j] == 2):
                self.score_player2 += 1
            if (self.gameboard[1][j] == 2 and self.gameboard[2][j] == 2 and
                    self.gameboard[3][j] == 2 and self.gameboard[4][j] == 2):
                self.score_player2 += 1
            if (self.gameboard[2][j] == 2 and self.gameboard[3][j] == 2 and
                    self.gameboard[4][j] == 2 and self.gameboard[5][j] == 2):
                self.score_player2 += 1
        
        # Check diagonal 
        
        # Check player 1
        
        if (self.gameboard[2][0] == 1 and self.gameboard[3][1] == 1 and
                self.gameboard[4][2] == 1 and self.gameboard[5][3] == 1):
            self.score_player1 += 1
        if (self.gameboard[1][0] == 1 and self.gameboard[2][1] == 1 and
                self.gameboard[3][2] == 1 and self.gameboard[4][3] == 1):
            self.score_player1 += 1
        if (self.gameboard[2][1] == 1 and self.gameboard[3][2] == 1 and
                self.gameboard[4][3] == 1 and self.gameboard[5][4] == 1):
            self.score_player1 += 1
        if (self.gameboard[0][0] == 1 and self.gameboard[1][1] == 1 and
                self.gameboard[2][2] == 1 and self.gameboard[3][3] == 1):
            self.score_player1 += 1
        if (self.gameboard[1][1] == 1 and self.gameboard[2][2] == 1 and
                self.gameboard[3][3] == 1 and self.gameboard[4][4] == 1):
            self.score_player1 += 1
        if (self.gameboard[2][2] == 1 and self.gameboard[3][3] == 1 and
                self.gameboard[4][4] == 1 and self.gameboard[5][5] == 1):
            self.score_player1 += 1
        if (self.gameboard[0][1] == 1 and self.gameboard[1][2] == 1 and
                self.gameboard[2][3] == 1 and self.gameboard[3][4] == 1):
            self.score_player1 += 1
        if (self.gameboard[1][2] == 1 and self.gameboard[2][3] == 1 and
                self.gameboard[3][4] == 1 and self.gameboard[4][5] == 1):
            self.score_player1 += 1
        if (self.gameboard[2][3] == 1 and self.gameboard[3][4] == 1 and
                self.gameboard[4][5] == 1 and self.gameboard[5][6] == 1):
            self.score_player1 += 1
        if (self.gameboard[0][2] == 1 and self.gameboard[1][3] == 1 and
                self.gameboard[2][4] == 1 and self.gameboard[3][5] == 1):
            self.score_player1 += 1
        if (self.gameboard[1][3] == 1 and self.gameboard[2][4] == 1 and
                self.gameboard[3][5] == 1 and self.gameboard[4][6] == 1):
            self.score_player1 += 1
        if (self.gameboard[0][3] == 1 and self.gameboard[1][4] == 1 and
                self.gameboard[2][5] == 1 and self.gameboard[3][6] == 1):
            self.score_player1 += 1
        if (self.gameboard[0][3] == 1 and self.gameboard[1][2] == 1 and
                self.gameboard[2][1] == 1 and self.gameboard[3][0] == 1):
            self.score_player1 += 1
        if (self.gameboard[0][4] == 1 and self.gameboard[1][3] == 1 and
                self.gameboard[2][2] == 1 and self.gameboard[3][1] == 1):
            self.score_player1 += 1
        if (self.gameboard[1][3] == 1 and self.gameboard[2][2] == 1 and
                self.gameboard[3][1] == 1 and self.gameboard[4][0] == 1):
            self.score_player1 += 1
        if (self.gameboard[0][5] == 1 and self.gameboard[1][4] == 1 and
                self.gameboard[2][3] == 1 and self.gameboard[3][2] == 1):
            self.score_player1 += 1
        if (self.gameboard[1][4] == 1 and self.gameboard[2][3] == 1 and
                self.gameboard[3][2] == 1 and self.gameboard[4][1] == 1):
            self.score_player1 += 1
        if (self.gameboard[2][3] == 1 and self.gameboard[3][2] == 1 and
                self.gameboard[4][1] == 1 and self.gameboard[5][0] == 1):
            self.score_player1 += 1
        if (self.gameboard[0][6] == 1 and self.gameboard[1][5] == 1 and
                self.gameboard[2][4] == 1 and self.gameboard[3][3] == 1):
            self.score_player1 += 1
        if (self.gameboard[1][5] == 1 and self.gameboard[2][4] == 1 and
                self.gameboard[3][3] == 1 and self.gameboard[4][2] == 1):
            self.score_player1 += 1
        if (self.gameboard[2][4] == 1 and self.gameboard[3][3] == 1 and
                self.gameboard[4][2] == 1 and self.gameboard[5][1] == 1):
            self.score_player1 += 1
        if (self.gameboard[1][6] == 1 and self.gameboard[2][5] == 1 and
                self.gameboard[3][4] == 1 and self.gameboard[4][3] == 1):
            self.score_player1 += 1
        if (self.gameboard[2][5] == 1 and self.gameboard[3][4] == 1 and
                self.gameboard[4][3] == 1 and self.gameboard[5][2] == 1):
            self.score_player1 += 1
        if (self.gameboard[2][6] == 1 and self.gameboard[3][5] == 1 and
                self.gameboard[4][4] == 1 and self.gameboard[5][3] == 1):
            self.score_player1 += 1
        
        # Check player 2
        
        if (self.gameboard[2][0] == 2 and self.gameboard[3][1] == 2 and
                self.gameboard[4][2] == 2 and self.gameboard[5][3] == 2):
            self.score_player2 += 1
        if (self.gameboard[1][0] == 2 and self.gameboard[2][1] == 2 and
                self.gameboard[3][2] == 2 and self.gameboard[4][3] == 2):
            self.score_player2 += 1
        if (self.gameboard[2][1] == 2 and self.gameboard[3][2] == 2 and
                self.gameboard[4][3] == 2 and self.gameboard[5][4] == 2):
            self.score_player2 += 1
        if (self.gameboard[0][0] == 2 and self.gameboard[1][1] == 2 and
                self.gameboard[2][2] == 2 and self.gameboard[3][3] == 2):
            self.score_player2 += 1
        if (self.gameboard[1][1] == 2 and self.gameboard[2][2] == 2 and
                self.gameboard[3][3] == 2 and self.gameboard[4][4] == 2):
            self.score_player2 += 1
        if (self.gameboard[2][2] == 2 and self.gameboard[3][3] == 2 and
                self.gameboard[4][4] == 2 and self.gameboard[5][5] == 2):
            self.score_player2 += 1
        if (self.gameboard[0][1] == 2 and self.gameboard[1][2] == 2 and
                self.gameboard[2][3] == 2 and self.gameboard[3][4] == 2):
            self.score_player2 += 1
        if (self.gameboard[1][2] == 2 and self.gameboard[2][3] == 2 and
                self.gameboard[3][4] == 2 and self.gameboard[4][5] == 2):
            self.score_player2 += 1
        if (self.gameboard[2][3] == 2 and self.gameboard[3][4] == 2 and
                self.gameboard[4][5] == 2 and self.gameboard[5][6] == 2):
            self.score_player2 += 1
        if (self.gameboard[0][2] == 2 and self.gameboard[1][3] == 2 and
                self.gameboard[2][4] == 2 and self.gameboard[3][5] == 2):
            self.score_player2 += 1
        if (self.gameboard[1][3] == 2 and self.gameboard[2][4] == 2 and
                self.gameboard[3][5] == 2 and self.gameboard[4][6] == 2):
            self.score_player2 += 1
        if (self.gameboard[0][3] == 2 and self.gameboard[1][4] == 2 and
                self.gameboard[2][5] == 2 and self.gameboard[3][6] == 2):
            self.score_player2 += 1
        if (self.gameboard[0][3] == 2 and self.gameboard[1][2] == 2 and
                self.gameboard[2][1] == 2 and self.gameboard[3][0] == 2):
            self.score_player2 += 1
        if (self.gameboard[0][4] == 2 and self.gameboard[1][3] == 2 and
                self.gameboard[2][2] == 2 and self.gameboard[3][1] == 2):
            self.score_player2 += 1
        if (self.gameboard[1][3] == 2 and self.gameboard[2][2] == 2 and
                self.gameboard[3][1] == 2 and self.gameboard[4][0] == 2):
            self.score_player2 += 1
        if (self.gameboard[0][5] == 2 and self.gameboard[1][4] == 2 and
                self.gameboard[2][3] == 2 and self.gameboard[3][2] == 2):
            self.score_player2 += 1
        if (self.gameboard[1][4] == 2 and self.gameboard[2][3] == 2 and
                self.gameboard[3][2] == 2 and self.gameboard[4][1] == 2):
            self.score_player2 += 1
        if (self.gameboard[2][3] == 2 and self.gameboard[3][2] == 2 and
                self.gameboard[4][1] == 2 and self.gameboard[5][0] == 2):
            self.score_player2 += 1
        if (self.gameboard[0][6] == 2 and self.gameboard[1][5] == 2 and
                self.gameboard[2][4] == 2 and self.gameboard[3][3] == 2):
            self.score_player2 += 1
        if (self.gameboard[1][5] == 2 and self.gameboard[2][4] == 2 and
                self.gameboard[3][3] == 2 and self.gameboard[4][2] == 2):
            self.score_player2 += 1
        if (self.gameboard[2][4] == 2 and self.gameboard[3][3] == 2 and
                self.gameboard[4][2] == 2 and self.gameboard[5][1] == 2):
            self.score_player2 += 1
        if (self.gameboard[1][6] == 2 and self.gameboard[2][5] == 2 and
                self.gameboard[3][4] == 2 and self.gameboard[4][3] == 2):
            self.score_player2 += 1
        if (self.gameboard[2][5] == 2 and self.gameboard[3][4] == 2 and
                self.gameboard[4][3] == 2 and self.gameboard[5][2] == 2):
            self.score_player2 += 1
        if (self.gameboard[2][6] == 2 and self.gameboard[3][5] == 2 and
                self.gameboard[4][4] == 2 and self.gameboard[5][3] == 2):
            self.score_player2 += 1