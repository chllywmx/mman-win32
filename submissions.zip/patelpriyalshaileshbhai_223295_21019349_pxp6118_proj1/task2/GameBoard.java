import java.io.*;
/**
 * 
 * This is the Gameboard class.  It implements a two dimension array that
 * represents a connect four gameboard. It keeps track of the player making
 * the next play based on the number of pieces on the game board. It provides
 * all of the methods needed to implement the playing of a max connect four
 * game.
 *
 */
class GameBoard
{
	
    int[][] playBoard;
    int currentTurn = 0;

    /**
     * @param file
     * This constructor creates a GameBoard object based on the input file.
     */
    public GameBoard(String file){
    	
        this.playBoard = new int[6][7];
        String gameData;
        BufferedReader input=null;
        
        try
            {
                //opening the input file
                FileReader freader = new FileReader(file);
                input = new BufferedReader(freader);
            }
            catch( IOException e )
            {
                System.out.println("\nProblem opening the input file!\nTry again." +
                        "\n");
                e.printStackTrace();
            }
        try{

            for(int i=0;i<playBoard.length;i++){
                int k;
                gameData= input.readLine();
                for(k=0 ; k < playBoard[i].length;k++){
                    playBoard[i][k]=Character.getNumericValue(gameData.charAt(k));
                }
            }
            gameData=input.readLine();
            this.currentTurn=Character.getNumericValue(gameData.charAt(0));
        }
        catch(Exception e)
        {
            playBoard = new int[][]{
                    {0,0,0,0,0,0,0,},
                    {0,0,0,0,0,0,0,},
                    {0,0,0,0,0,0,0,},
                    {0,0,0,0,0,0,0,},
                    {0,0,0,0,0,0,0,},
                    {0,0,0,0,0,0,0,},
            };
        }
    }

    /**
     * @param column
     * @return
     */
    public boolean isValidPlay(int column){
    	
        //checking the column bounds
        return playBoard[0][column]==0;
    }


    /**
     * @param column
     * @param player
     * @return
     */
    public boolean playAPiece(int column, int player){
        if(!isValidPlay(column))
        {
            System.out.println("Not a valid move");
            return false;
        }

        //starting at the bottom of the board,
        //place the piece into the first empty spot
        else
            {
            for (int i = 5; i >= 0; --i)
            {
                if (playBoard[i][column] == 0)
                {
                    playBoard[i][column] = player;
                    return true;
                }
            }
            return false;
            }
    }

    /**
     * @param column
     * 
     */
    public void removePiece(int column)
    {
        // starting looking at the top of the game board,
        // and remove the top piece
        for(int i=0;i<6;++i)
        {
            if(playBoard[i][column] != 0)
            {
                playBoard[i][column] = 0;
                break;
            }
        }
    }

    /**
     * method to print the GameBoard to the screen in a readable format
     * 
     */
    public void printGameBoard()
    {
        System.out.println("----------------");
        for(int i=0;i<6;++i)
        {
            System.out.println("|");
            for(int j=0;j<7;++j)
            {
                System.out.print(playBoard[i][j]+" ");
            }
            System.out.println("|");
        }
        System.out.println("-------------------");
    }
}
