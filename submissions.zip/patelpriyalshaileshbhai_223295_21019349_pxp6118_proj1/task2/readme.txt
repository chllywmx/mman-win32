Name  : Priyal Shaileshbhai Patel
UTA ID: 1001886118

Language used : Java Programming
Omega incompatible 

***************************************** CODE EXPLAINATION *****************************************

My code contains three classes AIPlayer, maxconnect4 and GameBoard

----> maxconnect4 class contains the main method where we initialize the game board, check whether it is one-move mode or interactive, 
    whether next turn is of human or computer, whether given input is valid or not

----> AIPlayer class contains evaluation function, minimax using alpha-beta pruning, calculating the final score, printing the output to the output file

----> GameBoard class contains creation of game board based on given input, placing or removing a piece, printing the game board
  
For this program, I have considered Player 1 as computer and Player 2 as human.

In one-move mode we will give a input file and based on the input file and depth, the output file is created.
  
In interactive mode human will play against a computer. 
If it is human's turn we can select any move without violating the board requirements.
If it is computer's move, the board is evaluated by making use of evaluation function and the computer will make its next move by using minimax.
  
Similarly, the game is continued and at the end we will count the number of quadruples for each player in all directions.
Ultimately, The player with more number of quadruples will win the game.


******************************************** HOW TO RUN *********************************************

type the following commands in command prompt under task2 folder
  
	javac *.java


The above command will compile all 3 java files and create respective classes. 

Please put respective input files under the same folder i.e. task2

Now, you are good to run as following :

  For one-move mode:
  java maxconnect4 one-move input1.txt output1.txt maxdepth

  For interactive mode:
  java maxconnect4 interactive input1.txt computer-next/human-next maxdepth




