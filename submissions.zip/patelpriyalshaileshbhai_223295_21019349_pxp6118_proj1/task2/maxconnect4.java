import java.io.*;

public class maxconnect4 {
	
	public static void main(String[] args) throws Exception {
		
		if (args.length != 4) {
			
			System.out.println("Four command-line arguments are needed:\n"
					+ "Usage: java [program name] interactive [input_file] [computer-next / human-next] [depth]\n"
					+ " or:  java [program name] one-move [input_file] [output_file] [depth]\n");
			System.exit(0);
		}

		// if well, parse inputs
		String gameMode = args[0].toString();
		String inputFile = args[1].toString();
		
		//initialize the game-board with input fed
		GameBoard b2 = new GameBoard(inputFile);
		
		//take the first turn
		int turn = b2.currentTurn;
		
		//instantiate the AI player object
		AIPlayer aiPlayer = new AIPlayer(b2);
		
		// depth level of AI search
		aiPlayer.depthLimit = Integer.parseInt(args[3].toString());
		
		// if given mode is one-move
		if (gameMode.equalsIgnoreCase("one-move")) {
			
			String outputFile = args[2].toString();
			aiPlayer.startGameOne(b2, outputFile);//call specific function
			
		} else if (gameMode.equalsIgnoreCase("interactive")) { // if given mode is interactive
			
			String nextmove = args[2].toString();
			
			// checking weather next move is of human or computer
			if (nextmove.equalsIgnoreCase("computer-next"))
				
				aiPlayer.startTheGame(1);
			
			else if (nextmove.equalsIgnoreCase("human-next"))
				
				aiPlayer.startTheGame(2);
			
			// if next move is neither made by human nor computer then display invalid input
			else {
				
				System.out.println("Please enter valid input");
				System.exit(0);
			}
			
		} else {
			
			System.out.println("Invalid mode");
			System.exit(0);
		}
	}
}