
import java.io.BufferedWriter;
import java.util.Scanner;
import java.io.FileWriter;

public class AIPlayer {

	private GameBoard gameBoard;
	private Scanner scanner;
	int nextMove = -1;
	int depthLimit = 0;
	int chance = 0;
	int high = 0;

	/**
	 * @param board
	 * construct the gameboard from inputs
	 */
	public AIPlayer(GameBoard board) {
		
		this.gameBoard = board;
		scanner = new Scanner(System.in);
	}

	/**
	 * @param board
	 * @return
	 */
	public int playTheGame(GameBoard board) {
		
		chance = 0;
		high = 0;
		int moves;
		int gridN;
		int gridK;
		int costScore = 0;
		int highScore = 0;

		for (moves = 5; moves >= 0; --moves) {
			
			for (gridN = 0; gridN <= 6; ++gridN) {
				
				if (board.playBoard[moves][gridN] == 0)
					continue;
				// checking cells on right side
				if (gridN <= 3) {
					for (gridK = 0; gridK < 4; ++gridK) {
						if (board.playBoard[moves][gridN + gridK] == 2)
							highScore++;
						else if (board.playBoard[moves][gridN + gridK] == 1)
							costScore++;
						else
							break;
					}
					if (highScore == 4)
						high++;
					else if (costScore == 4)
						chance++;
					highScore = 0;
					costScore = 0;
				}

				// while checking cells in upward direction
				if (moves >= 3) {
					for (gridK = 0; gridK < 4; ++gridK) {
						if (board.playBoard[moves - gridK][gridN] == 2)
							highScore++;
						else if (board.playBoard[moves - gridK][gridN] == 1)
							costScore++;
						else
							break;
					}
					if (highScore == 4)
						high++;
					else if (costScore == 4)
						chance++;
					highScore = 0;
					costScore = 0;
				}

				// now, when checking diagonals
				//also, to the diagonal left-up

				if (gridN <= 3 && moves >= 3) {
					for (gridK = 0; gridK < 4; ++gridK) {
						if (board.playBoard[moves - gridK][gridN + gridK] == 2)
							highScore++;
						else if (board.playBoard[moves - gridK][gridN + gridK] == 1)
							costScore++;
						else
							break;
					}
					if (highScore == 4)
						high++;
					else if (costScore == 4)
						chance++;
					highScore = 0;
					costScore = 0;
				}

				// diagonal right-up
				if (gridN >= 3 && moves >= 3) {
					for (gridK = 0; gridK < 4; ++gridK) {
						if (board.playBoard[moves - gridK][gridN - gridK] == 2)
							highScore++;
						else if (board.playBoard[moves - gridK][gridN - gridK] == 1)
							costScore++;
						else
							break;
					}
					if (highScore == 4)
						high++;
					else if (costScore == 4)
						chance++;
					highScore = 0;
					costScore = 0;
				}
			}
		}
		// if game is not ended
		for (int j = 0; j < 7; ++j) {
			if (board.playBoard[0][j] == 0)
				return -1;
		}
		// computer wins
		if (chance > high)
			return 1;
		// human wins
		else if (chance < high)
			return 2;
		// it's a tie
		else
			return 0;
	}

	/**
	 * @param aiPosition
	 * @param noOfMoves
	 * @return
	 */
	int calculateScore(int aiPosition, int noOfMoves) {
		
		int currMove = 4 - noOfMoves;
		if (aiPosition == 3)
			return 8 * currMove;
		else if (aiPosition == 2)
			return 5 * currMove;
		else if (aiPosition == 1)
			return currMove;
		else if (aiPosition == 0)
			return 0;
		else
			return 999;
	}
	

	/**
	 * @param board
	 * @param turn
	 * @throws Exception
	 */
	public void outToFile(GameBoard board, int turn) throws Exception {
		
		if (turn != 2) {
			
			BufferedWriter output = new BufferedWriter(new FileWriter("computer.txt"));
			for (int i = 0; i < 6; i++) {
				
				for (int j = 0; j < 7; j++) {
					
					output.write(board.playBoard[i][j] + 48);
				}
				output.write("\r\n");
			}
			// current turn
			output.write("2" + "\r\n");
			output.close();
		} else {
			
			BufferedWriter output = new BufferedWriter(new FileWriter("human.txt"));
			for (int i = 0; i < 6; i++) {
				
				for (int j = 0; j < 7; j++) {
					
					output.write(board.playBoard[i][j] + 48);
				}
				output.write("\r\n");
			}
			// current turn
			output.write("1" + "\r\n");
			output.close();
		}
	}

	/**
	 * @param board
	 * @return
	 */
	public int evaluateGameBoard(GameBoard board) {

		int gridQ = 0;
		int screen = 1;
		int emptyblocks = 0;
		int finalScore = 0;
		int moves = 0;
		
		for (int i = 5; i >= 0; --i) {
			
			for (int j = 0; j < 7; ++j) {
				
				int p = board.playBoard[i][j];
				if (p == 2 || p == 0)
					continue;

				if (j < 4) {
					for (gridQ = 1; gridQ <= 3; ++gridQ) {
						int s = board.playBoard[i][j + gridQ];
						if (s == 2) {
							emptyblocks = 0;
							screen = 0;
							break;
						} else if (s == 1)
							screen++;
						else
							emptyblocks++;
					}

					moves = 0;
					if (emptyblocks > 0)
						for (int rows = 1; rows <= 3; ++rows) {
							
							int column = j + rows;
							for (int start = i; start < 6; start++) {
								int t = board.playBoard[start][column];
								if (t == 0)
									moves++;
								else
									break;
							}
						}

					if (moves != 0)
						finalScore = finalScore + calculateScore(screen, moves);
					emptyblocks = 0;
					screen = 1;
				}

				if (i > 2) {
					for (gridQ = 1; gridQ <= 3; ++gridQ) {
						int currentNode = board.playBoard[i - gridQ][j];
						if (currentNode == 2) {
							screen = 0;
							break;
						} else if (currentNode == 1)
							screen++;
					}
					moves = 0;

					if (screen > 0) {
						int column = j;
						for (int start = i - gridQ + 1; start <= i - 1; start++) {
							int currentNode = board.playBoard[start][column];
							if (currentNode == 0)
								moves++;
							else
								break;
						}
					}
					if (moves != 0)
						finalScore = finalScore + calculateScore(screen, moves);
					emptyblocks = 0;
					screen = 1;
				}

				if (j > 2) {
					for (gridQ = 1; gridQ <= 3; ++gridQ) {
						int z = board.playBoard[i][j - gridQ];
						if (z == 2) {
							emptyblocks = 0;
							screen = 0;
							break;
						} else if (z == 1)
							screen++;
						else
							emptyblocks++;
					}
					moves = 0;
					if (emptyblocks > 0)
						for (int r = 1; r <= 3; ++r) {
							int column = j - r;
							for (int s = i; s < 6; s++) {
								int f = board.playBoard[s][column];
								if (f == 0)
									moves++;
								else
									break;
							}
						}

					if (moves != 0)
						finalScore = finalScore + calculateScore(screen, moves);
					emptyblocks = 0;
					screen = 1;
				}

				if (j < 4 && i > 2) {
					for (gridQ = 1; gridQ <= 3; ++gridQ) {
						int g = board.playBoard[i - gridQ][j + gridQ];
						if (g == 2) {
							emptyblocks = 0;
							screen = 0;
							break;
						} else if (g == 1)
							screen++;
						else
							emptyblocks++;
					}
					moves = 0;
					if (emptyblocks > 0) {
						for (int r = 1; r <= 3; ++r) {
							int column = j + r;
							int row = i - r;
							for (int s = row; s <= 5; ++s) {
								int h = board.playBoard[s][column];
								if (h == 0)
									moves++;
								else if (h == 1)
									;
								else
									break;
							}
						}
						if (moves != 0)
							finalScore = finalScore + calculateScore(screen, moves);
						emptyblocks = 0;
						screen = 1;
					}
				}

				if (i > 2 && j > 2) {
					for (gridQ = 1; gridQ <= 3; ++gridQ) {
						int l = board.playBoard[i - gridQ][j - gridQ];
						if (l == 2) {
							screen = 0;
							emptyblocks = 0;
							break;
						} else if (l == 1)
							screen++;
						else
							emptyblocks++;
					}
					moves = 0;
					if (emptyblocks > 0) {
						for (int r = 1; r <= 3; ++r) {
							int column = j - r;
							int row = i - r;
							for (int s = row; s < 6; ++s) {
								int d = board.playBoard[s][column];
								if (d == 0)
									moves++;
								else if (d == 1)
									;
								else
									break;
							}
						}
						if (moves != 0)
							finalScore = finalScore + calculateScore(screen, moves);
						emptyblocks = 0;
						screen = 1;
					}
				}
			}
		}
		return finalScore;
	}

	/**
	 * @return
	 */
	public int moveByComputer() {
		
		nextMove = -1;
		minimax(0, 1, Integer.MIN_VALUE, Integer.MAX_VALUE);
		return nextMove;
	}


	/**
	 * 
	 */
	public void moveByPlayer() {
		
		// selecting your move
		// this method is used only for interactive mode
		System.out.println("Make your move (select in between 1 to 7): ");
		int intValue = scanner.nextInt();
		
		// checking weather your move is valid or not
		while (intValue <= 0 || intValue >= 8 || !gameBoard.isValidPlay(intValue - 1)) {
			System.out.println("Not a valid move");
			intValue = scanner.nextInt();
		}
		
		// here we are assuming 2 is the opponent
		gameBoard.playAPiece(intValue - 1, 2);
	}
	
	
	/**
	 * @param board
	 * @return
	 */
	public boolean getInitialState(GameBoard board) {
		
		for (int i = 0; i < board.playBoard[5].length; i++) {
			
			int s = board.playBoard[5][i];
			if (s != 0)
				return false;
		}
		return true;
	}


	/**
	 * @param turn
	 * @throws Exception
	 */
	public void startTheGame(int turn) throws Exception {
		
		if (turn == 2) {
			
			gameBoard.printGameBoard();
			moveByPlayer();
		}
		gameBoard.printGameBoard();
		outToFile(gameBoard, 2);
		System.out.println("Computer move:");
		if (getInitialState(gameBoard))
			gameBoard.playAPiece(3, 1);
		else
			gameBoard.playAPiece(moveByComputer(), 1);
		gameBoard.printGameBoard();
		outToFile(gameBoard, 1);

		while (true) {
			
			moveByPlayer();
			gameBoard.printGameBoard();
			outToFile(gameBoard, 2);
			int finalResult = playTheGame(gameBoard);
			
			if (finalResult == 0) {
				
				System.out.println("It's a tie!");
				System.out.println("Computer score is: " + chance);
				System.out.println("Human score is: " + high);
				break;
			} else if (finalResult == 1) {
				
				System.out.println("Computer Wins!");
				System.out.println("Computer score is: " + chance);
				System.out.println("Human score is: " + high);
				break;
			} else if (finalResult == 2) {
				
				System.out.println("You Win!");
				System.out.println("Computer score is: " + chance);
				System.out.println("Human score is: " + high);
				break;
			}

			System.out.println("Computer move:");
			gameBoard.playAPiece(moveByComputer(), 1);
			gameBoard.printGameBoard();
			outToFile(gameBoard, 1);
			finalResult = playTheGame(gameBoard);
			if (finalResult == 0) {
				
				System.out.println("It's a tie!");
				System.out.println("Computer score is: " + chance);
				System.out.println("Human score is: " + high);
				break;
			} else if (finalResult == 1) {
				
				System.out.println("Computer Wins!");
				System.out.println("Computer score is: " + chance);
				System.out.println("Human score is: " + high);
				break;
			} else if (finalResult == 2) {
				
				System.out.println("You Win!");
				System.out.println("Computer score is: " + chance);
				System.out.println("Human score is: " + high);
				break;
			}

		}

	}

	/**
	 * @param board
	 * @param outputFile
	 * @throws Exception
	 */
	public void startGameOne(GameBoard board, String outputFile) throws Exception {
		
		if (checkTheBoard(board)) {
			
			System.out.println("The board is full");
			int finalResult = playTheGame(board);
			System.out.println("Computer score is: " + chance);
			System.out.println("Human score is: " + high);
			System.exit(0);
			
		} else {
			
			board.printGameBoard();
			int finalResult = playTheGame(board);
			System.out.println("Computer score is: " + chance);
			System.out.println("Human score is: " + high);
			System.out.println("Computer move:");
			board.playAPiece(moveByComputer(), 1);
			board.printGameBoard();
			finalResult = playTheGame(board);
			System.out.println("Computer score is: " + chance);
			System.out.println("Human score is: " + high);
			BufferedWriter output = new BufferedWriter(new FileWriter(outputFile));
			
			for (int i = 0; i < 6; i++) {
				for (int j = 0; j < 7; j++) {
					
					output.write(board.playBoard[i][j] + 48);
				}
				output.write("\r\n");
			}
			output.write("2" + "\r\n");
			output.close();
		}
	}

	/**
	 * @param depth
	 * @param playerturn
	 * @param alpha
	 * @param beta
	 * @return
	 */
	public int minimax(int depth, int playerturn, int alpha, int beta) {
		
		if (depthLimit == 0) {
			System.out.println("A Limit of depth should be atleast 1");
			System.exit(0);
		}

		if (beta <= alpha) {
			if (playerturn != 1)
				return Integer.MIN_VALUE;
			else
				return Integer.MAX_VALUE;
		}
		int finalResult = playTheGame(gameBoard);
		if (finalResult == 0)
			return 0;
		else if (finalResult == 1)
			return Integer.MAX_VALUE / 3;
		else if (finalResult == 2)
			return Integer.MIN_VALUE / 3;
		if (depth == depthLimit)
			return evaluateGameBoard(gameBoard);
		int minimum_score = Integer.MAX_VALUE;
		int maximum_score = Integer.MIN_VALUE;
		for (int j = 0; j < 7; ++j) {
			int current_score = 0;
			if (!gameBoard.isValidPlay(j))
				continue;
			if (playerturn == 1) {
				gameBoard.playAPiece(j, 1);
				current_score = minimax(depth + 1, 2, alpha, beta);
				if (depth == 0) {
					if (current_score > maximum_score)
						nextMove = j;
					if (current_score == Integer.MAX_VALUE / 3) {
						gameBoard.removePiece(j);
						break;
					}
				}
				maximum_score = Math.max(current_score, maximum_score);
				alpha = Math.max(current_score, alpha);
			} else if (playerturn == 2) {
				gameBoard.playAPiece(j, 2);
				current_score = minimax(depth + 1, 1, alpha, beta);
				minimum_score = Math.min(current_score, minimum_score);
				beta = Math.min(current_score, beta);
			}
			gameBoard.removePiece(j);
			if (current_score == Integer.MAX_VALUE || current_score == Integer.MIN_VALUE)
				break;
		}
		return playerturn == 1 ? maximum_score : minimum_score;
	}


	/**
	 * @param board
	 * @return
	 */
	public boolean checkTheBoard(GameBoard board) {
		
		int i;
		for (i = 0; i < board.playBoard[0].length; i++) {
			
			if (board.playBoard[0][i] == 0)
				return false;
		}
		return true;
	}

}