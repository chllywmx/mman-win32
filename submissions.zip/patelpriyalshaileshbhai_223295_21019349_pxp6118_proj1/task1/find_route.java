import java.io.*; //classes for all i/o operations in the program
import java.util.*; // utility packages import for collections API

/**
 * 
 * @author priyal
 * 
 * This is task-1 for AI Mini-Programming Assignment
 * the task is to find the optimal path between the cities and find the number of nodes expanded, total distance and final path
 * UTA ID : 1001886118
 * 
 */
public class find_route {
	

    //keep count of expanded nodes
    int expandedNodes=0;
    
    //storing the mapping of connecting cities
    Hashtable<String, ArrayList<String[]>> hashTableCity = new Hashtable<String, ArrayList<String[]>>();
    
    //storing the heuristics of connecting cities
    Hashtable<String, Integer> hashTableHCost = new Hashtable<String,Integer>();
    
    //to store any path between two cities
    Hashtable<String, Object[]> hashTablePath = new Hashtable<String, Object[]>();
    
	
	//starting point for the program
    public static void main(String[] args) throws IOException {
    	
        find_route findRoute = new find_route();//instantiation of the class
        
        if (args.length==3 && (args[0]!=null || args[1]!=null || args[2]!=null)) {
        	
        	findRoute.findUninformedRoute(args[0],args[1],args[2]); //un-informed search method call
        	
        } else if (args.length==4 && (args[0]!=null || args[1]!=null || args[2]!=null || args[3]!=null)) {
        	
        	findRoute.findInformedRoute(args[0],args[1],args[2],args[3]);  //informed search method call
        	
        } else {
        	
        	//if inputs are not entered correctly.
        	System.out.println("Please enter valid inputs! Example : find_route input1.txt Bremen Kassel");
        }
            
    }
    
  
    /**
     * @param inputFile
     * @param src
     * @param dest
     * @throws IOException
     * 
     * find route function for uninformed search
     */
    private void findUninformedRoute(String inputFile, String src, String dest) throws IOException {

        //mark the flag
        HashSet<String> visitedHashSet = new HashSet<String>();
        
        //fringe stores the data of city according to the path-cost 
        PriorityQueue<City> fringe = new PriorityQueue<City>(1,new CostComparator());
        
    	//read and process the input file
        readInputFile(inputFile);
        
        //Initializing the base fringe condition with path-cost=0
        fringe.add(new City(src,null,0));
        
        while (!fringe.isEmpty()){
         
        	//taking the latest node added to the fringe
            City currentNode = fringe.poll();
            
            //increment the count
            expandedNodes++;
            
            //find the route and store
            findRoute(currentNode);
            
            //If the destination is reached 
            if (currentNode.value.equals(dest)) 
                break; //break the loop
            
            //if the current city is in visited set
            if(visitedHashSet.contains(currentNode.value))
                continue; //skip the process
            
            ArrayList<String[]> connectedCities = hashTableCity.get(currentNode.value);
            Iterator<String[]> iteratorCity = connectedCities.iterator();
            
            //if we have connected cities then add all of them to end of the fringe
            while (iteratorCity.hasNext()){
            	
                String[] array = iteratorCity.next();
                City current = new City(array[0],currentNode,currentNode.gOfN+Integer.parseInt(array[1]));
                fringe.add(current);
            }
            
            //add the city to visited Set
            visitedHashSet.add(currentNode.value);
        }
        
        //prints the elements of the path
        printRoute(dest);
    }
    
    
    /**
     * @param inputFile
     * @param source
     * @param destination
     * @param hFile
     * @throws IOException
     * 
     * find route function for informed search
     */
    private void findInformedRoute(String inputFile, String source, String destination, String hFile) throws IOException {
     
        //mark the visited cities
        HashSet<String> visitedHashSet = new HashSet<String>();
        
        //fringe store the data of node on basis of path cost 
        PriorityQueue<City> fringe = new PriorityQueue<City>(1,new HeuristicComparator());
        
        //read the inputs
        readHeuristics(hFile);
        readInputFile(inputFile);
        
        //initialize the base fringe
        fringe.add(new City(source,null,0,0));
        
        while (!fringe.isEmpty()) {
         
        	//taking the latest node in the fringe
            City currentNode = fringe.poll();
            
            //increment the counter
            expandedNodes++;
            
            //find the route
            findRoute(currentNode);
            
            //If the destination is reached
            if (currentNode.value.equals(destination)) 
                break;
            
            //if the current city is already visited
            if(visitedHashSet.contains(currentNode.value))
                continue;
            
            //add all the connecting cities to the fringe for later traversal
            ArrayList<String[]> connectingCities = hashTableCity.get(currentNode.value);
            Iterator<String[]> iteratorCity = connectingCities.iterator();
            
            while (iteratorCity.hasNext()){
            	
                String[] str = iteratorCity.next();
                City node = new City(str[0],currentNode, currentNode.gOfN+Integer.parseInt(str[1]),currentNode.gOfN+Integer.parseInt(str[1])+hashTableHCost.get(str[0]));
                fringe.add(node);
            }
            
            //add the city to visited HashSet
            visitedHashSet.add(currentNode.value);
        }
        
        //prints the elements of the path found
        printRoute(destination);
    }
    
    /**
     * @param fileName
     * @throws IOException
     * 
     * process the file inputs to 2d matrix format
     * 
     */
    private void readInputFile(String fileName) throws IOException {
    	
        File file = new File(fileName);
        BufferedReader br = new BufferedReader(new FileReader(file.getPath()));
        String scanner;
        
        //read the file inputs till the end
        while (!(scanner=br.readLine()).equals("END OF INPUT")) {
        	
            String first = scanner.split(" ")[0];
            String second = scanner.split(" ")[1];
            String distance = scanner.split(" ")[2];
            
            //mark connection from first to second
            generateMapping(first, second,distance);
            
            //mark connection from second to first
            generateMapping(second, first, distance); 
        }
    }


    /**
     * @param first
     * @param second
     * @param distance
     * 
     * stores data from the input file to hashTableCity Object
     */
    private void generateMapping(String first, String second, String distance) {
    	
        String[] entry = {second, distance};
        
        if (hashTableCity.containsKey(first))
        	
            hashTableCity.get(first).add(entry);
        
        else {
        	
            ArrayList<String[]> element = new ArrayList<String[]>();
            element.add(entry);
            hashTableCity.put(first,element);
            
        }
    }

    
    /**
     * @param hFileName
     * @throws IOException
     * 
     * populating the Heuristics Hashtable from hFile provided 
     * 
     */
    private void readHeuristics(String hFileName) throws IOException {
    
        File file = new File(hFileName);
        Scanner sc = new Scanner(new FileReader(file.getPath()));
        String scanner;
        
        //read till end of input
        while (!(scanner = sc.nextLine()).equals("END OF INPUT")) {
            
        	hashTableHCost.put(scanner.split(" ")[0].toString(),Integer.parseInt(scanner.split(" ")[1].toString()));
        	
        }
    }

    
    /**
     * @param city
     * 
     * method to get the route between two nodes
     * 
     */
    public void findRoute(City city){
    
        if (!hashTablePath.containsKey(city.value) || (Integer) hashTablePath.get(city.value)[1]>city.gOfN){
        	
            Object[] valueRoute = { city.secondCity!=null ? city.secondCity.value : null, city.gOfN };
            hashTablePath.put(city.value,valueRoute);
        }
    }
    
    
    /**
     * @param dest
     * print the path and output
     * 
     */
    private void printRoute(String dest) {
    
    	//initialize to infinity for base cases
        String totalDistance = "infinity";
        
        // stack will be easier for recursive call backs
        Stack<String> pathFound = new Stack<String>();
        
        //if path has mapping for destination
        if (hashTablePath.containsKey(dest)){
        	
            totalDistance = hashTablePath.get(dest)[1]+" km";
            String parent = (String) hashTablePath.get(dest)[0];
            
            //if parent is not found then
            while (parent!=null){
            	
                int dist = (Integer)hashTablePath.get(dest)[1] - (Integer)hashTablePath.get(parent)[1];
                pathFound.push(parent+" to "+dest+ ", "+dist+" km");
                dest=parent;
                parent = (String)hashTablePath.get(dest)[0];
            }
        }
        
        //preparing the final output string 
        StringBuffer sb = new StringBuffer();
        sb.append("nodes expanded: "+expandedNodes+"\n");
        sb.append("distance: "+totalDistance+"\n");
        sb.append("route:\n");
        
        if (pathFound.isEmpty())
        	sb.append("none");
        else {
        	
            while (!pathFound.isEmpty()){
            	
                sb.append(pathFound.pop());
                sb.append("\n");
            }
        }
        
        System.out.println(sb.toString());
    }
}

/**
 * @author priyal
 * 
 * This custom data structure is define to store the current city, connecting city, the cost between the two.
 */
class City {
	
    int gOfN;  // path cost between two cities
    int hOfN;  // heuristic cost between two cities
    String value;    //value of the current city
    City secondCity;    //the other city connecting the current city
    
    //this constructor is used for uninformed search
    City(String value, City previous, int g) {
    	
        this.gOfN = g;
        this.secondCity = previous;
        this.value = value;
    }
    
    //constructor for informed search with H parameter
    City(String value, City previous, int g, int h){
    	
        this.gOfN = g;
        this.secondCity = previous;
        this.value = value;
        this.hOfN = h;
    }
}


/**
 * @author priyal
 * 
 * This class is used to sort the pathCost values in descending order in the fringe
 */
class CostComparator implements Comparator<City>{
    
	@Override
	public int compare(City n1,City n2){
		
        if (n1.gOfN>n2.gOfN) return 1;
        else if (n1.gOfN<n2.gOfN) return -1;
        else return 0;
    }
}


/**
 * @author priyal
 * 
 * This class is used to sort heuristic values in descending order in the fringe
 */
class HeuristicComparator implements Comparator<City>{

    @Override
    public int compare(City n1, City n2) {
        if (n1.hOfN>n2.hOfN) return 1;
        else  if (n1.hOfN<n2.hOfN) return -1;
        return 0;
    }
}

