Name  : Priyal Shaileshbhai Patel
UTA ID: 1001886118

Language used : Java Programming
Omega incompatible 

***************************************** CODE EXPLAINATION *****************************************

My code contains one java file find_route which contains 

----> find_route class contains the main method where we call the respective path finding algorithm based on the input parameters passed.

----> CostComparator class is used to sort the pathCost values in descending order in the fringe

----> HeuristicComparator class is used to sort the heauristic values in descending order in the fringe

----> also, I have defined City class; custom data structure is define to store the current city, connecting city, the cost between the two.


******************************************** HOW TO RUN *********************************************

type the following commands in command prompt under task1 folder
  
	javac find_route.java


The above command will compile the find_route java file and create respective classes. 

Please put respective input files under the same folder i.e. task1


Now, you are good to run as following :


  For Uninformed Search:
  java find_route input1.txt Bremen Kassel

  For Informed Search:
  java find_route input1.txt Bremen Kassel h_kassel.txt




