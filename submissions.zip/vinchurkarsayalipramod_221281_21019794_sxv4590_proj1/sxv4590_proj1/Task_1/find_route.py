#Name- Sayali Pramod Vinchurkar
#UTA ID- 1001874590
#Project 1 (Task 1)

from operator import itemgetter
from pickle import GLOBAL
import sys
from typing import final
import time

#finding cost for the route in output
def cost_finder(st,dest,arr):
    for items in range(len(arr)):
        if(arr[items][0]==st and arr[items][1]==dest):
            return arr[items][2]
        if(arr[items][1]==st and arr[items][0]==dest):
            return arr[items][2]

#informed search function implemented A* for this 
def  informed_search():
    cost, start, destination,heuristics= no_arg[1],no_arg[2],no_arg[3],no_arg[4]
    no_of_inputs,final_routes,heuristic_data,h_rates=[],[],[],{}
    #locations of the directory in which the cost and heuristic files are located
    input_location="C:/Users/User/Desktop/AI_Project/"+cost
    heuristic_location="C:/Users/User/Desktop/AI_Project/"+heuristics
    #reads the cost file
    for line in open(input_location,"r"):
         columns = line.rstrip('\n').split(" ")
         no_of_inputs.append(columns)
    no_of_inputs.pop()
    #reads the heuristic file
    for line in open(heuristic_location,"r"):
         columns = line.rstrip('\n').split(" ")
         heuristic_data.append(columns)
    heuristic_data.pop()
    #storing heuristic data in a dictionary
    for i in range(len(heuristic_data)):
        h_rates[heuristic_data[i][0]]=heuristic_data[i][1]
    #initializing fringe, cost, closed set and other variables
    expands,poped,generated,gn=0,0,1,0
    fringe,expense,close=[[start,0,gn]],0,[]
    #this loops is for finding destination state by performing A*(adding nodes to the fringe by calculating its cost+heuristic values, sorting the fringe, popping the nodes, expanding the nodes)
    while(start!=destination):
        poped+=1
        if start not in close:
            expands+=1
            for i in range(len(no_of_inputs)):      
                    close.append(start)
                    if no_of_inputs[i][0]==start: 
                        fringe.append([no_of_inputs[i][1],int(no_of_inputs[i][2])+gn+int(h_rates[no_of_inputs[i][1]]),int(no_of_inputs[i][2])+gn])
                        final_routes.append([no_of_inputs[i][1],no_of_inputs[i][0],int(no_of_inputs[i][2])+gn+int(h_rates[no_of_inputs[i][1]]),expense])
                        generated+=1
                    if  no_of_inputs[i][1]==start: 
                        g_n=int(no_of_inputs[i][2])+gn
                        fringe.append([no_of_inputs[i][0],int(no_of_inputs[i][2])+gn+int(h_rates[no_of_inputs[i][0]]),int(no_of_inputs[i][2])+gn])
                        final_routes.append([no_of_inputs[i][0],no_of_inputs[i][1],int(no_of_inputs[i][2])+gn+int(h_rates[no_of_inputs[i][0]]),expense])
                        generated+=1
            fringe=sorted(fringe, key=itemgetter(1))
        #if fringe is empty and we didn't found the destination state   
        if len(fringe)==0:
            print("It is impossible to reach goal state.")
            break   
        #pops node from front of the fringe and start searching from the next node available
        start=fringe[0][0]
        expense,gn=fringe[0][1],fringe[0][2]
        del fringe[0]
    #generating output as nodes popped, expanded, generated, optimal distance, and the route   
    if(len(fringe)!=0):
        cs=destination
        costtracker=expense
        rout_finder=[destination]
        while(costtracker!=0):
            for t in range(len(final_routes)):
                if(cs==final_routes[t][0]):
                    if(final_routes[t][2]==costtracker):
                        rout_finder.append(final_routes[t][1])
                        cs=final_routes[t][1]
                        costtracker=final_routes[t][3]
        #prints output to the console if destination is found             
        print("Number nodes Popped :",poped)
        print("Number of node expanded: ",expands)
        print("Nodes Generated: ",generated)
        print("Closest (optimal) distance: ",gn)
        
        rout_finder.reverse()
        print("Route: ")
        for item in range(len(rout_finder)-1):
            dista=cost_finder(rout_finder[item],rout_finder[item+1],no_of_inputs)
            print(rout_finder[item],"-->",rout_finder[item+1],dista,"km")
    #prints output to the console if destination is not found 
    else:
        print("Number nodes Popped :",poped)
        print("Number of node expanded: ",expands)
        print("Nodes Generated: ",generated)
        print("Distance: infinity")
        print("Final Route: None")

#Uninformed search function implemented by using UCS strategy
def uninformed_search():
    cost, start, destination = no_arg[1],no_arg[2],no_arg[3]
    no_of_inputs=[]
    final_routes=[]
    #locations of the directory in which the cost and heuristic files are located
    input_location="C:/Users/User/Desktop/AI_Project/"+cost
    #reads the cost file
    for line in open(input_location,"r"):
         columns = line.rstrip('\n').split(" ")
         no_of_inputs.append(columns)
    no_of_inputs.pop()
    #initializing fringe, cost, closed set and other variables
    expands,poped,generated=0,0,1
    fringe,expense,close=[[start,0]],0,[]
    #this loops is for finding destination state by performing UCS(adding nodes to the fringe, sorting the fringe, popping the nodes, expanding the nodes)
    while(start!=destination):
        if start not in close:
            expands+=1
            for i in range(len(no_of_inputs)):
                    close.append(start)
                    if no_of_inputs[i][0]==start: 
                        fringe.append([no_of_inputs[i][1],int(no_of_inputs[i][2])+expense])
                        final_routes.append([no_of_inputs[i][1],no_of_inputs[i][0],int(no_of_inputs[i][2])+expense,expense])
                        generated+=1
                    if  no_of_inputs[i][1]==start: 
                        fringe.append([no_of_inputs[i][0],int(no_of_inputs[i][2])+expense])
                        final_routes.append([no_of_inputs[i][0],no_of_inputs[i][1],int(no_of_inputs[i][2])+expense,expense])
                        generated+=1
            fringe=sorted(fringe, key=itemgetter(1))
        #if fringe is empty and we didn't found the destination state      
        if len(fringe)==0:
            print("It is impossible to reach goal state.")
            break       
        #pops node from front of the fringe and start searching from the next node available
        start=fringe[0][0]
        expense=fringe[0][1]
        del fringe[0]
        poped+=1
    #generating output as nodes popped, expanded, generated, optimal distance, and the route   
    if len(fringe)!=0:
        cs=destination
        costtracker=expense
        rout_finder=[destination]
        while(costtracker!=0):
            for t in range(len(final_routes)):
                if(cs==final_routes[t][0]):
                    if(final_routes[t][2]==costtracker):
                        rout_finder.append(final_routes[t][1])
                        cs=final_routes[t][1]
                        costtracker=final_routes[t][3]
        #prints output to the console if destination is found 
        print("Number nodes Popped :",poped)
        print("Number of node expanded: ",expands)
        print("Nodes Generated: ",generated)
        print("Closest (optimal) distance: ",expense)
        
        rout_finder.reverse()
        print("Route: ")
        for item in range(len(rout_finder)-1):
            dista=cost_finder(rout_finder[item],rout_finder[item+1],no_of_inputs)
            print(rout_finder[item],"-->",rout_finder[item+1],dista,"km")
    #prints output to the console if destination is not found 
    else:
        print("Number nodes Popped :",poped)
        print("Number of node expanded: ",expands)
        print("Nodes Generated: ",generated)
        print("Distance: Infinity")
        print("Final Route: None ")

#takes argument from the command line
no_arg = sys.argv

#if argument contains 4 arguments it will perform uninformed search
if len(no_arg)==4:
    uninformed_search()
#if argument contains 5 arguments it will perform uninformed search    
else:
    informed_search()


