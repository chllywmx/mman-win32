import copy
import random
import sys
import time

class maxConnect4Game:
    
    def __init__(self):
        self.game_board_matrix = [[0 for i in range(7)] for j in range(6)]
        self.currentTurn = 1
        self.player1Score = 0
        self.player2Score = 0
        self.pieceCount = 0
        self.gameFile = None
        self.utility = None
        random.seed()

    def play_player_position_taking_move(self, column):
        t_value = self.game_board_matrix[0][column]
        if not t_value:
            temp_loop = range(5, -1, -1)
            for i in temp_loop:  
                temp_value_2 = self.game_board_matrix[i][column]
                if not temp_value_2:
                    final_value = self.currentTurn
                    self.game_board_matrix[i][column] = final_value
                    final_counter = self.pieceCount + 1
                    self.pieceCount = final_counter
                    return 1

    def game_play_by_ai(self, depth, computer):
        temp_depth = depth - 1
        self.generate_successor_in_game(temp_depth, computer)
        column = self.selecting_best_move_in_current_position(computer)
        temp_result = self.play_player_position_taking_move(column)
        if not temp_result:
            self.game_play_by_ai(depth, computer)
        else:
            print('\n\nmove %d: Player %d, column %d\n' % (self.pieceCount, self.currentTurn, column+1))
        return

    def generate_successor_in_game(self, depth, computer):
        count_pieces = self.pieceCount
        if depth >= 0 and  count_pieces< 42:
            self.children = []
            for gameColumn in range(0, 7):
                temp_condition = self.game_board_matrix[0][gameColumn]
                if not temp_condition:
                    child_matrix = maxConnect4Game()
                    child_matrix.game_board_matrix = copy.deepcopy(self.game_board_matrix)
                    current_turn = self.currentTurn
                    if current_turn == 1:
                        child_matrix.currentTurn = 2
                    elif current_turn == 2:
                        child_matrix.currentTurn = 1
                    child_matrix.evaluation = 0
                    temp_pice_count = self.pieceCount + 1
                    child_matrix.pieceCount = temp_pice_count
                    if computer == current_turn:
                        self.eval(computer)
                        temp_utility = self.bestMove["utility"]
                        child_matrix.evaluation = temp_utility
                        temp_current_turn = self.currentTurn
                        child_matrix.game_board_matrix[self.bestMove["row"]][self.bestMove["column"]] = temp_current_turn
                        temp_best_move = self.bestMove["column"]
                        child_matrix.column = temp_best_move
                        self.children.append(child_matrix)
                        break
                    else:
                        for i in range(5, -1, -1):
                            if not child_matrix.game_board_matrix[i][gameColumn]:
                                child_matrix.game_board_matrix[i][gameColumn] = self.currentTurn
                                child_matrix.column = gameColumn
                                self.children.append(child_matrix)
                                break
            for child in self.children:
                temp_depth = depth - 1
                child.generate_successor_in_game(temp_depth, computer)       
        else: 
            self.player1Score = 0
            self.player2Score = 0
            for row in self.game_board_matrix:
                if row[0:4] == [1]*4:self.player1Score += 1
                if row[1:5] == [1]*4:self.player1Score += 1
                if row[2:6] == [1]*4:self.player1Score += 1
                if row[3:7] == [1]*4:self.player1Score += 1        
                if row[0:4] == [2]*4:self.player2Score += 1
                if row[1:5] == [2]*4:self.player2Score += 1
                if row[2:6] == [2]*4:self.player2Score += 1
                if row[3:7] == [2]*4:self.player2Score += 1
            for j in range(7):            
                if (self.game_board_matrix[0][j] == 1 and self.game_board_matrix[1][j] == 1 and self.game_board_matrix[2][j] == 1 and self.game_board_matrix[3][j] == 1): self.player1Score += 1
                if (self.game_board_matrix[1][j] == 1 and self.game_board_matrix[2][j] == 1 and self.game_board_matrix[3][j] == 1 and self.game_board_matrix[4][j] == 1): self.player1Score += 1
                if (self.game_board_matrix[2][j] == 1 and self.game_board_matrix[3][j] == 1 and self.game_board_matrix[4][j] == 1 and self.game_board_matrix[5][j] == 1): self.player1Score += 1
                if (self.game_board_matrix[0][j] == 2 and self.game_board_matrix[1][j] == 2 and self.game_board_matrix[2][j] == 2 and self.game_board_matrix[3][j] == 2): self.player2Score += 1
                if (self.game_board_matrix[1][j] == 2 and self.game_board_matrix[2][j] == 2 and self.game_board_matrix[3][j] == 2 and self.game_board_matrix[4][j] == 2): self.player2Score += 1
                if (self.game_board_matrix[2][j] == 2 and self.game_board_matrix[3][j] == 2 and self.game_board_matrix[4][j] == 2 and self.game_board_matrix[5][j] == 2): self.player2Score += 1
            if (self.game_board_matrix[2][0] == 1 and self.game_board_matrix[3][1] == 1 and self.game_board_matrix[4][2] == 1 and self.game_board_matrix[5][3] == 1): self.player1Score += 1
            if (self.game_board_matrix[1][0] == 1 and self.game_board_matrix[2][1] == 1 and self.game_board_matrix[3][2] == 1 and self.game_board_matrix[4][3] == 1): self.player1Score += 1
            if (self.game_board_matrix[2][1] == 1 and self.game_board_matrix[3][2] == 1 and self.game_board_matrix[4][3] == 1 and self.game_board_matrix[5][4] == 1): self.player1Score += 1
            if (self.game_board_matrix[0][0] == 1 and self.game_board_matrix[1][1] == 1 and self.game_board_matrix[2][2] == 1 and self.game_board_matrix[3][3] == 1): self.player1Score += 1
            if (self.game_board_matrix[1][1] == 1 and self.game_board_matrix[2][2] == 1 and self.game_board_matrix[3][3] == 1 and self.game_board_matrix[4][4] == 1): self.player1Score += 1
            if (self.game_board_matrix[2][2] == 1 and self.game_board_matrix[3][3] == 1 and self.game_board_matrix[4][4] == 1 and self.game_board_matrix[5][5] == 1): self.player1Score += 1
            if (self.game_board_matrix[0][1] == 1 and self.game_board_matrix[1][2] == 1 and self.game_board_matrix[2][3] == 1 and self.game_board_matrix[3][4] == 1): self.player1Score += 1
            if (self.game_board_matrix[1][2] == 1 and self.game_board_matrix[2][3] == 1 and self.game_board_matrix[3][4] == 1 and self.game_board_matrix[4][5] == 1): self.player1Score += 1
            if (self.game_board_matrix[2][3] == 1 and self.game_board_matrix[3][4] == 1 and self.game_board_matrix[4][5] == 1 and self.game_board_matrix[5][6] == 1): self.player1Score += 1
            if (self.game_board_matrix[0][2] == 1 and self.game_board_matrix[1][3] == 1 and self.game_board_matrix[2][4] == 1 and self.game_board_matrix[3][5] == 1): self.player1Score += 1
            if (self.game_board_matrix[1][3] == 1 and self.game_board_matrix[2][4] == 1 and self.game_board_matrix[3][5] == 1 and self.game_board_matrix[4][6] == 1): self.player1Score += 1
            if (self.game_board_matrix[0][3] == 1 and self.game_board_matrix[1][4] == 1 and self.game_board_matrix[2][5] == 1 and self.game_board_matrix[3][6] == 1): self.player1Score += 1
            if (self.game_board_matrix[0][3] == 1 and self.game_board_matrix[1][2] == 1 and self.game_board_matrix[2][1] == 1 and self.game_board_matrix[3][0] == 1): self.player1Score += 1
            if (self.game_board_matrix[0][4] == 1 and self.game_board_matrix[1][3] == 1 and self.game_board_matrix[2][2] == 1 and self.game_board_matrix[3][1] == 1): self.player1Score += 1
            if (self.game_board_matrix[1][3] == 1 and self.game_board_matrix[2][2] == 1 and self.game_board_matrix[3][1] == 1 and self.game_board_matrix[4][0] == 1): self.player1Score += 1
            if (self.game_board_matrix[0][5] == 1 and self.game_board_matrix[1][4] == 1 and self.game_board_matrix[2][3] == 1 and self.game_board_matrix[3][2] == 1): self.player1Score += 1
            if (self.game_board_matrix[1][4] == 1 and self.game_board_matrix[2][3] == 1 and self.game_board_matrix[3][2] == 1 and self.game_board_matrix[4][1] == 1): self.player1Score += 1
            if (self.game_board_matrix[2][3] == 1 and self.game_board_matrix[3][2] == 1 and self.game_board_matrix[4][1] == 1 and self.game_board_matrix[5][0] == 1): self.player1Score += 1
            if (self.game_board_matrix[0][6] == 1 and self.game_board_matrix[1][5] == 1 and self.game_board_matrix[2][4] == 1 and self.game_board_matrix[3][3] == 1): self.player1Score += 1
            if (self.game_board_matrix[1][5] == 1 and self.game_board_matrix[2][4] == 1 and self.game_board_matrix[3][3] == 1 and self.game_board_matrix[4][2] == 1): self.player1Score += 1
            if (self.game_board_matrix[2][4] == 1 and self.game_board_matrix[3][3] == 1 and self.game_board_matrix[4][2] == 1 and self.game_board_matrix[5][1] == 1): self.player1Score += 1
            if (self.game_board_matrix[1][6] == 1 and self.game_board_matrix[2][5] == 1 and self.game_board_matrix[3][4] == 1 and self.game_board_matrix[4][3] == 1): self.player1Score += 1
            if (self.game_board_matrix[2][5] == 1 and self.game_board_matrix[3][4] == 1 and self.game_board_matrix[4][3] == 1 and self.game_board_matrix[5][2] == 1): self.player1Score += 1
            if (self.game_board_matrix[2][6] == 1 and self.game_board_matrix[3][5] == 1 and self.game_board_matrix[4][4] == 1 and self.game_board_matrix[5][3] == 1): self.player1Score += 1
            if (self.game_board_matrix[2][0] == 2 and self.game_board_matrix[3][1] == 2 and self.game_board_matrix[4][2] == 2 and self.game_board_matrix[5][3] == 2): self.player2Score += 1
            if (self.game_board_matrix[1][0] == 2 and self.game_board_matrix[2][1] == 2 and self.game_board_matrix[3][2] == 2 and self.game_board_matrix[4][3] == 2): self.player2Score += 1
            if (self.game_board_matrix[2][1] == 2 and self.game_board_matrix[3][2] == 2 and self.game_board_matrix[4][3] == 2 and self.game_board_matrix[5][4] == 2): self.player2Score += 1
            if (self.game_board_matrix[0][0] == 2 and self.game_board_matrix[1][1] == 2 and self.game_board_matrix[2][2] == 2 and self.game_board_matrix[3][3] == 2): self.player2Score += 1
            if (self.game_board_matrix[1][1] == 2 and self.game_board_matrix[2][2] == 2 and self.game_board_matrix[3][3] == 2 and self.game_board_matrix[4][4] == 2): self.player2Score += 1
            if (self.game_board_matrix[2][2] == 2 and self.game_board_matrix[3][3] == 2 and self.game_board_matrix[4][4] == 2 and self.game_board_matrix[5][5] == 2): self.player2Score += 1
            if (self.game_board_matrix[0][1] == 2 and self.game_board_matrix[1][2] == 2 and self.game_board_matrix[2][3] == 2 and self.game_board_matrix[3][4] == 2): self.player2Score += 1
            if (self.game_board_matrix[1][2] == 2 and self.game_board_matrix[2][3] == 2 and self.game_board_matrix[3][4] == 2 and self.game_board_matrix[4][5] == 2): self.player2Score += 1
            if (self.game_board_matrix[2][3] == 2 and self.game_board_matrix[3][4] == 2 and self.game_board_matrix[4][5] == 2 and self.game_board_matrix[5][6] == 2): self.player2Score += 1
            if (self.game_board_matrix[0][2] == 2 and self.game_board_matrix[1][3] == 2 and self.game_board_matrix[2][4] == 2 and self.game_board_matrix[3][5] == 2): self.player2Score += 1
            if (self.game_board_matrix[1][3] == 2 and self.game_board_matrix[2][4] == 2 and self.game_board_matrix[3][5] == 2 and self.game_board_matrix[4][6] == 2): self.player2Score += 1
            if (self.game_board_matrix[0][3] == 2 and self.game_board_matrix[1][4] == 2 and self.game_board_matrix[2][5] == 2 and self.game_board_matrix[3][6] == 2): self.player2Score += 1
            if (self.game_board_matrix[0][3] == 2 and self.game_board_matrix[1][2] == 2 and self.game_board_matrix[2][1] == 2 and self.game_board_matrix[3][0] == 2): self.player2Score += 1
            if (self.game_board_matrix[0][4] == 2 and self.game_board_matrix[1][3] == 2 and self.game_board_matrix[2][2] == 2 and self.game_board_matrix[3][1] == 2): self.player2Score += 1
            if (self.game_board_matrix[1][3] == 2 and self.game_board_matrix[2][2] == 2 and self.game_board_matrix[3][1] == 2 and self.game_board_matrix[4][0] == 2): self.player2Score += 1
            if (self.game_board_matrix[0][5] == 2 and self.game_board_matrix[1][4] == 2 and self.game_board_matrix[2][3] == 2 and self.game_board_matrix[3][2] == 2): self.player2Score += 1
            if (self.game_board_matrix[1][4] == 2 and self.game_board_matrix[2][3] == 2 and self.game_board_matrix[3][2] == 2 and self.game_board_matrix[4][1] == 2): self.player2Score += 1
            if (self.game_board_matrix[2][3] == 2 and self.game_board_matrix[3][2] == 2 and self.game_board_matrix[4][1] == 2 and self.game_board_matrix[5][0] == 2): self.player2Score += 1
            if (self.game_board_matrix[0][6] == 2 and self.game_board_matrix[1][5] == 2 and self.game_board_matrix[2][4] == 2 and self.game_board_matrix[3][3] == 2): self.player2Score += 1
            if (self.game_board_matrix[1][5] == 2 and self.game_board_matrix[2][4] == 2 and self.game_board_matrix[3][3] == 2 and self.game_board_matrix[4][2] == 2): self.player2Score += 1
            if (self.game_board_matrix[2][4] == 2 and self.game_board_matrix[3][3] == 2 and self.game_board_matrix[4][2] == 2 and self.game_board_matrix[5][1] == 2): self.player2Score += 1
            if (self.game_board_matrix[1][6] == 2 and self.game_board_matrix[2][5] == 2 and self.game_board_matrix[3][4] == 2 and self.game_board_matrix[4][3] == 2): self.player2Score += 1
            if (self.game_board_matrix[2][5] == 2 and self.game_board_matrix[3][4] == 2 and self.game_board_matrix[4][3] == 2 and self.game_board_matrix[5][2] == 2): self.player2Score += 1
            if (self.game_board_matrix[2][6] == 2 and self.game_board_matrix[3][5] == 2 and self.game_board_matrix[4][4] == 2 and self.game_board_matrix[5][3] == 2): self.player2Score += 1
            if computer == 1:
                self.utility = self.player1Score - self.player2Score + self.evaluation
            else:
                self.utility = self.player2Score - self.player1Score + self.evaluation
    
    def performing_mini_max_over_current_move(self, computer):
        temp_utility = self.utility 
        if temp_utility is not None:
            t_uti = self.utility
            return t_uti
        elif self.currentTurn == computer:
            v = -999
            for child in self.children:
                temp_val = child.performing_mini_max_over_current_move(computer)
                v = max(v, temp_val)
        else:
            v = 999
            for child in self.children:
                temp_val = child.performing_mini_max_over_current_move(computer)
                v = min(v, temp_val)
        self.utility = v
        return self.utility

    def performing_alpha_beta_in_current_move(self, computer, alpha, beta):
        temp_uti = self.utility 
        if temp_uti is not None:
            t_uti = self.utility
            return t_uti
        elif self.currentTurn == computer:
            v = -999
            for child in self.children:
                temp_v = child.performing_alpha_beta_in_current_move(computer, alpha, beta)
                v = max(v, temp_v)
                if alpha >= beta:
                    self.utility = v
                    return self.utility
                else:
                    temp_max = max(alpha, v)
                    alpha = temp_max
        else:
            v = 999
            for child in self.children:
                temp_val = child.performing_alpha_beta_in_current_move(computer, alpha, beta)
                v = min(v, temp_val)
                if beta <= alpha:
                    self.utility = v
                    return self.utility
                else:
                    temp_min = min(v, beta)
                    beta = temp_min
        self.utility = v
        return self.utility

    def selecting_best_move_in_current_position(self, computer):
        alpha = -999
        beta  = 999
        v = self.performing_alpha_beta_in_current_move(computer, alpha, beta)
        for children_matrix in self.children:
            if children_matrix.utility == v:
                return children_matrix.column
        
    def eval(self, computer):
        if computer == 1:
            opposition = 2
        else:
            opposition = 1
        playableMoves = []
        for column in range(0, 7):
            temp_val = self.game_board_matrix[0][column]
            if not temp_val:
                list_loop = list(range(5, -1, -1))
                for row in list_loop:
                    temp_check = self.game_board_matrix[row][column]
                    if not temp_check:
                        temp_dict = {"row": row,"column": column}
                        playableMoves.append(temp_dict)
                        break
        if len(playableMoves) > 0:
            self.loose = -1
            self.win = -1
            self.prob_max_value = -1
            self.loose_best_move_in_game = None
            self.winBestMove = None
            self.prob_move_game = None
            self.randomMove = playableMoves[random.randrange(0, len(playableMoves))] 
            for move in playableMoves:
                looseCounter = 0
                winCounter = 0
                probCounter = 0
                if move["column"] - 3 >= 0:
                    column_min = move["column"] - 3
                else:
                    column_min = 0
                if move["column"] + 3 <= 6:
                    column_max = move["column"] + 3
                else:
                    column_max = 6
                current_row = self.game_board_matrix[move["row"]][:]
                current_row[move["column"]] = opposition
                for i in range(column_min, column_max - 2, 1):
                    if current_row[i:i+4] == [opposition]*4:
                        looseCounter += 1
                current_row[move["column"]] = computer
                for i in range(column_min, column_max - 2, 1):
                    if current_row[i:i+4] == [computer]*4:
                        winCounter += 1
                    try:
                        if current_row[i:i+4].index(opposition) >= 0:
                            pass
                    except:
                        probCounter += 1
                if move["row"] + 3 <= 5:
                    if self.game_board_matrix[move["row"] + 3][move["column"]] == opposition and self.game_board_matrix[move["row"] + 2][move["column"]] == opposition and self.game_board_matrix[move["row"] + 1][move["column"]] == opposition:
                        looseCounter += 1

                    if self.game_board_matrix[move["row"] + 3][move["column"]] == computer and self.game_board_matrix[move["row"] + 2][move["column"]] == computer and self.game_board_matrix[move["row"] + 1][move["column"]] == computer:
                        winCounter += 1

                    probArray = []
                    a = self.game_board_matrix[move["row"] + 3][move["column"]]
                    probArray.append(a)
                    b = self.game_board_matrix[move["row"] + 2][move["column"]]
                    probArray.append(b)
                    c = self.game_board_matrix[move["row"] + 1][move["column"]]
                    probArray.append(c)
                    try:
                        if probArray.index(opposition) >= 0:
                            pass
                    except:
                        temp_counter = probCounter + 1
                        probCounter = temp_counter
                        
                temp_R_start = move["row"]
                c_start = move["column"]
                i = -3
                while i != 0 and temp_R_start != 0 and c_start != 0:
                    temp_R_start = temp_R_start - 1
                    c_start = c_start - 1
                    i = i - 1

                r_end = move["row"]
                c_end = move["column"]
                i = 3
                while i != 0 and r_end != 5 and c_end != 6:
                    a= r_end + 1
                    r_end = a
                    b = c_end + 1
                    c_end = b
                    c = i - 1
                    i = c
                
                temp_R_start_save = temp_R_start
                r_end_save = r_end
                c_start_save = c_start
                c_end_save = c_end

                current_map = copy.deepcopy(self.game_board_matrix)
                current_map[move["row"]][move["column"]] = computer
                while temp_R_start <= r_end - 3:
                    if current_map[temp_R_start][c_start] == computer and current_map[temp_R_start+1][c_start+1] == computer and current_map[temp_R_start+2][c_start+2] == computer and current_map[temp_R_start+3][c_start+3] == computer:
                        winCounter += 1 

                    probArray = []
                    a = current_map[temp_R_start][c_start]
                    probArray.append(a)
                    b = current_map[temp_R_start+1][c_start+1]
                    probArray.append(b)
                    c = current_map[temp_R_start+2][c_start+2]
                    probArray.append(c)
                    d = current_map[temp_R_start+3][c_start+3]
                    probArray.append(d)
                    a = temp_R_start + 1
                    temp_R_start = a
                    b = c_start + 1
                    c_start = b

                    try:
                        if probArray.index(opposition) >= 0:
                            pass
                    except:
                        temp_co = probCounter + 1
                        probCounter = temp_co
                
                temp_R_start = temp_R_start_save
                r_end = r_end_save
                c_start = c_start_save
                c_end = c_end_save

                current_map = copy.deepcopy(self.game_board_matrix)
                current_map[move["row"]][move["column"]] = opposition
                while temp_R_start <= r_end - 3:
                    if current_map[temp_R_start][c_start] == opposition and current_map[temp_R_start+1][c_start+1] == opposition and current_map[temp_R_start+2][c_start+2] == opposition and current_map[temp_R_start+3][c_start+3] == opposition:
                        looseCounter += 1 
                    temp_R_start = temp_R_start + 1
                    c_start = c_start + 1

                temp_R_start = move["row"]
                c_start = move["column"]
                i = -3
                while i != 0 and temp_R_start != 0 and c_start != 6:
                    temp_R_start = temp_R_start - 1
                    c_start = c_start + 1
                    i = i - 1

                r_end = move["row"]
                c_end = move["column"]
                i = 3
                while i != 0 and r_end != 5 and c_end != 0:
                    r_end = r_end + 1
                    c_end = c_end - 1
                    i = i - 1
                
                temp_R_start_save = temp_R_start
                r_end_save = r_end
                c_start_save = c_start
                c_end_save = c_end
                
                current_map = copy.deepcopy(self.game_board_matrix)
                current_map[move["row"]][move["column"]] = computer
                while temp_R_start <= r_end - 3:
                    if current_map[temp_R_start][c_start] == computer and current_map[temp_R_start+1][c_start-1] == computer and current_map[temp_R_start+2][c_start-2] == computer and current_map[temp_R_start+3][c_start-3] == computer:
                        winCounter += 1 

                    probArray = []
                    a = current_map[temp_R_start][c_start]
                    probArray.append(a)
                    b = current_map[temp_R_start+1][c_start-1]
                    probArray.append(b)
                    c = current_map[temp_R_start+2][c_start-2]
                    probArray.append(c)
                    d = current_map[temp_R_start+3][c_start-3]
                    probArray.append(d)
                    
                    a = temp_R_start + 1
                    temp_R_start = a
                    b = c_start - 1
                    c_start = b

                    try:
                        if probArray.index(opposition) >= 0:
                            pass
                    except:
                        temp_counter = probCounter + 1
                        probCounter = temp_counter
                
                temp_R_start = temp_R_start_save
                r_end = r_end_save
                c_start = c_start_save
                c_end = c_end_save
                
                current_map = copy.deepcopy(self.game_board_matrix)
                current_map[move["row"]][move["column"]] = opposition
                while temp_R_start <= r_end - 3:
                    a = current_map[temp_R_start][c_start]
                    b = current_map[temp_R_start+2][c_start-2]
                    c = current_map[temp_R_start+1][c_start-1]
                    d = current_map[temp_R_start+3][c_start-3]
                    if a == opposition and c == opposition and b == opposition and d == opposition:
                        temp_counter = looseCounter + 1
                        looseCounter = temp_counter
                    a = temp_R_start + 1
                    temp_R_start = a
                    b = c_start - 1
                    c_start = b

                if looseCounter != 0 and looseCounter > self.loose:
                    self.loose = looseCounter
                    self.loose_best_move_in_game = move

                if winCounter != 0 and winCounter > self.win:
                    self.win = winCounter
                    self.winBestMove = move

                if probCounter != 0 and probCounter > self.prob_max_value:
                    self.prob_max_value = probCounter
                    self.prob_move_game = move

            if self.win >= self.loose and self.win != -1:
                self.bestMove = {"row" : self.winBestMove["row"],"column" : self.winBestMove["column"],"utility" : self.win * 4}
            elif self.win < self.loose:
                self.bestMove = {"row" : self.loose_best_move_in_game["row"],"column" : self.loose_best_move_in_game["column"],"utility" : self.loose * 4}
            elif self.prob_max_value > 0:
                self.bestMove = {"row" : self.prob_move_game["row"],"column" : self.prob_move_game["column"],"utility" : self.prob_max_value}
            else:
                self.bestMove = {"row" : self.randomMove["row"],"column" : self.randomMove["column"],"utility" : 0}
        else:
            self.bestMove = None

def playing_in_one_move_mode(currentGame, depth):
    if currentGame.pieceCount == 42:    
        print ('BOARD FULL\n\nGame Over!\n')
        sys.exit(0)
    if depth == 0:
        print ('Give a depth greater than 0')
        sys.exit(0)
    currentGame.game_play_by_ai(depth, currentGame.currentTurn) 
    print ('Game state after move:')
    print (' -----------------')
    for i in range(6):
        print(currentGame.game_board_matrix[i])
    print (' -----------------')
    currentGame.player1Score = 0
    currentGame.player2Score = 0
    for row in currentGame.game_board_matrix:
        if row[0:4] == [1]*4:currentGame.player1Score += 1
        if row[1:5] == [1]*4:currentGame.player1Score += 1
        if row[2:6] == [1]*4:currentGame.player1Score += 1
        if row[3:7] == [1]*4:currentGame.player1Score += 1        
        if row[0:4] == [2]*4:currentGame.player2Score += 1
        if row[1:5] == [2]*4:currentGame.player2Score += 1
        if row[2:6] == [2]*4:currentGame.player2Score += 1
        if row[3:7] == [2]*4:currentGame.player2Score += 1
    for j in range(7):            
        if (currentGame.game_board_matrix[0][j] == 1 and currentGame.game_board_matrix[1][j] == 1 and currentGame.game_board_matrix[2][j] == 1 and currentGame.game_board_matrix[3][j] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][j] == 1 and currentGame.game_board_matrix[2][j] == 1 and currentGame.game_board_matrix[3][j] == 1 and currentGame.game_board_matrix[4][j] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][j] == 1 and currentGame.game_board_matrix[3][j] == 1 and currentGame.game_board_matrix[4][j] == 1 and currentGame.game_board_matrix[5][j] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][j] == 2 and currentGame.game_board_matrix[1][j] == 2 and currentGame.game_board_matrix[2][j] == 2 and currentGame.game_board_matrix[3][j] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][j] == 2 and currentGame.game_board_matrix[2][j] == 2 and currentGame.game_board_matrix[3][j] == 2 and currentGame.game_board_matrix[4][j] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][j] == 2 and currentGame.game_board_matrix[3][j] == 2 and currentGame.game_board_matrix[4][j] == 2 and currentGame.game_board_matrix[5][j] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][0] == 1 and currentGame.game_board_matrix[3][1] == 1 and currentGame.game_board_matrix[4][2] == 1 and currentGame.game_board_matrix[5][3] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][0] == 1 and currentGame.game_board_matrix[2][1] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][3] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][1] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][3] == 1 and currentGame.game_board_matrix[5][4] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][0] == 1 and currentGame.game_board_matrix[1][1] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][3] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][1] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][4] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][4] == 1 and currentGame.game_board_matrix[5][5] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][1] == 1 and currentGame.game_board_matrix[1][2] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][4] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][2] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][5] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][5] == 1 and currentGame.game_board_matrix[5][6] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][2] == 1 and currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][5] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][5] == 1 and currentGame.game_board_matrix[4][6] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][3] == 1 and currentGame.game_board_matrix[1][4] == 1 and currentGame.game_board_matrix[2][5] == 1 and currentGame.game_board_matrix[3][6] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][3] == 1 and currentGame.game_board_matrix[1][2] == 1 and currentGame.game_board_matrix[2][1] == 1 and currentGame.game_board_matrix[3][0] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][4] == 1 and currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][1] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][1] == 1 and currentGame.game_board_matrix[4][0] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][5] == 1 and currentGame.game_board_matrix[1][4] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][2] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][4] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][1] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][1] == 1 and currentGame.game_board_matrix[5][0] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][6] == 1 and currentGame.game_board_matrix[1][5] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][3] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][5] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][2] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][2] == 1 and currentGame.game_board_matrix[5][1] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][6] == 1 and currentGame.game_board_matrix[2][5] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][3] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][5] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][3] == 1 and currentGame.game_board_matrix[5][2] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][6] == 1 and currentGame.game_board_matrix[3][5] == 1 and currentGame.game_board_matrix[4][4] == 1 and currentGame.game_board_matrix[5][3] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][0] == 2 and currentGame.game_board_matrix[3][1] == 2 and currentGame.game_board_matrix[4][2] == 2 and currentGame.game_board_matrix[5][3] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][0] == 2 and currentGame.game_board_matrix[2][1] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][3] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][1] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][3] == 2 and currentGame.game_board_matrix[5][4] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][0] == 2 and currentGame.game_board_matrix[1][1] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][3] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][1] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][4] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][4] == 2 and currentGame.game_board_matrix[5][5] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][1] == 2 and currentGame.game_board_matrix[1][2] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][4] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][2] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][5] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][5] == 2 and currentGame.game_board_matrix[5][6] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][2] == 2 and currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][5] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][5] == 2 and currentGame.game_board_matrix[4][6] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][3] == 2 and currentGame.game_board_matrix[1][4] == 2 and currentGame.game_board_matrix[2][5] == 2 and currentGame.game_board_matrix[3][6] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][3] == 2 and currentGame.game_board_matrix[1][2] == 2 and currentGame.game_board_matrix[2][1] == 2 and currentGame.game_board_matrix[3][0] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][4] == 2 and currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][1] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][1] == 2 and currentGame.game_board_matrix[4][0] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][5] == 2 and currentGame.game_board_matrix[1][4] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][2] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][4] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][1] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][1] == 2 and currentGame.game_board_matrix[5][0] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][6] == 2 and currentGame.game_board_matrix[1][5] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][3] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][5] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][2] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][2] == 2 and currentGame.game_board_matrix[5][1] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][6] == 2 and currentGame.game_board_matrix[2][5] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][3] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][5] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][3] == 2 and currentGame.game_board_matrix[5][2] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][6] == 2 and currentGame.game_board_matrix[3][5] == 2 and currentGame.game_board_matrix[4][4] == 2 and currentGame.game_board_matrix[5][3] == 2): currentGame.player2Score += 1
    print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))
    if currentGame.currentTurn == 1:
        currentGame.currentTurn = 2
    elif currentGame.currentTurn == 2:
        currentGame.currentTurn = 1
    for row in currentGame.game_board_matrix:
        currentGame.gameFile.write(''.join(str(col) for col in row) + '\r\n')
    currentGame.gameFile.write('%s\r\n' % str(currentGame.currentTurn))   

    currentGame.gameFile.close()

def playing_game_in_interactive_mode(currentGame, depth, computer):
    if currentGame.pieceCount == 42:    
        currentGame.player1Score = 0
        currentGame.player2Score = 0
        for row in currentGame.game_board_matrix:
            if row[0:4] == [1]*4:currentGame.player1Score += 1
            if row[1:5] == [1]*4:currentGame.player1Score += 1
            if row[2:6] == [1]*4:currentGame.player1Score += 1
            if row[3:7] == [1]*4:currentGame.player1Score += 1        
            if row[0:4] == [2]*4:currentGame.player2Score += 1
            if row[1:5] == [2]*4:currentGame.player2Score += 1
            if row[2:6] == [2]*4:currentGame.player2Score += 1
            if row[3:7] == [2]*4:currentGame.player2Score += 1
        for j in range(7):            
            if (currentGame.game_board_matrix[0][j] == 1 and currentGame.game_board_matrix[1][j] == 1 and currentGame.game_board_matrix[2][j] == 1 and currentGame.game_board_matrix[3][j] == 1): currentGame.player1Score += 1
            if (currentGame.game_board_matrix[1][j] == 1 and currentGame.game_board_matrix[2][j] == 1 and currentGame.game_board_matrix[3][j] == 1 and currentGame.game_board_matrix[4][j] == 1): currentGame.player1Score += 1
            if (currentGame.game_board_matrix[2][j] == 1 and currentGame.game_board_matrix[3][j] == 1 and currentGame.game_board_matrix[4][j] == 1 and currentGame.game_board_matrix[5][j] == 1): currentGame.player1Score += 1
            if (currentGame.game_board_matrix[0][j] == 2 and currentGame.game_board_matrix[1][j] == 2 and currentGame.game_board_matrix[2][j] == 2 and currentGame.game_board_matrix[3][j] == 2): currentGame.player2Score += 1
            if (currentGame.game_board_matrix[1][j] == 2 and currentGame.game_board_matrix[2][j] == 2 and currentGame.game_board_matrix[3][j] == 2 and currentGame.game_board_matrix[4][j] == 2): currentGame.player2Score += 1
            if (currentGame.game_board_matrix[2][j] == 2 and currentGame.game_board_matrix[3][j] == 2 and currentGame.game_board_matrix[4][j] == 2 and currentGame.game_board_matrix[5][j] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][0] == 1 and currentGame.game_board_matrix[3][1] == 1 and currentGame.game_board_matrix[4][2] == 1 and currentGame.game_board_matrix[5][3] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][0] == 1 and currentGame.game_board_matrix[2][1] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][3] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][1] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][3] == 1 and currentGame.game_board_matrix[5][4] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][0] == 1 and currentGame.game_board_matrix[1][1] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][3] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][1] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][4] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][4] == 1 and currentGame.game_board_matrix[5][5] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][1] == 1 and currentGame.game_board_matrix[1][2] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][4] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][2] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][5] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][5] == 1 and currentGame.game_board_matrix[5][6] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][2] == 1 and currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][5] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][5] == 1 and currentGame.game_board_matrix[4][6] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][3] == 1 and currentGame.game_board_matrix[1][4] == 1 and currentGame.game_board_matrix[2][5] == 1 and currentGame.game_board_matrix[3][6] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][3] == 1 and currentGame.game_board_matrix[1][2] == 1 and currentGame.game_board_matrix[2][1] == 1 and currentGame.game_board_matrix[3][0] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][4] == 1 and currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][1] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][1] == 1 and currentGame.game_board_matrix[4][0] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][5] == 1 and currentGame.game_board_matrix[1][4] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][2] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][4] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][1] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][1] == 1 and currentGame.game_board_matrix[5][0] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][6] == 1 and currentGame.game_board_matrix[1][5] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][3] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][5] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][2] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][2] == 1 and currentGame.game_board_matrix[5][1] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][6] == 1 and currentGame.game_board_matrix[2][5] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][3] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][5] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][3] == 1 and currentGame.game_board_matrix[5][2] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][6] == 1 and currentGame.game_board_matrix[3][5] == 1 and currentGame.game_board_matrix[4][4] == 1 and currentGame.game_board_matrix[5][3] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][0] == 2 and currentGame.game_board_matrix[3][1] == 2 and currentGame.game_board_matrix[4][2] == 2 and currentGame.game_board_matrix[5][3] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][0] == 2 and currentGame.game_board_matrix[2][1] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][3] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][1] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][3] == 2 and currentGame.game_board_matrix[5][4] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][0] == 2 and currentGame.game_board_matrix[1][1] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][3] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][1] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][4] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][4] == 2 and currentGame.game_board_matrix[5][5] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][1] == 2 and currentGame.game_board_matrix[1][2] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][4] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][2] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][5] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][5] == 2 and currentGame.game_board_matrix[5][6] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][2] == 2 and currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][5] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][5] == 2 and currentGame.game_board_matrix[4][6] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][3] == 2 and currentGame.game_board_matrix[1][4] == 2 and currentGame.game_board_matrix[2][5] == 2 and currentGame.game_board_matrix[3][6] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][3] == 2 and currentGame.game_board_matrix[1][2] == 2 and currentGame.game_board_matrix[2][1] == 2 and currentGame.game_board_matrix[3][0] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][4] == 2 and currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][1] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][1] == 2 and currentGame.game_board_matrix[4][0] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][5] == 2 and currentGame.game_board_matrix[1][4] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][2] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][4] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][1] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][1] == 2 and currentGame.game_board_matrix[5][0] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][6] == 2 and currentGame.game_board_matrix[1][5] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][3] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][5] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][2] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][2] == 2 and currentGame.game_board_matrix[5][1] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][6] == 2 and currentGame.game_board_matrix[2][5] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][3] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][5] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][3] == 2 and currentGame.game_board_matrix[5][2] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][6] == 2 and currentGame.game_board_matrix[3][5] == 2 and currentGame.game_board_matrix[4][4] == 2 and currentGame.game_board_matrix[5][3] == 2): currentGame.player2Score += 1
        if computer == 1:
            print('Score: Computer (Player 1) = %d, Human (Player 2) = %d\n' % (currentGame.player1Score, currentGame.player2Score))
            if currentGame.player1Score < currentGame.player2Score:
                print ("Congratulations, you WIN!")
            elif currentGame.player1Score > currentGame.player2Score:
                print ("Oops, you lost")
            else:
                print ("You were good. It is a draw")
        else:
            print('Score: Human (Player 1) = %d, Computer (Player 2) = %d\n' % (currentGame.player1Score, currentGame.player2Score))
            if currentGame.player1Score > currentGame.player2Score:
                print ("Congratulations, you WIN!")
            elif currentGame.player1Score < currentGame.player2Score:
                print ("Oops, you lost")
            else:
                print ("You were good. It is a draw")
        print ('BOARD FULL\n\nGame Over!\n')
        sys.exit(0)
    if depth == 0:
        print ('Give a depth greater than 0')
        sys.exit(0)
    if computer == currentGame.currentTurn:
        outFile = "computer.txt"
        currentGame.game_play_by_ai(depth, computer)
        print (' -----------------')
        for i in range(6):
            print(currentGame.game_board_matrix[i])
        print (' -----------------')
        currentGame.player1Score = 0
        currentGame.player2Score = 0
        for row in currentGame.game_board_matrix:
            if row[0:4] == [1]*4:currentGame.player1Score += 1
            if row[1:5] == [1]*4:currentGame.player1Score += 1
            if row[2:6] == [1]*4:currentGame.player1Score += 1
            if row[3:7] == [1]*4:currentGame.player1Score += 1        
            if row[0:4] == [2]*4:currentGame.player2Score += 1
            if row[1:5] == [2]*4:currentGame.player2Score += 1
            if row[2:6] == [2]*4:currentGame.player2Score += 1
            if row[3:7] == [2]*4:currentGame.player2Score += 1
        for j in range(7):            
            if (currentGame.game_board_matrix[0][j] == 1 and currentGame.game_board_matrix[1][j] == 1 and currentGame.game_board_matrix[2][j] == 1 and currentGame.game_board_matrix[3][j] == 1): currentGame.player1Score += 1
            if (currentGame.game_board_matrix[1][j] == 1 and currentGame.game_board_matrix[2][j] == 1 and currentGame.game_board_matrix[3][j] == 1 and currentGame.game_board_matrix[4][j] == 1): currentGame.player1Score += 1
            if (currentGame.game_board_matrix[2][j] == 1 and currentGame.game_board_matrix[3][j] == 1 and currentGame.game_board_matrix[4][j] == 1 and currentGame.game_board_matrix[5][j] == 1): currentGame.player1Score += 1
            if (currentGame.game_board_matrix[0][j] == 2 and currentGame.game_board_matrix[1][j] == 2 and currentGame.game_board_matrix[2][j] == 2 and currentGame.game_board_matrix[3][j] == 2): currentGame.player2Score += 1
            if (currentGame.game_board_matrix[1][j] == 2 and currentGame.game_board_matrix[2][j] == 2 and currentGame.game_board_matrix[3][j] == 2 and currentGame.game_board_matrix[4][j] == 2): currentGame.player2Score += 1
            if (currentGame.game_board_matrix[2][j] == 2 and currentGame.game_board_matrix[3][j] == 2 and currentGame.game_board_matrix[4][j] == 2 and currentGame.game_board_matrix[5][j] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][0] == 1 and currentGame.game_board_matrix[3][1] == 1 and currentGame.game_board_matrix[4][2] == 1 and currentGame.game_board_matrix[5][3] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][0] == 1 and currentGame.game_board_matrix[2][1] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][3] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][1] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][3] == 1 and currentGame.game_board_matrix[5][4] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][0] == 1 and currentGame.game_board_matrix[1][1] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][3] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][1] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][4] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][4] == 1 and currentGame.game_board_matrix[5][5] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][1] == 1 and currentGame.game_board_matrix[1][2] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][4] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][2] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][5] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][5] == 1 and currentGame.game_board_matrix[5][6] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][2] == 1 and currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][5] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][5] == 1 and currentGame.game_board_matrix[4][6] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][3] == 1 and currentGame.game_board_matrix[1][4] == 1 and currentGame.game_board_matrix[2][5] == 1 and currentGame.game_board_matrix[3][6] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][3] == 1 and currentGame.game_board_matrix[1][2] == 1 and currentGame.game_board_matrix[2][1] == 1 and currentGame.game_board_matrix[3][0] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][4] == 1 and currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][1] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][1] == 1 and currentGame.game_board_matrix[4][0] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][5] == 1 and currentGame.game_board_matrix[1][4] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][2] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][4] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][1] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][1] == 1 and currentGame.game_board_matrix[5][0] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][6] == 1 and currentGame.game_board_matrix[1][5] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][3] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][5] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][2] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][2] == 1 and currentGame.game_board_matrix[5][1] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][6] == 1 and currentGame.game_board_matrix[2][5] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][3] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][5] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][3] == 1 and currentGame.game_board_matrix[5][2] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][6] == 1 and currentGame.game_board_matrix[3][5] == 1 and currentGame.game_board_matrix[4][4] == 1 and currentGame.game_board_matrix[5][3] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][0] == 2 and currentGame.game_board_matrix[3][1] == 2 and currentGame.game_board_matrix[4][2] == 2 and currentGame.game_board_matrix[5][3] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][0] == 2 and currentGame.game_board_matrix[2][1] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][3] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][1] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][3] == 2 and currentGame.game_board_matrix[5][4] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][0] == 2 and currentGame.game_board_matrix[1][1] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][3] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][1] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][4] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][4] == 2 and currentGame.game_board_matrix[5][5] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][1] == 2 and currentGame.game_board_matrix[1][2] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][4] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][2] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][5] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][5] == 2 and currentGame.game_board_matrix[5][6] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][2] == 2 and currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][5] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][5] == 2 and currentGame.game_board_matrix[4][6] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][3] == 2 and currentGame.game_board_matrix[1][4] == 2 and currentGame.game_board_matrix[2][5] == 2 and currentGame.game_board_matrix[3][6] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][3] == 2 and currentGame.game_board_matrix[1][2] == 2 and currentGame.game_board_matrix[2][1] == 2 and currentGame.game_board_matrix[3][0] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][4] == 2 and currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][1] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][1] == 2 and currentGame.game_board_matrix[4][0] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][5] == 2 and currentGame.game_board_matrix[1][4] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][2] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][4] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][1] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][1] == 2 and currentGame.game_board_matrix[5][0] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[0][6] == 2 and currentGame.game_board_matrix[1][5] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][3] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][5] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][2] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][2] == 2 and currentGame.game_board_matrix[5][1] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][6] == 2 and currentGame.game_board_matrix[2][5] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][3] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][5] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][3] == 2 and currentGame.game_board_matrix[5][2] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][6] == 2 and currentGame.game_board_matrix[3][5] == 2 and currentGame.game_board_matrix[4][4] == 2 and currentGame.game_board_matrix[5][3] == 2): currentGame.player2Score += 1
        if computer == 1:
            print('Score: Computer (Player 1) = %d, Human (Player 2) = %d\n' % (currentGame.player1Score, currentGame.player2Score))
        else:
            print('Score: Human (Player 1) = %d, Computer (Player 2) = %d\n' % (currentGame.player1Score, currentGame.player2Score))
    else:
        outFile = "human.txt"
        try: 
            column = int(input("What column do you want to play at (from 1 to 7): "))
            if type(column) == int:
                if column > 0 and column <= 7:
                    result = currentGame.play_player_position_taking_move(column - 1)
                    if not result:
                        print ("No moves on column "+ str(column) + ". Try Again")
                        playing_game_in_interactive_mode(currentGame, depth, computer)
                    else:
                        if computer == 1:
                            print('Score: Computer (Player 1) = %d, Human (Player 2) = %d\n' % (currentGame.player1Score, currentGame.player2Score))
                        else:
                            print('Score: Human (Player 1) = %d, Computer (Player 2) = %d\n' % (currentGame.player1Score, currentGame.player2Score))
                else:
                    print ("Invalid Move. Try Again")
                    playing_game_in_interactive_mode(currentGame, depth, computer)
        except:
            sys.exit('Aborting. Wrong input given. The current state of the program is saved in ' + outFile)
    try:
        currentGame.gameFile = open(outFile, 'w')
    except:
        sys.exit('Error opening output file.')
    
    for row in currentGame.game_board_matrix:
        currentGame.gameFile.write(''.join(str(col) for col in row) + '\r\n')
    currentGame.gameFile.write('%s\r\n' % str(currentGame.currentTurn))

    nextGame = maxConnect4Game()
    nextGame.game_board_matrix = copy.deepcopy(currentGame.game_board_matrix)
    nextGame.pieceCount = currentGame.pieceCount
    nextGame.evaluation = 0
    currentGame.gameFile.close()
    if currentGame.currentTurn == 1:
        nextGame.currentTurn = 2
        currentGame.currentTurn = 2
    else:
        nextGame.currentTurn = 1
        currentGame.currentTurn = 1
    playing_game_in_interactive_mode(nextGame, depth, computer)

if __name__ == '__main__':
    start=time.time()
    argv = sys.argv
    if len(argv) != 5:
        print ('Four command-line arguments are needed:')
        print('Usage: %s interactive [input_file] [computer-next/human-next] [depth]' % argv[0])
        print('or: %s one-move [input_file] [output_file] [depth]' % argv[0])
        sys.exit(2)
    game_mode, inFile = argv[1:3]
    if not game_mode == 'interactive' and not game_mode == 'one-move':
        print('%s is an unrecognized game mode' % game_mode)
        sys.exit(2)
    currentGame = maxConnect4Game() 
    try:
        currentGame.gameFile = open(inFile, 'r')
    except IOError:
        sys.exit("\nError opening input file.\nCheck file name.\n")
    file_lines = currentGame.gameFile.readlines()
    currentGame.game_board_matrix = [[int(char) for char in line[0:7]] for line in file_lines[0:-1]]
    currentGame.currentTurn = int(file_lines[-1][0])
    currentGame.evaluation = 0
    currentGame.gameFile.close()
    print ('\nMaxConnect-4 game\n')
    print ('Game state before move:')
    print (' -----------------')
    for i in range(6):
        print(currentGame.game_board_matrix[i])
    print (' -----------------')
    currentGame.pieceCount = sum(1 for row in currentGame.game_board_matrix for piece in row if piece)
    currentGame.player1Score = 0
    currentGame.player2Score = 0
    for row in currentGame.game_board_matrix:
        if row[0:4] == [1]*4:currentGame.player1Score += 1
        if row[1:5] == [1]*4:currentGame.player1Score += 1
        if row[2:6] == [1]*4:currentGame.player1Score += 1
        if row[3:7] == [1]*4:currentGame.player1Score += 1        
        if row[0:4] == [2]*4:currentGame.player2Score += 1
        if row[1:5] == [2]*4:currentGame.player2Score += 1
        if row[2:6] == [2]*4:currentGame.player2Score += 1
        if row[3:7] == [2]*4:currentGame.player2Score += 1
    for j in range(7):            
        if (currentGame.game_board_matrix[0][j] == 1 and currentGame.game_board_matrix[1][j] == 1 and currentGame.game_board_matrix[2][j] == 1 and currentGame.game_board_matrix[3][j] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[1][j] == 1 and currentGame.game_board_matrix[2][j] == 1 and currentGame.game_board_matrix[3][j] == 1 and currentGame.game_board_matrix[4][j] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[2][j] == 1 and currentGame.game_board_matrix[3][j] == 1 and currentGame.game_board_matrix[4][j] == 1 and currentGame.game_board_matrix[5][j] == 1): currentGame.player1Score += 1
        if (currentGame.game_board_matrix[0][j] == 2 and currentGame.game_board_matrix[1][j] == 2 and currentGame.game_board_matrix[2][j] == 2 and currentGame.game_board_matrix[3][j] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[1][j] == 2 and currentGame.game_board_matrix[2][j] == 2 and currentGame.game_board_matrix[3][j] == 2 and currentGame.game_board_matrix[4][j] == 2): currentGame.player2Score += 1
        if (currentGame.game_board_matrix[2][j] == 2 and currentGame.game_board_matrix[3][j] == 2 and currentGame.game_board_matrix[4][j] == 2 and currentGame.game_board_matrix[5][j] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][0] == 1 and currentGame.game_board_matrix[3][1] == 1 and currentGame.game_board_matrix[4][2] == 1 and currentGame.game_board_matrix[5][3] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][0] == 1 and currentGame.game_board_matrix[2][1] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][3] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][1] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][3] == 1 and currentGame.game_board_matrix[5][4] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][0] == 1 and currentGame.game_board_matrix[1][1] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][3] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][1] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][4] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][4] == 1 and currentGame.game_board_matrix[5][5] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][1] == 1 and currentGame.game_board_matrix[1][2] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][4] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][2] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][5] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][5] == 1 and currentGame.game_board_matrix[5][6] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][2] == 1 and currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][5] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][5] == 1 and currentGame.game_board_matrix[4][6] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][3] == 1 and currentGame.game_board_matrix[1][4] == 1 and currentGame.game_board_matrix[2][5] == 1 and currentGame.game_board_matrix[3][6] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][3] == 1 and currentGame.game_board_matrix[1][2] == 1 and currentGame.game_board_matrix[2][1] == 1 and currentGame.game_board_matrix[3][0] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][4] == 1 and currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][1] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][3] == 1 and currentGame.game_board_matrix[2][2] == 1 and currentGame.game_board_matrix[3][1] == 1 and currentGame.game_board_matrix[4][0] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][5] == 1 and currentGame.game_board_matrix[1][4] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][2] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][4] == 1 and currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][1] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][3] == 1 and currentGame.game_board_matrix[3][2] == 1 and currentGame.game_board_matrix[4][1] == 1 and currentGame.game_board_matrix[5][0] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[0][6] == 1 and currentGame.game_board_matrix[1][5] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][3] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][5] == 1 and currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][2] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][4] == 1 and currentGame.game_board_matrix[3][3] == 1 and currentGame.game_board_matrix[4][2] == 1 and currentGame.game_board_matrix[5][1] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[1][6] == 1 and currentGame.game_board_matrix[2][5] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][3] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][5] == 1 and currentGame.game_board_matrix[3][4] == 1 and currentGame.game_board_matrix[4][3] == 1 and currentGame.game_board_matrix[5][2] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][6] == 1 and currentGame.game_board_matrix[3][5] == 1 and currentGame.game_board_matrix[4][4] == 1 and currentGame.game_board_matrix[5][3] == 1): currentGame.player1Score += 1
    if (currentGame.game_board_matrix[2][0] == 2 and currentGame.game_board_matrix[3][1] == 2 and currentGame.game_board_matrix[4][2] == 2 and currentGame.game_board_matrix[5][3] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][0] == 2 and currentGame.game_board_matrix[2][1] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][3] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][1] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][3] == 2 and currentGame.game_board_matrix[5][4] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][0] == 2 and currentGame.game_board_matrix[1][1] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][3] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][1] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][4] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][4] == 2 and currentGame.game_board_matrix[5][5] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][1] == 2 and currentGame.game_board_matrix[1][2] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][4] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][2] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][5] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][5] == 2 and currentGame.game_board_matrix[5][6] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][2] == 2 and currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][5] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][5] == 2 and currentGame.game_board_matrix[4][6] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][3] == 2 and currentGame.game_board_matrix[1][4] == 2 and currentGame.game_board_matrix[2][5] == 2 and currentGame.game_board_matrix[3][6] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][3] == 2 and currentGame.game_board_matrix[1][2] == 2 and currentGame.game_board_matrix[2][1] == 2 and currentGame.game_board_matrix[3][0] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][4] == 2 and currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][1] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][3] == 2 and currentGame.game_board_matrix[2][2] == 2 and currentGame.game_board_matrix[3][1] == 2 and currentGame.game_board_matrix[4][0] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][5] == 2 and currentGame.game_board_matrix[1][4] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][2] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][4] == 2 and currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][1] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][3] == 2 and currentGame.game_board_matrix[3][2] == 2 and currentGame.game_board_matrix[4][1] == 2 and currentGame.game_board_matrix[5][0] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[0][6] == 2 and currentGame.game_board_matrix[1][5] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][3] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][5] == 2 and currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][2] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][4] == 2 and currentGame.game_board_matrix[3][3] == 2 and currentGame.game_board_matrix[4][2] == 2 and currentGame.game_board_matrix[5][1] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[1][6] == 2 and currentGame.game_board_matrix[2][5] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][3] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][5] == 2 and currentGame.game_board_matrix[3][4] == 2 and currentGame.game_board_matrix[4][3] == 2 and currentGame.game_board_matrix[5][2] == 2): currentGame.player2Score += 1
    if (currentGame.game_board_matrix[2][6] == 2 and currentGame.game_board_matrix[3][5] == 2 and currentGame.game_board_matrix[4][4] == 2 and currentGame.game_board_matrix[5][3] == 2): currentGame.player2Score += 1
    print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))
    if game_mode == 'interactive':
        if argv[3] == "computer_next":
            computer = currentGame.currentTurn
        elif argv[3] == "human_next":
            if currentGame.currentTurn == 1:
                computer = 2
            else:
                computer = 1
        playing_game_in_interactive_mode(currentGame, int(argv[4]),computer)
    else: 
        outFile = argv[3]
        try:
            currentGame.gameFile = open(outFile, 'w')
        except:
            sys.exit('Error opening output file.')
        playing_in_one_move_mode(currentGame, int(argv[4])) 
    end=time.time()
    tt=end-start
    print("Execution time in seconds: {}".format(tt))