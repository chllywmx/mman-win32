Name: Sai Deepika Lingineni
UTA ID:1001924255

What Programming Language is used:
Python Programming

How the code is structured:

1. Search() - Checking all the parameters received and according to that choosing the appropriate informed/uninformed using conditional statement. 
2. __main__() - Complete driver code and pass all the required to search function.


How to run the code:

1.Open Terminal
2.Path should be set to the folder Task1

Run command for INFORMED SEARCH:

-- python find_route.py input.txt Bremen Kassel h_kassel.txt

Run command for UNINFORMED SEARCH:

--python find_route.py input.txt Bremen Kassel