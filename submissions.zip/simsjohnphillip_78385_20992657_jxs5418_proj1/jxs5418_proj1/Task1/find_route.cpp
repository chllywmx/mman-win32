//John-Phillip Sims
//1001585417
//CSE4308

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <vector>
#include <queue>

//the mapPath class.
//the data from the input file is put into an array of these objects
class mapPath{ 
	public:
		std::string city1;
		std::string city2;
		int pathCost;
		//std::vector<std::string> prevCities;
};

//the mapNode class
//as the searches go on, mapNodes are created and added to the fringe.
class mapNode{
	public:
		std::string cityName;
		int nodeCost;
		std::vector<std::string> prevCities;
};

//the hueristic class
//the data from the huesristic file is put into a vector of these objects
class hueristic{
	public:
		std::string cityName;
		int hueristicCost;
};

//the method called when hueristics are not used
void uninformedSearch(mapPath bigMap[], int numPaths, std::string startCity, std::string endCity){
	std::vector<std::string> closed;
	
	std::string currentCity;
	currentCity = startCity;
	
	int nodesPopped = 0;
	int nodesExpanded = 0;
	int nodesGenerated = 0;
	int distance = 0;
	
	std::vector<mapNode> fringe;
	
	mapNode first;
	first.cityName = startCity;
	first.nodeCost = 0;
	fringe.push_back(first);
	
	mapNode curr; //current city/node
	//mapNode next; //next city/node
	
	while(fringe.size() > 0){
		//std::cout << "in while loop" << std::endl;
	
		int minPos = 0;
		int i;
		for(i = 0; i < fringe.size(); i++){
			//std::cout << "in min for loop" << std::endl;
			if(fringe[i].nodeCost < fringe[minPos].nodeCost){
				minPos = i;
			}
		}
		
		curr = fringe[minPos];
		//curr = fringe.at(minPos);
		
		if(curr.cityName == endCity){
			std::cout << "Nodes Popped: " << nodesPopped << std::endl;
			std::cout << "Nodes Expanded: " << nodesExpanded << std::endl;
			std::cout << "Nodes Generated: " << nodesGenerated << std::endl;
			std::cout << "Distance: " << curr.nodeCost << " km" << std::endl;
			std::cout << "Route:"<< std::endl;
			if(curr.prevCities.empty()){
				std::cout << "Same city" << std::endl;
			}else{
				curr.prevCities.push_back(curr.cityName);
				
				for(i = 0; i < curr.prevCities.size()-1; i++){
					int lastpos = 0;
					int j;
					for(j = 0; j < numPaths; j++){
						if(curr.prevCities[i] == bigMap[j].city1 && curr.prevCities[i+1] == bigMap[j].city2){
							lastpos = j;
							j = numPaths;
							//break;
						}else if(curr.prevCities[i] == bigMap[j].city2 && curr.prevCities[i+1] == bigMap[j].city1){
							lastpos = j;
							j = numPaths;
							//break;
						}
					}
					std::cout << curr.prevCities[i] << " to " << curr.prevCities[i+1] << ", " << bigMap[lastpos].pathCost << " km" << std::endl;
					//std::cout << "|" << curr.prevCities[i] << "|" << std::endl;
					//std::cout << "size: " << curr.prevCities.size() << std::endl;
				}
			}
			return;
		}
		
		//std::cout << "pre-fringe erase" << std::endl;
		if(fringe.size() > 1){
			fringe.erase(fringe.begin()+minPos);
		}else{
			fringe.erase(fringe.begin());
		}
		//std::cout << "post-fringe erase" << std::endl;
		nodesPopped++;
		
		bool inClosed = false;
		for(i =0; i < closed.size(); i++){
			//std::cout << "in closed for loop" << std::endl;
			if(closed[i] == curr.cityName){
				inClosed = true;
				break;
			}
		}
		
		if(inClosed == false){
			bool expanded = false;
			
			for(i = 0; i < numPaths; i++){
				if(curr.cityName == bigMap[i].city1){
					//std::cout << "curr: |" << curr.cityName << "| bigMap[i].city1: |" << bigMap[i].city1 << "|" << std::endl;
					expanded = true;
					mapNode next;
					next.cityName = bigMap[i].city2;
					next.nodeCost = curr.nodeCost + bigMap[i].pathCost;
					int j;
					for(j = 0; j < curr.prevCities.size(); j++){
						next.prevCities.push_back(curr.prevCities[j]);
					}
					next.prevCities.push_back(curr.cityName);
					
					fringe.push_back(next);
					nodesGenerated++;
				
				}else if(curr.cityName == bigMap[i].city2){
					//std::cout << "curr: |" << curr.cityName << "| bigMap[i].city2: |" << bigMap[i].city2 << "|" << std::endl;
					expanded = true;
					mapNode next;
					next.cityName = bigMap[i].city1;
					next.nodeCost = curr.nodeCost + bigMap[i].pathCost;
					int j;
					for(j = 0; j < curr.prevCities.size(); j++){
						next.prevCities.push_back(curr.prevCities[j]);
					}
					next.prevCities.push_back(curr.cityName);
					
					fringe.push_back(next);
					nodesGenerated++;
				}
			}
			if(expanded == true){
				nodesExpanded++;
				closed.push_back(curr.cityName);
			}
		}
	}
	
	//should only get here if there is no path
	std::cout << "Nodes Popped: " << nodesPopped << std::endl;
	std::cout << "Nodes Expanded: " << nodesExpanded << std::endl;
	std::cout << "Nodes Generated: " << nodesGenerated << std::endl;
	std::cout << "Distance: infinity" << std::endl;
	std::cout << "Route: \n none" << std::endl;
	return;
}


void informedSearch(mapPath bigMap[], int numPaths, std::string startCity, std::string endCity, std::vector<hueristic> hueVector){
	std::vector<std::string> closed;
	
	std::string currentCity;
	currentCity = startCity;
	
	int nodesPopped = 0;
	int nodesExpanded = 0;
	int nodesGenerated = 0;
	int distance = 0;
	
	std::vector<mapNode> fringe;
	
	mapNode first;
	first.cityName = startCity;
	first.nodeCost = 0;
	fringe.push_back(first);
	
	mapNode curr; //current city/node
	//mapNode next; //next city/node
	
	while(fringe.size() > 0){
		//std::cout << "in while loop" << std::endl;
	
		int minPos = 0;
		int i;
		for(i = 0; i < fringe.size(); i++){
			//std::cout << "in min for loop" << std::endl;
			if(fringe[i].nodeCost < fringe[minPos].nodeCost){
				minPos = i;
			}
		}
		
		curr = fringe[minPos];
		//curr = fringe.at(minPos);
		
		if(curr.cityName == endCity){
			std::cout << "Nodes Popped: " << nodesPopped << std::endl;
			std::cout << "Nodes Expanded: " << nodesExpanded << std::endl;
			std::cout << "Nodes Generated: " << nodesGenerated << std::endl;
			std::cout << "Distance: " << curr.nodeCost << " km" << std::endl;
			std::cout << "Route:"<< std::endl;
			if(curr.prevCities.empty()){
				std::cout << "Same city" << std::endl;
			}else{
				curr.prevCities.push_back(curr.cityName);
				
				for(i = 0; i < curr.prevCities.size()-1; i++){
					int lastpos = 0;
					int j;
					for(j = 0; j < numPaths; j++){
						if(curr.prevCities[i] == bigMap[j].city1 && curr.prevCities[i+1] == bigMap[j].city2){
							lastpos = j;
							j = numPaths;
							//break;
						}else if(curr.prevCities[i] == bigMap[j].city2 && curr.prevCities[i+1] == bigMap[j].city1){
							lastpos = j;
							j = numPaths;
							//break;
						}
					}
					std::cout << curr.prevCities[i] << " to " << curr.prevCities[i+1] << ", " << bigMap[lastpos].pathCost << " km" << std::endl;
					//std::cout << "|" << curr.prevCities[i] << "|" << std::endl;
					//std::cout << "size: " << curr.prevCities.size() << std::endl;
				}
			}
			return;
		}
		
		//std::cout << "pre-fringe erase" << std::endl;
		if(fringe.size() > 1){
			fringe.erase(fringe.begin()+minPos);
		}else{
			fringe.erase(fringe.begin());
		}
		//std::cout << "post-fringe erase" << std::endl;
		nodesPopped++;
		
		bool inClosed = false;
		for(i =0; i < closed.size(); i++){
			//std::cout << "in closed for loop" << std::endl;
			if(closed[i] == curr.cityName){
				inClosed = true;
				break;
			}
		}
		
		bool hueCheck = true; //true for good to expand.  false for bad to expand
		int currHue = 0;
		for(i = 0; i < hueVector.size(); i++){
			if(hueVector[i].cityName == curr.cityName){
				currHue = hueVector[i].hueristicCost;
			}
			if(hueVector[i].cityName == curr.cityName && hueVector[i].hueristicCost > curr.nodeCost && fringe.size() > 0){
				hueCheck = false;
				break;
			}
		}
		
		if(inClosed == false && hueCheck == true){
			bool expanded = false;
			
			for(i = 0; i < numPaths; i++){
				if(curr.cityName == bigMap[i].city1){
					//std::cout << "curr: |" << curr.cityName << "| bigMap[i].city1: |" << bigMap[i].city1 << "|" << std::endl;
					expanded = true;
					mapNode next;
					next.cityName = bigMap[i].city2;
					next.nodeCost = curr.nodeCost + bigMap[i].pathCost;
					int j;
					for(j = 0; j < curr.prevCities.size(); j++){
						next.prevCities.push_back(curr.prevCities[j]);
					}
					next.prevCities.push_back(curr.cityName);
					
					fringe.push_back(next);
					nodesGenerated++;
				
				}else if(curr.cityName == bigMap[i].city2){
					//std::cout << "curr: |" << curr.cityName << "| bigMap[i].city2: |" << bigMap[i].city2 << "|" << std::endl;
					expanded = true;
					mapNode next;
					next.cityName = bigMap[i].city1;
					next.nodeCost = curr.nodeCost + bigMap[i].pathCost;
					int j;
					for(j = 0; j < curr.prevCities.size(); j++){
						next.prevCities.push_back(curr.prevCities[j]);
					}
					next.prevCities.push_back(curr.cityName);
					
					fringe.push_back(next);
					nodesGenerated++;
				}
			}
			if(expanded == true){
				nodesExpanded++;
				closed.push_back(curr.cityName);
			}
		}
	}
	
	//should only get here if there is no path
	std::cout << "Nodes Popped: " << nodesPopped << std::endl;
	std::cout << "Nodes Expanded: " << nodesExpanded << std::endl;
	std::cout << "Nodes Generated: " << nodesGenerated << std::endl;
	std::cout << "Distance: infinity" << std::endl;
	std::cout << "Route: \n none" << std::endl;
	return;
}


int main(int argc, char **argv){

	//uninformed search
	if(argc == 4){
		std::string fileName = argv[1];
		std::string startCity = argv[2];
		std::string endCity = argv[3];
		
		std::cout << fileName << ":" << startCity << ":" << endCity << std::endl;
		
		std::ifstream inFile(fileName);
		
		if(!inFile.is_open()){
			std::cout << "ERROR OPENING FILE!!!  ABORTING!!!" << std::endl;
			return 0;
		}
		
		
		std::string inLine;
		int numLines = 0;
		while(std::getline(inFile, inLine)){
			numLines++;
		}
		inFile.clear();
		inFile.seekg(0);
		
		mapPath bigMap[numLines];
		int currLine = 0;
		
		while(std::getline(inFile, inLine)){
			if(inLine.compare("END OF INPUT") == 0){
				break;
			}
			
			std::stringstream sstream(inLine);
			
			std::getline(sstream, bigMap[currLine].city1, ' ');
			std::getline(sstream, bigMap[currLine].city2, ' ');
			std::string lineInt;
			std::getline(sstream, lineInt, ' ');
			bigMap[currLine].pathCost = stoi(lineInt);
			
			//std::cout << bigMap[currLine].city1 << ":" << bigMap[currLine].city2 << ":" << bigMap[currLine].pathCost << ":" << std::endl;
			
			currLine++;
		}
		
		uninformedSearch(bigMap, numLines, startCity, endCity);
		
	}
	else if(argc == 5){	//informed search
		std::string fileName = argv[1];
		std::string startCity = argv[2];
		std::string endCity = argv[3];
		std::string hueFileName = argv[4];
		
		std::cout << fileName << ":" << startCity << ":" << endCity << ":" << hueFileName << std::endl;
		
		std::ifstream inFile(fileName);
		
		if(!inFile.is_open()){
			std::cout << "ERROR OPENING FILE!!!  ABORTING!!!" << std::endl;
			return 0;
		}
		
		
		std::string inLine;
		int numLines = 0;
		while(std::getline(inFile, inLine)){
			numLines++;
		}
		inFile.clear();
		inFile.seekg(0);
		
		mapPath bigMap[numLines];
		int currLine = 0;
		
		while(std::getline(inFile, inLine)){
			if(inLine.compare("END OF INPUT") == 0){
				break;
			}
			
			std::stringstream sstream(inLine);
			
			std::getline(sstream, bigMap[currLine].city1, ' ');
			std::getline(sstream, bigMap[currLine].city2, ' ');
			std::string lineInt;
			std::getline(sstream, lineInt, ' ');
			bigMap[currLine].pathCost = stoi(lineInt);
						
			currLine++;
		}
		
		
		std::ifstream hueFile(hueFileName);
		
		if(!hueFile.is_open()){
			std::cout << "ERROR OPENING HUERISTIC FILE!!!" << std::endl;
			return 0;
		}
		
		std::vector<hueristic> hueVector;
		while(std::getline(hueFile, inLine)){
			if(inLine.compare("END OF INPUT") == 0){
				break;
			}
			hueristic temp;
			std::stringstream sstream(inLine);
			
			std::getline(sstream, temp.cityName, ' ');
			std::string lineInt;
			std::getline(sstream, lineInt, ' ');
			temp.hueristicCost = stoi(lineInt);
			
			hueVector.push_back(temp); 
		}
		
		informedSearch(bigMap, numLines, startCity, endCity, hueVector);
		
	}else{
		std::cout << "Incorrect format" << std::endl;
		std::cout << "Try: ./find_route input_filename start_city destination_city" << std::endl;
		std::cout << "or : ./find_route input_filename start_city destination_city heuristic_filename" << std::endl;
	}

}
