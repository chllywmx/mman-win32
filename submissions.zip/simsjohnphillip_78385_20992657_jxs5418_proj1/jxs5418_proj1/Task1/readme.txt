John-Phillip Sims
1001585417

Programming language used: C++
	as such, it should be omega compatible.  I did write and run it on a simple Ubuntu VM.
	
Code structured:
	3 class descriptions
		class mapPath, which is used for storing the data from the input file
		class mapNode, objects of this class are created and pushed to the fringe as the search goes on
		class heuristic, a class to hold data from the heuristic input file
		
	the uninformed search method
		the method for the uninformed search.
		it starts by declaring some vectors to serve as the closed set and fringe and some ints to keep track of the nodes generated, expanded, and popped
		the very frist city node is created and pushed to the fringe
		
		a while loop that keeps going while the fringe has stuff in it
			finds the lowest cost path and removes it from the fringe
			checks to see if that node is the goal
				if it is, all the node generated, popped, expanded info is printed along with the route and the method returns
				
			checks to see if the current node is in closed set
			
			if not in the closed set, it goes through the vector of paths and sees which ones are connected to the current node
				any nodes connected to the current node are added to the fringe
				
		if this point in the method is reach, then no route exists
		
	the informed search method
		pretty much just the same as the uninformed search method, but the cost of the current node is checked with data from the heuristic file to determine if it is
		worth expanding
		
	The main method
		The data from the input file is read and put into a vector of mapPath objects
		if a heuristic file is being used, then the data from that file is placed into a vector of hueristic objects
		the appropriate search function is called.
		
How to run the code:
	Pull up the command console
	navigate to the directory where you placed find_route.cpp and the input files
	Compile the program with
		g++ -o find_route find_route.cpp
	run the program with either
		./find_route input_file start_city end_city
		or
		./find_route input_file start_city end_city hueristic_file
				
