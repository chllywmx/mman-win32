John-Phillip Sims
1001585417

I did not give myself enough time to actually do task 2, so I don't have a code submission.

That being said, I will write the rest of this read me as if I did have code.

Programming Language used:
	I would have done this in C++
	
How the code is structured:
	Start with the example code on the assignment webpage, 
	but with the aiPlay function editted to have depth-limited minimax and alpha-beta pruning
	Modifications to enable interactive mode and recording CPU runtime would also be necessary
	
Compilation and running:
	in a terminal, navigate to the directory with maxconnect4.cpp
	compile with: 
		g++ -o maxconnect4 maxconnect4.cpp
	run with either:
		./maxconnect4 interactive input_file human-next/computer-next depth
		or
		./maxconnect4 one-move input_file output_file depth

