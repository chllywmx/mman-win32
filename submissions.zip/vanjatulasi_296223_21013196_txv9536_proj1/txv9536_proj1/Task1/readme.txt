Tulasi Vanja - 1002029536
Programming Language: Java
Uninformed Search is implemented using UCS where adjacency matrix was used to track the edges between cities along with its cost
Compiling the code in java:javac find_route input1.txt Bremen Kassel h_kassel.txt
Running the code:java find_route