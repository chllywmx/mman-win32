import java.util.*;
import java.io.*;
@SuppressWarnings("unchecked")
class find_route{
    //static Map<Integer,Integer>edgeCost=new LinkedHashMap<Integer,Integer>();
    static HashMap<Integer, ArrayList<Integer>> edgeCost = new HashMap<Integer, ArrayList>();
    public static void main(String args[]){
       
    if(args.length==3){
      uninformedSearch(args);
    }
    else{
        //informed search
    }
    }
   

static void uninformedSearch(String inputs[]){
  
   try{  
     HashMap<String,Integer>hm=new HashMap<String,Integer>();
     BufferedReader br = new BufferedReader(new FileReader(inputs[0]));
      int content,ct=0;
      String readLine = "";
            while ((readLine = br.readLine()) != null) {
            if(!(readLine.equals("END OF INPUT"))){
               String a[]=readLine.split(" ");
                // System.out.println(a[0]);
                if(!(hm.containsKey(a[0]))){
                  hm.put(a[0],ct);
                  ct++;
    }
    if(!(hm.containsKey(a[1]))){
                  hm.put(a[1],ct);
                  ct++;
    }}}
    String orgcity=inputs[1];
    String destcity=inputs[2];
//     for (Map.Entry<String, Integer> element : hm.entrySet()) {
//     String key = element.getKey();
//    System.out.println(key);

   int adjacencyMatrix[][]=new int[hm.size()][hm.size()];
        String readLine1 = "";
      //adjacency matrix
     while ((readLine1 = br.readLine()) != null) {
            if(!(readLine.equals("END OF INPUT"))){
               String a[]=readLine1.split(" ");
               int row=hm.get(a[0]);
               int col=hm.get(a[1]);
               adjacencyMatrix[row][col]=Integer.parseInt(a[2]);
               adjacencyMatrix[col][row]=Integer.parseInt(a[2]);
               
            }}

            
List<String>cities=new ArrayList<String>();
List<Integer>visitedCities=new ArrayList<Integer>();
// List<String>closed=new List<String>();
List<Integer>cost=new ArrayList<Integer>();
List<Integer>costPath=new ArrayList<Integer>();
String poppedCity=orgcity;
int popValue=hm.get(orgcity);
int pop=0,exp=0,generated=0,totalCost=0;
pop++;
generated++;
boolean result=false;
cities.add(orgcity);
while(!poppedCity.equals("")){
   
    if(poppedCity.equals(destcity)){
        result =true;
        cities.add(poppedCity);
        break;
    }
    else{
        if(!visitedCities.contains(popValue)){
            cities.add(poppedCity);
            visitedCities.add(popValue);
            for(int i=0;i<hm.size();i++){
                if(adjacencyMatrix[popValue][i]!=0){
                cost.add(adjacencyMatrix[popValue][i]);
                addValues(i,adjacencyMatrix[popValue][i]);
                generated++;
            }}
             exp++;
             
        }
        Collections.sort(cost);
        int leastCostNode=cost.get(0);
        for (Map.Entry<Integer,Integer> set :
             edgeCost.entrySet()) {
               if(set.getValue()==leastCostNode){
                        poppedCity=set.getKey();
                        popValue=hm.get(poppedCity); 
                        totalCost=totalCost+leastCostNode;
                        costPath.add(leastCostNode);
                        cost.remove(0);   
                        pop++; 
                        break;     
               }
        }
       
    }}


 System.out.println("Nodes Popped:"+pop);
 System.out.println("Nodes Expanded:"+exp);
 System.out.println("Nodes Generated:"+generated);
 
if(result){
    int cnt=0;
    System.out.println("Distance:"+totalCost+" Km");
    System.out.println("Route:");
    for(int i=0;i<costPath.size();i++){
        System.out.println(cities.get(cnt)+" to "+cities.get(cnt++)+","+costPath.get(i));
        cnt=cnt+2;
    }
}
else{
    System.out.println("Distance:  infinity");
    System.out.println("Route:");
    System.out.println("None");
}
    }
 catch(Exception e){
       e.printStackTrace();
    }
}

public static void addValues(int key, int cost){
    ArrayList tempList = null;
   if (edgeCost.containsKey(key)) {
      tempList = edgeCost.get(key);
      if(tempList == null)
         tempList = new ArrayList();
      tempList.add(cost);  
   } else {
      tempList = new ArrayList();
      tempList.add(cost);               
   }
   edgeCost.put(key,tempList);
}}