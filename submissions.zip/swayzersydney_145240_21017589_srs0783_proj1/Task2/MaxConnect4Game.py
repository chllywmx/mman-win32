#!/usr/bin/env python

# Written by Chris Conly based on C++
# code provided by Vassilis Athitsos
# Written to be Python 2.4 compatible for omega

from copy import copy, deepcopy
import random
import sys


class MaxConnect4Game:
    def __init__(self):
        self.gameBoard = [[0 for _ in range(7)] for _ in range(6)]
        self.nextColumnSpaces = [0 for _ in range(7)]
        self.currentTurn = 1
        self.player1Score = 0
        self.player2Score = 0
        self.player1Combos = []
        self.player2Combos = []
        self.pieceCount = 0
        self.gameFile = None
        random.seed()

    # Count the number of pieces already played
    def check_piece_count(self):
        self.pieceCount = sum(1 for row in self.gameBoard for piece in row if piece)

    # Output current game status to console
    def print_game_board(self):
        print('      1 2 3 4 5 6 7 ')
        print('    -----------------')
        for i in range(6):
            print(' %d  |' % (6-i)),
            for j in range(7):
                print('%d' % self.gameBoard[i][j]),
            print '| '
        print('    -----------------')

    # Output current game status to file
    def print_game_board_to_file(self):
        for row in self.gameBoard:
            self.gameFile.write(''.join(str(col) for col in row) + '\r\n')
        self.gameFile.write('%s\r\n' % str(self.currentTurn))

    # Place the current player's piece in the requested column
    def play_piece(self, column):
        row = self.nextColumnSpaces[column]
        if row != 6:
            self.gameBoard[5-row][column] = self.currentTurn
            choice = (5-row, column)

            if self.currentTurn == 1:
                self.player2Combos = remove_combos([choice], self.player2Combos)
            elif self.currentTurn == 2:
                self.player1Combos = remove_combos([choice], self.player1Combos)

            self.nextColumnSpaces[column] += 1
            self.pieceCount += 1

            return 1
        else:
            return 0

        # if not self.gameBoard[0][column]:
        #     for i in range(5, -1, -1):
        #         if not self.gameBoard[i][column]:
        #             self.gameBoard[i][column] = self.currentTurn
        #             self.pieceCount += 1
        #             return 1

    # TODO
    def ai_play(self, depth):
        if any(self.nextColumnSpaces):
            choice_column = self.ids_min_max_search(depth)
        else:  # Computer is first to play blank game board
            choice_column = 3

        result = self.play_piece(choice_column)

        # TESTING
        # print('Result: %s' % result)
        # print('Column chosen: %s' % choice_column)
        if result:
            print('\nMove %d: Player %d, column %d\n' % (self.pieceCount, self.currentTurn, choice_column + 1))
        else:
            self.ai_play(depth)

        # rand_column =
        # result = self.play_piece(rand_column)
        # if not result:
        #     self.ai_play()
        # else:
        #     print('\n\nmove %d: Player %d, column %d\n' % (self.pieceCount, self.currentTurn, rand_column + 1))
        #     if self.currentTurn == 1:
        #         self.currentTurn = 2
        #     elif self.currentTurn == 2:
        #         self.currentTurn = 1

    def ids_min_max_search(self, depth_limit):
        max_node = True

        # Perfect game for a player has 16 possible connect-4s on single board
        min_value, max_value = -16, 16
        max_depth = 1
        best_move = (-1, -1)
        max_num_combos = -1

        while max_depth <= depth_limit:
            # TESTING
            # print(max_depth)

            current_depth = 1
            num_combos, move = min_max_search(self.nextColumnSpaces, self.player1Combos, self.player2Combos,
                                              max_node, max_depth, current_depth, min_value, max_value)
            if num_combos > max_num_combos:
                best_move = move
            max_depth += 1

            # TESTING
            # print(best_move[0])

        return best_move[0]

    # Calculate the number of 4-in-a-row each player has
    def count_score(self):
        self.player1Score = 0
        self.player2Score = 0

        # Check horizontally
        for row in self.gameBoard:
            # Check player 1
            if row[0:4] == [1] * 4:
                self.player1Score += 1
            if row[1:5] == [1] * 4:
                self.player1Score += 1
            if row[2:6] == [1] * 4:
                self.player1Score += 1
            if row[3:7] == [1] * 4:
                self.player1Score += 1
            # Check player 2
            if row[0:4] == [2] * 4:
                self.player2Score += 1
            if row[1:5] == [2] * 4:
                self.player2Score += 1
            if row[2:6] == [2] * 4:
                self.player2Score += 1
            if row[3:7] == [2] * 4:
                self.player2Score += 1

        # Check vertically
        for j in range(7):
            # Check player 1
            if (self.gameBoard[0][j] == 1 and self.gameBoard[1][j] == 1 and
                    self.gameBoard[2][j] == 1 and self.gameBoard[3][j] == 1):
                self.player1Score += 1
            if (self.gameBoard[1][j] == 1 and self.gameBoard[2][j] == 1 and
                    self.gameBoard[3][j] == 1 and self.gameBoard[4][j] == 1):
                self.player1Score += 1
            if (self.gameBoard[2][j] == 1 and self.gameBoard[3][j] == 1 and
                    self.gameBoard[4][j] == 1 and self.gameBoard[5][j] == 1):
                self.player1Score += 1
            # Check player 2
            if (self.gameBoard[0][j] == 2 and self.gameBoard[1][j] == 2 and
                    self.gameBoard[2][j] == 2 and self.gameBoard[3][j] == 2):
                self.player2Score += 1
            if (self.gameBoard[1][j] == 2 and self.gameBoard[2][j] == 2 and
                    self.gameBoard[3][j] == 2 and self.gameBoard[4][j] == 2):
                self.player2Score += 1
            if (self.gameBoard[2][j] == 2 and self.gameBoard[3][j] == 2 and
                    self.gameBoard[4][j] == 2 and self.gameBoard[5][j] == 2):
                self.player2Score += 1

        # Check diagonally
        #   Check player 1
        if (self.gameBoard[2][0] == 1 and self.gameBoard[3][1] == 1 and
                self.gameBoard[4][2] == 1 and self.gameBoard[5][3] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][0] == 1 and self.gameBoard[2][1] == 1 and
                self.gameBoard[3][2] == 1 and self.gameBoard[4][3] == 1):
            self.player1Score += 1
        if (self.gameBoard[2][1] == 1 and self.gameBoard[3][2] == 1 and
                self.gameBoard[4][3] == 1 and self.gameBoard[5][4] == 1):
            self.player1Score += 1
        if (self.gameBoard[0][0] == 1 and self.gameBoard[1][1] == 1 and
                self.gameBoard[2][2] == 1 and self.gameBoard[3][3] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][1] == 1 and self.gameBoard[2][2] == 1 and
                self.gameBoard[3][3] == 1 and self.gameBoard[4][4] == 1):
            self.player1Score += 1
        if (self.gameBoard[2][2] == 1 and self.gameBoard[3][3] == 1 and
                self.gameBoard[4][4] == 1 and self.gameBoard[5][5] == 1):
            self.player1Score += 1
        if (self.gameBoard[0][1] == 1 and self.gameBoard[1][2] == 1 and
                self.gameBoard[2][3] == 1 and self.gameBoard[3][4] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][2] == 1 and self.gameBoard[2][3] == 1 and
                self.gameBoard[3][4] == 1 and self.gameBoard[4][5] == 1):
            self.player1Score += 1
        if (self.gameBoard[2][3] == 1 and self.gameBoard[3][4] == 1 and
                self.gameBoard[4][5] == 1 and self.gameBoard[5][6] == 1):
            self.player1Score += 1
        if (self.gameBoard[0][2] == 1 and self.gameBoard[1][3] == 1 and
                self.gameBoard[2][4] == 1 and self.gameBoard[3][5] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][3] == 1 and self.gameBoard[2][4] == 1 and
                self.gameBoard[3][5] == 1 and self.gameBoard[4][6] == 1):
            self.player1Score += 1
        if (self.gameBoard[0][3] == 1 and self.gameBoard[1][4] == 1 and
                self.gameBoard[2][5] == 1 and self.gameBoard[3][6] == 1):
            self.player1Score += 1

        if (self.gameBoard[0][3] == 1 and self.gameBoard[1][2] == 1 and
                self.gameBoard[2][1] == 1 and self.gameBoard[3][0] == 1):
            self.player1Score += 1
        if (self.gameBoard[0][4] == 1 and self.gameBoard[1][3] == 1 and
                self.gameBoard[2][2] == 1 and self.gameBoard[3][1] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][3] == 1 and self.gameBoard[2][2] == 1 and
                self.gameBoard[3][1] == 1 and self.gameBoard[4][0] == 1):
            self.player1Score += 1
        if (self.gameBoard[0][5] == 1 and self.gameBoard[1][4] == 1 and
                self.gameBoard[2][3] == 1 and self.gameBoard[3][2] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][4] == 1 and self.gameBoard[2][3] == 1 and
                self.gameBoard[3][2] == 1 and self.gameBoard[4][1] == 1):
            self.player1Score += 1
        if (self.gameBoard[2][3] == 1 and self.gameBoard[3][2] == 1 and
                self.gameBoard[4][1] == 1 and self.gameBoard[5][0] == 1):
            self.player1Score += 1
        if (self.gameBoard[0][6] == 1 and self.gameBoard[1][5] == 1 and
                self.gameBoard[2][4] == 1 and self.gameBoard[3][3] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][5] == 1 and self.gameBoard[2][4] == 1 and
                self.gameBoard[3][3] == 1 and self.gameBoard[4][2] == 1):
            self.player1Score += 1
        if (self.gameBoard[2][4] == 1 and self.gameBoard[3][3] == 1 and
                self.gameBoard[4][2] == 1 and self.gameBoard[5][1] == 1):
            self.player1Score += 1
        if (self.gameBoard[1][6] == 1 and self.gameBoard[2][5] == 1 and
                self.gameBoard[3][4] == 1 and self.gameBoard[4][3] == 1):
            self.player1Score += 1
        if (self.gameBoard[2][5] == 1 and self.gameBoard[3][4] == 1 and
                self.gameBoard[4][3] == 1 and self.gameBoard[5][2] == 1):
            self.player1Score += 1
        if (self.gameBoard[2][6] == 1 and self.gameBoard[3][5] == 1 and
                self.gameBoard[4][4] == 1 and self.gameBoard[5][3] == 1):
            self.player1Score += 1

        #   Check player 2
        if (self.gameBoard[2][0] == 2 and self.gameBoard[3][1] == 2 and
                self.gameBoard[4][2] == 2 and self.gameBoard[5][3] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][0] == 2 and self.gameBoard[2][1] == 2 and
                self.gameBoard[3][2] == 2 and self.gameBoard[4][3] == 2):
            self.player2Score += 1
        if (self.gameBoard[2][1] == 2 and self.gameBoard[3][2] == 2 and
                self.gameBoard[4][3] == 2 and self.gameBoard[5][4] == 2):
            self.player2Score += 1
        if (self.gameBoard[0][0] == 2 and self.gameBoard[1][1] == 2 and
                self.gameBoard[2][2] == 2 and self.gameBoard[3][3] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][1] == 2 and self.gameBoard[2][2] == 2 and
                self.gameBoard[3][3] == 2 and self.gameBoard[4][4] == 2):
            self.player2Score += 1
        if (self.gameBoard[2][2] == 2 and self.gameBoard[3][3] == 2 and
                self.gameBoard[4][4] == 2 and self.gameBoard[5][5] == 2):
            self.player2Score += 1
        if (self.gameBoard[0][1] == 2 and self.gameBoard[1][2] == 2 and
                self.gameBoard[2][3] == 2 and self.gameBoard[3][4] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][2] == 2 and self.gameBoard[2][3] == 2 and
                self.gameBoard[3][4] == 2 and self.gameBoard[4][5] == 2):
            self.player2Score += 1
        if (self.gameBoard[2][3] == 2 and self.gameBoard[3][4] == 2 and
                self.gameBoard[4][5] == 2 and self.gameBoard[5][6] == 2):
            self.player2Score += 1
        if (self.gameBoard[0][2] == 2 and self.gameBoard[1][3] == 2 and
                self.gameBoard[2][4] == 2 and self.gameBoard[3][5] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][3] == 2 and self.gameBoard[2][4] == 2 and
                self.gameBoard[3][5] == 2 and self.gameBoard[4][6] == 2):
            self.player2Score += 1
        if (self.gameBoard[0][3] == 2 and self.gameBoard[1][4] == 2 and
                self.gameBoard[2][5] == 2 and self.gameBoard[3][6] == 2):
            self.player2Score += 1

        if (self.gameBoard[0][3] == 2 and self.gameBoard[1][2] == 2 and
                self.gameBoard[2][1] == 2 and self.gameBoard[3][0] == 2):
            self.player2Score += 1
        if (self.gameBoard[0][4] == 2 and self.gameBoard[1][3] == 2 and
                self.gameBoard[2][2] == 2 and self.gameBoard[3][1] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][3] == 2 and self.gameBoard[2][2] == 2 and
                self.gameBoard[3][1] == 2 and self.gameBoard[4][0] == 2):
            self.player2Score += 1
        if (self.gameBoard[0][5] == 2 and self.gameBoard[1][4] == 2 and
                self.gameBoard[2][3] == 2 and self.gameBoard[3][2] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][4] == 2 and self.gameBoard[2][3] == 2 and
                self.gameBoard[3][2] == 2 and self.gameBoard[4][1] == 2):
            self.player2Score += 1
        if (self.gameBoard[2][3] == 2 and self.gameBoard[3][2] == 2 and
                self.gameBoard[4][1] == 2 and self.gameBoard[5][0] == 2):
            self.player2Score += 1
        if (self.gameBoard[0][6] == 2 and self.gameBoard[1][5] == 2 and
                self.gameBoard[2][4] == 2 and self.gameBoard[3][3] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][5] == 2 and self.gameBoard[2][4] == 2 and
                self.gameBoard[3][3] == 2 and self.gameBoard[4][2] == 2):
            self.player2Score += 1
        if (self.gameBoard[2][4] == 2 and self.gameBoard[3][3] == 2 and
                self.gameBoard[4][2] == 2 and self.gameBoard[5][1] == 2):
            self.player2Score += 1
        if (self.gameBoard[1][6] == 2 and self.gameBoard[2][5] == 2 and
                self.gameBoard[3][4] == 2 and self.gameBoard[4][3] == 2):
            self.player2Score += 1
        if (self.gameBoard[2][5] == 2 and self.gameBoard[3][4] == 2 and
                self.gameBoard[4][3] == 2 and self.gameBoard[5][2] == 2):
            self.player2Score += 1
        if (self.gameBoard[2][6] == 2 and self.gameBoard[3][5] == 2 and
                self.gameBoard[4][4] == 2 and self.gameBoard[5][3] == 2):
            self.player2Score += 1


# Minimax search
def min_max_search(column_spaces, combos1, combos2, max_min_node, max_depth, current_depth, alpha, beta):
    # If 'max_min_node' is 1 -> MAX node
    # If 'max_min_node' is 0 -> MIN node
    min_value, max_value = -16, 16

    # Copy does not affect parent's list of available combinations and available column spaces
    copy_column_spaces = copy(column_spaces)
    copy_combos1 = deepcopy(combos1)
    copy_combos2 = deepcopy(combos2)

    if current_depth == max_depth:
        return node_utility(copy_column_spaces, max_min_node, combos1, combos2)

    if max_min_node:  # MAX node
        best_max = copy(min_value)
        best_position = (-1, -1)

        for i in range(7):
            if copy_column_spaces[i] != 6:
                new_combo = (i, 5-copy_column_spaces[i])
                copy_combos2 = remove_combos([new_combo], copy_combos2)
                copy_column_spaces[i] += 1

                num_combos, position = min_max_search(copy_column_spaces, combos1, copy_combos2, False,
                                                      max_depth, current_depth + 1, alpha, beta)
                # Update maximum (value, position) and alpha
                if num_combos >= best_max:
                    best_position = position
                best_max = max(best_max, num_combos)
                alpha = max(best_max, alpha)

                # Alpha-beta pruning:
                if best_max >= beta:
                    break

        return best_max, best_position

    else:  # MIN node
        best_min = copy(max_value)
        best_position = (-1, -1)

        for i in range(7):
            if copy_column_spaces[i] != 6:
                new_combo = (i, 5 - copy_column_spaces[i])
                copy_combos1 = remove_combos([new_combo], copy_combos1)
                copy_column_spaces[i] += 1

                num_combos, position = min_max_search(copy_column_spaces, copy_combos1, combos2, True,
                                                      max_depth, current_depth + 1, alpha, beta)
                # Update minimum (value, position) and beta
                if num_combos <= best_min:
                    best_position = position
                best_min = min(best_min, num_combos)
                beta = min(best_min, beta)

                # Alpha-beta pruning:
                if best_min <= alpha:
                    break

        return best_min, best_position


# Return the value and position with the highest number of available combinations
def node_utility(column_spaces, max_min_node, my_combos, their_combos):
    possible_moves = dict()

    # Get number of available combinations for the next available space in each column
    for column, row in enumerate(column_spaces):
        if row != 6:
            position = (column, row)
            possible_moves[position] = 0

            # Increment for each of our combinations
            for combo in my_combos:
                if position in combo:
                    possible_moves[position] += 1

            # Decrement for each of opponent's combinations
            for combo in their_combos:
                if position in combo:
                    possible_moves[position] -= 1

    # If call from MAX, return the maximum value and its position
    # If call from MIN, return the minimum value and its position
    if possible_moves:
        if max_min_node:
            position = max(possible_moves, key=possible_moves.get)
            value = max(possible_moves.values())
        else:
            position = min(possible_moves, key=possible_moves.get)
            value = min(possible_moves.values())
    else:
        print('Game board is already full\n')
        position = (-1, -1)
        value = 0

    return value, position


# Get all moves previously played by the player
def get_previous_moves(current_game, player):
    positions = []
    for i in range(6):
        for j in range(7):
            if current_game[i][j] == player:
                new_position = (i, j)
                positions.append(new_position)
    return positions


# Get all unique 69 connect4 combinations
def get_combos():
    combos = []

    # Add all horizontal combos (24)
    for row in range(6):
        for i in range(4):
            new_combo = ((row, i), (row, i + 1), (row, i + 2), (row, i + 3))
            combos.append(new_combo)

    # Add all vertical combos (21)
    for col in range(7):
        for i in range(3):
            new_combo = ((i, col), (i + 1, col), (i + 2, col), (i + 3, col))
            combos.append(new_combo)

    # Add all diagonal combos (24), 12 for each inner loop
    for col in range(4):
        for row in range(3, 6):  # rows 3, 4, 5
            new_combo = ((row, col), (row - 1, col + 1), (row - 2, col + 2), (row - 3, col + 3))
            combos.append(new_combo)

        for row in range(3):  # rows 0, 1, 2
            new_combo = ((row, col), (row + 1, col + 1), (row + 2, col + 2), (row + 3, col + 3))
            combos.append(new_combo)

    # TESTING
    # print(len(combos))
    # print(combos[0])

    return combos


# Remove combinations with positions that have that player's pieces
def remove_combos(positions, combos):
    while positions:
        p2_position = positions.pop(0)

        for i, combo in enumerate(combos):
            if p2_position in combo:
                combos.pop(i)

    return combos

# def define_heuristics():
#     is_full = False
#     turn = 1
#     next_column_space = [1, 1, 1, 1, 1, 1, 1]  # Vertical position for each column
#     grid = [[0, 0, 0, 0, 0, 0, 0],
#             [0, 0, 0, 0, 0, 0, 0],
#             [0, 0, 0, 0, 0, 0, 0],
#             [0, 0, 0, 0, 0, 0, 0],
#             [0, 0, 0, 0, 0, 0, 0],
#             [0, 0, 0, 0, 0, 0, 0]]
#     grids = [(1, turn, next_column_space, grid), ]
#
#     while not is_full:
#         current_item = grids.pop(0)
#
#         depth = current_item[0]
#         current_turn = current_item[1]
#         current_grid = current_item[3]
#         print(depth)
#         for col in range(7):
#             rows = deepcopy(current_item[2])
#             row = rows[col]
#
#             if row != 6:
#                 ncg = deepcopy(current_grid)
#                 ncg[6-row][col] = current_turn
#                 rows[col] += 1
#
#                 if current_turn == 1:
#                     next_turn = 2
#                 else:
#                     next_turn = 1
#
#                 # TESTING
#                 # print('Next available spaces: ')
#                 # print(rows)
#
#                 grids.append((depth + 1, next_turn, rows, ncg))
#
#         # print(len(grids))
#         # Test if full
#         is_full = True
#         for t in grids:
#             top_row = t[3][0]
#             # returns type 'list' but system inspector has false positive as 'int'
#             # noinspection PyTypeChecker
#             all_full = all(top_row)
#             if not all_full:
#                 is_full = False
#
#     print(len(grids))
