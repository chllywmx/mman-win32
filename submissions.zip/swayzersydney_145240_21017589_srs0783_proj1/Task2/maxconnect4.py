"""
Mini-Project 1
Max possible score (4308): 150 pts

PART 2
(Max: 75 pts)

The task in this programming assignment is to implement an agent that plays the Max-Connect4 game using search.
Figure 2 above shows the first few moves of a game.
The game is played on a 6x7 grid, with six rows and seven columns.

There are two players, player A (red) and player B (green).
The two players take turns placing pieces on the board:
    - the red player can only place red pieces, and
    - the green player can only place green pieces.

It is best to think of the board as standing upright.
We will assign a number to every row and column, as follows:
    - Columns are numbered from left to right, with numbers 1, 2, ..., 7.
    - Rows are numbered from bottom to top, with numbers 1, 2, ..., 6.

When a player makes a move, the move is completely determined by specifying the COLUMN where the piece will be
placed. If all six positions in that column are occupied, then the move is invalid, and the program should reject
it and force the player to make a valid move. In a valid move, once the column is specified, the piece is placed on
that column and "falls down", until it reaches the lowest unoccupied row in that column.

The game is over when all positions are occupied. Obviously, every complete game consists of 42 moves, and each
player makes 21 moves.

The score, at the end of the game is determined as follows:
    - Consider each quadruple of four consecutive positions on board, either in the horizontal, vertical, or
        each of the two diagonal directions (from bottom left to top right and from bottom right to top left).
    - The red player gets a point for each such quadruple where all four positions are occupied by red pieces.
    - Similarly, the green player gets a point for each such quadruple where all four positions are occupied by
        green pieces.
The player with the most points wins the game.

Your program will run in two modes:
    - an interactive mode, that is best suited for the program playing against a human player, and
    - a one-move mode, where the program reads the current state of the game from an input file, makes a single
        move, and writes the resulting state to an output file.
            > The one-move mode can be used to make programs play against each other.
            > Note that THE PROGRAM MAY BE EITHER THE RED OR THE GREEN PLAYER, THAT WILL BE SPECIFIED BY THE STATE,
                AS SAVED IN THE INPUT FILE.

As part of this assignment, you will also need to measure and report the time that your program takes, as a
function of the number of moves it explores.

    INTERACTIVE MODE
        In the interactive mode, the game should run from the command line with the following arguments
        (assuming a Java implementation, with obvious changes for C++ or other implementations):
                        java maxconnect4 interactive [input_file] [computer-next/human-next] [depth]
        For example:
                        java maxconnect4 interactive input1.txt computer-next 7

        Argument interactive:
            - specifies that the program runs in interactive mode.
        Argument [input_file]:
            - specifies an input file that contains an initial board state.
                > This way we can start the program from a non-empty board state. If the input file does not exist,
                    the program should just create an empty board state and start again from there.
        Argument [computer-first/human-first]:
            - specifies whether the computer should make the next move or the human.
        Argument [depth]:
            - specifies the number of moves in advance that the computer should consider while searching for its
                next move.
                    > In other words, this argument specifies the depth of the search tree. Essentially, this
                        argument will control the time takes for the computer to make a move.

        After reading the input file, the program gets into the following loop:
            1. If computer-next, goto 2, else goto 5.
            2. Print the current board state and score. If the board is full, exit.
            3. Choose and make the next move.
            4. Save the current board state in a file called computer.txt (in same format as input file).

            5. Print the current board state and score. If the board is full, exit.
            6. Ask the human user to make a move (make sure that the move is valid, otherwise repeat request to
                the user).
            7. Save the current board state in a file called human.txt (in same format as input file).
            8. Goto 2.

    ONE-MOVE MODE
        The purpose of the one-move mode is to make it easy for programs to compete against each other, and
        communicate their moves to each other using text files. The one-move mode is invoked as follows:
                        java maxconnect4 one-move [input_file] [output_file] [depth]
        For example:
                        java maxconnect4 one-move red_next.txt green_next.txt 5

        In this case, the program simply makes a single move and terminates.
        In particular, the program should:
            - Read the input file and initialize the board state and current score, as in interactive mode.
            - Print the current board state and score. If the board is full, exit.
            - Choose and make the next move.
            - Print the current board state and score.
            - Save the current board state to the output file IN EXACTLY THE SAME FORMAT THAT IS USED FOR
                INPUT FILES.
            - Exit.

SAMPLE CODE
    The sample code needs an input file to run. Sample input files that you can download are input1.txt and
    input2.txt. You are free to make other input files to experiment with, as long as they follow the same
    format. In the input files,
        - '0' stands for an empty spot,
        - '1' stands for a piece played by the red player, and
        - '2' stands for a piece played by the green player.
        - The last number in the input file indicates which player plays NEXT (and NOT which player played last).

    Sample (omega-compatible) code is available in:
        - Java: download files here. Compile using:
                    javac maxconnect4.java GameBoard.java AiPlayer.java
            > An example command line that runs the program (assuming that you have input1.txt saved in the
                same directory) is:
                    java maxconnect4 one-move input1.txt output1.txt 10

        - C++: download file here. Compile using:
                    g++ -o maxconnect4 maxconnect.cpp
            > An example command line that runs the program (assuming that you have input1.txt saved in the
                same directory) is:
                    maxconnect4 one-move input1.txt output1.txt 10

        - Python (Version 2.4): download file here.
            > An example command line that runs the program (assuming that you have input1.txt saved in the
                same directory) is:
                    ./maxconnect4.py one-move input1.txt output1.txt 10

MEASURING EXECUTION TIME
You can measure the execution time for your program on Linux/Mac machines by inserting the word "time" in the
beginning of your command line. For example, if you want to measure how much time it takes for your system to
make one move with the depth parameter set to 10, try this:
                                        time java maxconnect4 one-move red_next.txt green_next.txt 10
Your output will look something like:
                                        real    0m0.003s
                                        user    0m0.002s
                                        sys     0m0.001s
Out of the above three lines, the user line is what you should consider.

Windows machines do not have a similar command. However, you can approximate it by setup a batch script like this:
            @echo off
            set startTime=%time%
            java maxconnect4 one-move red_next.txt green_next.txt 10
            echo Start Time: %startTime%
            echo Finish Time: %time%
This will display text similar to the following after the output from your file:
            Start Time:  1:17:14.37
            Finish Time:  1:17:14.44
The difference between the two gives you the time (0.07s).

GRADING
The assignments will be graded out of 75 points.
    30 points:
        Implementing plain minimax.

    20 points:
        Implementing alpha-beta pruning (if correctly implemented, you also get the 30 points for plain minimax,
        you don't need to have separate implementations for it).

    15 points:
        Implementing the depth-limited version of minimax (if correctly implemented, and includes alpha-beta
        pruning, you also get the 30 points for plain minimax and 20 points for alpha-beta search, you don't
        need to have separate implementations for those).

        For full credit, you obviously need to come up with a reasonable evaluation function to be used in
        the context of depth-limited search. A "reasonable" evaluation function is defined to be an
        evaluation function that allows your program to consistently beat a random player.

    10 points:
        Include in your submission a table of CPU runtime (for making a single move) vs depth, when the
        board is empty (input1.txt). Your table should include every single depth, until (and including)
        the first depth for which the time exceeds one minute.
"""

# Written by Chris Conly based on C++
# code provided by Dr. Vassilis Athitsos
# Written to be Python 2.4 compatible for omega

from MaxConnect4Game import *


def one_move_game(current_game, depth, p1_positions, p2_positions):
    if current_game.pieceCount == 42:    # Is the board full already?
        print 'BOARD FULL\n\nGame Over!\n'
        sys.exit(0)

    current_game.player1Combos = get_combos()
    if p1_positions:
        current_game.player2Combos = current_game.remove_combos(p1_positions, current_game.player2Combos)
    if p2_positions:
        current_game.player1Combos = current_game.remove_combos(p2_positions, current_game.player1Combos)

    current_game.ai_play(depth)  # Make a move (only random is implemented)

    print 'Game state after move:'
    current_game.print_game_board()

    current_game.count_score()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (current_game.player1Score, current_game.player2Score))

    current_game.print_game_board_to_file()
    current_game.gameFile.close()


# TODO
def interactive_game(current_game, depth):
    # Remove any connect-4 combinations already played by p2
    current_game.player1Combos = get_combos()

    # Run game until the board is full
    while current_game.pieceCount != 42:
        # TESTING
        # current_game.ai_play(depth, combos)
        print('Current turn: %d\n' % current_game.currentTurn)

        if current_game.currentTurn == 1:
            current_game.ai_play(depth)
        else:
            # Ask user for column choice (check if valid) and remove from remaining computer combinations
            choice_column = int(input('Choose Column (1-7): ')) - 1

            while choice_column < 0 or choice_column > 6 or not current_game.play_piece(choice_column):
                print('Please choose a valid column: \n')
                choice_column = int(input('Choose Column (1-7): ')) - 1

        if current_game.currentTurn == 1:
            current_game.currentTurn = 2
        elif current_game.currentTurn == 2:
            current_game.currentTurn = 1

        # Print game board
        current_game.print_game_board()

        current_game.count_score()
        print('Score: Player 1 = %d, Player 2 = %d\n' % (current_game.player1Score, current_game.player2Score))

    # Print game results
    if current_game.pieceCount == 42:    # Is the board full?
        print('BOARD FULL\n\nGame Over!\n')

        if current_game.player1Score > current_game.player2Score:
            print('Sorry, you lose.\n')
        elif current_game.player1Score < current_game.player2Score:
            print('YOU BEAT THE COMPUTER!!\n')
        else:
            print('YOU BOTH TIED! IMPRESSIVE!\n')

    sys.exit(0)


def main(argv):
    # Make sure we have enough command-line arguments
    if len(argv) != 5:
        print 'Four command-line arguments are needed:'
        print('Usage: %s interactive [input_file] [computer-next/human-next] [depth]' % argv[0])
        print('or: %s one-move [input_file] [output_file] [depth]' % argv[0])
        sys.exit(2)

    game_mode, in_file = argv[1:3]

    if argv[4].isdigit():
        depth = int(argv[4])
        if depth < 1:
            print('Argument 5 [depth] must be a positive integer')
            sys.exit(2)
    else:
        print('Argument 5 [depth] must be a positive integer')
        sys.exit(2)

    if not game_mode == 'interactive' and not game_mode == 'one-move':
        print('%s is an unrecognized game mode' % game_mode)
        sys.exit(2)

    current_game = MaxConnect4Game()    # Create a game

    # Try to open the input file
    try:
        current_game.gameFile = open(in_file, 'r')
    except IOError:
        sys.exit("\nError opening input file.\nCheck file name.\n")

    # Read the initial game state from the file and save in a 2D list
    file_lines = current_game.gameFile.readlines()
    current_game.gameBoard = [[int(char) for char in line[0:7]] for line in file_lines[0:-1]]
    current_game.currentTurn = int(file_lines[-1][0])
    current_game.gameFile.close()

    print '\nMaxConnect-4 game\n'
    print 'Game state before move:'
    current_game.print_game_board()

    # Update a few game variables based on initial state and print the score
    current_game.check_piece_count()
    current_game.count_score()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (current_game.player1Score, current_game.player2Score))

    if game_mode == 'interactive':
        # Be sure to pass whatever else you need from the command line
        interactive_game(current_game, depth)

    # game_mode == 'one-move'
    else:
        p1_positions = get_previous_moves(current_game.gameBoard, 1)
        p2_positions = get_previous_moves(current_game.gameBoard, 2)

        # Set up the output file
        out_file = argv[3]
        try:
            current_game.gameFile = open(out_file, 'w')
        except IOError:
            sys.exit("\nError opening/creating output file.\nCheck file name.\n")
        # Be sure to pass any other arguments from the command line you might need.
        one_move_game(current_game, depth, p1_positions, p2_positions)


if __name__ == '__main__':
    main(sys.argv)
