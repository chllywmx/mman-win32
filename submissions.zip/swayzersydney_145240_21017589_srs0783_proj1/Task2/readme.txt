Name:       Sydney Swayzer
ID:         1001470783
Language:   Python 2.7.18
Created:    9 July 2022
Edited:     15 July 2022

Code Structure: (Built on sample code)

    Added to 'maxconnect4.py'
        FUNCTION play_piece()
            - Added line to remove that position in the column from other player's combinations

        FUNCTION interactive_game(current_game, depth, p2_positions)
            1) Remove any connect-4 combinations already played by p2 (indicated by 'p2_positions' list)
            2) Run game until the board is full
                a) If player1 turn (computer),
                    - Call function ai_play() with 'depth' and 'combos' as arguments

                b) If player2 turn,
                    - Ask user for column choice (check if valid)
                    - Call function play_piece() with user's column choice

                c) Print board state and scores after move

            3) Print game results


    Added to 'MaxConnect4Game.py'
        FUNCTION min_max_search(column_spaces, combos1, combos2, max_min_node, max_depth, current_depth, alpha, beta)
            1) Create copies of 'column_spaces', 'combos1', and 'combos2'
            2) If the current depth is the max depth
                a) Return the value and its position from the function node_utility()

            3) If a MAX node
                a) Set the maximum value to -16
                b) For every column (that isn't already full)
                    - Remove that position from the copy of player2's combinations
                    - Increment that column's next available space
                    - Get the value and position from calling min_max_search() with a MIN node,
                            new copy of player2's combinations, and updated copy of available column spaces

                    - Update the maximum value if the new value is greater
                    - Update alpha if the updated maximum value is greater
                    - Prune any remaining successors if the new value is greater than beta

                c) Return the maximum value with its position

            4) If a MIN node
                a) Set the minimum value to 16
                b) For every column (that isn't already full)
                    - Remove that position from the copy of player1's combinations
                    - Increment that column's next available space
                    - Get the value and position from calling min_max_search() with a MAX node,
                            new copy of player1's combinations, and updated copy of available column spaces

                    - Update the minimum value if the new value is less
                    - Update beta if the updated minimum value is less
                    - Prune any remaining successors if the new value is less than alpha

                c) Return the minimum value with its position


        FUNCTION node_utility(column_spaces, max_min_node, my_combos, their_combos)
            1) Create dictionary to hold every position's number of combination

            2) For every next available space in 'column_spaces'
                a) Increment the number for each of our combinations
                b) Decrement the number for each of their combinations

            3) If called by MAX node, return the maximum value and its position
            4) If called by MIN node, return the minimum value and its position


        FUNCTION get_previous_moves(current_game)
            1) Return positions a player has already filled on the board


        FUNCTION get_combos()
            1) Return all 69 connect-4 combinations playable on 6x7 board


        FUNCTION remove_combos(positions, combos)
            1) For every position player has made (in 'positions')
                a) Delete any combination in 'combos' that includes that position tuple

            2) Return the remaining available combinations


        class MaxConnect4Game:
            nextColumnSpaces:   holds index of the next available space of each column
            player1Combos:      lists all available combinations for player 1
            player2Combos:      lists all available combinations for player 2

            FUNCTION ai_play():
                1) Calls ids_min_max_search() with alpha = -16, beta = 16, depth from command line
                2) Returns the best column to choose for play_piece()

            FUNCTION ids_min_max_search(combos, depth_limit)
                1) Set the maximum depth to 1
                2) Set the minimum and maximum values to -16 and 16, respectively

                3) Until the maximum depth is greater than the depth limit
                    a) Set the current depth to 1
                    b) Get the best move and its number of combinations by calling min_max_search() with:
                        - current depth
                        - maximum depth
                        - minimum and maximum values as alpha and beta, respectively
                        - MAX node
                        - the game's column spaces, player1's combinations, and player2's combinations

                    c) If the new move's number of combinations is greater, replace the old chosen move with it
                    d) Increment the maximum depth

                4) Return the best move to choose


Code Execution (& Compilation):
    - Tested on Python versions:
        > 2.7.18
        > 3.10.5

    - Execution format (no compilation required):
        python maxconnect4.py interactive input1.txt computer-next 7
        python maxconnect4.py one-move input1.txt output1.txt 10