Name:       Sydney Swayzer
ID:         1001470783
Language:   Python 2.7.18
Created:    9 July 2022
Edited:     11 July 2022

Code Structure:

    FUNCTION load_data()
        1) Fill 'roads' (declared in main) with data in [input file]
        2) Fill 'city_dict' (declared in main) with data in 'roads' for each city
        3) Add heuristic values to each city in 'city_dict' from [heuristic file]
        4) Return names of start and goal cities

    FUNCTION a_star_search()
        1) Add the start node to 'fringe'
        2) Until either the goal is found or 'fringe' is empty
            a) Pop the next node from 'fringe'
            b) Check if the node is the goal
            c) If not the goal, check if the node is in 'closed_set'

            d) If not in 'closed_set',
                i)   For each neighboring node, get its information and calculate its f(n)
                ii)  Check if the node is already in 'fringe'
                        - If so, check if the new version's f(n) is less than that of the one in 'fringe'
                        - If [new f(n) < old f(n)], delete the old version from 'fringe'

                iii) Call insert_fringe() if not already in 'fringe' or [new f(n) < old f(n)] to add node to 'fringe'
                iv)  Add the node to 'closed_set'

        3) Return whether the goal was found and the number of nodes popped, expanded, and generated during search

    FUNCTION insert_fringe()
        1) Find the first node in 'fringe' whose f(n) is greater than that of the new node
        2) If found, insert the new node in its position
        3) If not, simply append it to 'fringe'

    FUNCTION get_goal_path()
        1) Make a dictionary of each city in 'closed_set' with its parent and step cost from parent (except start)
        2) Get the path from start to goal tracing back from goal
        3) While the traceback city is not the start,
            a) Add the city and its parent and step cost from the parent to 'goal_path'
            b) Set the traceback city to the parent city

    FUNCTION main()
        roads: list of tuples where each tuple contains
                        [0] city 1
                        [1] city 2
                        [2] step cost

        closed_set: list of tuples where each tuple contains
                        [0] city
                        [1] step cost
                        [2] f(n) = step cost + heuristic
                        [3] parent city (omitted for start node)

        goal_path: list of tuples where each tuple contains
                        [0] parent city
                        [1] city
                        [2] step cost

        city_dict: dictionary where
                    key = city name
                    value = list containing:
                        [0] list of indices in 'road' where city is found
                        [1] heuristic value

        closed_dict: dictionary where
                    key = city name
                    value = tuple containing:
                        [0] step cost
                        [1] parent city (omitted for start node)

        1) Call load_data()
        2) Call a_star_search()
        3) If a route exists, call get_goal_path() and calculate the total distance
        4) Print results including:
            a) Nodes popped
            b) Nodes expanded
            c) Nodes generated
            d) Distance (km)
            e) Route:
                - [city1, city2, step cost (km)] for each road taken (if one exists)

Code Execution (& Compilation):
    - Tested on Python versions:
        > 2.4.3
        > 2.7.18
        > 3.10.5

    - Execution format (no compilation required):
            python find_route.py input_file.txt origin_city destination_city heuristic_file.txt
