"""
Mini-Project 1
Max possible score (4308): 150 pts

PART 1
(Max: 75 pts)

Implement a search algorithm that can find a route between any two cities.
Your program will be called find_route, and will take exactly commandline arguments as follows:
    find_route input_filename origin_city destination_city heuristic_filename

An example command line is:
    find_route input1.txt Bremen Kassel (For doing Uninformed search)
or
    find_route input1.txt Bremen Kassel h_kassel.txt (For doing Informed search)

If heuristic is not provided then program must do uninformed search.
Argument input_filename is the name of a text file such as, that describes road connections between cities
in some part of the world. For example, the road system described by file input1.txt can be visualized in Figure 1
shown above.
You can assume that the input file is formatted in the same way as input1.txt:
    - Each line contains three items.
    - The last line contains the items "END OF INPUT", and that is how the program can detect that it has reached the
        end of the file.
    - The other lines of the file contain, in this order,
        > a source city,
        > a destination city, and
        > the length in kilometers of the road connecting directly those two cities.
    - Each city name will be a single word (for example, we will use New_York instead of New York), consisting of
        upper and lowercase letters and possibly underscores.

The program will compute a route between the origin city and the destination city, and will print out both the length
of the route and the list of all cities that lie on that route. It should also display the number of nodes expanded
and nodes generated. For example,
                                    find_route input1.txt Bremen Kassel
should have the following output:
                                    Nodes Popped: 12
                                    Nodes Expanded: 6
                                    Nodes Generated: 20
                                    Distance: 297.0 km
                                    Route:
                                    Bremen to Hannover, 132.0 km
                                    Hannover to Kassel, 165.0 km

and
                                    find_route input1.txt London Kassel
should have the following output:
                                    Nodes Popped: 7
                                    Nodes Expanded: 4
                                    Nodes Generated: 7
                                    Distance: infinity
                                    Route:
                                    None

For full credit, you should produce outputs identical in format to the above two examples.

If a heuristic file is provided, then program must perform Informed search. The heuristic file gives the estimate of
what the cost could be to get to the given destination from any start state (note this is just an estimate).
In this case, the command line would look like
    find_route input1.txt Bremen Kassel h_kassel.txt

Here the last argument contains a text file which has the heuristic values for every state wrt (with respect to) the
given destination city (note different destinations will need different heuristic values).

For example, you have been provided a sample file h_kassel.txt which gives the heuristic value for every state
(assuming kassel is the goal). Your program should use this information to reduce the number of nodes it ends up
expanding. Other than that, the solution returned by the program should be the same as the uninformed version.
For example,
                                    find_route input1.txt Bremen Kassel h_kassel.txt
should have the following output:
                                    Nodes Popped: 3
                                    Nodes Expanded: 2
                                    Nodes Generated: 8
                                    Distance: 297.0 km
                                    Route:
                                    Bremen to Hannover, 132.0 km
                                    Hannover to Kassel, 165.0 km

GRADING
The assignments will be graded out of 75 points.
    TODO (35 points):
        The program always finds a route between the origin and the destination, as long as such a route exists.

    TODO (15 points):
        The program terminates and reports that no route can be found when indeed no route exists that connects
        source and destination (e.g., if source is London and destination is Berlin, in the above example).

    TODO (15 points):
        In addition to the above requirements, the program always returns optimal routes. In other words, no shorter
        route exists than the one reported by the program.

    TODo (10 points):
        Correct implementation of any informed search method. Please note that you only need to make one submission
        that meets this and all previous requirements to get credit for all the parts.

    Negative points:
        Penalty points will be awarded by the instructor and TA generously and at will, for issues such as:
            - submission not including precise and accurate instructions for how to run the code,
            - wrong compression format for the submission, or
            - other failures to comply with the instructions given for this assignment.
        Partial credit for incorrect solutions will be given ONLY for code that is well-designed and well-documented.
        Code that is badly designed and badly documented can still get credit only as long as it accomplishes the
        required tasks.
"""
import sys


def load_data(argv):
    """
    Load in command line arguments.
        [1] Text file of cities and roads
            - Each line contains three items.
            - The last line contains the items "END OF INPUT", and that is how the program can detect that it has
                reached the end of the file.
            - The other lines of the file contain, in this order,
                > a source city,
                > a destination city, and
                > the length in kilometers of the road connecting directly those two cities.
            - Each city name will be a single word (for example, we will use New_York instead of New York),
                consisting of upper and lowercase letters and possibly underscores.

        [2] Name of SOURCE city

        [3] Name of DESTINATION city

        [4] Text file of heuristics
            - The heuristic file gives the estimate of what the cost could be to get to the given destination
                from any start state (note this is just an estimate).

    :return (roads, city_dict, src_city, dest_city)

    """
    city_dict = dict()
    roads = []

    # Get roads from input file (City1, City2, Step_cost)
    try:
        cities = open(argv[1], "r")
    except IndexError:
        print("Error: Missing command line argument 1 [input file].")
        sys.exit(1)
    except Exception:
        raise

    for line in cities:
        if "END OF INPUT" in line:
            break

        road = line.split()
        step_cost = (float(road[-1]),)
        del road[-1]
        road = tuple(road)
        road = road + step_cost

        roads.append(road)
    cities.close()

    # Add all cities to dictionary with 'road' index
    for i, road in enumerate(roads):
        for city in road[:2]:
            if city in city_dict:
                new_city = city_dict.get(city)
                new_city[0].append(i)
                city_dict[city] = new_city
            else:
                city_dict[city] = [[i]]

    # TESTING
    # for k, v in city_dict.items():
    #     print(k, v)

    # Check if SOURCE and DESTINATION are located on the map
    try:
        src_city = argv[2]
    except IndexError:
        print("Error: Missing command line argument 2 [source city].")
        sys.exit(1)

    try:
        dest_city = argv[3]
    except IndexError:
        print("Error: Missing command line argument 3 [destination city].")
        sys.exit(1)

    if src_city not in city_dict:
        print("Error: Source city %s was not located on the map." % src_city)
        sys.exit(1)
    elif dest_city not in city_dict:
        print("Error: Destination city %s was not located on the map." % dest_city)
        sys.exit(1)

    # Add heuristic values to each city
    try:
        heuristics = open(argv[4], "r")
    except IndexError:
        print("Error: Missing command line argument 4 [heuristics file].")
        sys.exit(1)
    except Exception:
        raise

    for h in heuristics:
        if "END OF INPUT" in h:
            break

        h = h.split()
        city = h[0]
        h_value = [float(h[-1])]

        if city in city_dict:
            new_city = city_dict.get(city)
            new_city.extend(h_value)
            city_dict[city] = new_city
        else:
            city_dict[city] = [[], h_value]    # No roads lead to this city
    heuristics.close()

    for city in city_dict:
        if len(city_dict.get(city)) != 2:
            print("Error: City %s has no heuristic value." % city)
            sys.exit(1)

    # TESTING
    # for k, v in city_dict.items():
    #     print(k, v)
    return roads, city_dict, src_city, dest_city


def a_star_search(roads, city_dict, start, goal):
    closed_set = []

    # Add starting city to the fringe and initialize values
    fringe = [(start, 0, city_dict.get(start)[1])]
    n_p, n_e, n_g = 0, 0, 1
    found_goal = False

    # Search until either the fringe is empty or goal is found
    while fringe and not found_goal:
        # Get the next city
        current_node = fringe.pop(0)
        n_p += 1
        in_closed = False

        # TESTING
        # print("Current node: %s %d %d" % current_node)

        # Check if node is the goal
        current_city = current_node[0]
        if current_city == goal:
            found_goal = True
            closed_set.append(current_node)
            continue

        # Check if node is in closed set
        for city in closed_set:
            if current_city == city[0]:
                in_closed = True
                break

        if not in_closed:
            neighbors = city_dict.get(current_city)[0]
            for i in neighbors:
                insert_into_fringe = True

                # Get neighbor information
                road = roads[i]
                if current_city == road[0]:
                    neighbor = road[1]
                else:
                    neighbor = road[0]

                step_cost = road[2]
                h_value = city_dict.get(neighbor)[1]
                f_n = step_cost + h_value

                # Check if neighbor is already in the fringe
                for j, city in enumerate(fringe):
                    if neighbor == city[0]:
                        if f_n < city[2]:
                            fringe.pop(j)
                        else:
                            insert_into_fringe = False
                        break

                # Insert new neighbor into the fringe
                if insert_into_fringe:
                    new_node = (neighbor, step_cost, f_n, current_city)
                    insert_fringe(fringe, new_node)
                n_g += 1
            n_e += 1
            closed_set.append(current_node)

    return closed_set, found_goal, n_p, n_e, n_g


def insert_fringe(sort_list, new_item):
    inserted = False
    for i, node in enumerate(sort_list):
        if new_item[2] < node[2]:
            sort_list.insert(i, new_item)
            inserted = True
            # TESTING
            # print("Node: %s %d %d inserted into fringe at %d" % (new_node, i))
            break

    if not inserted:
        sort_list.append(new_item)
        # TESTING
        # print("Node: %s %d %d appended to fringe" % (new_node)


def get_goal_path(closed_set, start, goal):
    # Make a dictionary of each city in 'closed_set' with its parent and step cost from parent (except start)
    goal_path = []
    closed_dict = dict()

    for city in closed_set:
        if city[0] != start:
            closed_dict[city[0]] = (city[1], city[3])

    # Get the path from start to goal tracing back from goal
    tb_city = goal
    while tb_city != start:
        road_info = closed_dict.get(tb_city)
        parent_city = road_info[1]

        # Add city to goal path
        goal_path.insert(0, (parent_city, tb_city, road_info[0]))
        tb_city = parent_city

    return goal_path


def print_results(n_p, n_e, n_g, route_exists, total_dist, goal_path):
    print("Nodes Popped:    %d" % n_p)
    print("Nodes Expanded:  %d" % n_e)
    print("Nodes Generated: %d" % n_g)

    if route_exists:
        print("Distance: %.1f km" % total_dist)
        for city in goal_path:
            print("    %s to %s, %.1f km" % city)

    else:
        print("Distance: infinity")
        print("Route:")
        print("    None")


def main(argv):
    roads, city_dict, start, goal = load_data(argv)
    closed_set, route_exists, n_popped, n_expanded, n_generated = a_star_search(roads, city_dict, start, goal)
    # TESTING
    # print(n_popped, n_expanded, n_generated)
    # for city in closed_set:
    #     print(city)

    # Get goal path and distance
    total_dist, goal_path = 0, []
    if route_exists:
        goal_path = get_goal_path(closed_set, start, goal)
        for city in goal_path:
            total_dist += city[2]

    # Print results
    print_results(n_popped, n_expanded, n_generated, route_exists, total_dist, goal_path)


if __name__ == "__main__":
    main(sys.argv)
