import sys
from MaxConnect4Game import *

def oneMoveGame(currentGame):
    if currentGame.pieceCount == 42:    
        print ('BOARD FULL\n\nGame Over!\n')
        sys.exit(0)

    currentGame.aiPlay()
    print ('Game state after move:')
    currentGame.printGameBoard()

    currentGame.countScore()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))
    
    currentGame.printGameBoardToFile()
    currentGame.gameFile.close()

def computer_next(currentGame, depth = 7):
    currentGame.comPlay(int(depth))

    currentGame.countScore()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))
    
    currentGame.printGameBoardToFile()
    currentGame.gameFile.close()
    human_next(currentGame)
    

def human_next(currentGame):
    while not currentGame.pieceCount == 42: 
        user_move = int(input("Enter column no. between [1-7], Where you would like to play?"))
        if not (0 < user_move < 8):
            print ("Invalid input, Please enter a column no. between [1-7]")
            continue
        if not currentGame.playPiece(user_move-1):
            print ("Coloumn is full, please enter another one")
            continue
        
        try:
            currentGame.gameFile = open("human.txt", 'w')
            print("The current user move is at col: ", str(user_move))
            print ('Game state after move:')
            currentGame.printGameBoard()
            currentGame.printGameBoardToFile()
            currentGame.gameFile.close()
            currentGame.countScore()
            print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))
            computer_next(currentGame)
        except Exception:
            print("Exception")

def interactiveGame(currentGame, next_turn):
    # Fill me in
    # sys.exit('Interactive mode is currently not implemented')
    if next_turn == "human-next":
        human_next(currentGame)
    elif next_turn == "computer-next":
        computer_next(currentGame)


def main(argv):
    # Make sure we have enough command-line arguments
    if len(argv) != 5:
        print ('Four command-line arguments are needed:')
        print('Usage: %s interactive [input_file] [computer-next/human-next] [depth]' % argv[0])
        print('or: %s one-move [input_file] [output_file] [depth]' % argv[0])
        sys.exit(2)

    game_mode, inFile = argv[1:3]
    next_turn = argv[3]
    depth = argv[4]

    if not game_mode == 'interactive' and not game_mode == 'one-move':
        print('%s is an unrecognized game mode' % game_mode)
        sys.exit(2)

    currentGame = maxConnect4Game() # Create a game

    # Try to open the input file
    try:
        currentGame.gameFile = open(inFile, 'r')
    except IOError:
        # sys.exit("\nError opening input file.\nCheck file name.\n")
        print("No input file, creating an initial state input file to play the game")
        initial_state = "0000000\n0000000\n0000000\n0000000\n0000000\n0000000\n1"
        input_file = open(inFile, "w")
        input_file.write(initial_state)
        input_file.close()
        currentGame.gameFile = open(inFile, 'r')

    # Read the initial game state from the file and save in a 2D list
    file_lines = currentGame.gameFile.readlines()
    currentGame.gameBoard = [[int(char) for char in line[0:7]] for line in file_lines[0:-1]]
    currentGame.currentTurn = int(file_lines[-1][0])
    currentGame.gameFile.close()

    print ('\nMaxConnect-4 game\n')
    print ('Game state before move:')
    currentGame.printGameBoard()

    # Update a few game variables based on initial state and print the score
    currentGame.checkPieceCount()
    currentGame.countScore()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))

    if game_mode == 'interactive':
        interactiveGame(currentGame, next_turn) # Be sure to pass whatever else you need from the command line
    else: # game_mode == 'one-move'
        # Set up the output file
        outFile = argv[3]
        try:
            currentGame.gameFile = open(outFile, 'w')
        except:
            sys.exit('Error opening output file.')
        oneMoveGame(currentGame) # Be sure to pass any other arguments from the command line you might need.


if __name__ == '__main__':
    main(sys.argv)