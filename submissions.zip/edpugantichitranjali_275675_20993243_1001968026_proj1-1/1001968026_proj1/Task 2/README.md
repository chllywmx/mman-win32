## NAME:Chitranjali Edpuganti
## UTA ID:1001968026

# Language: Python

## Code structure:

maxconnect4Game.py - Main code- this is invoked to start the game, this inturn takes care of subsequent moves in one move game or interactive min max game
MaxConnect4Game.py - This is the game board instances and all the methods related to the game board, like checking the pieces count and moving the pieces and determining min and max moves.

## Instructions to run:
No need of installling any packages, run on python 3.7+

Open your terminal and cd into task 1 directory.
1) Test case 1: Type 'python maxconnect4.py one-move input1.txt output1.txt 7'
Output for above command would be as below:

MaxConnect-4 game

Game state before move:
 -----------------
 | 0 0 0 0 0 0 0 | 
 | 0 0 0 0 0 0 0 | 
 | 0 0 0 0 0 0 0 | 
 | 0 0 0 0 0 0 0 | 
 | 0 0 0 0 0 0 0 | 
 | 0 0 0 0 0 0 0 | 
 -----------------
Score: Player 1 = 0, Player 2 = 0



move 1: Player 1, column 2

Game state after move:
 -----------------
 | 0 0 0 0 0 0 0 | 
 | 0 0 0 0 0 0 0 | 
 | 0 0 0 0 0 0 0 | 
 | 0 0 0 0 0 0 0 | 
 | 0 0 0 0 0 0 0 | 
 | 0 1 0 0 0 0 0 | 
 -----------------
Score: Player 1 = 0, Player 2 = 0


2) Test case 2: Type 'python maxconnect4.py interactive input1.txt human-next 7'
