import sys
import operator

#Node definition
class nodeTree:
    def __init__(self, parent, curr, g, d, f, Uninformed):
        self.Uninformed = Uninformed
        self.parent = parent
        self.curr = curr
        self.g = g #g(n)
        self.d = d #depth
        self.f = f #f(n), heu case
        
    def __str__(self):
        if self.Uninformed:
            return self.curr+": g= "+str(self.g) + ",d= "+str(self.d)+",Parent ->{"+str(self.parent)+"}"

def expandNode(node, route_json, h):
    next_routes = route_json[node.curr]
    next_nodes = []
    for i in next_routes:
        total_cost = node.g + i[1]
        if node.Uninformed:
            next_nodes.append(nodeTree(node, i[0], total_cost, node.d + 1, 0, node.Uninformed))
        else:
            next_nodes.append(nodeTree(node, i[0], total_cost, node.d + 1, total_cost + h[i[0]], node.Uninformed))

    return next_nodes

# path_trace the path from node
def path_trace(node, route_json):
    trace_list = []
    distance = node.g
    while node is not None:
        parent = node.parent
        if parent is not None:
            #get the distance from current node to parent
            dist = (x for x in route_json[parent.curr] if
                   x[0] == node.curr)
            l=next(dist)
            trace_list.append(parent.curr+" to "+node.curr+ ", "+str(l[1])+" km")
        node = parent
    print("Distance: " + str(distance))
    print("Route:")
    trace_list.reverse()
    for i in trace_list:
        print(i)

def get_file_content(file, is_h=False):
    filedata = open(file, 'r')
    route_json = {}
    heu_json = {}
    for line in filedata:
        line = line.strip()

        if not is_h:
            if line != 'END OF INPUT':
                route_list = line.split(' ')
                route_list[2] = float(route_list[2])

                # Map the to and fro distances of each city w.r.t other cities
                if route_list[0] in route_json:
                    route_json[route_list[0]].append([route_list[1], route_list[2]])
                else:
                    route_json[route_list[0]] = [[route_list[1], route_list[2]]]

                if route_list[1] in route_json:
                    route_json[route_list[1]].append([route_list[0], route_list[2]])
                else:
                    route_json[route_list[1]] = [[route_list[0], route_list[2]]]
            else:
                return route_json
        else:
            if line != 'END OF INPUT':
                h_line = line.split(' ')
                h_line[1] = float(h_line[1])
                heu_json[h_line[0]] = h_line[1]
            else:
                return heu_json

def main():
    if len(sys.argv) == 5:
        print("Informed Search")
        Uninformed = False
    else:
        print("Uninformed search")
        Uninformed = True
    
    if len(sys.argv) != 1 :
        #transorm route data to json
       route_json = get_file_content(sys.argv[1])
    else:
        print("Please provide route file!")
        sys.exit()
    
    h = {}
    if not Uninformed:
        h = get_file_content(sys.argv[4], is_h=True)
    
    fringe = []
    if Uninformed:
        fringe.append(nodeTree(None, sys.argv[2], 0, 0, 0, Uninformed))
        # print(fringe)
    else:
        fringe.append(nodeTree(None, sys.argv[2], 0, 0, h[sys.argv[2]], Uninformed))

    visited = []
    nodes_popped = 0
    nodes_expanded = 0
    nodes_generated = 0
    final = sys.argv[3] #destination node
    while len(fringe) > 0:
        # print(visited)
        node = fringe.pop(0)
        nodes_popped += 1
        # print(node.curr, nodes_popped)
        # goal curr checked
        if node.curr != final:
            if node.curr not in visited:
                visited.append(node.curr)
                next_nodes = expandNode(node, route_json, h)
                nodes_expanded = nodes_expanded + 1
                for x in next_nodes:
                    fringe.append(x)
                nodes_generated = nodes_generated + len(next_nodes)

                #sort based on f(n) in heuristic case, to get min cost to pop
                if Uninformed:
                    fringe = sorted(fringe, key=operator.attrgetter('g'))
                else:
                    fringe = sorted(fringe, key=operator.attrgetter('f'))
        else:
            print("Nodes Popped: " + str(nodes_popped))
            print("Nodes Expanded: " + str(nodes_expanded))
            print("Nodes Generated: " + str(nodes_generated))
            path_trace(node, route_json)
            sys.exit()
    else:
        #  No route found
        print("Nodes Popped: " + str(nodes_popped))
        print("Nodes Expanded: " + str(nodes_expanded))
        print("Nodes Generated: " + str(nodes_generated))
        print("Distance:infinity")
        print("Route:None")

if __name__ == "__main__":
    main()