## NAME:Chitranjali Edpuganti
## UTA ID:1001968026

# Language: Python

## Code structure:

find_route.py - Consist of creating and expanding nodes, and then performs informed or uninformed search
Input1 and h_kassel are respective input and heuristic files already provided.

## Instructions to run:
No need of installling any packages, run on python 3.7+

Open your terminal and cd into task 1 directory.
1) Test case 1: Type 'python find_route.py input1.txt London Kassel'
Output for above command would be as below:

Uninformed search
Nodes Popped: 7
Nodes Expanded: 4
Nodes Generated: 6
Distance:infinity
Route:None

2) Test case 2: Type 'python find_route.py input1.txt Bremen Kassel h_kassel.txt' (with heuristic)
Output for above command would be as below:

Informed Search
Nodes Popped: 3
Nodes Expanded: 2
Nodes Generated: 7
Distance: 297.0
Route:
Bremen to Hannover, 132.0 km
Hannover to Kassel, 165.0 km