Name: Siva Teja Reddy Korrapati
UTA ID: 1002027876
Programming Language Used: Python

I used PyCharm 2022.1.3 

To run the code: Right click on the find_route.py and open in termal and give the following commands

For doing Uninformed search: python find_route.py input1.txt [City1] [City2]

Example for doing uninformed search: python find_route.py input1.txt Bermen Kassel

For doing Informed search: python find_route.py input1.txt [City1] [City2] h_kassel.txt

Example for doing informed search: python find_route.py input1.txt Bremen Kassel h_Kassel.txt


