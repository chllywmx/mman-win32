import sys
import math
def uninformed_search(distance_list,source,destination): #this function performs uninformed search
    set_of_cities = set()
    nodes_generated = 1
    nodes_popped = 1
    no_of_nodes_expanded = 0
    generated_nodes = []
    route_list = []
    nodes_expanded = []
    generated_nodes.append([source, None, 0.0, 0])
    route_list.append([source, None, 0.0, 0])
    city = source
    flag = False
    while not flag:
        if not generated_nodes:
            return False
        nodes_expanded.append(city)
        parent_cost = float(generated_nodes[0][2])
        prev_depth = generated_nodes[0][3]
        generated_nodes.pop(0)
        nodes_popped += 1
        if city not in set_of_cities:
            no_of_nodes_expanded += 1
            for i in distance_list:
                if city in i:
                    nodes_generated+=1
                    a =[distance_list.index(i),i.index(city)]
                    if a[1] == 0:
                        city_temp = distance_list[distance_list.index(i)][1]
                        parent = city
                        depth = prev_depth +1
                        total_cost = parent_cost + float(distance_list[distance_list.index(i)][2])  
                        generated_nodes.append([city_temp, parent, total_cost, depth])
                        route_list.append([city_temp, parent, total_cost, depth])
                    elif a[1] == 1:
                        city_temp = distance_list[distance_list.index(i)][0]
                        parent = city
                        depth = prev_depth +1
                        total_cost = parent_cost + float(distance_list[distance_list.index(i)][2])
                        generated_nodes.append([city_temp, parent, total_cost, depth])
                        route_list.append([city_temp, parent, total_cost, depth])
                    
                        
        set_of_cities.add(city)
        generated_nodes = sorted(generated_nodes,key=lambda x: x[2])

        if generated_nodes:
            city = generated_nodes[0][0]
            distance = generated_nodes[0][2]
         #   no_of_nodes_expanded = len(nodes_expanded) + 1
            
        else:
            nodes_popped -= 1
            distance = "infinity"
          #  no_of_nodes_expanded = len(nodes_expanded)

        if city == destination or distance == "infinity":
            print_data(nodes_popped, no_of_nodes_expanded,nodes_generated,distance, route_list, source, destination) 
            flag = True

def informed_search(distance_list,source,destination, heuristic): #this function performs informed search
    route_list = []
    nodes_expanded = []
    set_of_cities = set()
    nodes_generated = 1
    nodes_popped = 1
    no_of_nodes_expanded = 0
    generated_nodes = []
    generated_nodes.append([source, None, 0.0, 0, 0.0])
    route_list.append([source, None, 0.0, 0, 0.0])
    city = source
    flag = False
    while not flag:
        if not generated_nodes:
            return False
        nodes_expanded.append(city)
        parent_cost = float(generated_nodes[0][4])
        prev_depth = generated_nodes[0][3]
        generated_nodes.pop(0)
        nodes_popped += 1
        if city not in set_of_cities:
            no_of_nodes_expanded += 1
            for i in distance_list:
                if city in i:
                    nodes_generated+=1
                    a =[distance_list.index(i),i.index(city)]
                    if a[1] == 0:
                        city_temp = distance_list[distance_list.index(i)][1]
                        parent = city
                        depth = prev_depth +1
                        for j in heuristic:
                            if city_temp in j:
                                heuristic_value = float(heuristic[heuristic.index(j)][1])
                        actual_cost = parent_cost + float(distance_list[distance_list.index(i)][2])
                        total_cost = heuristic_value + parent_cost + float(distance_list[distance_list.index(i)][2])
                        generated_nodes.append([city_temp, parent, total_cost, depth, actual_cost])
                        route_list.append([city_temp, parent, total_cost, depth, actual_cost])
                    elif a[1] == 1:
                        city_temp = distance_list[distance_list.index(i)][0]
                        parent = city
                        depth = prev_depth +1
                        for j in heuristic:
                            if city_temp in j:
                                heuristic_value = float(heuristic[heuristic.index(j)][1])
                        actual_cost = parent_cost + float(distance_list[distance_list.index(i)][2])
                        total_cost = heuristic_value + parent_cost + float(distance_list[distance_list.index(i)][2])
                        generated_nodes.append([city_temp, parent, total_cost, depth, actual_cost])
                        route_list.append([city_temp, parent, total_cost, depth, actual_cost])
        set_of_cities.add(city)
        generated_nodes = sorted(generated_nodes,key=lambda x: x[2])
        if generated_nodes:
            city = generated_nodes[0][0]
            distance = generated_nodes[0][2]
            #no_of_nodes_expanded = len(nodes_expanded) + 1
            
        else:
            distance = "infinity"
            nodes_popped -= 1
            #no_of_nodes_expanded = len(nodes_expanded)
        if city == destination or distance == "infinity":
            print_data(nodes_popped, no_of_nodes_expanded,nodes_generated,distance, route_list, source, destination) 
            flag = True
            
def print_data(nodes_popped, nodes_expanded,nodes_generated,distance, route_list, start, end): #this function prints the output in required format
    print("Nodes Popped :", nodes_popped)
    print("Nodes Expanded:", nodes_expanded)
    print("Nodes Generated:", nodes_generated)
    if distance == "infinity":
        print("Distance: " + str(distance))
        print("Route:")
        print("None")
    else:
        print("Distance: " + str(distance) + "km")
        print("Route:")
        route = []
        for i in route_list:
            if end in i and distance in i:
                route.append(i)
        for i in range(route[0][3]-1):
            for j in route_list:
                if route:
                    if route[-1][1] in j and route[-1][3] - 1 in j:
                        route.append(j)
        route.reverse()
        if len(sys.argv) == 4:
            for i in range(len(route)):
                if i > 0:
                    print(route[i][1]+" to "+route[i][0]+", "+str(route[i][2] - route[i-1][2])+"km")
                else:
                    print(route[i][1]+" to ",route[i][0]+", "+str(route[i][2])+"km")        
        elif len(sys.argv) == 5:
            for i in range(len(route)):
                if i > 0:
                    print(route[i][1]+" to "+route[i][0]+", "+str(route[i][4] - route[i-1][4])+"km")
                else:
                    print(route[i][1]+" to "+route[i][0]+", "+str(route[i][4])+"km")
                    
if __name__ == '__main__':            
    input_file = open(sys.argv[1],"r")
    distances_list = []
    for line in input_file:
        if line == "END OF INPUT":
            break
        input_data = line.rstrip('\n').split(" ")
        distances_list.append(input_data) 
    source = sys.argv[2]
    destination = sys.argv[3]
    if len(sys.argv) == 4:
        uninformed_search(distances_list, source, destination)
    elif len(sys.argv) == 5:
        heuristic_input_file = open(sys.argv[4],"r")
        heuristic = []
        for line in heuristic_input_file:
            if line == "END OF INPUT":
                break
            h_data = line.rstrip('\n').split(" ")
            heuristic.append(h_data)
        informed_search(distances_list, source, destination, heuristic)
