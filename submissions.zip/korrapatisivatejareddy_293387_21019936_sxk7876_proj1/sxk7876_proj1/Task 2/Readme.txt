Name: Siva Teja Reddy Korrapati
UTA ID: 1002027876
Programming Language used: Python

To run the code: right click on the MaxConnect4Game.py and open in termiinal

Commands to run the code:

For One-Move Mode: python maxconnect.py one-move input1.txt output.txt 1

For Interactive Mode: python maxconnect4.py interactive input1.txt human-next 3

