from MaxConnect4Game import maxConnect4Game
from copy import deepcopy
import math

def alpha_beta(state):
    nodes = []
    for a,s in succesors(state):
        v = min_value(state=s, minint=-math.inf, maxint=math.inf, depth=deepcopy(state.depth))
        nodes.append((a,v))
    counter = 0
    for a_and_v in nodes:
        if counter == 0:
            a = a_and_v[0]
            v = a_and_v[1]
            counter = counter + 1
            continue
        if a_and_v[1] > v:
            a = a_and_v[0]
            v = a_and_v[1]
        counter = counter + 1
    return a

def min_value(state, minint, maxint, depth):
    if state.checkPieceCount() == 42 or depth == 1:
        state.countScore()
        return state.scoreCount()
    v = math.inf
    for a,s in succesors(state):
        v = min(v,max_value(s,minint,maxint,deepcopy(depth-1)))
        if v <= minint:
            return v
        maxint = min(maxint,v)
    return v

def max_value(state, minint, maxint, depth):
    if state.checkPieceCount() == 42 or depth == 1:
        state.countScore()
        return state.scoreCount()

    v = -math.inf
    for a,s in succesors(state):
        v = max(v,min_value(s,minint,maxint,deepcopy(depth-1)))
        if v >= maxint:
            return v
        minint = max(minint, v)
    return v

def succesors(state):
    playPieceList = []
    if state.currentTurn == 1:
        childTurn = 2
    else:
        childTurn = 1
    for i in range(7):
        new_gameBoard = maxConnect4Game()
        new_gameBoard.gameBoard = deepcopy(state.gameBoard)
        new_gameBoard.currentTurn = childTurn
        if new_gameBoard.playPiece(i):
            playPieceList.append((i,new_gameBoard))
    return playPieceList