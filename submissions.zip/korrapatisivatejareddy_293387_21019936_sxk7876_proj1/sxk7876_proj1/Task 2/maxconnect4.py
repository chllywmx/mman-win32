from copy import deepcopy
import alphabeta
import sys
from MaxConnect4Game import *


def oneMoveGame(currentGame):
    if currentGame.pieceCount == 42:
        print('Board is full!\n')
        sys.exit(0)
    value_of_a = alphabeta.alpha_beta(currentGame)
    currentGame.playPiece(value_of_a)
    print('Game state after move:')
    currentGame.printGameBoard()
    currentGame.countScore()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))
    currentGame.printGameBoardToFile()
    currentGame.gameFile.close()


def interactiveGame(board , nextPlayer):
    # Fill me in
    print('Current board : ')
    board.printGameBoard()   # displaying the game board
    board.countScore()  # displaying score
    print('Score: PlayerA = %d, PlayerB = %d\n' % (board.player1Score, board.player2Score))
    if nextPlayer == 'human-next':
        while board.checkPieceCount() != 42:  # checking if the board is empty or not
            print("Your turn") 
            print(" -----------")
            print("Enter a column number between 1 and 7:")
            userMove = int(input()) 
            if not 0 < userMove < 8:    # checking if it is valid input or not
                continue
            if not board.play(userMove - 1):
                print("Column "+ str(userMove) + " is full.")
                continue
            print("The move you made: " + str(userMove))
            board.printGameBoard() 
            board.gameFile = open("human.txt", 'w')
            board.printGameBoardToFile()
            board.gameFile.close()  
            if board.checkPieceCount() == 42:    
                print("No more moves possible, Game Over!")
                board.score()
                print('Score: PlayerA = %d, PlayerB = %d\n' % (board.player1Score, board.player2Score))
                break
            else:
                print("Computer is conputing based on next " + str(board.depth) + " steps...")
                if board.currentTurn == 1:
                    board.currentTurn = 2
                elif board.currentTurn == 2:
                    board.currentTurn = 1
                board.aiPlay() 
                board.printGameBoard() 
                board.gameFile = open('computer.txt', 'w')
                board.printGameBoardToFile()
                board.gameFile.close()
                board.countScore()
                print('Score: PlayerA = %d, PlayerB = %d\n' % (board.player1Score, board.player2Score))
    else:
        board.aiPlay()
        board.gameFile = open('computer.txt', 'w')
        board.printGameBoardToFile()
        board.gameFile.close()
        board.printGameBoard()  
        board.countScore() 
        print('Score: PlayerA = %d, PlayerB = %d\n' % (board.player1Score, board.player2Score))
        while board.checkPieceCount() != 42:
            print("Your turn") 
            print(" ------- ----")
            print("Enter a column number between 1 and 7:")
            userMove = int(input())
            if not 0 < userMove < 8: 
                continue
            if not board.play(userMove - 1):
                print("Column "+ str(userMove) + " is full.")
                continue
            print("The move you made: " + str(userMove))
            board.printGameBoard() 
            board.gameFile = open("human.txt", 'w')
            board.printGameBoardToFile()
            board.gameFile.close()  
            if board.checkPieceCount() == 42:    
                print("No more moves possible, Game Over!")
                board.score()
                print('Score: PlayerA = %d, PlayerB = %d\n' % (board.player1Score, board.player2Score))
                break
            else:   # computer move
                print("Computer is conputing based on next " + str(board.depth) + " steps...")
                if board.currentTurn == 1:
                    board.currentTurn = 2
                elif board.currentTurn == 2:
                    board.currentTurn = 1
                board.aiPlay()  # computing the computer move with the minmax alpha beta pruning
                board.printGameBoard()
                board.gameFile = open('computer.txt', 'w')
                board.printGameBoardToFile()
                board.gameFile.close() 
                board.countScore()
                print('Score: PlayerA = %d, PlayerB = %d\n' % (board.player1Score, board.player2Score))

    if board.checkPieceCount() == 42:
        if board.player1Score > board.player2Score:
            print("Player 1 wins")
        if board.player1Score == board.player2Score:
            print("The game is a tie")
        if board.player1Score < board.player2Score:
            print("Player 2 wins")
        print("Game Over!")

def main(argv):
    # Make sure we have enough command-line arguments
    if len(argv) != 5:
        print('Four command-line arguments are needed:')
        print('Usage: %s interactive [input_file] [computer-next/human-next] [depth]' % argv[0])
        print('or: %s one-move [input_file] [output_file] [depth]' % argv[0])
        sys.exit(2)
    game_type, inFile = argv[1:3]

    if not game_type == 'interactive' and not game_type == 'one-move':
        print('Please enter valid game mode')
        sys.exit(2)

    currentGame = maxConnect4Game() # Create a game
    currentGame.depth = int(sys.argv[4])
    # Try to open the input file
    try:
        currentGame.gameFile = open(inFile, 'r')
    except IOError:
        sys.exit("\nError opening input file.\nCheck file name.\n")

    # Read the initial game state from the file and save in a 2D list
    file_lines = currentGame.gameFile.readlines()
    # print 'file lines: ',file_lines
    currentGame.gameBoard = [[int(char) for char in line[0:7]] for line in file_lines[0:-1]]
    # print(currentGame.gameBoard)
    currentGame.currentTurn = int(file_lines[-1][0])
    # print 'current turn: ',currentGame.currentTurn
    currentGame.gameFile.close()

    print('\nMaxConnect-4 game\n')
    print('Board before move:')
    currentGame.printGameBoard()

    currentGame.checkPieceCount()
    currentGame.countScore()
    print('Score: Player 1 = %d, Player 2 = %d\n' % (currentGame.player1Score, currentGame.player2Score))

    if game_type == 'interactive':
        player_turn = sys.argv[3]
        file_not_found = True
        interactiveGame(currentGame,player_turn) # Be sure to pass whatever else you need from the command line
    else:
        outFile = argv[3]
        try:
            currentGame.gameFile = open(outFile, 'w')
        except:
            sys.exit('Error opening output file.')
        oneMoveGame(currentGame) # Be sure to pass any other arguments from the command line you might need.

if __name__ == '__main__':
    main(sys.argv)