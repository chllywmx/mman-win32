
import java.util.*;
import java.io.*;

public class file
{
	String first_city;

	String second_city;

	int distance;

	String get_first_city()
	{
		return first_city;
	}

	String get_second_city()
	{
		return second_city;
	}

	int getdistance()
	{
		return distance;
	}

	

}
