ID: 1002015018
Full Name: Yanamadala NVenkata Satya Sai Sree Lakshmi Deepthi
Part1

Programming Language: Java

Implemented the Graph Search using the Uniform Cost Search Algorithm to find the best route available based on the routes specified in the file. The following functions are employed:

class find_route:
The function Adding_children is used to add the cities and distance information to the array list children if either of the city is source or destination, the function get_distance returns the distance between two cities if either city is a source or destination in the route_found array list, the function print_route prints the path by backtracking the parent node from which we found the optimal path to the destination. In main method i am taking the command line input and calling the various functions.

Class file:
It is used to traverse through the file of routes and extract the name of the cities to check if it is a source_city or destination_city.

Class node:
There are various function to get the information of the city example its cost depth its parent node from which it was explored.

Commnads to run:

Paste all the files in the same folder 
Command1:
javac find_route.java
Command2:
java find_route input1.txt source destination_city
(Use any destination and source city to get optimal path)

Example:
javac find_route.java
java find_route input1.txt Bremen kassel


Command3:
javac find_route.java
Command4:
java find_route input1.txt source destination_city h_kassel.txt
(Use any destination and source city to get optimal path)

Example:
javac find_route.java
java find_route input1.txt Bremen Kassel h_kassel.txt

