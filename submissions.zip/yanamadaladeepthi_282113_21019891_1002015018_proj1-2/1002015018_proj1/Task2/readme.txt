ID: 1002015018
Full Name: Yanamadala NVenkata Satya Sai Sree Lakshmi Deepthi
Part 2

maxconnect4.java: Main java file that is compiled, It takes input and calls other classes.
AIPlayer.java: This file stores the information about a player. It could be a computer or a human player.
GameBoard.java: This file contains the game details like grid and all the functions for nextStep, output the file are written in it.
Info.java: This class stores the current bode and all the successor boards for this current node.
Command to compile code:
javac maxconnect4.java
Command to run the code: 
java maxconnect4 one-move input1.txt output.txt 3

Command to compile code:
javac maxconnect4.java
Command to run the code: 
java maxconnect4 interactive input1.txt computer-next 7