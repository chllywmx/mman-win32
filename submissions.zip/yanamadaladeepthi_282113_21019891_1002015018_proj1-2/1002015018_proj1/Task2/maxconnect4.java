import java.util.Scanner;

public class maxconnect4 {
	public static void main(String[] args) {
		try {
			//check for correct number of arguments
			if(args.length != 4) {
				System.out.println("Four command-line arguments are needed:\n"
									+"Usage: java [program name] interactive [input_file] [computer-next / human-next] [depth]\n"
									+ " or:  java [program name] one-move [input_file] [output_file] [depth]\n");
				exit_function( 0 );
			}
			
			//Process arguments
			String mode_of_Game = args[0].toString(); //specifies interactive or one-move mode
			String connect4_inputFile = args[1].toString(); //name of input game file
			int level_of_depth = Integer.parseInt(args[3]); //depth level of AI depth-limited search
			 	
			//Create game board and AI Player
			GameBoard currentGame_Board = new GameBoard(connect4_inputFile);
			
			//Play specified mode 
			if(mode_of_Game.equalsIgnoreCase("interactive")) {
				String first_Player = args[2].toString();
				Inter_mode(currentGame_Board, first_Player, level_of_depth);
			} else if(mode_of_Game.equalsIgnoreCase("one-move")) {
				String out_file = args[2].toString();
				oneMove_mode(currentGame_Board, out_file, level_of_depth);
			} else {
				System.out.println("ERROR: '" + mode_of_Game + "' is an unsupported game mode! Try again.");
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	private static void Inter_mode(GameBoard currentGame_Board, String first_Player, int level_of_depth) throws Exception {
		int humanNumber; //values on board are either 1 or 2. based on input file and program arguments, player's value will either be 1 or 2
		if(first_Player.equalsIgnoreCase("human-next")) {
			humanNumber = currentGame_Board.getCurrentTurn();
		} else {
			humanNumber = GameBoard.Playes_sum_of_turns - currentGame_Board.getCurrentTurn(); 
		}
		
		AIPlayer ai = new AIPlayer(GameBoard.Playes_sum_of_turns - humanNumber, level_of_depth);
		
		Scanner reader = new Scanner(System.in);
		while(!currentGame_Board.isGameOver()) {
			if(currentGame_Board.getCurrentTurn() == humanNumber) {
				currentGame_Board.print_board();
				System.out.print("Enter column to play (" + currentGame_Board.symbolToString(humanNumber) + "): ");
				try {
					int column = Integer.parseInt(reader.next());
					if(currentGame_Board.isPlayValid(column)) {
						currentGame_Board.playTurn(column);
						currentGame_Board.save_board("human.txt");
					} else {
						System.out.println("\n***ERROR: Invalid move!***");
					}
				} catch(Exception e) {
					System.out.println("\n***ERROR: " + e.getMessage() + "***");
				}
			} else {
				currentGame_Board.print_board();
				currentGame_Board.playTurn(ai.search_For_BestPlay(currentGame_Board));
				currentGame_Board.save_board("computer.txt");
			}
		}
		
		currentGame_Board.print_board();
		System.out.println("The game is over.");
		reader.close();
	}
	
	private static void oneMove_mode(GameBoard currentGame_Board, String out, int limit_depth) throws Exception {
		currentGame_Board.print_board();
		if(!currentGame_Board.isGameOver()) {
			AIPlayer ai = new AIPlayer(currentGame_Board.getCurrentTurn(), limit_depth);
			currentGame_Board.playTurn(ai.search_For_BestPlay(currentGame_Board));
			currentGame_Board.print_board();
		}
		
		currentGame_Board.save_board(out);
	}

   private static void exit_function( int value )
   {
	   System.out.println("exiting from MaxConnectFour.java!\n\n");
	   System.exit( value );
   }
  // end of class connectFour
}
