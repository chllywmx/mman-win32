public class AIPlayer {
	//class member variables
	public int player_turn;
	public int limit_of_depth;
	
	// constructors
	public AIPlayer(){
		//default constructor
	}
	public AIPlayer(int pl, int dp) {
		player_turn = pl;
		limit_of_depth = dp;
	}
	public int search_For_BestPlay(GameBoard board) {
		if(limit_of_depth == 0) { 
			for(int col = 0; col < GameBoard.TOTAL_COLUMNS; col++)
			{
				if(board.isPlayValid(col)) {
					return col;
				}
			}
		}
		
		Info node = new Info(board, 0, -1);
		int bestValue = find_maximum(node, -999999, 999999);
		for(Info next : node.next_nodes ) {
			if(next.value == bestValue)
			{
				return next.current_col;
			}
		}
		
		return -1;
	}
	
	private int find_maximum(Info node, int a, int b) {
		if(node.current_game_board.isGameOver() || node.limit_depth == limit_of_depth) {
			node.value = node.current_game_board.calculatePossibiliy(player_turn);
			return node.value;
		}
		
		int value = -999999;
		node.next_nodes = node.get_Next_Nodes();
		for(Info next : node.next_nodes) {
			value = Math.max(value, find_minimum(next, a, b));
			if(value >= b) {
				node.value = value;
				return value;
			}
			
			a = Math.max(a, value);
		}
		node.value = value;
		return value;
	}
	
	private int find_minimum(Info node, int a, int b) {
		if(node.current_game_board.isGameOver() || node.limit_depth == limit_of_depth) {
			node.value = node.current_game_board.calculatePossibiliy(player_turn);
			return node.value;
		}
		
		int value = 999999;
		node.next_nodes = node.get_Next_Nodes();
		for(Info next : node.next_nodes) {
			value = Math.min(value, find_maximum(next, a, b));
			if(value <= a) {
				node.value = value;
				return value;
			}
			
			b = Math.min(b, value);
		}
		
		node.value = value;
		return value;
	}
}
