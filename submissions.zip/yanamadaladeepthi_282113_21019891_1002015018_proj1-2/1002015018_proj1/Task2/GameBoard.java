import java.io.*;
import java.util.ArrayList;
import java.util.Collections;

public class GameBoard implements Cloneable {
	//Board dimensions
	public static final int TOTAL_ROWS = 6;
	public static final int TOTAL_COLUMNS = 7;
	public static final int Playes_sum_of_turns = 3; 
	
	//Class fields
	private int[][] GAME_board;
	private int whose_turn;
	private int Pieces_Number_Count;
	
	//Constructor
	public GameBoard(String inputFileName) throws Exception {
		GAME_board = new int[TOTAL_ROWS][TOTAL_COLUMNS];
		Pieces_Number_Count = 0;
		BufferedReader input=null;
		
		try {
			//Open input file
			input = new BufferedReader(new FileReader(inputFileName));
			
			//Read game data
			ArrayList<String> add_data = new ArrayList<String>();
			String gameData = null;
			while((gameData = input.readLine()) != null) { 
				add_data.add(gameData); 
			}
			input.close();
			
			//Set GAME_board values
			for(int i = 0; i < TOTAL_ROWS; i++) {
				String currentLine = add_data.get(i);
				
				for(int col = 0; col < TOTAL_COLUMNS; col++) {
					int value = Character.getNumericValue(currentLine.charAt(col));
					
					if(value == 0 || value == 1 || value ==2) {
						GAME_board[i][col] = value;
					} else {
						throw new Exception("Invalid value at block [" + i + ", " + col + "].\n");
					}
					
					if(value != 0) {
						Pieces_Number_Count++;
					}
				}
			}
			
			//Get whose turn it is (last line in data)
			whose_turn = Integer.parseInt(add_data.get(add_data.size() - 1));
			if(whose_turn != 1 && whose_turn != 2) { 
				throw new Exception("Invalid turn value at block.\n"); 
			}
		} catch(Exception e) { 
			whose_turn = 1;
		}
	}
	
	public GameBoard(GameBoard otherGame) {
		whose_turn = otherGame.whose_turn;
		Pieces_Number_Count = otherGame.Pieces_Number_Count;
		GAME_board = new int[TOTAL_ROWS][TOTAL_COLUMNS];
		
		//copy GAME_board
		for(int r = 0; r < TOTAL_ROWS; r++) {
			for(int col = 0; col < TOTAL_COLUMNS; col++)
			{
				this.GAME_board[r][col] = otherGame.GAME_board[r][col];
			}
		}
	}
	
	public int calculateScore(int player) {
		int score = 0;
		
		for(int r = 0; r < TOTAL_ROWS; r++) {
			for(int col = 0; col < TOTAL_COLUMNS; col++) {
				//check horizontal (3 spaces to right of current space)
				if(col + 3 < TOTAL_COLUMNS) {
					if(GAME_board[r][col] == player && GAME_board[r][col+1] == player && GAME_board[r][col+2] == player && GAME_board[r][col+3] == player) {
						score++;
					}
				}
				
				//check vertical (3 spaces down of current space)
				if(r + 3 < TOTAL_ROWS) {
					if(GAME_board[r][col] == player && GAME_board[r+1][col] == player && GAME_board[r+2][col] == player && GAME_board[r+3][col] == player) {
						score++;
					}
				}
				//check diagonal / (3 spaces down and to left of current space)
				if(r + 3 < TOTAL_ROWS && col - 3 >= 0) {
					if(GAME_board[r][col] == player && GAME_board[r + 1][col - 1] == player && GAME_board[r + 2][col - 2] == player && GAME_board[r + 3][col - 3] == player) {
						score++;
					}
				}
				
				//check diagonal \ (3 spaces down and to right of current space)
				if(r + 3 < TOTAL_ROWS && col + 3 < TOTAL_COLUMNS) {
					if(GAME_board[r][col] == player && GAME_board[r + 1][col + 1] == player && GAME_board[r + 2][col + 2] == player && GAME_board[r + 3][col + 3] == player) {
						score++;
					}
				}
			}
		}
		
		return score;
	}
	
	//accounts for completed connect 4s as well as "connect" 1s, 2s, and 3s that have potential to be a connect 4 
	public int calculatePossibiliy(int playerNumber) {
		int utility = 0;
		int enemyNumber = Playes_sum_of_turns - playerNumber; //only options are 1 or 2; if turn is 1, 3 - 1 = 2 and if turn is 2, 3 - 2 = 1
		
		for(int r = 0; r < TOTAL_ROWS; r++) {
			for(int col = 0; col < TOTAL_COLUMNS; col++) {
				ArrayList<Integer> values = new ArrayList<Integer>();
				
				//-----check horizontal (3 spaces to right of current space)------
				if(col + 3 < TOTAL_COLUMNS) {
					values.add(GAME_board[r][col]);
					values.add(GAME_board[r][col+1]);
					values.add(GAME_board[r][col+2]);
					values.add(GAME_board[r][col+3]);
					
					utility = updateUtility(utility, values, playerNumber, enemyNumber);
				}
				
				//check vertical (3 spaces down of current space)
				if(r + 3 < TOTAL_ROWS) {
					values.clear();
					values.add(GAME_board[r][col]);
					values.add(GAME_board[r+1][col]);
					values.add(GAME_board[r+2][col]);
					values.add(GAME_board[r+3][col]);
					
					utility = updateUtility(utility, values, playerNumber, enemyNumber);
				}
				//check diagonal / (3 spaces down and to left of current space)
				if(r + 3 < TOTAL_ROWS && col - 3 >= 0) {
					values.clear();
					values.add(GAME_board[r][col]);
					values.add(GAME_board[r+1][col-1]);
					values.add(GAME_board[r+2][col-2]);
					values.add(GAME_board[r+3][col-3]);
					
					utility = updateUtility(utility, values, playerNumber, enemyNumber);
				}
				
				//check diagonal \ (3 spaces down and to right of current space)
				if(r + 3 < TOTAL_ROWS && col + 3 < TOTAL_COLUMNS) {
					values.clear();
					values.add(GAME_board[r][col]);
					values.add(GAME_board[r+1][col+1]);
					values.add(GAME_board[r+2][col+2]);
					values.add(GAME_board[r+3][col+3]);
				
					utility = updateUtility(utility, values, playerNumber, enemyNumber);
				}
			}	
		}
		return utility;
	}
	
	private int updateUtility(int utility, ArrayList<Integer> values, int playerNumber, int enemyNumber) {
		if(!values.contains(enemyNumber)) //if only contains player chips or empty space, contains connect 4 or possible connect 4
		{
			int count = Collections.frequency(values, playerNumber);
			switch(count) {
			case 1:
				utility += 1;
				break;
			case 2:
				utility += 10;
				break;
			case 3:
				utility += 25;
				break;
			case 4:
				utility += 100;
				break;
			}
		} else if(!values.contains(playerNumber)) { //if only contains enemy chips or empty space, contains connect 4 or possible connect 4
			int count = Collections.frequency(values, enemyNumber);
			switch(count) {
			case 1:
				utility -= 1;
				break;
			case 2:
				utility -= 10;
				break;
			case 3:
				utility -= 25;
				break;
			case 4:
				utility -= 100;
				break;
			}
		}
		
		return utility;
	}
	
	public int getCurrentTurn() {
		return whose_turn;
	}
	
	public int getNumPieces() {
		return Pieces_Number_Count;
	}
	
	public int[][] getBoard() {
		return GAME_board;
	}
	
	public boolean isPlayValid(int column) {
		//return true if column if within bounds and column is not full (top space of column is empty)
		return ((0 <= column && column < TOTAL_COLUMNS) && GAME_board[0][column] == 0);
	}
	
	public void playTurn(int col) {
		for(int r = TOTAL_ROWS - 1; r >= 0; r--) {
			if(GAME_board[r][col] == 0) {
				GAME_board[r][col] = whose_turn;
				Pieces_Number_Count++;
				nextTurn();
				break;
			}
		}
	}
	
	public void print_board() {
		//print divider line
		System.out.println("_________________________");
		//print first line with column indicator numbers
		String indexsLine = "";
		for(int y = 0; y < TOTAL_COLUMNS; y++) {
			indexsLine += " " + String.valueOf(y); 
		} 
		System.out.println(indexsLine);
		
		//print GAME_board
		for(int[] i : GAME_board) {
			String line = "|";
			for(int num : i) {
				line += symbolToString(num);
				line += "|";
			}
			
			System.out.println(line);
		}
		
		//print scores
		System.out.println(symbolToString(1) + " Score: " + String.valueOf(calculateScore(1)));
		System.out.println(symbolToString(2) + " Score: " + String.valueOf(calculateScore(2)));
	}
	
	public void save_board(String file) throws Exception {
		//open output file
		BufferedWriter output = new BufferedWriter(new FileWriter(file));
		
		//save GAME_board
		for(int[] i : GAME_board) {
			for(int n : i) {
				output.write(String.valueOf(n));
			}
			output.newLine();
		}
		
		//save next turn
		output.write(String.valueOf(whose_turn));
		
		//close output file
		output.close();
	}
	
	public boolean isGameOver() {
		return (getNumPieces() == TOTAL_ROWS * TOTAL_COLUMNS);
	}
	
	public String symbolToString(int turn) {
		String result;
		switch(turn) {
		case 0: //blank space for empty space
			result = "-";
			break;
		case 1:
			result = "X";
			break;
		case 2:
			result = "O";
			break;
		default:
			result = "e"; //e for error
		}
		
		return result;
	}
	
	private void nextTurn() {
		if(whose_turn == 1) {
			whose_turn = 2;
		} else {
			whose_turn = 1;
		}
	}
}
