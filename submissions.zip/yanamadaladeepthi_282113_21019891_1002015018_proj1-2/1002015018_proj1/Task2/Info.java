import java.util.ArrayList;

public class Info {
	//class fields
	public GameBoard current_game_board;
	public int limit_depth;
	public int current_col; //the col that was played to get to this node
	public int value;
	public ArrayList<Info> next_nodes;
	
	//constructor
	public Info(GameBoard game, int depth, int col) {
		current_game_board = game;
		limit_depth = depth;
		current_col = col;
	}
	
	public ArrayList<Info> get_Next_Nodes() {
		ArrayList<Info> inheritors = new ArrayList<Info>();
		for(int col = 0; col < GameBoard.TOTAL_COLUMNS; col++) {
			if(current_game_board.isPlayValid(col)) {
				GameBoard tempGame = new GameBoard(current_game_board);
				tempGame.playTurn(col);
				inheritors.add(new Info(tempGame, limit_depth+1, col));
			}
		}
		
		return inheritors;
	}
}
